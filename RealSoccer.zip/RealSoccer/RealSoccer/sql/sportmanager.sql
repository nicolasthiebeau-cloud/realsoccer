-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mar 10 Novembre 2009 à 21:45
-- Version du serveur: 5.1.36
-- Version de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `sportmanager`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin_info`
--

CREATE TABLE IF NOT EXISTS `admin_info` (
  `adinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` int(10) NOT NULL,
  `ch_1` int(11) NOT NULL,
  `ch_2` int(11) NOT NULL,
  `ch_3` int(11) NOT NULL,
  `ch_4` int(11) NOT NULL,
  `ch_5` int(11) NOT NULL,
  `mode` tinyint(2) NOT NULL,
  `url` tinyint(2) NOT NULL,
  PRIMARY KEY (`adinfo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `admin_info`
--


-- --------------------------------------------------------

--
-- Structure de la table `automatisation`
--

CREATE TABLE IF NOT EXISTS `automatisation` (
  `auto_id` int(11) NOT NULL AUTO_INCREMENT,
  `auto_type` varchar(128) NOT NULL,
  `auto_date` date NOT NULL,
  PRIMARY KEY (`auto_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `automatisation`
--


-- --------------------------------------------------------

--
-- Structure de la table `classement`
--

CREATE TABLE IF NOT EXISTS `classement` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `compet_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `saison_nbr` tinyint(2) NOT NULL,
  `classement` tinyint(2) NOT NULL,
  `MJ` tinyint(2) NOT NULL,
  `V` tinyint(2) NOT NULL,
  `N` tinyint(2) NOT NULL,
  `D` tinyint(2) NOT NULL,
  `BP` int(3) NOT NULL,
  `BC` int(3) NOT NULL,
  `point` int(3) NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `classement`
--


-- --------------------------------------------------------

--
-- Structure de la table `classement_joueur`
--

CREATE TABLE IF NOT EXISTS `classement_joueur` (
  `classj_id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `compet_id` int(11) NOT NULL,
  `saison_nbr` tinyint(3) NOT NULL,
  `champ_sel` tinyint(3) NOT NULL DEFAULT '0',
  `champ_but` tinyint(3) NOT NULL DEFAULT '0',
  `champ_pasdec` tinyint(3) NOT NULL DEFAULT '0',
  `champ_cjaune` tinyint(3) NOT NULL DEFAULT '0',
  `champ_crouge` tinyint(3) NOT NULL DEFAULT '0',
  `cupnat_sel` tinyint(3) NOT NULL DEFAULT '0',
  `cupnat_but` tinyint(3) NOT NULL DEFAULT '0',
  `cupnat_pasdec` tinyint(3) NOT NULL DEFAULT '0',
  `cupnat_cjaune` tinyint(3) NOT NULL DEFAULT '0',
  `cupnat_crouge` tinyint(3) NOT NULL DEFAULT '0',
  `hcomp_sel` tinyint(3) NOT NULL DEFAULT '0',
  `hcomp_but` tinyint(3) NOT NULL DEFAULT '0',
  `hcomp_pasdec` tinyint(3) NOT NULL DEFAULT '0',
  `hcomp_cjaune` tinyint(3) NOT NULL DEFAULT '0',
  `hcomp_crouge` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`classj_id`),
  KEY `champ_sel` (`champ_sel`,`champ_but`,`champ_pasdec`,`champ_cjaune`,`champ_crouge`,`cupnat_sel`,`cupnat_but`,`cupnat_pasdec`,`cupnat_cjaune`,`cupnat_crouge`,`hcomp_sel`,`hcomp_but`,`hcomp_pasdec`,`hcomp_cjaune`,`hcomp_crouge`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `classement_joueur`
--


-- --------------------------------------------------------

--
-- Structure de la table `competition`
--

CREATE TABLE IF NOT EXISTS `competition` (
  `compet_id` int(11) NOT NULL AUTO_INCREMENT,
  `pays_id` int(11) NOT NULL,
  `compet_name` varchar(256) DEFAULT NULL,
  `division` int(5) NOT NULL,
  `poule` int(3) NOT NULL,
  `nb_equipe` tinyint(2) NOT NULL DEFAULT '0',
  `nb_equipe_fictive` tinyint(2) NOT NULL DEFAULT '10',
  `max_equipe` tinyint(2) NOT NULL DEFAULT '10',
  `compet_history` text,
  PRIMARY KEY (`compet_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `competition`
--


-- --------------------------------------------------------

--
-- Structure de la table `competition_cup`
--

CREATE TABLE IF NOT EXISTS `competition_cup` (
  `cup_id` int(11) NOT NULL AUTO_INCREMENT,
  `pays_id` int(11) NOT NULL,
  `cup_name` varchar(128) NOT NULL,
  PRIMARY KEY (`cup_id`),
  KEY `pays_id` (`pays_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `competition_cup`
--


-- --------------------------------------------------------

--
-- Structure de la table `comptes`
--

CREATE TABLE IF NOT EXISTS `comptes` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(30) NOT NULL,
  `mdp` varchar(32) NOT NULL DEFAULT 'efcf586d1e7dabd0f36951c3b5922293',
  `email` varchar(75) NOT NULL,
  `lang` varchar(8) NOT NULL DEFAULT 'fr',
  `lang_other` varchar(256) DEFAULT NULL,
  `rang` tinyint(2) NOT NULL DEFAULT '0',
  `coach_name` varchar(255) NOT NULL,
  `joindate` int(10) DEFAULT NULL,
  `joinip` varchar(15) NOT NULL,
  `lastlogin` int(10) DEFAULT NULL,
  `lastip` varchar(15) NOT NULL,
  `canal_choice` int(5) NOT NULL DEFAULT '1',
  `dateformat_choice` varchar(6) NOT NULL DEFAULT 'd-m-Y',
  `timeformat_choice` varchar(6) NOT NULL DEFAULT 'H:i',
  `membre_msn` varchar(250) NOT NULL,
  `membre_siteweb` varchar(100) NOT NULL,
  `membre_avatar` varchar(100) NOT NULL,
  `membre_signature` varchar(200) NOT NULL,
  `membre_localisation` varchar(100) NOT NULL,
  `membre_inscrit` int(11) NOT NULL,
  `membre_derniere_visite` int(11) NOT NULL,
  `membre_post` int(11) NOT NULL,
  `ban_raison` text NOT NULL,
  PRIMARY KEY (`account_id`),
  KEY `canal_choice` (`canal_choice`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `comptes`
--

INSERT INTO `comptes` (`account_id`, `pseudo`, `mdp`, `email`, `lang`, `lang_other`, `rang`, `coach_name`, `joindate`, `joinip`, `lastlogin`, `lastip`, `canal_choice`, `dateformat_choice`, `timeformat_choice`, `membre_msn`, `membre_siteweb`, `membre_avatar`, `membre_signature`, `membre_localisation`, `membre_inscrit`, `membre_derniere_visite`, `membre_post`, `ban_raison`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@admin.com', 'Francais', '', 5, 'Admin', 1256993306, '127.0.0.1', 1257866742, '127.0.0.1', 1, 'd-m-Y', 'H:i', '', '', '', '', '', 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Structure de la table `configuration`
--

CREATE TABLE IF NOT EXISTS `configuration` (
  `config_name` varchar(64) NOT NULL,
  `config_value` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `configuration`
--

INSERT INTO `configuration` (`config_name`, `config_value`) VALUES
('smos_version', '0.8.4'),
('rang_0', 'Banni'),
('rang_1', 'Membre'),
('rang_2', 'Donateur'),
('rang_3', 'Modérateur'),
('rang_4', 'Inspecteur'),
('rang_5', 'Administrateur'),
('stop_inscription', '1'),
('team_shirt_dom', '00_cl2.png'),
('team_shirt_ext', '11_cl2.png'),
('team_money', '100000'),
('stade_infra', '1;9;3;4;5;6;7;8'),
('formationcenter', '0'),
('trainingcenter', '1'),
('place_debout', '10'),
('place_assise', '15'),
('place_debout_couverte', '15'),
('place_assise_couverte', '20'),
('tribune_presidentielle', '50'),
('buvette', '3'),
('nom_stade', '5000'),
('nom_tribune', '5000'),
('note_pri_min', '10'),
('note_pri_max', '15'),
('note_sec_min', '5'),
('note_sec_max', '10'),
('note_age_min', '17'),
('note_age_max', '30'),
('note_tll_min', '150'),
('note_tll_max', '210'),
('salaire_multiple', '50'),
('jourdevente', '2'),
('expulsion_penalite', '10'),
('training_day', '3'),
('salaire_day', '1'),
('recette_day', '2'),
('minuteplay', '60'),
('note_tal_min', '20'),
('note_tal_max', '60'),
('note_pres_min', '0'),
('note_pres_max', '100'),
('cf_achat_joueur', '5000'),
('cf_age_min', '14'),
('cf_age_max', '16'),
('cf_salaire_jeune', '1000'),
('upload_dir', 'c:/wamp/www/SMOS/upload/'),
('suspension', '2'),
('decal_time', '1');

-- --------------------------------------------------------

--
-- Structure de la table `equipes`
--

CREATE TABLE IF NOT EXISTS `equipes` (
  `team_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) DEFAULT NULL,
  `compet_id` int(11) NOT NULL,
  `team_name` varchar(128) NOT NULL,
  `team_country` int(5) NOT NULL DEFAULT '0',
  `team_region` int(5) NOT NULL,
  `team_devise` varchar(128) DEFAULT NULL,
  `fanion` varchar(256) DEFAULT NULL,
  `fanion_valid` tinyint(1) NOT NULL DEFAULT '0',
  `team_shirt_dom` varchar(16) NOT NULL DEFAULT '00_cl1.png',
  `team_shirt_ext` varchar(16) NOT NULL DEFAULT '11_cl1.png',
  `team_money` int(15) NOT NULL DEFAULT '100000',
  `formationcenter` tinyint(2) NOT NULL DEFAULT '0',
  `trainingcenter` tinyint(2) NOT NULL DEFAULT '1',
  `training_choice` tinyint(2) NOT NULL DEFAULT '0',
  `stade_name` text NOT NULL,
  `stade_infra` text NOT NULL,
  `sponsor_id` int(11) NOT NULL DEFAULT '0',
  `team_cup` text NOT NULL,
  `team_history` text NOT NULL,
  `fictive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`team_id`),
  KEY `account_id` (`account_id`),
  KEY `team_country` (`team_country`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `equipes`
--


-- --------------------------------------------------------

--
-- Structure de la table `equipes_mess_interne`
--

CREATE TABLE IF NOT EXISTS `equipes_mess_interne` (
  `team_id` int(11) NOT NULL,
  `date` int(10) NOT NULL,
  `ch_1` varchar(16) NOT NULL,
  `ch_2` varchar(16) NOT NULL,
  `ch_3` varchar(16) NOT NULL,
  `ch_4` varchar(16) NOT NULL,
  `ch_5` varchar(16) NOT NULL,
  `mode` tinyint(2) NOT NULL,
  `url` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `equipes_mess_interne`
--


-- --------------------------------------------------------

--
-- Structure de la table `forum_categorie`
--

CREATE TABLE IF NOT EXISTS `forum_categorie` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_nom` varchar(30) NOT NULL,
  `cat_ordre` int(11) NOT NULL,
  PRIMARY KEY (`cat_id`),
  UNIQUE KEY `cat_ordre` (`cat_ordre`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `forum_categorie`
--


-- --------------------------------------------------------

--
-- Structure de la table `forum_config`
--

CREATE TABLE IF NOT EXISTS `forum_config` (
  `config_nom` varchar(200) NOT NULL,
  `config_valeur` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `forum_config`
--


-- --------------------------------------------------------

--
-- Structure de la table `forum_forum`
--

CREATE TABLE IF NOT EXISTS `forum_forum` (
  `forum_id` int(11) NOT NULL AUTO_INCREMENT,
  `forum_cat_id` mediumint(8) NOT NULL,
  `forum_name` varchar(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `forum_desc` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `forum_ordre` mediumint(8) NOT NULL,
  `forum_last_post_id` int(11) NOT NULL,
  `forum_topic` mediumint(8) NOT NULL,
  `forum_post` mediumint(8) NOT NULL,
  `auth_view` tinyint(4) NOT NULL,
  `auth_post` tinyint(4) NOT NULL,
  `auth_topic` tinyint(4) NOT NULL,
  `auth_annonce` tinyint(4) NOT NULL,
  `auth_modo` tinyint(4) NOT NULL,
  PRIMARY KEY (`forum_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `forum_forum`
--


-- --------------------------------------------------------

--
-- Structure de la table `forum_post`
--

CREATE TABLE IF NOT EXISTS `forum_post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_createur` int(11) NOT NULL,
  `post_texte` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `post_time` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `post_forum_id` int(11) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `forum_post`
--


-- --------------------------------------------------------

--
-- Structure de la table `forum_topic`
--

CREATE TABLE IF NOT EXISTS `forum_topic` (
  `topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `forum_id` int(11) NOT NULL,
  `topic_titre` char(60) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `topic_createur` int(11) NOT NULL,
  `topic_vu` mediumint(8) NOT NULL,
  `topic_time` int(11) NOT NULL,
  `topic_genre` varchar(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `topic_last_post` int(11) NOT NULL,
  `topic_first_post` int(11) NOT NULL,
  `topic_post` mediumint(8) NOT NULL,
  `topic_locked` int(4) NOT NULL,
  PRIMARY KEY (`topic_id`),
  UNIQUE KEY `topic_last_post` (`topic_last_post`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `forum_topic`
--


-- --------------------------------------------------------

--
-- Structure de la table `joueurs`
--

CREATE TABLE IF NOT EXISTS `joueurs` (
  `player_id` int(15) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `photo_valid` tinyint(1) NOT NULL DEFAULT '0',
  `nom` varchar(32) NOT NULL,
  `surnom` varchar(32) NOT NULL,
  `prenom` varchar(32) NOT NULL,
  `age` tinyint(2) NOT NULL,
  `taille` int(3) NOT NULL DEFAULT '175',
  `position` tinyint(2) NOT NULL,
  `nationalite` int(11) NOT NULL,
  `forme` varchar(6) NOT NULL DEFAULT '100',
  `moral` varchar(6) NOT NULL DEFAULT '100',
  `talent` tinyint(3) NOT NULL DEFAULT '50',
  `pression` tinyint(3) NOT NULL DEFAULT '50',
  `experience` tinyint(2) NOT NULL DEFAULT '0',
  `influence` varchar(6) NOT NULL,
  `agressivite` tinyint(2) NOT NULL DEFAULT '10',
  `reflexes` varchar(6) NOT NULL,
  `pdballe` varchar(6) NOT NULL,
  `degagement` varchar(6) NOT NULL,
  `marquage` varchar(6) NOT NULL,
  `tacles` varchar(6) NOT NULL,
  `tete` varchar(6) NOT NULL,
  `centres` varchar(6) NOT NULL,
  `passes` varchar(6) NOT NULL,
  `vitesse` varchar(6) NOT NULL,
  `tir` varchar(6) NOT NULL,
  `creativite` varchar(6) NOT NULL,
  `dribble` varchar(6) NOT NULL,
  `cdp_arrete` varchar(6) NOT NULL,
  `salaire` int(10) NOT NULL,
  `trainsolo_choice` tinyint(2) NOT NULL DEFAULT '0',
  `statut` tinyint(1) NOT NULL DEFAULT '0',
  `ldtransfert` tinyint(1) NOT NULL DEFAULT '0',
  `indisponible` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`),
  KEY `team_id` (`team_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `joueurs`
--


-- --------------------------------------------------------

--
-- Structure de la table `joueurs_achat_demande`
--

CREATE TABLE IF NOT EXISTS `joueurs_achat_demande` (
  `dmd_id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) NOT NULL,
  `team_dmd` int(11) NOT NULL,
  `new_price` int(11) NOT NULL,
  `team_accept` int(11) NOT NULL,
  PRIMARY KEY (`dmd_id`),
  KEY `player_id` (`player_id`,`team_dmd`,`team_accept`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `joueurs_achat_demande`
--


-- --------------------------------------------------------

--
-- Structure de la table `joueurs_estimation`
--

CREATE TABLE IF NOT EXISTS `joueurs_estimation` (
  `note_1` tinyint(3) NOT NULL,
  `note_2` tinyint(3) NOT NULL,
  `note_3` tinyint(3) NOT NULL,
  `note_4` tinyint(3) NOT NULL,
  `valeur` int(10) NOT NULL,
  KEY `note_1` (`note_1`,`note_2`,`note_3`,`note_4`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `joueurs_estimation`
--


-- --------------------------------------------------------

--
-- Structure de la table `joueurs_historique`
--

CREATE TABLE IF NOT EXISTS `joueurs_historique` (
  `player_id` int(11) NOT NULL,
  `transfert` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `joueurs_historique`
--


-- --------------------------------------------------------

--
-- Structure de la table `joueurs_position`
--

CREATE TABLE IF NOT EXISTS `joueurs_position` (
  `pos_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` tinyint(2) NOT NULL,
  `pos_name` varchar(32) NOT NULL,
  `pos_shortname` varchar(8) NOT NULL,
  `position` tinyint(2) NOT NULL,
  PRIMARY KEY (`pos_id`),
  KEY `position` (`position`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `joueurs_position`
--

INSERT INTO `joueurs_position` (`pos_id`, `group_id`, `pos_name`, `pos_shortname`, `position`) VALUES
(1, 1, 'Gardien', 'GB', 1),
(2, 2, 'Défenseur', 'DC', 2),
(3, 3, 'Milieu', 'MC', 3),
(4, 4, 'Attaquant', 'AC', 4);

-- --------------------------------------------------------

--
-- Structure de la table `joueurs_suivi`
--

CREATE TABLE IF NOT EXISTS `joueurs_suivi` (
  `account_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `ltra_id` int(11) NOT NULL,
  `type` varchar(64) NOT NULL,
  KEY `account_id` (`account_id`,`player_id`,`ltra_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `joueurs_suivi`
--


-- --------------------------------------------------------

--
-- Structure de la table `journal`
--

CREATE TABLE IF NOT EXISTS `journal` (
  `journal_id` int(11) NOT NULL AUTO_INCREMENT,
  `pays` int(11) NOT NULL,
  `region` int(11) NOT NULL,
  `titre` varchar(128) CHARACTER SET utf8 NOT NULL,
  `corp` text CHARACTER SET utf8 NOT NULL,
  `auteur` int(11) NOT NULL,
  `creanews` int(10) NOT NULL,
  PRIMARY KEY (`journal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `journal`
--


-- --------------------------------------------------------

--
-- Structure de la table `matchs`
--

CREATE TABLE IF NOT EXISTS `matchs` (
  `renco_id` int(11) NOT NULL AUTO_INCREMENT,
  `saison_nbr` tinyint(2) NOT NULL,
  `compet_id` int(11) NOT NULL DEFAULT '0',
  `cup_id` int(11) NOT NULL DEFAULT '0',
  `timematch` int(10) NOT NULL,
  `journee` tinyint(10) DEFAULT NULL,
  `team_id1` int(11) NOT NULL,
  `team_id2` int(11) NOT NULL,
  `score1` varchar(2) NOT NULL,
  `score2` varchar(2) NOT NULL,
  `matchinfo` text,
  `compoinfo` text,
  `eq1_info` text,
  `eq2_info` text,
  `commentinfo` text,
  `renco_type` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`renco_id`),
  KEY `renco_type` (`renco_type`),
  KEY `cup_id` (`cup_id`),
  KEY `renco_id` (`renco_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `matchs`
--


-- --------------------------------------------------------

--
-- Structure de la table `matchs_amical_demande`
--

CREATE TABLE IF NOT EXISTS `matchs_amical_demande` (
  `dmd_id` int(11) NOT NULL AUTO_INCREMENT,
  `timematch` int(10) NOT NULL,
  `team_dom` int(11) NOT NULL,
  `team_ext` int(11) NOT NULL,
  `team_dmd` int(11) NOT NULL,
  `team_accept` int(11) NOT NULL,
  `detail` text NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`dmd_id`),
  KEY `team_dom` (`team_dom`,`team_ext`),
  KEY `team_accept` (`team_accept`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `matchs_amical_demande`
--


-- --------------------------------------------------------

--
-- Structure de la table `matchs_encours`
--

CREATE TABLE IF NOT EXISTS `matchs_encours` (
  `match_id` int(11) NOT NULL AUTO_INCREMENT,
  `renco_id` int(11) NOT NULL,
  `compet_id` int(11) NOT NULL DEFAULT '0',
  `timematch_dep` int(10) NOT NULL,
  `match_min` int(3) NOT NULL DEFAULT '1',
  `match_adj` tinyint(1) NOT NULL DEFAULT '1',
  `combien_adj` tinyint(1) NOT NULL DEFAULT '0',
  `id_team1` int(11) NOT NULL,
  `id_team2` int(11) NOT NULL,
  `joueur_eq1` text NOT NULL,
  `joueur_eq2` text NOT NULL,
  `note_eq1` int(5) NOT NULL,
  `note_eq2` int(5) NOT NULL,
  `carton_jaune` text NOT NULL,
  `carton_rouge` text NOT NULL,
  `expulsion` text NOT NULL,
  `blesse` text NOT NULL,
  PRIMARY KEY (`match_id`),
  KEY `renco_id` (`renco_id`),
  KEY `compet_id` (`compet_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=48 ;

--
-- Contenu de la table `matchs_encours`
--


-- --------------------------------------------------------

--
-- Structure de la table `messagerie`
--

CREATE TABLE IF NOT EXISTS `messagerie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sujet` varchar(255) NOT NULL,
  `expediteur` varchar(255) NOT NULL,
  `destinataire` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `timestamp` bigint(20) NOT NULL DEFAULT '0',
  `vu` enum('0','1') NOT NULL DEFAULT '0',
  `efface` enum('0','1','2') NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `messagerie`
--


-- --------------------------------------------------------

--
-- Structure de la table `minichat`
--

CREATE TABLE IF NOT EXISTS `minichat` (
  `mnc_id` int(11) NOT NULL AUTO_INCREMENT,
  `mnc_time` int(10) NOT NULL,
  `account_id` int(11) NOT NULL,
  `texte` text NOT NULL,
  `canal` int(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`mnc_id`),
  KEY `account_id` (`account_id`),
  KEY `canal` (`canal`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `minichat`
--


-- --------------------------------------------------------

--
-- Structure de la table `minichat_canal`
--

CREATE TABLE IF NOT EXISTS `minichat_canal` (
  `canal_id` int(5) NOT NULL,
  `canal_name` varchar(64) NOT NULL,
  `position` int(5) NOT NULL,
  PRIMARY KEY (`canal_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Contenu de la table `minichat_canal`
--

INSERT INTO `minichat_canal` (`canal_id`, `canal_name`, `position`) VALUES
(1, 'Francophone', 2),
(2, 'International', 1),
(3, 'English', 3);

-- --------------------------------------------------------

--
-- Structure de la table `pays`
--

CREATE TABLE IF NOT EXISTS `pays` (
  `pays_id` int(11) NOT NULL AUTO_INCREMENT,
  `pays_name` varchar(128) NOT NULL,
  `pays_champ` varchar(128) NOT NULL,
  `pays_zone` int(3) NOT NULL,
  `pays_file_nom` varchar(32) DEFAULT NULL,
  `pays_file_prenom` varchar(32) DEFAULT NULL,
  `pays_flag` varchar(32) NOT NULL,
  `pays_money` varchar(64) NOT NULL,
  `pays_select` tinyint(1) NOT NULL DEFAULT '0',
  `pays_actif` tinyint(1) NOT NULL DEFAULT '0',
  `config_nbteam_perchamp` tinyint(2) NOT NULL DEFAULT '10',
  `config_heurematch` varchar(8) NOT NULL DEFAULT '20:00',
  `config_tpsentre2match` tinyint(2) NOT NULL DEFAULT '2',
  `pays_classement` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pays_id`),
  KEY `config_nbteam_perchamp` (`config_nbteam_perchamp`,`config_heurematch`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=202 ;

--
-- Contenu de la table `pays`
--

INSERT INTO `pays` (`pays_id`, `pays_name`, `pays_champ`, `pays_zone`, `pays_file_nom`, `pays_file_prenom`, `pays_flag`, `pays_money`, `pays_select`, `pays_actif`, `config_nbteam_perchamp`, `config_heurematch`, `config_tpsentre2match`, `pays_classement`) VALUES
(1, 'France', 'Championnat de France', 999, 'nom_france.txt', 'prenom_france.txt', 'fra.gif', 'Euro', 1, 1, 10, '20:00', 2, 0),
(2, 'Angleterre', 'English Championship', 998, 'nom_uk-us.txt', 'prenom_uk-us.txt', 'eng.gif', 'Livres', 1, 1, 10, '20:00', 3, 0),
(3, 'Espagne', 'Liga Española', 997, 'nom_espagne.txt', 'prenom_espagne.txt', 'esp.gif', 'Euro', 1, 1, 10, '20:00', 3, 0),
(4, 'Italie', 'Campionato Italiano', 997, 'nom_italie.txt', 'prenom_italie.txt', 'ita.gif', 'Euro', 1, 1, 10, '20:00', 3, 0),
(5, 'Albanie', '', 997, NULL, NULL, 'alb.gif', 'Leke', 0, 0, 10, '20:00', 2, 0),
(6, 'Andorre', '', 997, 'nom_espagne.txt', 'prenom_espagne.txt', 'and.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(7, 'Arménie', '', 995, NULL, NULL, 'arm.gif', '', 0, 0, 10, '20:00', 2, 0),
(8, 'Autriche', '', 999, 'nom_autriche.txt', NULL, 'aus.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(9, 'Azerbaïdjan', '', 995, NULL, NULL, 'aze.gif', '', 0, 0, 10, '20:00', 2, 0),
(10, 'Belgique', 'Championnat de Belgique', 999, 'nom_belgique.txt', 'prenom_france.txt', 'bel.gif', 'Euro', 1, 1, 10, '20:00', 3, 0),
(11, 'Bélarus', '', 996, NULL, NULL, 'blr.gif', '', 0, 0, 10, '20:00', 2, 0),
(12, 'Bosnie-Herzégovine', '', 997, 'nom_bosnie.txt', NULL, 'bos.gif', '', 0, 0, 10, '20:00', 2, 0),
(13, 'Bulgarie', '', 996, NULL, NULL, 'bul.gif', 'Leva', 0, 0, 10, '20:00', 2, 0),
(14, 'Croatie', '', 997, NULL, NULL, 'cro.gif', 'Kuna', 0, 0, 10, '20:00', 2, 0),
(15, 'Chypre', '', 995, NULL, NULL, 'cyp.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(16, 'République tchèque', '', 996, 'nom_tchequie.txt', NULL, 'cze.gif', 'Koruny', 0, 0, 10, '20:00', 2, 0),
(17, 'Danemark', '', 998, 'nom_danemark.txt', NULL, 'den.gif', 'Couronne', 0, 0, 10, '20:00', 2, 0),
(18, 'Estonie', '', 998, NULL, NULL, 'est.gif', 'Krooni', 0, 0, 10, '20:00', 2, 0),
(19, 'Finlande', '', 998, 'nom_finlande.txt', NULL, 'fin.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(20, 'Géorgie', '', 995, NULL, NULL, 'geo.gif', '', 0, 0, 10, '20:00', 2, 0),
(21, 'Allemagne', 'Deutsche Meisterschaft', 999, 'nom_allemagne.txt', NULL, 'ger.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(22, 'Grèce', '', 997, 'nom_grece.txt', NULL, 'gre.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(23, 'Hongrie', '', 996, NULL, NULL, 'hun.gif', '', 0, 0, 10, '20:00', 2, 0),
(24, 'Islande', '', 998, NULL, NULL, 'isl.gif', 'Couronne', 0, 0, 10, '20:00', 2, 0),
(25, 'République d’Irlande', 'Irish League', 998, 'nom_uk-us.txt', 'prenom_uk-us.txt', 'irl.gif', 'Euro', 1, 0, 10, '20:00', 2, 0),
(26, 'Kazakhstan', '', 995, NULL, NULL, 'kaz.gif', '', 0, 0, 10, '20:00', 2, 0),
(27, 'Lettonie', '', 998, NULL, NULL, 'lat.gif', '', 0, 0, 10, '20:00', 2, 0),
(28, 'Lituanie', '', 998, NULL, NULL, 'lit.gif', '', 0, 0, 10, '20:00', 2, 0),
(29, 'Luxembourg', 'Championnat du Luxembourg', 999, 'nom_france.txt', 'prenom_france.txt', 'lux.gif', 'Euro', 1, 0, 10, '20:00', 2, 0),
(30, 'Macédoine', '', 997, NULL, NULL, 'mac.gif', '', 0, 0, 10, '20:00', 2, 0),
(31, 'Malte', '', 997, NULL, NULL, 'mal.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(32, 'Moldavie', '', 996, NULL, NULL, 'mol.gif', '', 0, 0, 10, '20:00', 2, 0),
(33, 'Pays-Bas', '', 999, NULL, NULL, 'ned.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(34, 'Norvège', '', 998, NULL, NULL, 'nor.gif', '', 0, 0, 10, '20:00', 2, 0),
(35, 'Pologne', '', 996, 'nom_pologne.txt', 'prenom_pologne.txt', 'pol.gif', '', 1, 0, 10, '20:00', 2, 0),
(36, 'Portugal', 'Liga Portuguesa', 997, 'nom_portugal.txt', NULL, 'por.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(37, 'Roumanie', '', 996, 'nom_roumanie.txt', NULL, 'rom.gif', '', 0, 0, 10, '20:00', 2, 0),
(38, 'Russie', '', 995, 'nom_russie.txt', NULL, 'rus.gif', '', 0, 0, 10, '20:00', 2, 0),
(39, 'Ecosse', 'Scottish League', 998, 'nom_uk-us.txt', 'prenom_uk-us.txt', 'sco.gif', '', 1, 0, 10, '20:00', 2, 0),
(40, 'Slovaquie', '', 996, 'nom_slovaquie.txt', NULL, 'slk.gif', '', 0, 0, 10, '20:00', 2, 0),
(41, 'Slovénie', '', 997, NULL, NULL, 'slo.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(42, 'Suède', '', 998, NULL, NULL, 'swe.gif', '', 0, 0, 10, '20:00', 2, 0),
(43, 'Suisse', 'Championnat de Suisse', 999, 'nom_france.txt', 'prenom_france.txt', 'swi.gif', '', 1, 0, 10, '20:00', 2, 0),
(44, 'Turquie', '', 995, NULL, NULL, 'tur.gif', '', 0, 0, 10, '20:00', 2, 0),
(45, 'Ukraine', '', 996, NULL, NULL, 'ukr.gif', '', 0, 0, 10, '20:00', 2, 0),
(46, 'Pays de Galles', '', 998, NULL, NULL, 'wal.gif', '', 0, 0, 10, '20:00', 2, 0),
(47, 'Îles Féroé', '', 998, NULL, NULL, 'fer.gif', '', 0, 0, 10, '20:00', 2, 0),
(48, 'Serbie', '', 997, 'nom_serbie.txt', 'prenom_serbie.txt', 'ser.gif', '', 1, 0, 10, '20:00', 2, 0),
(49, 'San Marin', '', 997, NULL, NULL, 'sma.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(50, 'Monténégro', '', 997, 'nom_serbie.txt', 'prenom_serbie.txt', 'mon.gif', '', 1, 0, 10, '20:00', 2, 0),
(51, 'Liechtenstein', '', 999, NULL, NULL, 'lie.gif', 'Euro', 0, 0, 10, '20:00', 2, 0),
(52, 'Irlande du Nord', '', 998, 'nom_uk-us.txt', 'prenom_uk-us.txt', 'irn.gif', '', 1, 0, 10, '20:00', 2, 0),
(53, 'Uruguay', '', 993, 'nom_espagne.txt', 'prenom_espagne.txt', 'uru.gif', '', 1, 0, 10, '20:00', 2, 0),
(54, 'Pérou', '', 993, 'nom_espagne.txt', 'prenom_espagne.txt', 'per.gif', '', 1, 0, 10, '20:00', 2, 0),
(55, 'Paraguay', '', 993, 'nom_espagne.txt', 'prenom_espagne.txt', 'par.gif', '', 1, 0, 10, '20:00', 2, 0),
(56, 'Guatemala', '', 994, 'nom_espagne.txt', 'prenom_espagne.txt', 'gua.gif', '', 1, 0, 10, '20:00', 2, 0),
(57, 'Chili', '', 993, 'nom_espagne.txt', 'prenom_espagne.txt', 'chi.gif', 'Pesos', 1, 0, 10, '20:00', 2, 0),
(58, 'Bolivie', '', 993, 'nom_espagne.txt', 'prenom_espagne.txt', 'bol.gif', '', 1, 0, 10, '20:00', 2, 0),
(59, 'Argentine', '', 993, 'nom_espagne.txt', 'prenom_espagne.txt', 'arg.gif', 'Pesos', 1, 0, 10, '20:00', 2, 0),
(60, 'Brésil', '', 993, 'nom_portugal.txt', NULL, 'bra.gif', 'Reais', 0, 0, 10, '20:00', 2, 0),
(61, 'Colombie', '', 993, 'nom_espagne.txt', 'prenom_espagne.txt', 'col.gif', 'Pesos', 1, 0, 10, '20:00', 2, 0),
(62, 'Venezuela', '', 993, 'nom_espagne.txt', 'prenom_espagne.txt', 'ven.gif', '', 1, 0, 10, '20:00', 2, 0),
(63, 'Equateur', '', 993, NULL, NULL, 'equ.gif', '', 0, 0, 10, '20:00', 2, 0),
(64, 'Israël', '', 995, NULL, NULL, 'isr.gif', '', 0, 0, 10, '20:00', 2, 0),
(66, 'Afrique du Sud', '', 991, NULL, NULL, 'saf.gif', '', 0, 0, 10, '20:00', 2, 0),
(67, 'Algérie', '', 991, NULL, NULL, 'alg.gif', '', 0, 0, 10, '20:00', 2, 0),
(68, 'Angola', '', 991, NULL, NULL, 'ang.gif', '', 0, 0, 10, '20:00', 2, 0),
(69, 'Bénin', '', 991, NULL, NULL, 'ben.gif', '', 0, 0, 10, '20:00', 2, 0),
(70, 'Botswana', '', 991, NULL, NULL, 'bot.gif', '', 0, 0, 10, '20:00', 2, 0),
(71, 'Burkina Faso', '', 991, NULL, NULL, 'bur.gif', '', 0, 0, 10, '20:00', 2, 0),
(72, 'Burundi', '', 991, NULL, NULL, 'buu.gif', '', 0, 0, 10, '20:00', 2, 0),
(73, 'Cameroun', '', 991, NULL, NULL, 'cam.gif', '', 0, 0, 10, '20:00', 2, 0),
(74, 'Cap-Vert', '', 991, NULL, NULL, 'cap.gif', '', 0, 0, 10, '20:00', 2, 0),
(75, 'Comores', '', 991, NULL, NULL, 'com.gif', '', 0, 0, 10, '20:00', 2, 0),
(76, 'Congo', '', 991, NULL, NULL, 'rco.gif', '', 0, 0, 10, '20:00', 2, 0),
(77, 'Côte d''Ivoire', '', 991, NULL, NULL, 'cdi.gif', '', 0, 0, 10, '20:00', 2, 0),
(78, 'Djibouti', '', 991, NULL, NULL, 'dji.gif', '', 0, 0, 10, '20:00', 2, 0),
(79, 'Egypte', '', 991, NULL, NULL, 'egy.gif', '', 0, 0, 10, '20:00', 2, 0),
(80, 'Ethiopie', '', 991, NULL, NULL, 'eth.gif', '', 0, 0, 10, '20:00', 2, 0),
(81, 'Gabon', '', 991, NULL, NULL, 'gab.gif', '', 0, 0, 10, '20:00', 2, 0),
(82, 'Gambie', '', 991, NULL, NULL, 'gam.gif', '', 0, 0, 10, '20:00', 2, 0),
(83, 'Ghana', '', 991, NULL, NULL, 'gha.gif', '', 0, 0, 10, '20:00', 2, 0),
(84, 'Guinée', '', 991, NULL, NULL, 'gui.gif', '', 0, 0, 10, '20:00', 2, 0),
(85, 'Guinée Équatoriale', '', 991, NULL, NULL, 'gue.gif', '', 0, 0, 10, '20:00', 2, 0),
(86, 'Guinée-Bissau', '', 991, NULL, NULL, 'gbi.gif', '', 0, 0, 10, '20:00', 2, 0),
(87, 'Kenya', '', 991, NULL, NULL, 'ken.gif', '', 0, 0, 10, '20:00', 2, 0),
(88, 'Lesotho', '', 991, NULL, NULL, 'les.gif', '', 0, 0, 10, '20:00', 2, 0),
(89, 'Libéria', '', 991, NULL, NULL, 'lib.gif', '', 0, 0, 10, '20:00', 2, 0),
(90, 'Libye', '', 991, NULL, NULL, 'lby.gif', '', 0, 0, 10, '20:00', 2, 0),
(91, 'Madagascar', '', 991, NULL, NULL, 'mad.gif', '', 0, 0, 10, '20:00', 2, 0),
(92, 'Malawi', '', 991, NULL, NULL, 'maw.gif', '', 0, 0, 10, '20:00', 2, 0),
(93, 'Mali', '', 991, NULL, NULL, 'mali.gif', '', 0, 0, 10, '20:00', 2, 0),
(94, 'Maroc', '', 991, NULL, NULL, 'mar.gif', '', 0, 0, 10, '20:00', 2, 0),
(95, 'Maurice', '', 991, NULL, NULL, 'mrt.gif', '', 0, 0, 10, '20:00', 2, 0),
(96, 'Mauritanie', '', 991, NULL, NULL, 'mau.gif', '', 0, 0, 10, '20:00', 2, 0),
(97, 'Mozambique', '', 991, NULL, NULL, 'moz.gif', '', 0, 0, 10, '20:00', 2, 0),
(98, 'Namibie', '', 991, NULL, NULL, 'nam.gif', '', 0, 0, 10, '20:00', 2, 0),
(99, 'Niger', '', 991, NULL, NULL, 'nig.gif', '', 0, 0, 10, '20:00', 2, 0),
(100, 'Nigeria', '', 991, NULL, NULL, 'nia.gif', '', 0, 0, 10, '20:00', 2, 0),
(101, 'Ouganda', '', 991, NULL, NULL, 'uga.gif', '', 0, 0, 10, '20:00', 2, 0),
(102, 'RD Congo', '', 991, NULL, NULL, 'rdc.gif', '', 0, 0, 10, '20:00', 2, 0),
(103, 'Rwanda', '', 991, NULL, NULL, 'rwa.gif', '', 0, 0, 10, '20:00', 2, 0),
(104, 'Sénégal', '', 991, NULL, NULL, 'sen.gif', '', 0, 0, 10, '20:00', 2, 0),
(105, 'Seychelles', '', 991, NULL, NULL, 'sey.gif', '', 0, 0, 10, '20:00', 2, 0),
(106, 'Sierra Leone', '', 991, NULL, NULL, 'sie.gif', '', 0, 0, 10, '20:00', 2, 0),
(107, 'Somalie', '', 991, NULL, NULL, 'som.gif', '', 0, 0, 10, '20:00', 2, 0),
(108, 'Soudan', '', 991, NULL, NULL, 'sud.gif', '', 0, 0, 10, '20:00', 2, 0),
(109, 'Swaziland', '', 991, NULL, NULL, 'swa.gif', '', 0, 0, 10, '20:00', 2, 0),
(110, 'Tanzanie', '', 991, NULL, NULL, 'tan.gif', '', 0, 0, 10, '20:00', 2, 0),
(111, 'Tchad', '', 991, NULL, NULL, 'tch.gif', '', 0, 0, 10, '20:00', 2, 0),
(112, 'Togo', '', 991, NULL, NULL, 'tog.gif', '', 0, 0, 10, '20:00', 2, 0),
(113, 'Tunisie', '', 991, NULL, NULL, 'tun.gif', '', 0, 0, 10, '20:00', 2, 0),
(114, 'Zambie', '', 991, NULL, NULL, 'zam.gif', '', 0, 0, 10, '20:00', 2, 0),
(115, 'Zimbabwe', '', 991, NULL, NULL, 'zim.gif', '', 0, 0, 10, '20:00', 2, 0),
(116, 'Afghanistan', '', 990, NULL, NULL, 'afg.gif', '', 0, 0, 10, '20:00', 2, 0),
(117, 'Arabie Saoudite', '', 990, NULL, NULL, 'asd.gif', '', 0, 0, 10, '20:00', 2, 0),
(118, 'Australie', '', 990, NULL, NULL, 'ast.gif', '', 0, 0, 10, '20:00', 2, 0),
(119, 'Bahreïn', '', 990, NULL, NULL, 'bhr.gif', '', 0, 0, 10, '20:00', 2, 0),
(120, 'Bangladesh', '', 990, NULL, NULL, 'ban.gif', '', 0, 0, 10, '20:00', 2, 0),
(121, 'Cambodge', '', 990, NULL, NULL, 'cbd.gif', '', 0, 0, 10, '20:00', 2, 0),
(122, 'RP Chine', '', 990, NULL, NULL, 'chn.gif', '', 0, 0, 10, '20:00', 2, 0),
(123, 'Taiwan', '', 990, NULL, NULL, 'tai.gif', '', 0, 0, 10, '20:00', 2, 0),
(124, 'Emirats Arabes Unis', '', 990, NULL, NULL, 'eau.gif', '', 0, 0, 10, '20:00', 2, 0),
(125, 'Hongkong', '', 990, NULL, NULL, 'hko.gif', '', 0, 0, 10, '20:00', 2, 0),
(126, 'Inde', '', 990, NULL, NULL, 'ind.gif', '', 0, 0, 10, '20:00', 2, 0),
(127, 'Indonésie', '', 990, NULL, NULL, 'ida.gif', '', 0, 0, 10, '20:00', 2, 0),
(128, 'Irak', '', 990, NULL, NULL, 'irq.gif', '', 0, 0, 10, '20:00', 2, 0),
(129, 'Iran', '', 990, NULL, NULL, 'ira.gif', '', 0, 0, 10, '20:00', 2, 0),
(130, 'Japon', '', 990, NULL, NULL, 'jap.gif', '', 0, 0, 10, '20:00', 2, 0),
(131, 'Jordanie', '', 990, NULL, NULL, 'jor.gif', '', 0, 0, 10, '20:00', 2, 0),
(132, 'Kirghizistan', '', 990, NULL, NULL, 'kyr.gif', '', 0, 0, 10, '20:00', 2, 0),
(133, 'Koweït', '', 990, NULL, NULL, 'kuw.gif', '', 0, 0, 10, '20:00', 2, 0),
(134, 'Liban', '', 990, NULL, NULL, 'lbn.gif', '', 0, 0, 10, '20:00', 2, 0),
(135, 'Macau', '', 990, NULL, NULL, 'maca.gif', '', 0, 0, 10, '20:00', 2, 0),
(136, 'Malaisie', '', 990, NULL, NULL, 'mys.gif', '', 0, 0, 10, '20:00', 2, 0),
(137, 'Maldives', '', 990, NULL, NULL, 'mld.gif', '', 0, 0, 10, '20:00', 2, 0),
(138, 'Mongolie', '', 990, NULL, NULL, 'mga.gif', '', 0, 0, 10, '20:00', 2, 0),
(139, 'Myanmar', '', 990, NULL, NULL, 'mya.gif', '', 0, 0, 10, '20:00', 2, 0),
(140, 'Népal', '', 990, NULL, NULL, 'nep.gif', '', 0, 0, 10, '20:00', 2, 0),
(141, 'Oman', '', 990, NULL, NULL, 'oma.gif', '', 0, 0, 10, '20:00', 2, 0),
(142, 'Ouzbékistan', '', 990, NULL, NULL, 'uzb.gif', '', 0, 0, 10, '20:00', 2, 0),
(143, 'Pakistan', '', 990, NULL, NULL, 'pak.gif', '', 0, 0, 10, '20:00', 2, 0),
(144, 'Palestine', '', 990, NULL, NULL, 'pal.gif', '', 0, 0, 10, '20:00', 2, 0),
(145, 'Qatar', '', 990, NULL, NULL, 'qat.gif', '', 0, 0, 10, '20:00', 2, 0),
(146, 'RDP Corée', '', 990, NULL, NULL, 'kon.gif', '', 0, 0, 10, '20:00', 2, 0),
(147, 'République de Corée', '', 990, NULL, NULL, 'cos.gif', '', 0, 0, 10, '20:00', 2, 0),
(148, 'Singapour', '', 990, NULL, NULL, 'sin.gif', '', 0, 0, 10, '20:00', 2, 0),
(149, 'Sri Lanka', '', 990, NULL, NULL, 'sri.gif', '', 0, 0, 10, '20:00', 2, 0),
(150, 'Syrie', '', 990, NULL, NULL, 'syr.gif', '', 0, 0, 10, '20:00', 2, 0),
(151, 'Tadjikistan', '', 990, NULL, NULL, 'taj.gif', '', 0, 0, 10, '20:00', 2, 0),
(152, 'Thaïlande', '', 990, NULL, NULL, 'tha.gif', '', 0, 0, 10, '20:00', 2, 0),
(153, 'Timor Oriental', '', 990, NULL, NULL, 'tim.gif', '', 0, 0, 10, '20:00', 2, 0),
(154, 'Turkménistan', '', 990, NULL, NULL, 'tkm.gif', '', 0, 0, 10, '20:00', 2, 0),
(155, 'Viêt-Nam', '', 990, NULL, NULL, 'vie.gif', '', 0, 0, 10, '20:00', 2, 0),
(156, 'Yémen', '', 990, NULL, NULL, 'yem.gif', '', 0, 0, 10, '20:00', 2, 0),
(157, 'Anguilla', '', 994, NULL, NULL, 'agl.gif', '', 0, 0, 10, '20:00', 2, 0),
(158, 'Antigua-et-Barbuda', '', 994, NULL, NULL, 'aeb.gif', '', 0, 0, 10, '20:00', 2, 0),
(159, 'Antilles néerlandaises', '', 994, NULL, NULL, 'ant.gif', '', 0, 0, 10, '20:00', 2, 0),
(160, 'Aruba', '', 994, NULL, NULL, 'aru.gif', '', 0, 0, 10, '20:00', 2, 0),
(161, 'Bahamas', '', 994, NULL, NULL, 'bah.gif', '', 0, 0, 10, '20:00', 2, 0),
(162, 'Barbade', '', 994, NULL, NULL, 'bar.gif', '', 0, 0, 10, '20:00', 2, 0),
(163, 'Belize', '', 994, NULL, NULL, 'blz.gif', '', 0, 0, 10, '20:00', 2, 0),
(164, 'Bermudes', '', 994, NULL, NULL, 'ber.gif', '', 0, 0, 10, '20:00', 2, 0),
(165, 'Iles Caïmans ', '', 994, NULL, NULL, 'cay.gif', '', 0, 0, 10, '20:00', 2, 0),
(166, 'Canada', '', 994, NULL, NULL, 'can.gif', '', 0, 0, 10, '20:00', 2, 0),
(167, 'Costa Rica', '', 994, NULL, NULL, 'cor.gif', '', 0, 0, 10, '20:00', 2, 0),
(168, 'Cuba', '', 994, NULL, NULL, 'cub.gif', '', 0, 0, 10, '20:00', 2, 0),
(169, 'Dominique', '', 994, NULL, NULL, 'dom.gif', '', 0, 0, 10, '20:00', 2, 0),
(170, 'Etats-Unis d’Amérique', '', 994, NULL, NULL, 'usa.gif', '', 0, 0, 10, '20:00', 2, 0),
(171, 'Grenade', '', 994, NULL, NULL, 'gra.gif', '', 0, 0, 10, '20:00', 2, 0),
(172, 'Guyana', '', 994, NULL, NULL, 'guy.gif', '', 0, 0, 10, '20:00', 2, 0),
(173, 'Haïti', '', 994, NULL, NULL, 'hai.gif', '', 0, 0, 10, '20:00', 2, 0),
(174, 'Honduras', '', 994, NULL, NULL, 'hon.gif', '', 0, 0, 10, '20:00', 2, 0),
(175, 'Iles Vierges Américaines', '', 994, NULL, NULL, 'iva.gif', '', 0, 0, 10, '20:00', 2, 0),
(176, 'Iles Vierges Britanniques', '', 994, NULL, NULL, 'ivr.gif', '', 0, 0, 10, '20:00', 2, 0),
(177, 'Jamaïque', '', 994, NULL, NULL, 'jam.gif', '', 0, 0, 10, '20:00', 2, 0),
(178, 'Mexique', '', 994, NULL, NULL, 'mex.gif', '', 0, 0, 10, '20:00', 2, 0),
(179, 'Montserrat', '', 994, NULL, NULL, 'mts.gif', '', 0, 0, 10, '20:00', 2, 0),
(180, 'Nicaragua', '', 994, NULL, NULL, 'nic.gif', '', 0, 0, 10, '20:00', 2, 0),
(181, 'Panama', '', 994, NULL, NULL, 'pan.gif', '', 0, 0, 10, '20:00', 2, 0),
(182, 'Porto Rico', '', 994, NULL, NULL, 'pri.gif', '', 0, 0, 10, '20:00', 2, 0),
(183, 'République dominicaine', '', 994, NULL, NULL, 'red.gif', '', 0, 0, 10, '20:00', 2, 0),
(184, 'Sainte-Lucie', '', 994, NULL, NULL, 'slu.gif', '', 0, 0, 10, '20:00', 2, 0),
(185, 'Saint-Kitts-et-Nevis', '', 994, NULL, NULL, 'ski.gif', '', 0, 0, 10, '20:00', 2, 0),
(186, 'Saint-Vincent et les Grenadines', '', 994, NULL, NULL, 'svi.gif', '', 0, 0, 10, '20:00', 2, 0),
(187, 'Salvador', '', 994, NULL, NULL, 'sal.gif', '', 0, 0, 10, '20:00', 2, 0),
(188, 'Suriname', '', 994, NULL, NULL, 'sur.gif', '', 0, 0, 10, '20:00', 2, 0),
(189, 'Trinité-et-Tobago', '', 994, NULL, NULL, 'tet.gif', '', 0, 0, 10, '20:00', 2, 0),
(190, 'Turks et Caicos', '', 994, NULL, NULL, 'tec.gif', '', 0, 0, 10, '20:00', 2, 0),
(191, 'Fidji', '', 989, NULL, NULL, 'fid.gif', '', 0, 0, 10, '20:00', 2, 0),
(192, 'Iles Cook', '', 989, NULL, NULL, 'ico.gif', '', 0, 0, 10, '20:00', 2, 0),
(193, 'Nouvelle-Calédonie', '', 989, NULL, NULL, 'fra.gif', '', 0, 0, 10, '20:00', 2, 0),
(194, 'Nouvelle-Zélande', '', 989, NULL, NULL, 'nze.gif', '', 0, 0, 10, '20:00', 2, 0),
(195, 'Iles Salomon', '', 989, NULL, NULL, 'isa.gif', '', 0, 0, 10, '20:00', 2, 0),
(196, 'Samoa', '', 989, NULL, NULL, 'sam.gif', '', 0, 0, 10, '20:00', 2, 0),
(197, 'Samoa américaines', '', 989, NULL, NULL, 'asa.gif', '', 0, 0, 10, '20:00', 2, 0),
(198, 'Tahiti', '', 989, NULL, NULL, 'tah.gif', '', 0, 0, 10, '20:00', 2, 0),
(199, 'Tonga', '', 989, NULL, NULL, 'ton.gif', '', 0, 0, 10, '20:00', 2, 0),
(200, 'Tuvalu', '', 989, NULL, NULL, 'tuv.gif', '', 0, 0, 10, '20:00', 2, 0),
(201, 'Vanuatu', '', 989, NULL, NULL, 'van.gif', '', 0, 0, 10, '20:00', 2, 0);

-- --------------------------------------------------------

--
-- Structure de la table `region`
--

CREATE TABLE IF NOT EXISTS `region` (
  `region_id` int(11) NOT NULL AUTO_INCREMENT,
  `pays_id` int(11) NOT NULL,
  `region_name` varchar(128) NOT NULL,
  `region_img` varchar(128) NOT NULL,
  PRIMARY KEY (`region_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=115 ;

--
-- Contenu de la table `region`
--

INSERT INTO `region` (`region_id`, `pays_id`, `region_name`, `region_img`) VALUES
(1, 1, 'Alsace', ''),
(2, 1, 'Aquitaine', ''),
(3, 1, 'Auvergne', ''),
(4, 1, 'Basse-Normandie', ''),
(5, 1, 'Bourgogne', ''),
(6, 1, 'Bretagne', ''),
(7, 1, 'Centre', ''),
(8, 1, 'Champagne-Ardenne', ''),
(9, 1, 'Corse', ''),
(10, 1, 'Franche-Comté', ''),
(11, 1, 'Haute-Normandie', ''),
(12, 1, 'Ile-de-France', ''),
(13, 1, 'Languedoc-Roussillon', ''),
(14, 1, 'Limousin', ''),
(15, 1, 'Lorraine', ''),
(16, 1, 'Midi-Pyrénées', ''),
(17, 1, 'Nord-Pas-de-Calais', ''),
(18, 1, 'Outre-Mer', ''),
(19, 1, 'Pays-de-la-Loire', ''),
(20, 1, 'Picardie', ''),
(21, 1, 'Poitou-Charentes', ''),
(22, 1, 'Provence-Alpes-Côte-d''Azur', ''),
(23, 1, 'Rhône-Alpes', ''),
(24, 2, 'East', ''),
(25, 2, 'East Midlands', ''),
(26, 2, 'London', ''),
(27, 2, 'North East', ''),
(28, 2, 'North West', ''),
(29, 2, 'South East', ''),
(30, 2, 'South West', ''),
(31, 2, 'West Midlands', ''),
(32, 2, 'Yorkshire and the Humber', ''),
(33, 3, 'Andalucía', ''),
(34, 3, 'Aragón', ''),
(35, 3, 'Asturias', ''),
(36, 3, 'Cantabria', ''),
(37, 3, 'Castilla La Mancha', ''),
(38, 3, 'Castilla y León', ''),
(39, 3, 'Cataluña', ''),
(40, 3, 'Ceuta', ''),
(41, 3, 'Comunidad Valenciana', ''),
(42, 3, 'Extremadura', ''),
(43, 3, 'Galicia', ''),
(44, 3, 'Islas Baleares', ''),
(45, 3, 'Islas Canarias', ''),
(46, 3, 'La Rioja', ''),
(47, 3, 'Madrid', ''),
(48, 3, 'Melilla', ''),
(49, 3, 'Navarra', ''),
(50, 3, 'País Vasca', ''),
(51, 4, 'Abruzzo', ''),
(52, 4, 'Basilicata', ''),
(53, 4, 'Calabria', ''),
(54, 4, 'Campania', ''),
(55, 4, 'Emilia-Romagna', ''),
(56, 4, 'Friuli-Venezia Giulia', ''),
(57, 4, 'Lazio', ''),
(58, 4, 'Liguria', ''),
(59, 4, 'Lombardia', ''),
(60, 4, 'Marche', ''),
(61, 4, 'Molise', ''),
(62, 4, 'Piemonte', ''),
(63, 4, 'Puglia', ''),
(64, 4, 'Sardegna', ''),
(65, 4, 'Sicilia', ''),
(66, 4, 'Toscana', ''),
(67, 4, 'Trentino-Alto Adige', ''),
(68, 4, 'Umbria', ''),
(69, 4, 'Valle d''Aosta', ''),
(70, 4, 'Veneto', ''),
(71, 10, 'Limbourg', ''),
(72, 10, 'Liège', ''),
(73, 10, 'Hainaut', ''),
(74, 10, 'Flandre-Orientale', ''),
(75, 10, 'Flandre-Occidentale', ''),
(76, 10, 'Bruxelles-Capitale', ''),
(77, 10, 'Brabant wallon', ''),
(78, 10, 'Brabant flamand', ''),
(79, 10, 'Anvers', ''),
(80, 10, 'Luxembourg', ''),
(81, 10, 'Namur', ''),
(82, 21, 'Baden-Württemberg', ''),
(83, 21, 'Bayern', ''),
(84, 21, 'Berlin', ''),
(85, 21, 'Brandenburg', ''),
(86, 21, 'Bremen', ''),
(87, 21, 'Hamburg', ''),
(88, 21, 'Hessen', ''),
(89, 21, 'Mecklenburg-Vorpommern', ''),
(90, 21, 'Niedersachsen', ''),
(91, 21, 'Nordrhein-Westfalen', ''),
(92, 21, 'Rheinland-Pfalz', ''),
(93, 21, 'Saarland', ''),
(94, 21, 'Sachsen', ''),
(95, 21, 'Sachsen-Anhalt', ''),
(96, 21, 'Schleswig-Holstein', ''),
(97, 21, 'Thüringen', ''),
(98, 43, 'Appenzell Rhodes-Intérieures', ''),
(99, 43, 'Argovie', ''),
(100, 43, 'Berne', ''),
(101, 43, 'Bâle-Campagne', ''),
(102, 43, 'Fribourg', ''),
(103, 43, 'Grisons', ''),
(104, 43, 'Jura', ''),
(105, 43, 'Lucerne', ''),
(106, 43, 'Neuchâtel', ''),
(107, 43, 'Saint-Gall', ''),
(108, 43, 'Schwytz', ''),
(109, 43, 'Soleure', ''),
(110, 43, 'Tessin', ''),
(111, 43, 'Thurgovie', ''),
(112, 43, 'Valais', ''),
(113, 43, 'Vaud', ''),
(114, 43, 'Zurich', '');

-- --------------------------------------------------------

--
-- Structure de la table `sponsor`
--

CREATE TABLE IF NOT EXISTS `sponsor` (
  `sponsor_id` int(11) NOT NULL AUTO_INCREMENT,
  `sponsor_name` varchar(128) NOT NULL,
  `sponsor_img` varchar(32) NOT NULL,
  `sponsor_money` int(32) NOT NULL,
  `sponsor_div` tinyint(2) NOT NULL,
  `sponsor_paysid` int(11) DEFAULT NULL,
  PRIMARY KEY (`sponsor_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Contenu de la table `sponsor`
--

INSERT INTO `sponsor` (`sponsor_id`, `sponsor_name`, `sponsor_img`, `sponsor_money`, `sponsor_div`, `sponsor_paysid`) VALUES
(1, 'Coca cola', '', 10000, 1, NULL),
(2, 'Axa', '', 11500, 1, 1),
(3, 'Justin Bridou', '', 12270, 1, 1),
(4, 'Jambon d''Aoste', '', 9800, 1, 1),
(5, '9 T', '', 13580, 1, 1),
(6, 'Telecom Italia', '', 16000, 1, 4),
(7, 'TF1', '', 10250, 2, 1),
(8, 'Philips', '', 9300, 2, 1);

-- --------------------------------------------------------

--
-- Structure de la table `stade`
--

CREATE TABLE IF NOT EXISTS `stade` (
  `stad_id` int(11) NOT NULL AUTO_INCREMENT,
  `stad_type` varchar(64) NOT NULL,
  `stad_pos` varchar(64) NOT NULL,
  `pla_debout` int(10) NOT NULL,
  `pla_assise` int(10) NOT NULL,
  `pla_debout_couv` int(10) NOT NULL,
  `pla_assise_couv` int(10) NOT NULL,
  `tribune_presi` int(10) NOT NULL,
  `buvette` tinyint(1) NOT NULL,
  `duree_const` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `tribune_img` varchar(64) NOT NULL,
  PRIMARY KEY (`stad_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Contenu de la table `stade`
--

INSERT INTO `stade` (`stad_id`, `stad_type`, `stad_pos`, `pla_debout`, `pla_assise`, `pla_debout_couv`, `pla_assise_couv`, `tribune_presi`, `buvette`, `duree_const`, `price`, `tribune_img`) VALUES
(1, 'Stade', 'nordouest', 50, 0, 0, 0, 0, 0, 0, 0, 'base'),
(2, 'Stade', 'nord', 200, 0, 0, 0, 0, 0, 0, 0, 'base'),
(3, 'Stade', 'nordest', 50, 0, 0, 0, 0, 0, 0, 0, 'base'),
(4, 'Stade', 'ouest', 200, 0, 0, 0, 0, 0, 0, 0, 'base'),
(5, 'Stade', 'est', 200, 0, 0, 0, 0, 0, 0, 0, 'base'),
(6, 'Stade', 'sudouest', 50, 0, 0, 0, 0, 0, 0, 0, 'base'),
(7, 'Stade', 'sud', 200, 0, 0, 0, 0, 0, 0, 0, 'base'),
(8, 'Stade', 'sudest', 50, 0, 0, 0, 0, 0, 0, 0, 'base'),
(9, 'Equipement', 'nord', 300, 0, 50, 0, 0, 1, 259200, 10000, 'infra1'),
(10, 'Equipement', 'sud', 300, 0, 50, 0, 0, 1, 259200, 10000, 'infra1'),
(11, 'Tribune', 'nord', 250, 1250, 0, 0, 0, 0, 259200, 20000, 'trib1'),
(12, 'Tribune', 'sud', 250, 1250, 0, 0, 0, 0, 259200, 20000, 'trib1'),
(13, 'Tribune', 'est', 0, 0, 250, 1000, 0, 0, 432000, 25000, 'tribc1'),
(14, 'Tribune', 'ouest', 0, 0, 250, 1000, 0, 0, 432000, 25000, 'tribc1');

-- --------------------------------------------------------

--
-- Structure de la table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) DEFAULT NULL,
  `staff_nom` varchar(64) NOT NULL,
  `staff_prenom` varchar(64) NOT NULL,
  `staff_age` tinyint(2) NOT NULL,
  `staff_salaire` int(11) NOT NULL,
  `poste_actu` varchar(128) NOT NULL,
  `note` int(3) NOT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `staff`
--


-- --------------------------------------------------------

--
-- Structure de la table `stamp_blessure`
--

CREATE TABLE IF NOT EXISTS `stamp_blessure` (
  `id_player` int(11) NOT NULL,
  `type` varchar(64) CHARACTER SET utf8 NOT NULL,
  `blessure` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_player`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `stamp_blessure`
--


-- --------------------------------------------------------

--
-- Structure de la table `stamp_construction`
--

CREATE TABLE IF NOT EXISTS `stamp_construction` (
  `type` varchar(18) CHARACTER SET utf8 NOT NULL,
  `id` int(5) NOT NULL,
  `position` varchar(16) CHARACTER SET utf8 NOT NULL,
  `timestamp_fin` int(10) NOT NULL,
  `id_team` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `stamp_construction`
--


-- --------------------------------------------------------

--
-- Structure de la table `stamp_suspension`
--

CREATE TABLE IF NOT EXISTS `stamp_suspension` (
  `id_player` int(11) NOT NULL,
  `id_team` int(11) NOT NULL,
  `id_compet` int(11) NOT NULL,
  `suspension` int(2) NOT NULL,
  PRIMARY KEY (`id_player`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `stamp_suspension`
--


-- --------------------------------------------------------

--
-- Structure de la table `tactiques`
--

CREATE TABLE IF NOT EXISTS `tactiques` (
  `tact_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_team` int(11) NOT NULL,
  `tact_name` varchar(128) NOT NULL,
  `tact_using` varchar(20) NOT NULL,
  `N1` int(11) NOT NULL,
  `N2` int(11) NOT NULL,
  `N3` int(11) NOT NULL,
  `N4` int(11) NOT NULL,
  `N5` int(11) NOT NULL,
  `N6` int(11) NOT NULL,
  `N7` int(11) NOT NULL,
  `N8` int(11) NOT NULL,
  `N9` int(11) NOT NULL,
  `N10` int(11) NOT NULL,
  `N11` int(11) NOT NULL,
  `N12` int(11) NOT NULL,
  `N13` int(11) NOT NULL,
  `N14` int(11) NOT NULL,
  `N15` int(11) NOT NULL,
  `penalty` int(11) NOT NULL,
  `cfranc` int(11) NOT NULL,
  PRIMARY KEY (`tact_id`),
  KEY `penalty` (`penalty`,`cfranc`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `tactiques`
--


-- --------------------------------------------------------

--
-- Structure de la table `whosonline`
--

CREATE TABLE IF NOT EXISTS `whosonline` (
  `online_id` int(11) NOT NULL,
  `online_time` int(11) NOT NULL,
  `online_ip` int(15) NOT NULL,
  PRIMARY KEY (`online_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `whosonline`
--

