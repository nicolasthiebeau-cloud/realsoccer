<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
21/11/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

class joueur
{
	//Toutes les fonctions des pages joueur.php, joueur_menu.php, public_joueur.php, renvoi.php
	
	/*## Change la position du joueur ##*/
	function changeposition($player_id, $position)
	{
		$position = htmlentities(addslashes($position));
		$requete = sql::update("UPDATE joueurs SET position = {$position} WHERE player_id = {$player_id}");
	}
	
	/*## Cr�ation/modification du surnom ##*/
	function changesurnom($player_id, $surname) 
	{
		$surname = htmlentities(addslashes($surname));
		$requete = sql::update("UPDATE joueurs SET surnom = '{$surname}' WHERE player_id = {$player_id}");
	}
	
	/*## Change le statut (vente) ##*/
	function changestatut($player_id, $statut)
	{
		$requete = sql::update("UPDATE joueurs SET statut = {$statut} WHERE player_id = {$player_id}");
	}
	
	function rharasp_infojoueur($player_id)
	{
		return sql::fetch("SELECT * FROM joueurs 
						   LEFT JOIN joueurs_historique ON joueurs_historique.player_id = joueurs.player_id 
						   LEFT JOIN joueurs_position ON joueurs_position.pos_id = joueurs.position 
						   LEFT JOIN classement_joueur ON classement_joueur.player_id = joueurs.player_id 
						   LEFT JOIN equipes ON equipes.team_id = joueurs.team_id 
						   LEFT JOIN pays ON pays.pays_id = joueurs.nationalite 
						   LEFT JOIN joueurs_achat_demande ON joueurs_achat_demande.player_id = joueurs.player_id 
						   WHERE joueurs.player_id= '".$player_id."' ORDER BY saison_nbr DESC LIMIT 1");
	}
	
	
	/*## Verifie le nombre de demande d'achat pour le joueur ##*/
	function verif_player_offer($player_id, $team_id)
	{
		$data = sql::fetch("SELECT COUNT(*) AS dmdplayerexist FROM joueurs_achat_demande WHERE player_id={$player_id} AND team_dmd = {$team_id}");
		return $data['dmdplayerexist'];
	}
	
	/*## Compte le nombre de joueur de plus de 16 ans ##*/
	function limit15playermin($team_id)
	{
		if($team_id == 0) return 20;
		else
		{
			$data = sql::fetch("SELECT COUNT(*) AS nb_joueur FROM joueurs WHERE team_id = {$team_id} AND age >= 17");
			return $data['nb_joueur'];
		}
	}
	
	/*## Affichage du nom, pr�nom, position, drapeau, equipe et surnom si il existe ##*/
	function affiche_titre($prenom, $surnom, $nom, $team_id, $team_name, $pays_flag, $pos_name)
	{
		$catcat = NULL;
		$catcat .= '<span class="title1">' . stripslashes($prenom) . ' ';
		
		if ($surnom != NULL) $catcat .= '\' '. stripslashes($surnom) . ' \' ';
		
		$catcat .= stripslashes($nom) . '</span><br /><span class="subtitle1">';
		$catcat .= '<img src="images/flag' . '/' . $pays_flag . '" width="32" height="20" style="vertical-align: middle;" /> ';
		$catcat .= $pos_name . ', ';
		$catcat .= '<a href="club.php?zone=public&amp;page=teaminfo&amp;id=' . $team_id . '">'; 
		
		if($team_id == 0) $catcat .= '<a href="club.php?zone=support&amp;page=notice#sansclub">' . SANSCLUB . '</a>'; 
		else $catcat .= $team_name . '</b></span>';
		
		return $catcat;
	}
	
	/*## Affichage de la photo du joueur si elle existe ##*/
	function affiche_photo($photo, $photo_valid)
	{
		if($photo != NULL AND $photo_valid == 1) return'<img src="upload/joueur/'.$photo.'" style="vertical-align: middle;">';
		else return'<img src="images/icone/noportrait.png" width="150" height="150" />';
	}
	
	/*## Affichage de la nationalite du joueur ##*/
	function affiche_nationalite($pays_flag, $pays_name)
	{
		return'<img src="images/flag' . '/' . $pays_flag . '" width="32" height="20" style="vertical-align: middle;" />&nbsp; ' . $pays_name;
	}
	
	/*## Affiche le nom de jour depuis que le joueur est au club ##*/
	function auclub_depuisquand($stamp)
	{
		if(isset($stamp) && $stamp != 0)
		{
			$result = round((time() - $stamp) / (24 * 60 * 60));
			
			if($result == 0)
			{
				$result = round((time() - $stamp) / (60 * 60)) . ' ' . HEURE;
				
				if($result == 0) $result = round((time() - $stamp) / 60) . ' ' . MINUTE;
			}
			
			else $result = $result . ' ' . JOUR;
		}
		
		else return FORMACLUB;
		
		return $result;
	}
	
	/*## Estimation du joueur selon les ventes ##*/
	function estimation_joueur($data, $info)
	{
		$age = 5; $talent = 50; $carac = 5;
		
		if($data['position'] == 1)
		{
			$calcul = sql::fetch("SELECT AVG(valeur) valeurtotal 
								  FROM joueurs_estimation ");
		}
		
		elseif($data['position'] == 2)
		{
			$calcul = sql::fetch("SELECT AVG(valeur) valeurtotal 
								  FROM joueurs_estimation");
		}
		
		elseif($data['position'] == 3)
		{
			$calcul = sql::fetch("SELECT AVG(valeur) valeurtotal 
								  FROM joueurs_estimation");
		}
		
		elseif($data['position'] == 4)
		{
			$calcul = sql::fetch("SELECT AVG(valeur) valeurtotal 
								  FROM joueurs_estimation");
		}
		
		if($calcul['valeurtotal'] == NULL) return NOESTIMATION; else return round($calcul['valeurtotal']) . ' ' . $info['pays_money'];
	}
	
	/*## Changement de la couleur de police selon la note ##*/
	function notecolor20($note)
	{
			if($note <= 5) 	return'<span style="color:#A4B1C1;"><strong>' . $note . '</strong></span>';
		elseif($note <= 10) return'<span style="color:#648CBC;"><strong>' . $note . '</strong></span>';
		elseif($note <= 15) return'<span style="color:#1178F3;"><strong>' . $note . '</strong></span>';
		elseif($note <= 20) return'<span style="color:#1C5FB0;"><strong>' . $note . '</strong></span>';
	}
	
	//Renvoi le nom de l'�quipe � partir du team_id
	function teamid_to_teamname($team_id) 
	{
		if($team_id == 0) return SANSCLUB;
		else
		{
			$data = sql::fetch("SELECT team_name FROM equipes WHERE team_id= {$team_id}"); 
			return $data['team_name'];
		}
	}
}
?>