<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
11/11/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

class centreformation
{
	//Toutes les fonctions de la page centreformation.php
	
	/*## Construction du centre de formation ##*/
	function construction_centre($cout_amelioration, $temps_construction, $info)
	{
		$construc = sql::fetch("SELECT COUNT(*) AS exist FROM stamp_construction WHERE type = 'centreformation' AND id_team = '".$info['team_id']."'");
		
		if($construc['exist'] == 0)
		{
			$info['formationcenter']++;
			$tmstp_fin = time() + $temps_construction;
			$requete = sql::update("UPDATE equipes SET team_money= team_money - '".$cout_amelioration."' WHERE team_id='".$info['team_id']."'");
			
			$requete = sql::insert("INSERT INTO stamp_construction(type, id, timestamp_fin, id_team) 
									VALUES('centreformation', '".$info['trainingcenter']."', '".$tmstp_fin."', '".$info['team_id']."')");
			
			return FCCONSTRUCOK;
		}
	}
	
	/*## Agrandissement du centre d'entrainement ##*/
	function agrandissement_centre($cout_amelioration, $temps_construction, $info, $CONF)
	{
		if ($info['formationcenter'] < 10)
		{
			$construc = sql::fetch("SELECT COUNT(*) AS exist FROM stamp_construction WHERE type = 'centreentrainement' AND id_team = '".$info['team_id']."'");
			
			if($construc['exist'] == 0)
			{
				$info['formationcenter']++;
				$tmstp_fin = time() + $temps_construction;
				$requete = sql::update("UPDATE equipes SET team_money= team_money - '".$cout_amelioration."' WHERE team_id='".$info['team_id']."'");
				
				$requete = sql::insert("INSERT INTO stamp_construction(type, id, timestamp_fin, id_team) 
										VALUES('centreformation', '".$info['formationcenter']."', '".$tmstp_fin."', '".$info['team_id']."')");
				return FCUPGRAOK;
			}
		}
		
		else return FCNIVMAX;
	}
	
	function recrut_jeune($position, $nationalite, $info)
	{
		$a = sql::fetch("SELECT COUNT(*) AS nbr FROM joueurs WHERE team_id = {$info['team_id']} AND age < 17");
		
		switch($info['formationcenter']) //nombre de jeune pouvant �tre dans le centre selon le niveau
		{
			case 1: $nbmaxjeune = 1; break;
			case 2: $nbmaxjeune = 1; break;
			case 3: $nbmaxjeune = 2; break;
			case 4: $nbmaxjeune = 2; break;
			case 5: $nbmaxjeune = 3; break;
			case 6: $nbmaxjeune = 3; break;
			case 7: $nbmaxjeune = 4; break;
			case 8: $nbmaxjeune = 4; break;
			case 9: $nbmaxjeune = 5; break;
			case 10: $nbmaxjeune = 6; break;
			default : $nbmaxjeune = 0; break;
		}
		
		if ($a['nbr'] == $nbmaxjeune)
		{
			return FCMAXJEUNE1 . ' ' . $nbmaxjeune . ' ' . FCMAXJEUNE2 . ' ' . $info['formationcenter'];
		}
		
		else
		{
			$position = htmlentities(addslashes($position)); 
			$pays_id = htmlentities(addslashes($nationalite)); 
			
			// si pas assez d'argent
			if ($info['team_money'] < $CONF['cf_achat_joueur'])
			{
				return FCNOMONEY;
			}
			
			else
			{
				$min = (0);
				$max = (10);
				$salaire = $CONF['cf_salaire_jeune'];
				
				$data = sql::fetch("SELECT pays_file_nom, pays_file_prenom FROM pays WHERE pays_id = {$pays_id}");
				
				//-------------------------------------------------------
				// Choix d'une liste de nom al�atoire selon le pays(pays_id)
				if ($data['pays_file_nom'] != NULL) $sourcefile = 'txt' . '/' . $data['pays_file_nom'];
				else $sourcefile = 'txt' . '/' . 'nom_france.txt';
				$bddfile = fopen($sourcefile, "r");
				$bddarray = array(); // Cr�ation du tableau qui contiendra toutes les phrases
				while ( $line = fgets($bddfile) ) { array_push($bddarray, $line); }// On la rajoute au tableau
				fclose ($bddfile); // On ferme le fichier
				srand((double)microtime(2) * 1000000) ;
				$nom = $bddarray[rand(0, count($bddarray)-1)];
				//-------------------------------------------------------
				
				//-------------------------------------------------------
				// Choix d'une liste de pr�nom al�atoire selon le pays(pays_id)
				if ($data['pays_file_prenom'] != NULL) $sourcefile = 'txt' . '/' . $data['pays_file_prenom'];
				else $sourcefile = 'txt' . '/' . 'prenom_france.txt';
				$bddfile = fopen($sourcefile, "r");
				$bddarray = array(); // Cr�ation du tableau qui contiendra toutes les phrases
				while ( $line = fgets($bddfile) ) { array_push($bddarray, $line); }// On la rajoute au tableau
				fclose ($bddfile); // On ferme le fichier
				srand((double)microtime(2) * 1000000) ;
				$prenom = $bddarray[rand(0, count($bddarray)-1)];
				//-------------------------------------------------------
				
				if ($position == 4)
				{    
					$influ = rand($min, $max) + (0.5 * $info['formationcenter']); $reflex = rand($min, $max) + (0.5 * $info['formationcenter']);    
					$pdballe = rand($min, $max) + (0.5 * $info['formationcenter']); $degag = rand($min, $max) + (0.5 * $info['formationcenter']);    
					$marq = rand($min, $max) + (0.5 * $info['formationcenter']); $tacle = rand($min, $max) + (0.5 * $info['formationcenter']);    
					$tete = rand($min, $max) + (1 * $info['formationcenter']); $centre = rand($min, $max) + (0.5 * $info['formationcenter']);
					$passe = rand($min, $max) + (0.5 * $info['formationcenter']); $vites = rand($min, $max) + (0.5 * $info['formationcenter']);
					$tir = rand($min, $max) + (1 * $info['formationcenter']); $creat = rand($min, $max) + (1 * $info['formationcenter']);
					$dribble = rand($min, $max) + (1 * $info['formationcenter']); $cdpa = rand($min, $max) + (0.5 * $info['formationcenter']);
					$agress = rand($min, $max) + (0.5 * $info['formationcenter']);
				}
				
				elseif ($position == 3)
				{
					$infonflu = rand($min, $max) + (0.5 * $info['formationcenter']); $reflex = rand($min, $max) + (0.5 * $info['formationcenter']);    
					$pdballe = rand($min, $max) + (0.5 * $info['formationcenter']); $degag = rand($min, $max) + (0.5 * $info['formationcenter']);    
					$marq = rand($min, $max) + (0.5 * $info['formationcenter']); $tacle = rand($min, $max) + (0.5 * $info['formationcenter']);    
					$tete = rand($min, $max) + (0.5 * $info['formationcenter']); $centre = rand($min, $max) + (1 * $info['formationcenter']);
					$passe = rand($min, $max) + (1 * $info['formationcenter']); $vites = rand($min, $max) + (1 * $info['formationcenter']);
					$tir = rand($min, $max) + (1 * $info['formationcenter']); $creat = rand($min, $max) + (0.5 * $info['formationcenter']);
					$dribble = rand($min, $max) + (0.5 * $info['formationcenter']); $cdpa = rand($min, $max) + (0.5 * $info['formationcenter']);
					$agress = rand($min, $max) + (0.5 * $info['formationcenter']);
				}
				
				elseif ($position == 2)
				{
					$infonflu = rand($min, $max) + (0.5 * $info['formationcenter']); $reflex = rand($min, $max) + (0.5 * $info['formationcenter']);    
					$pdballe = rand($min, $max) + (0.5 * $info['formationcenter']); $degag = rand($min, $max) + (1 * $info['formationcenter']);    
					$marq = rand($min, $max) + (1 * $info['formationcenter']); $tacle = rand($min, $max) + (1 * $info['formationcenter']);    
					$tete = rand($min, $max) + (1 * $info['formationcenter']); $centre = rand($min, $max) + (0.5 * $info['formationcenter']);
					$passe = rand($min, $max) + (0.5 * $info['formationcenter']); $vites = rand($min, $max) + (0.5 * $info['formationcenter']);
					$tir = rand($min, $max) + (0.5 * $info['formationcenter']); $creat = rand($min, $max) + (0.5 * $info['formationcenter']);
					$dribble = rand($min, $max) + (0.5 * $info['formationcenter']); $cdpa = rand($min, $max) + (0.5 * $info['formationcenter']);
					$agress = rand($min, $max) + (0.5 * $info['formationcenter']);
				}

				elseif ($position == 1)
				{
					//Gardien
					$infonflu = rand($min, $max) + (1 * $info['formationcenter']); $reflex = rand($min, $max) + (1 * $info['formationcenter']);    
					$pdballe = rand($min, $max) + (1 * $info['formationcenter']); $degag = rand($min, $max) + (1 * $info['formationcenter']);    
					$marq = rand($min, $max) + (0.5 * $info['formationcenter']); $tacle = rand($min, $max) + (0.5 * $info['formationcenter']);    
					$tete = rand($min, $max) + (0.5 * $info['formationcenter']); $centre = rand($min, $max) + (0.5 * $info['formationcenter']);
					$passe = rand($min, $max) + (0.5 * $info['formationcenter']); $vites = rand($min, $max) + (0.5 * $info['formationcenter']);
					$tir = rand($min, $max) + (0.5 * $info['formationcenter']); $creat = rand($min, $max) + (0.5 * $info['formationcenter']);
					$dribble = rand($min, $max) + (0.5 * $info['formationcenter']); $cdpa = rand($min, $max) + (0.5 * $info['formationcenter']);
					$agress = rand($min, $max) + (0.5 * $info['formationcenter']);
				}
				
				else
				{
					$infonflu = rand($min, $max) + (0.5 * $info['formationcenter']); $reflex = rand($min, $max) + (0.5 * $info['formationcenter']);    
					$pdballe = rand($min, $max) + (0.5 * $info['formationcenter']); $degag = rand($min, $max) + (0.5 * $info['formationcenter']);    
					$marq = rand($min, $max) + (0.5 * $info['formationcenter']); $tacle = rand($min, $max) + (0.5 * $info['formationcenter']);    
					$tete = rand($min, $max) + (0.5 * $info['formationcenter']); $centre = rand($min, $max) + (0.5 * $info['formationcenter']);
					$passe = rand($min, $max) + (0.5 * $info['formationcenter']); $vites = rand($min, $max) + (0.5 * $info['formationcenter']);
					$tir = rand($min, $max) + (0.5 * $info['formationcenter']); $creat = rand($min, $max) + (0.5 * $info['formationcenter']);
					$dribble = rand($min, $max) + (0.5 * $info['formationcenter']); $cdpa = rand($min, $max) + (0.5 * $info['formationcenter']);
					$agress = rand($min, $max) + (0.5 * $info['formationcenter']);
				}
				
				//On met le joueur dans la base de donn�e
				// on retire l'argent
				$argent_total = ($info['team_money'] - $CONF['cf_achat_joueur']); //a modifi� quand je ferais la tarification selon les zone g�o
				$sql = sql::update("UPDATE equipes SET team_money='".$argent_total."' WHERE team_id = '".$info['team_id']."'");
				
				if(isset($CONF['cf_age_min'])) $age_min = $CONF['cf_age_min']; 
				if(isset($CONF['cf_age_max'])) $age_max = $CONF['cf_age_max'];
				if(isset($CONF['note_tll_min'])) $tll_min = $CONF['note_tll_min']; 
				if(isset($CONF['note_tll_max'])) $tll_max = $CONF['note_tll_max'];
				if(isset($CONF['note_tal_min'])) $tal_min = $CONF['note_tal_min']; 	
				if(isset($CONF['note_tal_max'])) $tal_max = $CONF['note_tal_max'];
				if(isset($CONF['note_pres_min'])) $pres_min = $CONF['note_pres_min']; 	
				if(isset($CONF['note_pres_max'])) $pres_max = $CONF['note_pres_max'];
				
				$age = rand($age_min, $age_max);
				$taille = rand($tll_min, $tll_max);
				$talent = rand($tal_min, $tal_max);
				$pression = rand($pres_min, $pres_max);
				$experience = rand(0, 1);
				$aggressivite = rand(0, 10);
				
				$requete = sql::insert("INSERT INTO joueurs
				(team_id, nom, prenom, age, taille, position, nationalite, talent, pression, influence, agressivite, reflexes, 
				pdballe, degagement, marquage, tacles, tete, centres, passes, vitesse, tir, creativite, dribble, cdp_arrete, salaire)
				VALUES ('".$info['team_id']."', '".addslashes($nom)."',  '".addslashes($prenom)."', '".$age."', '".$taille."', '".$position."', 
				'".$pays_id."', '".$talent."', '".$pression."', '".$influ."',  '".$agress."', '".$reflex."', '".$pdballe."', '".$degag."', 
				'".$marq."', '".$tacle."', '".$tete."', '".$centre."', '".$passe."', '".$vites."', '".$tir."', '".$creat."'
				, '".$dribble."', '".$cdpa."', '".$salaire."')");
				
				$player_id = mysql_insert_id();
				
				$transfert = time() . '/' . $info['team_id'] . '/FORMACLUB';
				$requete = sql::insert("INSERT INTO joueurs_historique(player_id, transfert) 
										VALUES ('".$player_id."', '".$transfert."')"); 
				
				return FCJEUNERECRUT;
			}
		}
	}
	
	
	/*## Le compte � rebours pour les timestamps ##*/
	function comparetimestamp($timestamp) 
	{
		$tmp = ($timestamp - time());
		$heures = floor($tmp / 3600);
		$minutes = floor((($tmp / 3600) - $heures) * 60);
		$secondes = round((((($tmp / 3600) - $heures) * 60) - $minutes) * 60);
		return $heures . ' Heures ' . $minutes . ' minutes ' . $secondes . ' secondes ';
	}
}
?>