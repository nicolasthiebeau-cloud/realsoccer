<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/11/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

class entrainement
{
	//Toutes les fonctions de la page entrainement.php
	
	/*## Construction du centre d'entrainement ##*/
	function construction_centre($cout_amelioration, $temps_construction, $info)
	{
		$construc = sql::fetch("SELECT COUNT(*) AS exist FROM stamp_construction WHERE type = 'centreentrainement' AND id_team = '".$info['team_id']."'");
		
		if($construc['exist'] == 0)
		{
			$info['trainingcenter']++;
			$tmstp_fin = time() + $temps_construction;
			$requete = sql::update("UPDATE equipes SET team_money= team_money - '".$cout_amelioration."' WHERE team_id='".$info['team_id']."'");
			
			$requete = sql::insert("INSERT INTO stamp_construction(type, id, timestamp_fin, id_team) 
									VALUES('centreentrainement', '".$info['trainingcenter']."', '".$tmstp_fin."', '".$info['team_id']."')");
			
			return TRCONSTRUCOK;
		}
	}
	
	/*## Agrandissement du centre d'entrainement ##*/
	function agrandissement_centre($cout_amelioration, $temps_construction, $info)
	{
		if ($info['trainingcenter'] < 10)
		{
			$construc = sql::fetch("SELECT COUNT(*) AS exist FROM stamp_construction WHERE type = 'centreentrainement' AND id_team = '".$info['team_id']."'");
			
			if($construc['exist'] == 0)
			{
				$info['trainingcenter']++;
				$tmstp_fin = time() + $temps_construction;
				$requete = sql::update("UPDATE equipes SET team_money= team_money - '".$cout_amelioration."' WHERE team_id='".$info['team_id']."'");
				
				$requete = sql::insert("INSERT INTO stamp_construction(type, id, timestamp_fin, id_team) 
										VALUES('centreentrainement', '".$info['trainingcenter']."', '".$tmstp_fin."', '".$info['team_id']."')");
				return TRUPGRAOK;
			}
		}
		
		else return TRNIVMAX;
	}
	
	/*## Cr�ation de l'entraineur ##*/
	function creation_entraineur($nationalite, $info)
	{
		//Generation age
		$age = rand(38, 60); // Age de l'entraineur
		$note = rand(0, 100); //g�n�ration note ---A VOIR
		$salaire = 5000;
		
		$data = sql::fetch("SELECT pays_file_nom, pays_file_prenom 
							FROM pays 
							WHERE pays_id = '".$nationalite."'");
		
		//-------------------------------------------------------
		// Choix d'une liste de nom al�atoire selon le pays(pays_id)
		if ($data['pays_file_nom'] != NULL) $sourcefile = 'txt' . '/' . $data['pays_file_nom'];
		else $sourcefile = 'txt' . '/' . 'nom_france.txt';
		$bddfile = fopen($sourcefile, "r");
		$bddarray = array(); // Cr�ation du tableau qui contiendra toutes les phrases
		while ( $line = fgets($bddfile) ) { array_push($bddarray, $line); }// On la rajoute au tableau
		fclose ($bddfile); // On ferme le fichier
		srand((double)microtime(2) * 1000000) ;
		$nom = $bddarray[rand(0, count($bddarray)-1)];
		//-------------------------------------------------------
		
		//-------------------------------------------------------
		// Choix d'une liste de pr�nom al�atoire selon le pays(pays_id)
		if ($data['pays_file_prenom'] != NULL) $sourcefile = 'txt' . '/' . $data['pays_file_prenom'];
		else $sourcefile = 'txt' . '/' . 'prenom_france.txt';
		$bddfile = fopen($sourcefile, "r");
		$bddarray = array(); // Cr�ation du tableau qui contiendra toutes les phrases
		while ( $line = fgets($bddfile) ) { array_push($bddarray, $line); }// On la rajoute au tableau
		fclose ($bddfile); // On ferme le fichier
		srand((double)microtime(2) * 1000000) ;
		$prenom = $bddarray[rand(0, count($bddarray)-1)];
		//-------------------------------------------------------
		
		//On cr�e l'entraineur dans la base de donn�e
		$requete = sql::insert("INSERT INTO staff
								VALUES ('', '".$info['team_id']."', '".addslashes($nom)."', '".addslashes($prenom)."', '".$age."', '".$salaire."', 'Entraineur', '".$note."')");
		
		return TRENTRAIRECRUT;
	}
	
	/*## Choix de l'entrainement collectif ##*/
	function entrainement_collectif($train, $info)
	{
		if ($train != NULL) $requete = sql::update("UPDATE equipes SET training_choice='".$train."' WHERE team_id='".$info['team_id']."'");
	}
	
	function entrainement_individuel($indivjoueur, $indivtrain, $info)
	{
		//On enleve tous les entrainements des joueurs
		$requete = sql::update("UPDATE joueurs SET trainsolo_choice= 0 WHERE team_id='".$info['team_id']."' AND age >= 17");
		
		$nb = count($indivjoueur);
		
		for($nbi = 0; $nbi < $nb; $nbi++)
		{
			if(isset($indivjoueur[$nbi]) && isset($indivtrain[$nbi]))
			{
				$requete = sql::update("UPDATE joueurs SET trainsolo_choice='".$indivtrain[$nbi]."' WHERE player_id='".$indivjoueur[$nbi]."'");
			}
			
			else return TRHAVETRAININDIVI;
		}
	}
	
	function entrainement_jeune($jjoueur, $jtrain, $info)
	{
		//On enleve tous les entrainements des jeunes
		$requete = sql::update("UPDATE joueurs SET trainsolo_choice= 0 WHERE team_id='".$info['team_id']."' AND age <= 16");
		
		$nb = count($jjoueur);
		
		for($nbi = 0; $nbi < $nb; $nbi++)
		{
			if(isset($jjoueur[$nbi]) && isset($jtrain[$nbi]))
			{
				$requete = sql::update("UPDATE joueurs SET trainsolo_choice='".$jtrain[$nbi]."' WHERE player_id='".$jjoueur[$nbi]."'");
			}
		}
	}
	
	/*## Le compte � rebours pour les timestamps ##*/
	function comparetimestamp($timestamp) 
	{
		$tmp = ($timestamp - time());
		$heures = floor($tmp / 3600);
		$minutes = floor((($tmp / 3600) - $heures) * 60);
		$secondes = round((((($tmp / 3600) - $heures) * 60) - $minutes) * 60);
		return $heures . ' Heures ' . $minutes . ' minutes ' . $secondes . ' secondes ';
	}
}
?>