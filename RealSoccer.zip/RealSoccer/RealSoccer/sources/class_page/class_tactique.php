<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/11/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

class tactique
{
	//Toutes les fonctions de la page tactique.php
	
	/*## Verifie que l'�quipe est compl�te, sinon il renvoi les position manquante ##*/
	function verif_joueur_exist($nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11)
	{
		$error = array();
		
		if(!isset($nbr1) || $nbr1 == 0) $error[] = 1;
		if(!isset($nbr2) || $nbr2 == 0) $error[] = 2;
		if(!isset($nbr3) || $nbr3 == 0) $error[] = 3;
		if(!isset($nbr4) || $nbr4 == 0) $error[] = 4;
		if(!isset($nbr5) || $nbr5 == 0) $error[] = 5;
		if(!isset($nbr6) || $nbr6 == 0) $error[] = 6;
		if(!isset($nbr7) || $nbr7 == 0) $error[] = 7;
		if(!isset($nbr8) || $nbr8 == 0) $error[] = 8;
		if(!isset($nbr9) || $nbr9 == 0) $error[] = 9;
		if(!isset($nbr10) || $nbr10 == 0) $error[] = 10;
		if(!isset($nbr11) || $nbr11 == 0) $error[] = 11;
		
		return $error;
	}
	
	/*## Verifie que le tireur de penalty est bien sur la feuille de match ##*/
	function verif_tireur_penalty($defautpenalty, $nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11)
	{
		$error = 0;
		
		if(in_array($defautpenalty, array($nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11, NULL))) $error++;
		
		return $error;
	}
	
	/*## Verifie que le tireur de penalty est bien sur la feuille de match ##*/
	function verif_tireur_cfranc($defautcfranc, $nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11)
	{
		$error = 0;
		
		if(in_array($defautcfranc, array($nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11, NULL))) $error++;
		
		return $error;
	}
	
	function create_tactique($chx_tact, $defautpenalty, $defautcfranc, $nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11, $info)
	{
		if(!isset($nbr12)) $nbr12 = 0;
		if(!isset($nbr13)) $nbr13 = 0;
		if(!isset($nbr14)) $nbr14 = 0;
		if(!isset($nbr15)) $nbr15 = 0;
		
		$data = sql::fetch("SELECT COUNT(*) AS exist FROM tactiques WHERE id_team = {$info['team_id']}");
		
		if ($data['exist'] == 0)
		{
			$requete = sql::insert("INSERT INTO tactiques 
									VALUES ('', '".$info['team_id']."', '', '".$chx_tact."', '".$nbr1."', '".$nbr2."', '".$nbr3."', '".$nbr4."', '".$nbr5."', '".$nbr6."', 
											'".$nbr7."', '".$nbr8."', '".$nbr9."', '".$nbr10."', '".$nbr11."', '".$nbr12."', '".$nbr13."', '".$nbr14."', '".$nbr15."', '".$defautpenalty."', '".$defautcfranc."')");
			
			return CREAOK;
		}
		
		else
		{
			$requete = sql::update("UPDATE tactiques 
									SET tact_using='".$chx_tact."', N1='".$nbr1."', N2='".$nbr2."', N3='".$nbr3."', N4='".$nbr4."', N5='".$nbr5."', 
										N6='".$nbr6."', N7='".$nbr7."', N8='".$nbr8."', N9='".$nbr9."', N10='".$nbr10."', N11='".$nbr11."', N12='".$nbr12."', 
										N13='".$nbr13."', N14='".$nbr14."', N15='".$nbr15."', penalty='".$defautpenalty."', cfranc='".$defautcfranc."' 
									WHERE id_team='".$info['team_id']."'");
			
			return MAJOK;
		}
	}
	
	/*## Affiche la position du joueur si elle existe ##*/
	function show_number_player($info_effect, $player_id, $nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11)
	{
		$affiche = NULL;
		$num = NULL;
		
		if(isset($info_effect)) $numeromax = 0; else $numeromax = 15;
		 
			if(isset($nbr1) && $nbr1 == $player_id) $num = 1;
		elseif(isset($nbr2) && $nbr2 == $player_id) $num = 2;
		elseif(isset($nbr3) && $nbr3 == $player_id) $num = 3;
		elseif(isset($nbr4) && $nbr4 == $player_id) $num = 4;
		elseif(isset($nbr5) && $nbr5 == $player_id) $num = 5;
		elseif(isset($nbr6) && $nbr6 == $player_id) $num = 6;
		elseif(isset($nbr7) && $nbr7 == $player_id) $num = 7;
		elseif(isset($nbr8) && $nbr8 == $player_id) $num = 8;
		elseif(isset($nbr9) && $nbr9 == $player_id) $num = 9;
		elseif(isset($nbr10) && $nbr10 == $player_id) $num = 10;
		elseif(isset($nbr11) && $nbr11 == $player_id) $num = 11;
		 
		for($numero = 1; $numero <= $numeromax; $numero++)
		{
			$affiche .= '<option value="'.$numero . ';' . $player_id.'"';
			if(isset($num) && $num == $numero) $affiche .= 'selected="selected"';
			$affiche .= '>'.$numero.'</option>';
		}
		
		return $affiche;
	}
	 
	
}
?>