<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/11/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

class stade
{
	//Toutes les fonctions des pages stade.php, stade_infra.php, public_stade.php
	
	/*## Affichage du nom du stade ##*/
	function affiche_nom_stade($stade_name)
	{
		//S�paration du nom du stade et des tribunes
		$name = explode(';', $stade_name);
		return $name[0];
	}
	
	/*## Affichage du stade ##*/
	function stade_viewer($stade_infra, $team_id)
	{
		$trib = explode(';', $stade_infra);
		
		$req = sql::query("SELECT stad_pos, tribune_img, (SELECT COUNT(*) FROM stamp_construction WHERE position = stade.stad_pos AND id_team = {$team_id}) exist  
						   FROM stade 
						   WHERE stad_id IN ({$trib[0]}, {$trib[1]}, {$trib[2]}, {$trib[3]}, {$trib[4]}, {$trib[5]}, {$trib[6]}, {$trib[7]})");
		
		while($donnees = mysql_fetch_assoc($req))
		{
			if(($donnees['exist']) == 1) $construct = 1; else $construct = 0;
			$raytrib[$donnees['stad_pos']] = $donnees['stad_pos'] . ';' . $donnees['tribune_img'] . ';' . $construct;
		}
		
		$stadium = NULL;
		
		for($nbr = 1; $nbr <= 8; $nbr++)
		{
			switch($nbr)
			{
				case 1: $trib = explode(';', $raytrib['nordouest']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 2: $trib = explode(';', $raytrib['nord']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 3: $trib = explode(';', $raytrib['nordest']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 4: $trib = explode(';', $raytrib['ouest']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 5: $trib = explode(';', $raytrib['est']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 6: $trib = explode(';', $raytrib['sudouest']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 7: $trib = explode(';', $raytrib['sud']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 8: $trib = explode(';', $raytrib['sudest']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				default : return 'Inconnu'; break;
			}
			
			if($nametrib == 'est') $stadium .= '<div id="stade"></div>';
			
			$stadium .= '<a href="club.php?zone=management&amp;page=infrastade&amp;tribune='.$nametrib.'">';
			$stadium .= '<div id="tribu_'.$nametrib.'" style="background-image:url(images/stade/'.$pictrib.'_'.$nametrib.'.gif); background-repeat:no-repeat;">';
			if($trib[2] == 1) $stadium .= '<img src="images/stade/travaux.gif" class="construct" />';
			$stadium .= '</div></a>';
		}
		
		return $stadium;
	}
	
	/*## Affichage du stade (public) ##*/
	function stade_viewer_public($stade_infra, $team_id)
	{
		$trib = explode(';', $stade_infra);
		
		$req = sql::query("SELECT stad_pos, tribune_img, (SELECT COUNT(*) FROM stamp_construction WHERE position = stade.stad_pos AND id_team = {$team_id}) exist  
						   FROM stade 
						   WHERE stad_id IN ({$trib[0]}, {$trib[1]}, {$trib[2]}, {$trib[3]}, {$trib[4]}, {$trib[5]}, {$trib[6]}, {$trib[7]})");
		
		while($donnees = mysql_fetch_assoc($req))
		{
			if(($donnees['exist']) == 1) $construct = 1; else $construct = 0;
			$raytrib[$donnees['stad_pos']] = $donnees['stad_pos'] . ';' . $donnees['tribune_img'] . ';' . $construct;
		}
		
		$stadium = NULL;
		
		for($nbr = 1; $nbr <= 8; $nbr++)
		{
			switch($nbr)
			{
				case 1: $trib = explode(';', $raytrib['nordouest']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 2: $trib = explode(';', $raytrib['nord']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 3: $trib = explode(';', $raytrib['nordest']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 4: $trib = explode(';', $raytrib['ouest']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 5: $trib = explode(';', $raytrib['est']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 6: $trib = explode(';', $raytrib['sudouest']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 7: $trib = explode(';', $raytrib['sud']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				case 8: $trib = explode(';', $raytrib['sudest']); $nametrib = $trib[0]; $pictrib = $trib[1]; break;
				default : return 'Inconnu'; break;
			}
			
			if($nametrib == 'est') $stadium .= '<div id="stade"></div>';
			
			$stadium .= '<div id="tribu_'.$nametrib.'" style="background-image:url(images/stade/'.$pictrib.'_'.$nametrib.'.gif); background-repeat:no-repeat;">';
			if($trib[2] == 1) $stadium .= '<img src="images/stade/travaux.gif" class="construct" />';
			$stadium .= '</div>';
		}
		
		return $stadium;
	}
	
	/*## Changement du nom du stade ##*/
	function stade_change_name($nomstade, $info, $CONF)
	{
		//S�paration du nom du stade et des tribunes
		$name = explode(';', $info['stade_name']);
		
		//Protection de la saisie
		$nomstade = htmlentities(addslashes($nomstade));
		$nonpermis = array(";", "&");
		$newcarac = array("/", "/");
		$nomstade = str_replace($nonpermis, $newcarac, $nomstade);
		
		//Recuperation du cout d'un changement
		$cout_change = $CONF['nom_stade'];
		
							$champname = $nomstade;
		if(isset($name[1])) $champname .= $name[1];
							$champname .= ';';
		if(isset($name[2])) $champname .= $name[2];
							$champname .= ';';
		if(isset($name[3])) $champname .= $name[3];
							$champname .= ';';
		if(isset($name[4])) $champname .= $name[4];
							$champname .= ';';
		if(isset($name[5])) $champname .= $name[5];
							$champname .= ';';
		if(isset($name[6])) $champname .= $name[6];
							$champname .= ';';
		if(isset($name[7])) $champname .= $name[7];
							$champname .= ';';
		if(isset($name[8])) $champname .= $name[8];
							$champname .= ';';
		
		//Update table �quipes
		$requete = sql::update("UPDATE equipes 
								SET stade_name = '{$champname}', 
									team_money = team_money - '{$cout_change}' 
								WHERE team_id = {$info['team_id']}");
		
		echo '<meta http-equiv="refresh" content="0;url=club.php?zone=management&amp;page=stade">';
	}
	
	/*## Affichage du nom de la tribune ##*/
	function affiche_nom_tribune($stade_name, $tribune)
	{
		//S�paration du nom du stade et des tribunes
		$nameexpl = explode(';', $stade_name);
		
		//Protection de la saisie
		$tribune = htmlentities(addslashes($tribune));
		
		switch($tribune)
		{
			case "nordouest" : 	if(isset($nameexpl[1])) $name = $nameexpl[1]; else $name = 0; break;
			case "nord" : 		if(isset($nameexpl[2])) $name = $nameexpl[2]; else $name = 0; break;
			case "nordest" : 	if(isset($nameexpl[3])) $name = $nameexpl[3]; else $name = 0; break;
			case "ouest" : 		if(isset($nameexpl[4])) $name = $nameexpl[4]; else $name = 0; break;
			case "est" : 		if(isset($nameexpl[5])) $name = $nameexpl[5]; else $name = 0; break;
			case "sudouest" :	if(isset($nameexpl[6])) $name = $nameexpl[6]; else $name = 0; break;
			case "sud" : 		if(isset($nameexpl[7])) $name = $nameexpl[7]; else $name = 0; break;
			case "sudest" : 	if(isset($nameexpl[8])) $name = $nameexpl[8]; else $name = 0; break;
			default : 			$trib = 'error'; $name =  'error'; break;
		}
		
		if($name == 0) return NONDEFINI; else return $name;
	}
	
	/*## Construction d'une tribune ##*/
	function tribune_construction($tribune, $stad_id, $tmp_fin, $price, $info)
	{
		$stad_id = htmlentities(addslashes($stad_id));
		$tmp_fin = htmlentities(addslashes($tmp_fin));
		$price = htmlentities(addslashes($price));
		$tmstp_fin = time() + $tmp_fin;
		
		if ($price <= $info['team_money'])
		{
			$requete = sql::update("UPDATE equipes SET team_money = team_money - '".$price."' WHERE team_id = '".$info['team_id']."'");
			
			$requete = sql::insert("INSERT INTO stamp_construction(type, id, position, timestamp_fin, id_team) 
								   VALUES ('tribune', '".$stad_id."', '".$tribune."', '".$tmstp_fin."', '".$info['team_id']."')");
		}
		
		else return NOMONEY; 
	}
	
	/*## Changement du nom d'une tribune ##*/
	function tribune_change_name($tribune, $nomtribune, $info, $CONF)
	{
		//Protection de la saisie
		$nomtribune = htmlentities(addslashes($nomtribune));
		$nonpermis = array(";", "&");
		$newcarac = array("/", "/");
		$nomtribune = str_replace($nonpermis, $newcarac, $nomtribune);
		
		//Recuperation du cout d'un changement
		$cout_change = $CONF['nom_tribune'];
		
		//S�paration du nom du stade et des tribunes
		$nameexpl = explode(';', $info['stade_name']);
		
		if ($cout_change <= $info['team_money'])
		{
			if ($tribune == 'nordouest') 
			{ $champtribname = $nameexpl[0] . ';' . $nomtribune . ';' . $nameexpl[2] . ';' . $nameexpl[3] . ';' . $nameexpl[4] . ';' . 
							   $nameexpl[5] . ';' . $nameexpl[6] . ';' . $nameexpl[7] . ';' . $nameexpl[8]; }
			elseif ($tribune == 'nord') 
			{ $champtribname = $nameexpl[0] . ';' . $nameexpl[1] . ';' . $nomtribune . ';' . $nameexpl[3] . ';' . $nameexpl[4] . ';' . 
							   $nameexpl[5] . ';' . $nameexpl[6] . ';' . $nameexpl[7] . ';' . $nameexpl[8]; }
			elseif ($tribune == 'nordest') 
			{ $champtribname = $nameexpl[0] . ';' . $nameexpl[1] . ';' . $nameexpl[2] . ';' . $nomtribune . ';' . $nameexpl[4] . ';' . 
							   $nameexpl[5] . ';' . $nameexpl[6] . ';' . $nameexpl[7] . ';' . $nameexpl[8]; }
			elseif ($tribune == 'ouest') 
			{ $champtribname = $nameexpl[0] . ';' . $nameexpl[1] . ';' . $nameexpl[2] . ';' . $nameexpl[3] . ';' . $nomtribune . ';' . 
							   $nameexpl[5] . ';' . $nameexpl[6] . ';' . $nameexpl[7] . ';' . $nameexpl[8]; }
			elseif ($tribune == 'est') 
			{ $champtribname = $nameexpl[0] . ';' . $nameexpl[1] . ';' . $nameexpl[2] . ';' . $nameexpl[3] . ';' . $nameexpl[4] . ';' . 
							   $nomtribune . ';' . $nameexpl[6] . ';' . $nameexpl[7] . ';' . $nameexpl[8]; }
			elseif ($tribune == 'sudouest') 
			{ $champtribname = $nameexpl[0] . ';' . $nameexpl[1] . ';' . $nameexpl[2] . ';' . $nameexpl[3] . ';' . $nameexpl[4] . ';' . 
							   $nameexpl[5] . ';' . $nomtribune . ';' . $nameexpl[7] . ';' . $nameexpl[8]; }
			elseif ($tribune == 'sud') 
			{ $champtribname = $nameexpl[0] . ';' . $nameexpl[1] . ';' . $nameexpl[2] . ';' . $nameexpl[3] . ';' . $nameexpl[4] . ';' . 
							   $nameexpl[5] . ';' . $nameexpl[6] . ';' . $nomtribune . ';' . $nameexpl[8]; }
			elseif ($tribune == 'sudest') 
			{ $champtribname = $nameexpl[0] . ';' . $nameexpl[1] . ';' . $nameexpl[2] . ';' . $nameexpl[3] . ';' . $nameexpl[4] . ';' . 
							   $nameexpl[5] . ';' . $nameexpl[6] . ';' . $nameexpl[7] . ';' . $nomtribune; }
			
			$requete = sql::update("UPDATE equipes 
									SET stade_name = '".$champtribname."', 
										team_money = team_money - '".$cout_change."' 
									WHERE team_id = '".$info['team_id']."'");
			echo '<meta http-equiv="refresh" content="0;url=club.php?zone=management&amp;page=infrastade&amp;tribune=' . $tribune . '">';
		}
		
		else return NOMONEY2;
	}
	
	/*## Convertion en jour ##*/
	function switchcontrucdate($construct)
	{
		return $construct / 86400;
	}

	/*## Le compte � rebours pour les timestamps ##*/
	function comparetimestamp($timestamp) 
	{
		$tmp = ($timestamp - time());
		$heures = floor($tmp / 3600);
		$minutes = floor((($tmp / 3600) - $heures) * 60);
		$secondes = round((((($tmp / 3600) - $heures) * 60) - $minutes) * 60);
		return $heures . ' Heures ' . $minutes . ' minutes ' . $secondes . ' secondes ';
	}
}
?>