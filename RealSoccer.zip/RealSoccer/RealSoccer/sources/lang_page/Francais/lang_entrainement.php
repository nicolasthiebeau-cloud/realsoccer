<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
10/11/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

define("CREAOK", "Cr�ation r�ussi");
define("MAJOK", "Mise � jour r�ussi");
define("ERROR_BADCFRANC", "Le tireur de coup franc par d�faut n'est pas dans la feuille de match");
define("ERROR_BADPENALTY", "Le tireur de p�nalty par d�faut n'est pas dans la feuille de match");
define("ERROR_MANQUEJOUEUR", "Il manque les positions suivantes");
define("TACTIK", "Tactique");
define("EQUIPTYPE", "Equipe type");
define("REMPLA", "Remplacant");
define("REMPLAGAR", "Remplacant gardien");
define("REMPLADEF", "Remplacant d�fenseur");
define("REMPLAMIL", "Remplacant milieu");
define("REMPLAATK", "Remplacant attaquant");
define("TACTGEN", "Tactique g�n�rale");
define("TIRCFRANC", "Tireur de coup-franc");
define("TIRCFRANCINFO", "Le joueur doit �tre sur la feuille de match");
define("TIRPENALTY", "Tireur de p�nalty");
define("TIRPENALTYINFO", "Le joueur doit �tre sur la feuille de match");
define("VALID_TACTIK", "Valider votre tactique");
?>