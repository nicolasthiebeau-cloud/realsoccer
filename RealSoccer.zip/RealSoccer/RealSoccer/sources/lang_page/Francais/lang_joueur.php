<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
21/11/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

define("MAJ", "Mise � jour");
define("SURNAME", "Surnom");
define("CATEG_CHANGE", "Choisir un nouveau poste");
define("DEPUIS", "Au club depuis");
define("JOUR", "Jour(s)");
define("HEURE", "Heure(s)");
define("MINUTE", "Minute(s)");
define("FORMACLUB", "Form� au club");
define("SANSCLUB", "Sans club");
define("LIBRE", "Libre");
define("ACHATLIBRE", "Recruter librement");
define("SALAIRE", "Salaire hebdomadaire");
define("VALEUR", "Valeur");
define("NOESTIMATION", "Pas d'estimation");
define("STATUT", "Statut");
define("VENTE_NO", "Le joueur n'est pas � vendre");
define("VENTE_YES", "Le manager accepte les offres d'achats");
define("AUTRES", "Autres");
define("TECHNIQUE", "Techniques");
define("MENTAL", "Mental");
define("HISTORIQUE", "Historique");
define("SAISON_STAT", "Statistiques de la saison");
define("HORSCOMPET", "Hors comp�tition");
define("NATCUP", "Coupe nationale");
define("CONTICUP", "Coupe continentale");
define("AB_SEL", "S�ls");
define("AB_PASDEC", "Pas. D�c.");
define("AB_CJAUNE", "C. Jaune");
define("AB_CROUGE", "C. Rouge");
define("WEEK", "Semaine");
define("CM", "cm");
define("DATE", "Date");
define("CLUB", "Club");
define("PHOTO_INFO", "Photo du joueur, n�cessite une validation. Max 150 x 150 et 30Ko");
define("PHOTO_TAILLE", "La photo de votre joueur d�passe la taille maximum autoris�, elle fait");
define("NIVEAU", "Niveau");
define("INFO_NIVEAU", "Le niveau vous donne une estimation du joueur pour chaque poste, selon ces notes.");
define("RESILI", "Resiliation de contrat :");
define("INFO_RESILI", "Si ce joueur n'entre plus dans vos schemas tactiques, vous avez la possibilit� de vous s&eacute;parer de lui. La r�siliation de contrat coute 1000 euros");
define("RESILI_REPLY", "Etes vous sur de vouloir vraiment vous separer de");
define("RESILI_OK", "Oui, je me separe de ce joueur !");
define("RESILI_NO", "Le renvoi du joueur est impossible car vous avez atteint la limite minimum de joueur autoris�");
define("OFFERACHAT", "Faire une offre d'achat");
define("OFFERTWICE", "Vous avez d�j� faire une offre pour ce joueur");
define("OFFERMINPL", "Vous ne pouvez faire une offre d'achat car le club � atteint la limite minimum de joueur");
define("OFFERYOUNG", "Vous ne pouvez faire une offre d'achat car le joueur est trop jeune");
define("OFFERNO", "Le joueur n'est pas � vendre");
define("OFFRE", "Offre en cours");
//define("", "");
?>