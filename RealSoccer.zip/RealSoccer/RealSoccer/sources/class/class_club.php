<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
18/05/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

class club
{
	//Regroupement de toutes les informations du joueur
	function info_alljunction($pseudo)
	{ 
		return sql::fetch("SELECT * 
						   FROM comptes 
						   LEFT JOIN equipes ON comptes.account_id = equipes.account_id 
						   LEFT JOIN joueurs ON equipes.team_id = joueurs.team_id 
						   LEFT JOIN classement ON equipes.team_id = classement.team_id 
						   LEFT JOIN competition ON equipes.compet_id = competition.compet_id 
						   LEFT JOIN matchs ON competition.compet_id = matchs.compet_id 
						   LEFT JOIN pays ON pays.pays_id = equipes.team_country 
						   LEFT JOIN region ON equipes.team_region = region.region_id 
						   LEFT JOIN sponsor ON equipes.sponsor_id = sponsor.sponsor_id 
						   WHERE pseudo = '{$pseudo}'");
	}
	
	//Regroupement de toutes les informations du joueur (affichage au public)
	function info_publicjunction($team_id)
	{
		return sql::fetch("SELECT equipes.team_id, team_name, team_devise, fanion, fanion_valid, team_shirt_dom, team_shirt_ext, stade_name, stade_infra, team_cup, fictive, 
								   comptes.account_id, pseudo, lang, coach_name, joindate, lastlogin, 
								   pays.pays_id, pays_name, config_tpsentre2match, 
								   region_id, region_name, 
								   competition.compet_id, division, poule, 
								   staff_nom, staff_prenom, poste_actu 
							FROM equipes 
							LEFT JOIN comptes ON comptes.account_id = equipes.account_id 
							LEFT JOIN pays ON pays.pays_id = equipes.team_country 
							LEFT JOIN region ON region.region_id = equipes.team_region 
							LEFT JOIN competition ON equipes.compet_id = competition.compet_id 
							LEFT JOIN staff ON staff.team_id = equipes.team_id 
							WHERE equipes.team_id= {$team_id}");
	}
	
	//Onglet du menu
	function menutab($zone, $tab)
	{
			if($zone == $tab) return'class="tabon-main"';
		elseif($tab == 'main' AND $zone == NULL) return'class="tabon-main"';
		elseif($tab == 'competition' AND $zone == 'match') return'class="tabon-main"';
		elseif($tab == 'main' AND $zone == 'bureaumanager') return'class="tabon-main"';
		elseif($tab == 'main' AND $zone == 'public') return'class="tabon-main"';
		elseif($tab == 'support' AND $zone == 'support') return'class="tabon-main"';
		elseif($tab == 'support' AND $zone == 'forums') return'class="tabon-main"';
		else return'class="taboff-main"';
	}
	
	//Changer la langue du compte
	function changelanguage($lang, $account_id) { $resultat = sql::update("UPDATE comptes SET lang = '{$lang}' WHERE account_id = {$account_id}"); }
	
	//Changer de canal dans le minichat
	function changecanal($canal, $account_id) { $resultat = sql::update("UPDATE comptes SET canal_choice = {$canal} WHERE account_id = {$account_id}"); }
	
	//Purge des demandes de match amicaux
	function purge_demande_ma() { $requete = sql::delete("DELETE FROM matchs_amical_demande WHERE timematch <= ".time().""); }
	
	//Purge des suspensions
	function timestamp_suspension()
	{
		$req = sql::query("SELECT player_id, team_id, id_compet 
						   FROM stamp_suspension 
						   LEFT JOIN joueurs ON joueurs.player_id = stamp_suspension.id_player 
						   WHERE suspension = 0");
			
		while ($donnees = mysql_fetch_assoc($req))
		{
			$requete = sql::update("UPDATE joueurs SET indisponible = 0 WHERE player_id = '{$donnees['player_id']}'");
			$requete = sql::delete("DELETE FROM stamp_suspension WHERE id_player = {$donnees['player_id']} AND id_compet = {$donnees['id_compet']}");
		}
	}
	
	//fonction auto pour la construction du stade, du centre de formation, et du centre d'entrainement
	function timestamp_construction($team_id) 
	{
		$req = sql::query("SELECT type, id, position, timestamp_fin, stade_infra, id_team
						   FROM stamp_construction 
						   LEFT JOIN equipes ON equipes.team_id = stamp_construction.id_team 
						   WHERE timestamp_fin <= ".time()." 
							 AND id_team = {$team_id}");
		
		$nb = mysql_num_rows($req);
		
		if ($nb >= 1)
		{
			$type = array();
			$id = array();
			$position = array();
			$timestamp_fin = array();
			
			while($donnees = mysql_fetch_assoc($req))
			{
				$type[] = $donnees['type'];
				$id[] = $donnees['id'];
				$position[] = $donnees['position'];
				$timestamp_fin[] = $donnees['timestamp_fin'];
				$stade_infra = $donnees['stade_infra'];
				$stad_id = $donnees['id_team'];
			}
			
			for($def = 0; $nb > $def; $def++)
			{
				if($type[$def] == 'tribune')
				{
					$tribexpl = explode(';', $stade_infra);
						
					switch($position[$def])
					{
						case "nordouest" : 	$champtrib = $stad_id . ';' . $tribexpl[1] . ';' . $tribexpl[2] . ';' . $tribexpl[3] . ';' . $tribexpl[4] . ';' . $tribexpl[5] . ';' . $tribexpl[6] . ';' . $tribexpl[7]; break;
						case "nord" : 		$champtrib = $tribexpl[0] . ';' . $stad_id . ';' . $tribexpl[2] . ';' . $tribexpl[3] . ';' . $tribexpl[4] . ';' . $tribexpl[5] . ';' . $tribexpl[6] . ';' . $tribexpl[7]; break;
						case "nordest" : 	$champtrib = $tribexpl[0] . ';' . $tribexpl[1] . ';' . $stad_id . ';' . $tribexpl[3] . ';' . $tribexpl[4] . ';' . $tribexpl[5] . ';' . $tribexpl[6] . ';' . $tribexpl[7]; break;
						case "ouest" : 		$champtrib = $tribexpl[0] . ';' . $tribexpl[1] . ';' . $tribexpl[2] . ';' . $stad_id . ';' . $tribexpl[4] . ';' . $tribexpl[5] . ';' . $tribexpl[6] . ';' . $tribexpl[7]; break;
						case "est" : 		$champtrib = $tribexpl[0] . ';' . $tribexpl[1] . ';' . $tribexpl[2] . ';' . $tribexpl[3] . ';' . $stad_id . ';' . $tribexpl[5] . ';' . $tribexpl[6] . ';' . $tribexpl[7]; break;
						case "sudouest" :	$champtrib = $tribexpl[0] . ';' . $tribexpl[1] . ';' . $tribexpl[2] . ';' . $tribexpl[3] . ';' . $tribexpl[4] . ';' . $stad_id . ';' . $tribexpl[6] . ';' . $tribexpl[7]; break;
						case "sud" : 		$champtrib = $tribexpl[0] . ';' . $tribexpl[1] . ';' . $tribexpl[2] . ';' . $tribexpl[3] . ';' . $tribexpl[4] . ';' . $tribexpl[5] . ';' . $stad_id . ';' . $tribexpl[7]; break;
						case "sudest" : 	$champtrib = $tribexpl[0] . ';' . $tribexpl[1] . ';' . $tribexpl[2] . ';' . $tribexpl[3] . ';' . $tribexpl[4] . ';' . $tribexpl[5] . ';' . $tribexpl[6] . ';' . $stad_id; break;
						default : 			$champtrib = 'error'; break;
						}
						
						$requete = sql::update("UPDATE equipes SET stade_infra = '{$champtrib}' WHERE team_id = {$team_id}");
						//$requete = sql::delete("DELETE FROM timestamp WHERE type = 'tribune' AND id = {$id[$def]} AND id_team = {$team_id}");
				}
				
				elseif($type[$def] == 'centreformation')
				{
					//$requete = sql::update("UPDATE equipes SET formationcenter = {$contruct['id']} WHERE team_id={$team_id}");
					//$requete = sql::delete("DELETE FROM timestamp WHERE type = 'centreformation' AND id = {$id[$def]} AND id_team = {$team_id}");
				}
				
				elseif($type[$def] == 'centreentrainement')
				{
					//$requete = sql::update("UPDATE equipes SET trainingcenter = {$contruct['id']} WHERE team_id={$team_id}");
					//$requete = sql::delete("DELETE FROM timestamp WHERE type = 'centreentrainement' AND id = {$id[$def]} AND id_team = {$team_id}");
				}
			}
		}
	}
	
	//Automatisation___________________________________________________________

	//Fonction automatique de pr�levement des salaires de joueur et staff
	function salaire_hebdo($salaire_day)
	{
		$dayname = date('w'); $date = date('Y-m-d');
		
		$log = sql::fetch("SELECT COUNT(*) AS auto_exist FROM automatisation WHERE auto_date = '{$date}' AND auto_type = 'salaire'"); 
		
		if ($dayname == $salaire_day && $log['auto_exist'] == 0) //dayname 1 represente lundi
		{
			$nb = sql::fetch("SELECT COUNT(*) AS team_total FROM equipes"); 
			
			$team = 1;
			
			while($nb['team_total'] >= $team)
			{
				$data = sql::fetch("SELECT SUM(salaire) AS salaire_tot FROM joueurs WHERE team_id = {$team}");
				$data2 = sql::fetch("SELECT SUM(staff_salaire) AS salaire_staff_tot FROM staff WHERE team_id = {$team}");
				
				$depenses = $data['salaire_tot'] + $data2['salaire_staff_tot'];
				
				$requete = sql::update("UPDATE equipes SET team_money = team_money - {$depenses} WHERE team_id = {$team}");
				
				$team++;
			}
			
			$requete = sql::insert("INSERT INTO automatisation VALUES ('', 'salaire', '{$date}')"); 
			$requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, mode) VALUES (0, ".time().", 5)"); 
		}
	}
	
	//Fonction automatique de recette hebdomadaire (sponsor)
	function recette_hebdo($recette_day) 
	{
		$dayname = date('w'); $date = date('Y-m-d');
		
		$log = sql::fetch("SELECT COUNT(*) AS auto_exist FROM automatisation WHERE auto_date = '{$date}' AND auto_type = 'sponsor'"); 
		
		if ($dayname == $recette_day && $log['auto_exist'] == 0) //dayname 2 represente mardi
		{
			$req = sql::query("SELECT team_id, equipes.sponsor_id, sponsor_money 
							   FROM equipes 
							   LEFT JOIN sponsor ON sponsor.sponsor_id = equipes.sponsor_id 
							   WHERE equipes.sponsor_id != 0 
							     AND fictive = 0");
			
			while ($donnees = mysql_fetch_assoc($req))
			{
				$requete = sql::update("UPDATE equipes SET team_money = team_money + '{$donnees['sponsor_money']}' WHERE team_id = ".$donnees['team_id']."");
			}
			
			$requete = sql::insert("INSERT INTO automatisation VALUES ('', 'sponsor', '{$date}')"); 
			$requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, mode) VALUES (0, ".time().", 7)"); 
		}
	}
	
	function training_hebdo($training_day) //Fonction automatique d'entrainement
	{
		$dayname = date('w'); $date = date('Y-m-d');
		
		$log = sql::fetch("SELECT COUNT(*) AS auto_exist FROM automatisation WHERE auto_date = '{$date}' AND auto_type = 'entrainement'");
		
		if ($dayname == $training_day && $log['auto_exist'] == 0)
		{
			//Collectif
			$req = sql::query("SELECT team_id, trainingcenter, training_choice 
							   FROM equipes 
							   WHERE training_choice != 0");
			
			while ($donnees = mysql_fetch_assoc($req))
			{
				switch($donnees['trainingcenter']) //Niveau du centre d'entrainement
				{
					case 1: $niv_collec = 0.05; break;
					case 2: $niv_collec = 0.05; break;
					case 3: $niv_collec = 0.1; break;
					case 4: $niv_collec = 0.1; break;
					case 5: $niv_collec = 0.15; break;
					case 6: $niv_collec = 0.15; break;
					case 7: $niv_collec = 0.20; break;
					case 8: $niv_collec = 0.20; break;
					case 9: $niv_collec = 0.20; break;
					case 10: $niv_collec = 0.20; break;
					default : $niv_collec = 0; break;
				}
				
				switch($donnees['training_choice']) //Choix de l'entrainement collectif pour les plus de 17 ans
				{
					case 1: $requete = sql::update("UPDATE joueurs SET centres = centres + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND centres < 20 AND age >= 17"); break;
					case 2: $requete = sql::update("UPDATE joueurs SET cdp_arrete = cdp_arrete + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND cdp_arrete < 20 AND age >= 17"); break;
					case 3: $requete = sql::update("UPDATE joueurs SET creativite = creativite + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND creativite < 20 AND age >= 17"); break;
					case 4: $requete = sql::update("UPDATE joueurs SET degagement = degagement + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND degagement < 20 AND age >= 17"); break;
					case 5: $requete = sql::update("UPDATE joueurs SET dribble = dribble + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND dribble < 20 AND age >= 17"); break;
					case 6: $requete = sql::update("UPDATE joueurs SET influence = influence + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND influence < 20 AND age >= 17"); break;
					case 7: $requete = sql::update("UPDATE joueurs SET marquage = marquage + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND marquage < 20 AND age >= 17"); break;
					case 8: $requete = sql::update("UPDATE joueurs SET passes = passes + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND passes < 20 AND age >= 17"); break;
					case 9: $requete = sql::update("UPDATE joueurs SET pdballe = pdballe + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND pdballe < 20 AND age >= 17"); break;
					case 10: $requete = sql::update("UPDATE joueurs SET reflexes = reflexes + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND reflexes < 20 AND age >= 17"); break;
					case 11: $requete = sql::update("UPDATE joueurs SET tacles = tacles + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND tacles < 20 AND age >= 17"); break;
					case 12: $requete = sql::update("UPDATE joueurs SET tete = tete + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND tete < 20 AND age >= 17"); break;
					case 13: $requete = sql::update("UPDATE joueurs SET tir = tir + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND tir < 20 AND age >= 17"); break;
					case 14: $requete = sql::update("UPDATE joueurs SET vitesse = vitesse + '{$niv_collec}' WHERE team_id = {$donnees['team_id']} AND vitesse < 20 AND age >= 17"); break;
					default : echo'erreur'; break;
				}
			}
			
			//Individuel
			$req = sql::query("SELECT player_id, trainsolo_choice, 
									  trainingcenter 
							   FROM joueurs 
							   LEFT JOIN equipes ON equipes.team_id = joueurs.team_id 
							   WHERE trainsolo_choice != 0");
			
			while ($donnees = mysql_fetch_assoc($req))
			{
				switch($donnees['trainingcenter']) //Niveau du centre d'entrainement
				{
					case 1: $niv_indiv = 0; break;
					case 2: $niv_indiv = 0.1; break;
					case 3: $niv_indiv = 0.15; break;
					case 4: $niv_indiv = 0.15; break;
					case 5: $niv_indiv = 0.15; break;
					case 6: $niv_indiv = 0.15; break;
					case 7: $niv_indiv = 0.15; break;
					case 8: $niv_indiv = 0.20; break;
					case 9: $niv_indiv = 0.25; break;
					case 10: $niv_indiv = 0.30; break;
					default : $niv_indiv = 0; break;
				}
				
				switch($donnees['trainsolo_choice']) //Choix de l'entrainement individuel
				{
					case 1: $requete = sql::update("UPDATE joueurs SET centres = centres + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND centres < 20"); break;
					case 2: $requete = sql::update("UPDATE joueurs SET cdp_arrete = cdp_arrete + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND cdp_arrete < 20"); break;
					case 3: $requete = sql::update("UPDATE joueurs SET creativite = creativite + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND creativite < 20"); break;
					case 4: $requete = sql::update("UPDATE joueurs SET degagement = degagement + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND degagement < 20"); break;
					case 5: $requete = sql::update("UPDATE joueurs SET dribble = dribble + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND dribble < 20"); break;
					case 6: $requete = sql::update("UPDATE joueurs SET influence = influence + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND influence < 20"); break;
					case 7: $requete = sql::update("UPDATE joueurs SET marquage = marquage + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND marquage < 20"); break;
					case 8: $requete = sql::update("UPDATE joueurs SET passes = passes + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND passes < 20"); break;
					case 9: $requete = sql::update("UPDATE joueurs SET pdballe = pdballe + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND pdballe < 20"); break;
					case 10: $requete = sql::update("UPDATE joueurs SET reflexes = reflexes + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND reflexes < 20"); break;
					case 11: $requete = sql::update("UPDATE joueurs SET tacles = tacles + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND tacles < 20"); break;
					case 12: $requete = sql::update("UPDATE joueurs SET tete = tete + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND tete < 20"); break;
					case 13: $requete = sql::update("UPDATE joueurs SET tir = tir + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND tir < 20"); break;
					case 14: $requete = sql::update("UPDATE joueurs SET vitesse = vitesse + '{$niv_indiv}' WHERE player_id = {$donnees['player_id']} AND vitesse < 20"); break;
					default : echo'erreur'; break;
				}
			}
			
			$requete = sql::insert("INSERT INTO automatisation VALUES ('', 'entrainement', '{$date}')"); 
		}
	}
	
	//Bureau manager__________________________________________________________
	
	//Recuperation du dernier match et affichage sur la page d'acceuil
	function last_match($team_id)
	{
		$data = sql::fetch("SELECT matchs.compet_id,  matchs.cup_id, timematch, team_id1, team_id2, renco_type, 
								   equipes1.team_name AS team1_name, equipes2.team_name AS team2_name, 
								   compet_name, cup_name 
							FROM matchs 
							LEFT JOIN equipes AS equipes1 ON matchs.team_id1 = equipes1.team_id 
							LEFT JOIN equipes AS equipes2 ON matchs.team_id2 = equipes2.team_id 
							LEFT JOIN competition ON matchs.compet_id = competition.compet_id 
							LEFT JOIN competition_cup ON matchs.cup_id = competition_cup.cup_id 
							WHERE (team_id1={$team_id} OR team_id2={$team_id}) AND score1= ' ' ORDER BY timematch LIMIT 1");
		
		$newdate = time();
		$datematch = round(($data['timematch'] - $newdate) / 86400);
		
		if($datematch == 0)
		{
			$datematch = 'aujourd\'hui � ' . date('H:i', $data['timematch']);
		}
		
		else $datematch = 'dans ' . date('d', $datematch) . ' jour(s)';
		
		if($data['renco_type'] == 1)
		{
			if($data['team_id1'] == $team_id) return $data['compet_name'] . ' ' . $datematch . ' : <strong>'.D.'</strong>&nbsp;&nbsp;<a href="club.php?zone=public&amp;page=teaminfo&amp;id=' . $data['team_id2'] . '">' . $data['team2_name'] . '</a>';
			else return $data['compet_name'] . ' ' . $datematch . ' : <strong>'.E.'</strong>&nbsp;&nbsp;<a href="club.php?zone=public&amp;page=teaminfo&amp;id=' . $data['team_id1'] . '">' . $data['team1_name'] . '</a>';
		}
		
		elseif($data['renco_type'] == 2)
		{
			if($data['team_id1'] == $team_id) return'match amical ' . $datematch . ' : <strong>'.D.'</strong>&nbsp;&nbsp;<a href="club.php?zone=public&amp;page=teaminfo&amp;id=' . $data['team_id2'] . '">' . $data['team2_name'] . '</a>';
			else return'match amical ' . $datematch . ' : <strong>'.E.'</strong>&nbsp;&nbsp;<a href="club.php?zone=public&amp;page=teaminfo&amp;id=' . $data['team_id1'] . '">' . $data['team1_name'] . '</a>';
		}
	}
	
	//Affichage des message du club
	function mess_interne_choose($date, $ch_1, $ch_2, $ch_3, $ch_4, $ch_5, $mode, $url, $info)
	{
		//$date = date('Y-m-d');
		//$requete = "INSERT INTO equipes_mess_interne(team_id, date, mode) VALUES (0, {$date}, 4)"; 
		//$resultat = mysql_query($requete);
		
		$newdate = explode("-", $date);
		
		if($mode == 1 OR $mode == 2 OR $mode == 3)
		{
			$data = sql::fetch("SELECT team_name FROM equipes WHERE team_id= {$ch_1}");
			$ch_1 = $data['team_name'];
		}
		
		switch($mode)
		{
			//Message de vente ou achat de joueur
			case 1: return date($info['dateformat_choice'], $date) . ' Vous avez acheter <a href="club.php?zone=management&amp;page=joueur&amp;id='.$url.'#view">'.$ch_3.'</a> ' . A . ' '.$ch_1.' ' . POUR . ' '.$ch_2; break;
			case 2: return date($info['dateformat_choice'], $date) . ' Vous avez vendu <a href="club.php?zone=public&amp;page=joueur&amp;id='.$url.'#view">'.$ch_3.'</a> ' . A . ' '.$ch_1.' ' . POUR . ' '.$ch_2; break;
			case 3: return date($info['dateformat_choice'], $date) . ' ' . $ch_1.' � refuser votre offre d\'achat de '.$ch_2.' ' . POUR . ' <a href="club.php?zone=public&amp;page=joueur&amp;id='.$url.'#view">'.$ch_3.'</a>'; break; 
			case 4: return date($info['dateformat_choice'], $date) . ' Vous avez recruter librement <a href="club.php?zone=management&amp;page=joueur&amp;id='.$url.'#view">'.$ch_3.'</a> ' . A . ' '. SANSCLUB; break;
			//Message de la partie auto
			case 5: return date($info['dateformat_choice'], $date) . ' Les salaires des joueurs ont �t� vers�s'; break;
			case 6: return date($info['dateformat_choice'], $date) . ' Il manque un joueur dans votre tactique'; break;
			case 7: return date($info['dateformat_choice'], $date) . ' Votre sponsor � effectuer le versement'; break;
			//Message de validation de fanion
			case 8: return date($info['dateformat_choice'], $date) . ' Votre fanion a �t� accepter'; break;
			case 9: return date($info['dateformat_choice'], $date) . ' Votre fanion a �t� refuser'; break;
			//Message de validation de photo de joueur
			//	ch1: nom joueur/ch2: prenom joueur
			case 10: return date($info['dateformat_choice'], $date) . ' La photo pour '.$ch_1.' '.$ch_2.' a �t� accepter'; break;
			case 11: return date($info['dateformat_choice'], $date) . ' La photo pour '.$ch_1.' '.$ch_2.' a �t� refuser'; break;
			//Message de bienvenue
			case 12: return date($info['dateformat_choice'], $date) . ' Bienvenue dans votre club ' . $info['coach_name'] . ' !'; break;
			
			default : return 'error'; break;
		}
	}
	
	//Affichage du message sur les sponsors en page d'accueil et page sponsor
	function viewsponsor($sponsor_name, $sponsor_money)
	{
		if(isset($sponsor_name)) return CONTRA1 . ' ' . $sponsor_name . ' ' . CONTRA2 . ' ' . $sponsor_money . ' ' . CONTRA3;
		else return NOSPONSORS;
	}
	
	//Choix match amical du joueur en page d'acceuil
	function gestionmatchamical($dmd_id, $team_id, $mode)
	{
		$data = sql::fetch("SELECT dmd_id, timematch, team_dom, team_ext, team_dmd, team_accept, 
								   (SELECT saison_nbr FROM classement WHERE team_id = matchs_amical_demande.team_accept ORDER BY saison_nbr DESC) saison_nbr 
							FROM matchs_amical_demande WHERE dmd_id = {$dmd_id}");
		$team_dom = $data['team_dom']; $team_ext = $data['team_ext'];
		
		if($data['team_accept'] == $team_id)
		{
			if($mode == 'acceptamical')
			{
				$datematch = date('Y-m-d', $data['timematch']);
				
				$requete = sql::insert("INSERT INTO matchs(saison_nbr, timematch, team_id1, team_id2, renco_type) 
										VALUES ({$data['saison_nbr']}, {$data['timematch']}, {$team_dom}, {$team_ext}, '2')"); 
				
				$requete = sql::delete("DELETE FROM matchs_amical_demande 
										WHERE FROM_UNIXTIME(timematch, '%Y-%m-%d') = '{$datematch}' AND (team_dom IN ({$team_dom}, {$team_ext}) OR team_ext IN ({$team_dom}, {$team_ext}))");
			}
			
			else
			{
				$requete = sql::delete("DELETE FROM matchs_amical_demande WHERE dmd_id = {$dmd_id}");
			}
		}
	}
	
	//Choix de la lettre E ou D
	function choosematchextdom($team_id, $team_dom, $team_ext)
	{
		if($team_dom == $team_id) return'<strong>' . D . '</strong>';
		else return'<strong>' . E . '</strong>';
	}
	
	//Capacit� totale du stade
	function capa_stade($stade_infra)
	{
		$trib = explode(';', $stade_infra);
		
		$nb = sql::fetch("SELECT SUM(pla_debout) AS place_debout, 
								 SUM(pla_assise) AS place_assise,
								 SUM(pla_debout_couv) AS place_debout_couverte, 
								 SUM(pla_assise_couv) AS place_assise_couverte 
						  FROM stade WHERE stad_id IN ($trib[0], $trib[1], $trib[2], $trib[3], $trib[4], $trib[5], $trib[6], $trib[7])");
		
		return $nb['place_debout'] + $nb['place_assise'] + $nb['place_debout_couverte'] + $nb['place_assise_couverte'];
	}
	
	//Nombre de joueur de l'�quipe
	function nb_joueur($team_id) 
	{
		$data = sql::fetch("SELECT COUNT(*) AS nb_joueur FROM joueurs WHERE team_id={$team_id}");
		return $data['nb_joueur'];
	}
	
	//Bureau manager > budget___________________________________________________
	
	//Somme de tous les salaires de l'�quipe
	function salaire_joueur_total($team_id)
	{
		$data = sql::fetch("SELECT SUM(salaire) AS salaire_tot FROM joueurs WHERE team_id={$team_id}");
		return $data['salaire_tot'];
		
	}
	
	//Somme de tous les salaires du staff de l'�quipe
	function salaire_staff_total($team_id) 
	{
		$data = sql::fetch("SELECT SUM(staff_salaire) AS salaire_tot FROM staff WHERE team_id={$team_id}");
		if($data['salaire_tot'] != NULL) return $data['salaire_tot'];
		else return 0;
	}

	//Effectif__________________________________________________________
	
	//Affichage de la position du classement
	function position_classement($team_id, $compet_id) 
	{
		$pos = 1;
		
		$req = sql::query("SELECT * 
							FROM classement 
							WHERE compet_id= {$compet_id} 
							  AND MJ != 0 
							ORDER BY saison_nbr DESC, point DESC, BP-BC DESC LIMIT 10");
							
		while($donnees = mysql_fetch_assoc($req))
		{
			if($donnees['team_id'] == $team_id) return $pos;
			else $pos++;
		}
		
		if(!isset($donnees['team_id'])) return '-';
	}

	function colorchoice($color)
	{
		if($color == 1) return'class="homepage_sub_row_3"';
		else return'class="homepage_sub_row_2"';
	}

	function smallposition($pos_group, $pos_name)
	{
			if($pos_group == 1) return '<span style="color:#E56E16;"><strong>' . $pos_name . '</strong></span>';
		elseif($pos_group == 2) return '<span style="color:#1651E5;"><strong>' . $pos_name . '</strong></span>';
		elseif($pos_group == 3) return '<span style="color:#38CC29;"><strong>' . $pos_name . '</strong></span>';
		elseif($pos_group == 4) return '<span style="color:#E51616;"><strong>' . $pos_name . '</strong></span>';
	}

	function info_compo($donnees)
	{
			if($donnees['N1'] == $donnees['player_id']) return'1';
		elseif($donnees['N2'] == $donnees['player_id']) return'2';
		elseif($donnees['N3'] == $donnees['player_id']) return'3';
		elseif($donnees['N4'] == $donnees['player_id']) return'4';
		elseif($donnees['N5'] == $donnees['player_id']) return'5';
		elseif($donnees['N6'] == $donnees['player_id']) return'6';
		elseif($donnees['N7'] == $donnees['player_id']) return'7';
		elseif($donnees['N8'] == $donnees['player_id']) return'8';
		elseif($donnees['N9'] == $donnees['player_id']) return'9';
		elseif($donnees['N10'] == $donnees['player_id']) return'10';
		elseif($donnees['N11'] == $donnees['player_id']) return'11';
		elseif($donnees['N12'] == $donnees['player_id']) return'12';
		elseif($donnees['N13'] == $donnees['player_id']) return'13';
		elseif($donnees['N14'] == $donnees['player_id']) return'14';
		elseif($donnees['N15'] == $donnees['player_id']) return'15';
		else return'';
	}
	
	//Championnat__________________________________________________________
	
	//Affichage de la couleur dans le classement de la page championnat
	function classcolor($classement)
	{
		switch($classement)
		{
			case 1 : return 'class="class_pos1"'; break;
			case 2 : return 'class="class_pos2"'; break;
			case 3 : return 'class="class_pos3"'; break;
			case 4 : return 'class="class_pos4"'; break;
			case 5 : return 'class="class_pos5"'; break;
			case 6 : return 'class="class_pos6"'; break;
			case 7 : return 'class="class_pos7"'; break;
			case 8 : return 'class="class_pos8"'; break;
			case 9 : return 'class="class_pos9"'; break;
			case 10 : return 'class="class_pos10"'; break;
			default : return ''; break;
		}
	}
	
	//Verifie si un joueur qui est dans la tactique est suspendu ou blesser et l'enleve si oui
	function verif_player_ontactik($player_id, $team_id)
	{
		$data = sql::fetch("SELECT * FROM tactiques WHERE id_team = '{$team_id}'"); 
		
		$mess = 0;
		
		if($data['N1'] == $player_id) { sql::update("UPDATE tactiques SET N1 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N2'] == $player_id) { sql::update("UPDATE tactiques SET N2 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N3'] == $player_id) { sql::update("UPDATE tactiques SET N3 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N4'] == $player_id) { sql::update("UPDATE tactiques SET N4 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N5'] == $player_id) { sql::update("UPDATE tactiques SET N5 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N6'] == $player_id) { sql::update("UPDATE tactiques SET N6 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N7'] == $player_id) { sql::update("UPDATE tactiques SET N7 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N8'] == $player_id) { sql::update("UPDATE tactiques SET N8 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N9'] == $player_id) { sql::update("UPDATE tactiques SET N9 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N10'] == $player_id) { sql::update("UPDATE tactiques SET N10 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N11'] == $player_id) { sql::update("UPDATE tactiques SET N11 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N12'] == $player_id) { sql::update("UPDATE tactiques SET N12 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N13'] == $player_id) { sql::update("UPDATE tactiques SET N13 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N14'] == $player_id) { sql::update("UPDATE tactiques SET N14 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['N15'] == $player_id) { sql::update("UPDATE tactiques SET N15 = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['penalty'] == $player_id) { sql::update("UPDATE tactiques SET penalty = NULL WHERE team_id = {$team_id}"); $mess++; }
		if($data['cfranc'] == $player_id) { sql::update("UPDATE tactiques SET cfranc = NULL WHERE team_id = {$team_id}"); $mess++; }
		
		if($mess >= 1) $requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, mode) VALUES ({$team_id}, ".time().", 6)");
	}
	
	//Affichage des notes etoile
	function compare_etoile($player_id, $data, $position)
	{
		if($position == 1)
		{
			$addi = $data['pdballe'] + $data['degagement'] + $data['reflexes'] + $data['influence'];
			$notesansround = $addi / 4;
			$note = round($notesansround);
		}
		
		elseif($position == 2)
		{
			$addi = $data['marquage'] + $data['tacles'] + $data['degagement'] + $data['tete'];
			$notesansround = $addi / 4;
			$note = round($notesansround);
		}
		
		elseif($position == 3)
		{
			$addi = $data['centres'] + $data['passes'] + $data['vitesse'] + $data['tir'];
			$notesansround = $addi / 4;
			$note = round($notesansround);
		}
		
		elseif($position == 4)
		{
			$addi = $data['tir'] + $data['creativite'] + $data['tete'] + $data['dribble'];
			$notesansround = $addi / 4;
			$note = round($notesansround);
		}
		
		switch($note)
		{
			case 0: return '<img src="images/icone/0star.png" width="54" height="10" alt="0" border="0" />'; break;
			case 1: return '<img src="images/icone/0-1star.png" width="54" height="10" alt="1" border="0" />'; break;
			case 2: return '<img src="images/icone/0-1star.png" width="54" height="10" alt="2" border="0" />'; break;
			case 3: return '<img src="images/icone/1star.png" width="54" height="10" alt="3" border="0" />'; break;
			case 4: return '<img src="images/icone/1star.png" width="54" height="10" alt="4" border="0" />'; break;
			case 5: return '<img src="images/icone/1-2star.png" width="54" height="10" alt="5" border="0" />'; break;
			case 6: return '<img src="images/icone/1-2star.png" width="54" height="10" alt="6" border="0" />'; break;
			case 7: return '<img src="images/icone/2star.png" width="54" height="10" alt="7" border="0" />'; break;
			case 8: return '<img src="images/icone/2star.png" width="54" height="10" alt="8" border="0" />'; break;
			case 9: return '<img src="images/icone/2-3star.png" width="54" height="10" alt="9" border="0" />'; break;
			case 10: return '<img src="images/icone/2-3star.png" width="54" height="10" alt="10" border="0" />'; break;
			case 11: return '<img src="images/icone/3star.png" width="54" height="10" alt="11" border="0" />'; break;
			case 12: return '<img src="images/icone/3star.png" width="54" height="10" alt="12" border="0" />'; break;
			case 13: return '<img src="images/icone/3-4star.png" width="54" height="10" alt="13" border="0" />'; break;
			case 14: return '<img src="images/icone/3-4star.png" width="54" height="10" alt="14" border="0" />'; break;
			case 15: return '<img src="images/icone/4star.png" width="54" height="10" alt="15" border="0" />'; break;
			case 16: return '<img src="images/icone/4star.png" width="54" height="10" alt="16" border="0" />'; break;
			case 17: return '<img src="images/icone/4-5star.png" width="54" height="10" alt="17" border="0" />'; break;
			case 18: return '<img src="images/icone/4-5star.png" width="54" height="10" alt="18" border="0" />'; break;
			case 19: return '<img src="images/icone/5star.png" width="54" height="10" alt="19" border="0" />'; break;
			case 20: return '<img src="images/icone/5star.png" width="54" height="10" alt="20" border="0" />'; break;
			default : return 'Inconnu'; break;
		}
	}
	
	//Affiche si le joueur est demander > en vente > bless� > suspendu
	function info_effect($blessure, $suspension, $vente, $dmd)
	{
			if(isset($dmd)) return'<img src="images/icone/obs.gif" width="22" height="14" />';
		elseif(isset($vente) && $vente == 1) return'<img src="images/icone/ldt.gif" width="22" height="14" />';
		elseif(isset($blessure)) return'<img src="images/icone/blessure.gif" width="22" height="14" />' . $blessure;
		elseif(isset($suspension)) return'<img src="images/icone/crouge.gif" width="22" height="14" />' . $suspension;
	}
	
	/*## Changement de la couleur de police selon la note ##*/
	function notecolor100($note)
	{
			if($note <= 25) 	return'<span style="color:#86CE7F;"><strong>' . $note . '%</strong></span>';
		elseif($note <= 50) 	return'<span style="color:#38CC29;"><strong>' . $note . '%</strong></span>';
		elseif($note <= 75) 	return'<span style="color:#27AA19;"><strong>' . $note . '%</strong></span>';
		elseif($note <= 100) 	return'<span style="color:#138707;"><strong>' . $note . '%</strong></span>';
	}
	
	//Achat joueur_______________________________________________________
	
	//Achat direct d'un joueur sans club
	function joueurachatdirect($player_id, $team_id, $price, $name)
	{
		$last = sql::fetch("SELECT compet_id, saison_nbr FROM classement_joueur WHERE team_id = {$team_id} ORDER BY saison_nbr DESC LIMIT 1");
		
		//On transfert le joueur
		$requete = sql::update("UPDATE joueurs SET team_id = {$team_id}, statut = 0, stamp = ".time()." WHERE player_id = {$player_id}");
		
		//On retire l'argent..
		$requete = sql::update("UPDATE equipes SET team_money = team_money - {$price}  WHERE team_id = {$team_id}");
		
		//On modifie le classement_joueur
		$requete = sql::update("UPDATE classement_joueur 
								SET team_id = {$team_id}, compet_id = {$last['compet_id']}, saison_nbr = {$last['saison_nbr']} 
								WHERE player_id = {$player_id}");
		
		//Ajout dans l'historique du joueur
		$old = sql::fetch("SELECT transfert FROM joueurs_historique WHERE player_id = {$player_id}");
		
		$transfert = $old['transfert'] . ';' . time() . '/' . $team_id . '/' . $price;
		
		$requete = sql::update("UPDATE joueurs_historique SET transfert = '{$transfert}'  WHERE player_id = {$player_id}");
		
		//Message pour l'acheteur
		$requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, ch_1, ch_2, ch_3, mode, url) 
								VALUES ({$team_id}, ".time().", 0, {$price}, '{$name}', 1, {$player_id})"); 
	}
	
	//Vente ou Refus de la vente par le joueur
	function gestionachatdemande($dmd_id, $team_id, $mode)
	{
		$last = sql::fetch("SELECT saison_nbr FROM classement_joueur WHERE team_id = {$team_id} ORDER BY saison_nbr DESC LIMIT 1");
		
		$view = sql::fetch("SELECT * FROM joueurs_achat_demande 
							LEFT JOIN joueurs ON joueurs_achat_demande.player_id = joueurs.player_id 
							LEFT JOIN equipes ON joueurs.team_id = equipes.team_id 
							WHERE dmd_id = {$dmd_id}");
		
		if($view['team_accept'] == $team_id)
		{
			if($mode == 'acceptoffre')
			{
				//On verifie si le joueur est dans la tactique du joueur vendeur => si oui on l'enleve de la tactique
				$this->verif_player_ontactik($view['player_id'], $view['team_accept']);
				
				//On transfert le joueur
				$requete = sql::update("UPDATE joueurs SET team_id = {$view['team_dmd']}, statut = 0, stamp = ".time()." WHERE player_id = {$view['player_id']}");
				
				//On retire l'argent..
				$requete = sql::update("UPDATE equipes SET team_money = team_money - {$view['new_price']}  WHERE team_id = {$view['team_dmd']}");
				
				//...Et on le donne � l'autre �quipe
				$requete = sql::update("UPDATE equipes SET team_money = team_money  + {$view['new_price']}  WHERE team_id = {$view['team_accept']}");
				
				//On modifie le classement_joueur
				$requete = sql::update("UPDATE classement_joueur 
										SET team_id = {$view['team_dmd']}, compet_id = {$view['compet_id']} 
										WHERE player_id = {$view['player_id']} 
										  AND saison_nbr={$last['saison_nbr']}");
				
				//Ajout dans joueur estimation
				$requete = sql::insert("INSERT INTO joueurs_estimation (age, position, talent, pression, influence, agressivite, reflexes, pdballe, degagement, marquage, tacles, tete, centres, passes, vitesse, tir, creativite, dribble, cdp_arrete, valeur)
										VALUES ({$view['age']}, {$view['position']}, {$view['talent']}, {$view['pression']}, 
												'{$view['influence']}', '{$view['agressivite']}', '{$view['reflexes']}', '{$view['pdballe']}', 
												'{$view['degagement']}', '{$view['marquage']}', '{$view['tacles']}', '{$view['tete']}', '{$view['centres']}', 
												'{$view['passes']}', '{$view['vitesse']}', '{$view['tir']}', '{$view['creativite']}', '{$view['dribble']}', 
												'{$view['cdp_arrete']}', {$view['new_price']})");
				
				//Ajout dans l'historique du joueur
				$old = sql::fetch("SELECT transfert FROM joueurs_historique WHERE player_id = {$view['player_id']}");
				
				$transfert = $old['transfert'] . ';' . time() . '/' . $view['team_dmd'] . '/' . $view['new_price'];
				
				$requete = sql::update("UPDATE joueurs_historique SET transfert = '{$transfert}'  WHERE player_id = {$view['player_id']}");
				
				//Ajout de message pour les 2 �quipes
				$ch_1a = $view['team_dmd']; //Equipe achetante
				$ch_1v = $view['team_accept']; //Equipe vendante
				$ch_2 = $view['new_price']; //Somme
				$ch_3 = $view['prenom'] . ' ' . $view['nom']; //Identit� du joueur
				
				//Message pour le vendeur
				$requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, ch_1, ch_2, ch_3, mode, url) 
										VALUES ({$ch_1v}, ".time().", {$ch_1a}, {$ch_2}, '{$ch_3}', 2, {$view['player_id']})"); 
				
				//Message pour l'acheteur
				$requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, ch_1, ch_2, ch_3, mode, url) 
										VALUES ({$ch_1a}, ".time().", {$ch_1v}, {$ch_2}, '{$ch_3}', 1, {$view['player_id']})"); 
				
				//On enleve toutes les demandes de ce joueurs
				$requete = sql::delete("DELETE FROM joueurs_achat_demande WHERE player_id = {$view['player_id']}");
			}
			
			else
			{
				//Ajout de message pour les 2 �quipes
				$ch_1a = $view['team_dmd']; //Equipe achetante
				$ch_1v = $view['team_accept']; //Equipe vendante
				$ch_2 = $view['new_price']; //Somme
				$ch_3 = $view['prenom'] . ' ' . $view['nom']; //Identit� du joueur
				
				//Message pour l'acheteur
				$requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, ch_1, ch_2, ch_3, mode, url) 
										VALUES ({$ch_1a}, ".time().", {$ch_1v}, {$ch_2}, '{$ch_3}', 3, {$view['player_id']})"); 
				
				//On enleve la demande pour ce joueur
				$requete = sql::delete("DELETE FROM joueurs_achat_demande WHERE dmd_id = {$dmd_id}");
			}
		}
	}
}
?>