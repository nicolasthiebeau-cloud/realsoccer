<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
15/05/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

class match_apl
{
	function meteo()
	{
		srand ((double) microtime() * 10000000); 
		$input = array ('meteo1', 'meteo2', 'meteo3', 'meteo4', 'meteo5', 'meteo6', 'meteo7', 'meteo8', 'meteo9');
		$rand_keys = array_rand ($input, 2); 
		return $input[$rand_keys[0]];
	}
	
	function stade($stade_infra, $renco_type, $team_id1, $team_id2, $meteo, $CONF)
	{
		$trib = explode(';', $stade_infra);
		
		$infotribune = sql::fetch("SELECT SUM(pla_debout) AS place_debout, 
										  SUM(pla_assise) AS place_assise, 
										  SUM(pla_debout_couv) AS place_debout_couverte, 
										  SUM(pla_assise_couv) AS place_assise_couverte, 
										  SUM(tribune_presi) AS tribune_presidentielle, 
										  SUM(buvette) AS buvette 
								   FROM stade WHERE stad_id IN ('".$trib[0]."', '".$trib[1]."', '".$trib[2]."', '".$trib[3]."', '".$trib[4]."', '".$trib[5]."', '".$trib[6]."', '".$trib[7]."')");
		
		if($renco_type == 2) //Si match amical, on divise la somme par deux et on partage l'argent entre les 2 clubs.
		{
			$money1 = $infotribune['place_debout'] * $CONF['place_debout'];
			$money2 = $infotribune['place_assise'] * $CONF['place_assise'];
			$money3 = $infotribune['place_debout_couverte'] * $CONF['place_debout_couverte']; 
			$money4 = $infotribune['place_assise_couverte'] * $CONF['place_assise_couverte'];
			$money5 = $infotribune['tribune_presidentielle'] * $CONF['tribune_presidentielle']; 
			$money6 = $infotribune['buvette'] * ($CONF['buvette'] * ($money1 + $money2 + $money3 + $money4 + $money5));
			
			//Affluence al�atoire
			$rand_afflu = '0.' . rand(4,8);
			
			$moneyplus = $rand_afflu * ($money1 + $money2 + $money3 + $money4 + $money5 + $money6);
			return $rand_afflu * ($infotribune['place_debout'] + $infotribune['place_assise'] + $infotribune['place_debout_couverte'] + $infotribune['place_assise_couverte'] + $infotribune['tribune_presidentielle']);
			
			$divmoneyplus = $moneyplus / 2;
			
			//On ajoute la recette du match au 2 �quipes
			$requete = sql::update("UPDATE equipes 
									SET team_money = team_money + ".round($divmoneyplus)." 
									WHERE team_id IN ('".$team_id1."', '".$team_id2.")");
		}
		
		else
		{
			$money1 = $infotribune['place_debout'] * $CONF['place_debout'];
			$money2 = $infotribune['place_assise'] * $CONF['place_assise'];
			$money3 = $infotribune['place_debout_couverte'] * $CONF['place_debout_couverte']; 
			$money4 = $infotribune['place_assise_couverte'] * $CONF['place_assise_couverte'];
			$money5 = $infotribune['tribune_presidentielle'] * $CONF['tribune_presidentielle']; 
			$money6 = $infotribune['buvette'] * ($CONF['buvette'] * ($money1 + $money2 + $money3 + $money4 + $money5));
			
			//Affluence du stade selon la m�t�o
			if($meteo == 'meteo7' OR $meteo == 'meteo8' OR $meteo == 'meteo9') $rand_afflu = '0.' . rand(5,9);
			elseif($meteo == 'meteo3' OR $meteo == 'meteo5' OR $meteo == 'meteo6') $rand_afflu = '0.' . rand(7,9);
			else $rand_afflu = '0.' . rand(8,99);
			
			$moneyplus = $rand_afflu * ($money1 + $money2 + $money3 + $money4 + $money5 + $money6);
			return $rand_afflu * ($infotribune['place_debout'] + $infotribune['place_assise'] + $infotribune['place_debout_couverte'] + $infotribune['place_assise_couverte'] + $infotribune['tribune_presidentielle']);
			
			//On ajoute la recette du match � l'�quipe jouant � domicile
			$requete = sql::update("UPDATE equipes 
									SET team_money = team_money + '".round($moneyplus)."' 
									WHERE team_id = '".$team_id1."'");
		}
	}

	function arbitre($pays_file_nom, $pays_file_prenom, $pays_flag)
	{
		// Choix d'une liste de nom al�atoire selon le pays
		if ($pays_file_nom != NULL) $sourcefile = 'txt' . '/' . $pays_file_nom;
		else $sourcefile = 'txt' . '/' . 'nom_france.txt';
		$bddfile = fopen($sourcefile, "r");
		$bddarray = array(); // Cr�ation du tableau qui contiendra toutes les phrases
		while ( $line = fgets($bddfile) ) { array_push($bddarray, $line); }// On la rajoute au tableau
		fclose ($bddfile); // On ferme le fichier
		srand((double)microtime(2) * 1000000) ;
		$arb_nom = $bddarray[rand(0, count($bddarray)-1)];
		
		// Choix d'une liste de pr�nom al�atoire selon le pays(pays_id)
		if ($pays_file_prenom != NULL) $sourcefile = 'txt' . '/' . $pays_file_prenom;
		else $sourcefile = 'txt' . '/' . 'prenom_france.txt';
		$bddfile = fopen($sourcefile, "r");
		$bddarray = array(); // Cr�ation du tableau qui contiendra toutes les phrases
		while ( $line = fgets($bddfile) ) { array_push($bddarray, $line); }// On la rajoute au tableau
		fclose ($bddfile); // On ferme le fichier
		srand((double)microtime(2) * 1000000) ;
		$arb_prenom = $bddarray[rand(0, count($bddarray)-1)];
		
		return $pays_flag . ';' . $arb_prenom . ' ' . $arb_nom;
	}

	function prmslettre($mot) //On affiche la premiere lettre du pr�nom
	{
		$new_chaine = chunk_split($mot, 1, " ");
		$lettre = explode(" ", $new_chaine);
		return $lettre[0] . '.';
	}

	function note($position, $forme, $moral, $talent, $influence, $reflexes, $pdballe, $degagement, $marquage, $tacles, $tete, $centres, $passes, $vitesse, $tir, $creativite, $dribble)
	{
		if($position == 1) return $forme + $moral + $talent + $pdballe + $reflexes + $degagement + $influence;
		elseif($position == 2) return $forme + $moral + $talent + $marquage + $tacles + $degagement + $tete;
		elseif($position == 3) return $forme + $moral + $talent + $centres + $passes + $vitesse + $tir;
		elseif($position == 4) return $forme + $moral + $talent + $tir + $creativite + $tete + $dribble;
	}

	function recup_randplayer($team_id, $player1, $player2, $player3, $player4, $player5, $player6, $player7, $player8, $player9, $player10, $player11)
	{
		return sql::fetch("SELECT player_id, nom, prenom, position, forme, moral, talent, influence, reflexes, 
								  pdballe, degagement, marquage, tacles, tete, centres, passes, vitesse, tir, 
								  creativite, dribble 
						   FROM joueurs 
						   WHERE player_id NOT IN ({$player1}, {$player2}, {$player3}, {$player5}, {$player6}, {$player7}, {$player8}, {$player9}, {$player10}, {$player11}) 
							 AND team_id = {$team_id} 
							 AND indisponible = 0 
						   ORDER BY rand() 
						   LIMIT 1");
	}
	
	function choice_eqp($difference) //Choix de l'�quipe qui jouera l'action
	{
		$occasion = rand(1,10);
		
		//Ratio d'action
		if ($difference >= 0 && $difference <= 10)
		{
			switch($occasion)
			{
				case 1: return'eqp+'; break;
				case 2: return'eqp+'; break;
				case 3: return'eqp+'; break;
				case 4: return'eqp+'; break;
				case 5: return'nocaz'; break;
				case 6: return'nocaz'; break;
				case 7: return'eqp-'; break;
				case 8: return'eqp-'; break;
				case 9: return'eqp-'; break;
				case 10: return'eqp-'; break;
				default : return 'error'; break;
			}
		}
		
		elseif ($difference >= 11 && $difference <= 25)
		{
			switch($occasion)
			{
				case 1: return'eqp+'; break;
				case 2: return'eqp+'; break;
				case 3: return'eqp+'; break;
				case 4: return'eqp+'; break;
				case 5: return'nocaz'; break;
				case 6: return'nocaz'; break;
				case 7: return'nocaz'; break;
				case 8: return'eqp-'; break;
				case 9: return'eqp-'; break;
				case 10: return'eqp-'; break;
				default : return 'error'; break;
			}
		}
		
		elseif ($difference >= 26 && $difference <= 35)
		{
			switch($occasion)
			{
				case 1: return'eqp+'; break;
				case 2: return'eqp+'; break;
				case 3: return'eqp+'; break;
				case 4: return'eqp+'; break;
				case 5: return'eqp+'; break;
				case 6: return'nocaz'; break;
				case 7: return'nocaz'; break;
				case 8: return'nocaz'; break;
				case 9: return'eqp-'; break;
				case 10: return'eqp-'; break;
				default : return 'error'; break;
			}
		}
		
		elseif ($difference >= 36 && $difference <= 50)
		{
			switch($occasion)
			{
				case 1: return'eqp+'; break;
				case 2: return'eqp+'; break;
				case 3: return'eqp+'; break;
				case 4: return'eqp+'; break;
				case 5: return'eqp+'; break;
				case 6: return'nocaz'; break;
				case 7: return'nocaz'; break;
				case 8: return'nocaz'; break;
				case 9: return'eqp-'; break;
				case 10: return'eqp-'; break;
				default : return 'error'; break;
			}
		}
		
		elseif ($difference >= 51 && $difference <= 75)
		{
			switch($occasion)
			{
				case 1: return'eqp+'; break;
				case 2: return'eqp+'; break;
				case 3: return'eqp+'; break;
				case 4: return'eqp+'; break;
				case 5: return'eqp+'; break;
				case 6: return'eqp+'; break;
				case 7: return'nocaz'; break;
				case 8: return'nocaz'; break;
				case 9: return'eqp-'; break;
				case 10: return'eqp-'; break;
				default : return 'error'; break;
			}
		}
		
		else
		{
			switch($occasion)
			{
				case 1: return'eqp+'; break;
				case 2: return'eqp+'; break;
				case 3: return'eqp+'; break;
				case 4: return'eqp+'; break;
				case 5: return'eqp+'; break;
				case 6: return'eqp+'; break;
				case 7: return'nocaz'; break;
				case 8: return'nocaz'; break;
				case 9: return'nocaz'; break;
				case 10: return'eqp-'; break;
				default : return 'error'; break;
			}
		}
	}

	//Action Passes_____________________________________

	function passe_zone2($renco_id, $bloqueur, $passeur)
	{
		//On compare passeur(passe + talent - pression) <> et bloqueur (passe + talent + pression)
		$score_passeur = $passeur['talent'] + $passeur['pression'] + $passeur['passes'];
		$score_bloqueur = $bloqueur['talent'] + $bloqueur['pression'] + $bloqueur['tacles'];
		
		if($score_passeur > $score_bloqueur) //Si passeur sup�rieur
		{
			$agress_bloqueur = $bloqueur['agressivite'] + $bloqueur['tacles'];
			
			
			// >= 35 : function faute : type 1, 2, 3, function contre, function action d�fensive
			if($agress_bloqueur >= 35)
			{
				$secret = rand(1,3);
				$passe_zone2_choice = rand(1,3);
					if($passe_zone2_choice == 1) return'faute_pet';
				elseif($passe_zone2_choice == 2 AND $secret == 3) return'contre';
				else							 return'action_def';
			}
			
			// >= 25 : function faute : type 1, 2, 3, function contre, function action d�fensive
			elseif($agress_bloqueur >= 25)
			{
				$secret = rand(1,4);
				$passe_zone2_choice = rand(1,4);
					if($passe_zone2_choice == 1) return'faute_pet';
				elseif($passe_zone2_choice == 2 AND $secret == 3) return'contre';
				else							 return'action_def';
			}
			
			// >= 15 : function faute : type 1, 2, 3, function contre, function action d�fensive
			elseif($agress_bloqueur >= 15)
			{
				$secret = rand(1,5);
				$passe_zone2_choice = rand(1,5);
					if($passe_zone2_choice == 1) return'faute_pet';
				elseif($passe_zone2_choice == 2 AND $secret == 3) return'contre';
				else							 return'action_def';
			}
			
			// sinon : function faute : type 1, 2, 3, function contre, function action d�fensive
			else
			{
				$secret = rand(1,6);
				$passe_zone2_choice = rand(1,6);
					if($passe_zone2_choice == 1) return'faute_pet';
				elseif($passe_zone2_choice == 2 AND $secret == 3) return'contre';
				else							 return'action_def';
			}
		}
		
		else //Sinon => commentaire passe manqu�
		{
			return'pass_manquer';
		}
	}

	function passe_zone3($renco_id, $passeur, $bloqueur)
	{
		//On compare passeur(passe + talent - pression) <> et bloqueur (passe + talent + pression)
		$score_passeur = $passeur['talent'] + $passeur['pression'] + $passeur['passes'];
		$score_bloqueur = $bloqueur['talent'] + $bloqueur['pression'] + $bloqueur['tacles'];
		
		if($score_passeur >= $score_bloqueur) //Si passeur sup�rieur
		{
			//Si bloqueur(agressivit� + pression) et ...
			$agress_bloqueur = $bloqueur['agressivite'] + $bloqueur['tacles'];
			$secret = rand(1,3);
			
			// >= 35 : function faute, function faute moyenne, function faute grave : type 1, 2, 3, function action offensive
			if($agress_bloqueur >= 35)
			{
				$passe_zone3_choice = rand(1,5);
					if($passe_zone3_choice == 1) return'action_off';
				elseif($passe_zone3_choice == 2) return'faute_moy';
				elseif($passe_zone3_choice == 3 AND $secret = 3) return'faute_gro';
				else							 return'faute_pet';
			}
			
			// >= 25 : function faute, function faute moyenne, function faute grave : type 1, 2, 3, function action offensive
			elseif($agress_bloqueur >= 25)
			{
				$passe_zone3_choice = rand(1,6);
					if($passe_zone3_choice == 1) return'action_off';
				elseif($passe_zone3_choice == 2 AND $secret == 3) return'faute_moy';
				elseif($passe_zone3_choice == 3 AND $secret == 3) return'faute_gro';
				else							 return'faute_pet';
			}
			
			// >= 15 : function faute,  function faute moyenne : type 1, 2, 3, function action offensive
			elseif($agress_bloqueur >= 15)
			{
				$passe_zone3_choice = rand(1,4);
					if($passe_zone3_choice == 1) return'action_off';
				elseif($passe_zone3_choice == 2 AND $secret == 3) return'faute_moy';
				elseif($passe_zone3_choice == 3) return'tacle';
				else							 return'faute_pet';
			}
			
			// sinon : function faute : type 1, function action offensive
			else
			{
				$passe_zone3_choice = rand(1,3);
					if($passe_zone3_choice == 1) return'action_off';
				elseif($passe_zone3_choice == 2) return'tacle';
				else							 return'faute_pet';
			}
		}
		
		else //Sinon => commentaire passe manqu�
		{
			return'pass_manquer';
		}
	}

	function passe_zone4($renco_id, $passeur, $bloqueur)
	{
		//On compare passeur(passes + talent - pression) <> et bloqueur (tacles + talent + pression)
		$score_passeur = $passeur['talent'] + $passeur['pression'] + $passeur['passes'];
		$score_bloqueur = $bloqueur['talent'] + $bloqueur['pression'] + $bloqueur['tacles'];
		
		if($score_passeur >= $score_bloqueur) //Si passeur sup�rieur
		{
			//Si bloqueur(agressivit� + pression) et ...
			$agress_bloqueur = $bloqueur['agressivite'] + $bloqueur['tacles'];
			$secret = rand(1,3);
			$bless = rand(1,80);
			
			// >= 35 : function faute, function faute moyenne, function faute grave : type 1, 2, 3, function action offensive
			if($agress_bloqueur >= 35)
			{
				$passe_zone3_choice = rand(1,5);
					if($passe_zone3_choice == 1) return'action_off';
				elseif($passe_zone3_choice == 2) return'faute_moy';
				elseif($passe_zone3_choice == 3 AND $secret = 3) return'faute_gro';
				elseif($passe_zone3_choice == 4 AND $passeur['forme'] < $bless) return'blessure';
				else							 return'faute_pet';
			}
			
			// >= 25 : function faute, function faute moyenne, function faute grave : type 1, 2, 3, function action offensive
			elseif($agress_bloqueur >= 25)
			{
				$passe_zone3_choice = rand(1,6);
					if($passe_zone3_choice == 1) return'action_off';
				elseif($passe_zone3_choice == 2 AND $secret == 3) return'faute_moy';
				elseif($passe_zone3_choice == 3 AND $secret == 3) return'faute_gro';
				elseif($passe_zone3_choice == 4 AND $pass_comp4 < $bless) return'blessure';
				else							 return'faute_pet';
			}
			
			// >= 15 : function faute,  function faute moyenne : type 1, 2, 3, function action offensive
			elseif($agress_bloqueur >= 15)
			{
				$passe_zone3_choice = rand(1,4);
					if($passe_zone3_choice == 1) return'action_off';
				elseif($passe_zone3_choice == 2 AND $secret == 3) return'faute_moy';
				elseif($passe_zone3_choice == 3) return'tacle';
				else							 return'faute_pet';
			}
			
			// sinon : function faute : type 1, function action offensive
			else
			{
				$passe_zone3_choice = rand(1,3);
					if($passe_zone3_choice == 1) return'action_off';
				elseif($passe_zone3_choice == 2) return'tacle';
				else							 return'faute_pet';
			}
		}
		
		else //Sinon => commentaire passe manqu�
		{
			return'pass_manquer';
		}
		
		//Ajout de la fatigue de l'action
	}

	//Action Offensive_____________________________________

	function compare_gardien_tireur($team_id1, $team_id2, $score1, $score2, $gardien, $tireur, $mode) //On compare le tireur au gardien
	{
		$note_gardien = ($gardien['forme'] + $gardien['moral'] + $gardien['talent'] + $gardien['reflexes'] + $gardien['pdballe']) - $gardien['pression'];
		
		if($mode == 'cfranc') 	   $note_tireur = ($tireur['forme'] + $tireur['moral'] + $tireur['talent'] + $tireur['centres'] + $tireur['cdp_arrete']) - $tireur['pression'];
		elseif($mode == 'penalty') $note_tireur = ($tireur['forme'] + $tireur['moral'] + $tireur['talent'] + $tireur['tir'] + $tireur['cdp_arrete']) - $tireur['pression'];
		elseif($mode == 'tir') 	   $note_tireur = ($tireur['forme'] + $tireur['moral'] + $tireur['talent'] + $tireur['tir'] + $tireur['creativite']) - $tireur['pression'];
		
		srand ((double) microtime() * 10000000);
		
		if ($note_gardien >= $note_tireur)
		{
				if($gardien['team_id'] == $team_id1 AND $score2 <= 2) $input = array ('nobut', 'nobut', 'nobut', 'but', 'but'); // 3 nobut / 2 but
			elseif($gardien['team_id'] == $team_id1 AND $score2 <= 4) $input = array ('nobut', 'nobut', 'nobut', 'but', 'nobut'); // 4 nobut / 1 but
			elseif($gardien['team_id'] == $team_id1 AND $score2 <= 6) $input = array ('nobut', 'nobut', 'nobut', 'but', 'nobut'); // 4 nobut / 1 but
			
			elseif($gardien['team_id'] == $team_id2 AND $score1 <= 2) $input = array ('nobut', 'nobut', 'nobut', 'but', 'but'); // 3 nobut / 2 but
			elseif($gardien['team_id'] == $team_id2 AND $score1 <= 4) $input = array ('nobut', 'nobut', 'nobut', 'but', 'nobut'); // 4 nobut / 1 but
			elseif($gardien['team_id'] == $team_id2 AND $score1 <= 6) $input = array ('nobut', 'nobut', 'nobut', 'but', 'nobut'); // 4 nobut / 1 but
			else $input = array ('nobut', 'nobut', 'nobut', 'but', 'nobut'); // 5 nobut / 0 but
		}
		
		elseif ($note_gardien < $note_tireur)
		{
				if($tireur['team_id'] == $team_id1 AND $score1 <= 2) $input = array ('nobut', 'but', 'but', 'but', 'nobut'); // 2 nobut / 3 but
			elseif($tireur['team_id'] == $team_id1 AND $score1 <= 4) $input = array ('nobut', 'but', 'but', 'nobut', 'nobut'); // 3 nobut / 2 but
			elseif($tireur['team_id'] == $team_id1 AND $score1 <= 6) $input = array ('nobut', 'but', 'nobut', 'nobut', 'nobut'); // 4 nobut / 1 but
			
			elseif($tireur['team_id'] == $team_id2 AND $score2 <= 2) $input = array ('nobut', 'but', 'but', 'but', 'nobut'); // 2 nobut / 3 but
			elseif($tireur['team_id'] == $team_id2 AND $score2 <= 4) $input = array ('nobut', 'but', 'but', 'nobut', 'nobut'); // 3 nobut / 2 but
			elseif($tireur['team_id'] == $team_id2 AND $score2 <= 6) $input = array ('nobut', 'but', 'nobut', 'nobut', 'nobut'); // 4 nobut / 1 but
			else $input = array ('nobut', 'nobut', 'nobut', 'but', 'nobut'); // 5 nobut / 0 but
		}
		
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}

	function random_commentaire_attaque_reussi() //Random commentaire attaque r�ussi
	{
		srand ((double) microtime() * 10000000); $input = array (1, 2, 3, 4, 5, 6);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}

	function random_commentaire_attaque_manquer() //Random commentaire attaque manquer
	{
		srand ((double) microtime() * 10000000); $input = array (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}

	function random_commentaire_contreattaque_reussi() //Random commentaire contre attaque r�ussi
	{
		srand ((double) microtime() * 10000000); $input = array (1, 2, 3, 4, 5, 6);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}

	function random_commentaire_contreattaque_manquer() //Random commentaire contre attaque manquer
	{
		srand ((double) microtime() * 10000000); $input = array (1, 2, 3, 4, 5, 6);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}
	
	function ajout_commentaire($mi_temps, $arretdejeu, $comletter, $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien, $defenseur1, $commentinfo, $ratio, $teamchoice, $mode)
	{
		if($teamchoice == 1 AND $ratio == 'eqp+' OR $teamchoice == 2 AND $ratio == 'eqp-') 
		{ 
			$score = ++$score1 . '-' . $score2; 
			$color = 1; 
		}
		else 
		{ 
			$score = $score1 . '-' . ++$score2; 
			$color = 2; 
		}
		
			if($mode == 0) $commentinfo .= ';' . $mi_temps . $comletter . $num . '_' . $score . '_' . $teamatk . '_' . $teamdef . '_' . $attaquant1 . '/' . $attaquant2 . '_' . $gardien . '/' . $defenseur1 . '_' . $color;
		elseif($mode == 1) $commentinfo .= ';' . $mi_temps . '+' . $arretdejeu . $comletter . $num . '_' . $score . '_' . $teamatk . '_' . $teamdef . '_' . $attaquant1 . '/' . $attaquant2 . '_' . $gardien . '/' . $defenseur1 . '_' . $color;
		
		return $commentinfo;
	}
	
	function ajout_eq_info($mi_temps, $attaquant1, $eq_info)
	{
		//Ajout du buteur � la variable
		$eq_info .= '/' . $attaquant1 . '/' . $mi_temps;
		
		return $eq_info;
	}

	function classement_buteur($compet_id, $renco_id, $renco_type, $saison_nbr, $attaquant1, $teamatk)
	{
		if($renco_type == 1) //Si c'est une rencontre de championnat
		{
			//PARTIE BUTEUR - On update le buteur________________________
			$requete = "UPDATE classement_joueur SET champ_but = champ_but + 1 WHERE player_id='".$attaquant1."' AND team_id= '".$teamatk."' AND saison_nbr = '".$saison_nbr."'";
			$resultat = mysql_query($requete);
		}
		
		elseif($renco_type == 2) //Si c'est une rencontre amical
		{
			//PARTIE BUTEUR - On update le buteur________________________
			$requete = "UPDATE classement_joueur SET hcomp_but = hcomp_but + 1 WHERE player_id='".$attaquant1."' AND team_id= '".$teamatk."' AND saison_nbr = '".$saison_nbr."'";
			$resultat = mysql_query($requete);
		}
	}

	function classement_passeur($compet_id, $renco_id, $renco_type, $saison_nbr, $attaquant2, $teamatk) //Ajout au classement des passeurs
	{
		if($renco_type == 1) //Si c'est une rencontre de championnat
		{
			//PARTIE PASSEUR - On update le passeur______________________
			$requete = "UPDATE classement_joueur SET champ_pasdec = champ_pasdec + 1 WHERE player_id='".$attaquant2."' AND team_id= '".$teamatk."' AND saison_nbr = '".$saison_nbr."'";
			$resultat = mysql_query($requete);
		}
		
		elseif($renco_type == 2) //Si c'est une rencontre amical
		{
			//PARTIE BUTEUR - On update le buteur________________________
			$requete = "UPDATE classement_joueur SET hcomp_pasdec = hcomp_pasdec + 1 WHERE player_id='".$attaquant2."' AND team_id= '".$teamatk."' AND saison_nbr = '".$saison_nbr."'";
			$resultat = mysql_query($requete);
		}
	}

	//Faute Simple_____________________________________

	function random_faute_simple($zone_select) //Random des fautes simple selon les zones
	{
		srand ((double) microtime() * 10000000); 
			if($zone_select == 2) $input = array (1, 4, 5);
		elseif($zone_select == 3) $input = array (1, 3, 4, 5);
		elseif($zone_select == 4) $input = array (1, 2, 3, 4, 5);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}

	function recuptireurcfranc($teamatk, $team_id1, $team_id2, $cfranc1, $cfranc2) //Recuperation du tireur de coup franc (s'il existe)
	{
		if($teamatk == $team_id1) $tireur = $cfranc1; else $tireur = $cfranc2;
		if (isset($tireur) && $tireur != NULL) return $tireur; else return'noplayer';
	}

	function random_commentaire_faute_simple() //Random commentaire faute simple
	{
		srand ((double) microtime() * 10000000); $input = array (1, 2, 3);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}

	//Faute Moyenne_____________________________________

	function verif_carton_jaune($player, $carton_jaune) //Verifie si le joueur � d�j� un carton
	{
		$carton = explode('/', $carton_jaune);
		$nb_carton = count($carton); 
		$nb = 0; 
		$dejacarton = 0;
		
		while($nb_carton > $nb)
		{
			if($player == $carton[$nb]) $dejacarton++; $nb++;
		}
		
		if ($dejacarton >= 1) return'dejacarton'; else return'pascarton';
	}

	function expulsejoueur($defenseur1, $joueur_eq)
	{
		
		$pl = explode(";", $joueur_eq);
		$nb = count($pl); $nb--;

		for($tot = 0; $tot <= $nb; $tot++)
		{
			if($pl[$tot] != $defenseur1) $new_joueur_eq[] = $pl[$tot];
		}

		$new_joueur_eq = implode(";", $new_joueur_eq);
		
		return $new_joueur_eq;
	}

	function equip_expulsion_doublecarton_jaune($saison_nbr, $defenseur1, $renco_type, $team_id) //Expulsion du joueur (2eme carton jaune)
	{
		if($renco_type == 1) //Si c'est une rencontre de championnat
		{
			$requete = sql::update("UPDATE classement_joueur SET champ_crouge = champ_crouge + 1 WHERE player_id='".$defenseur1."' AND team_id= '".$team_id."' AND saison_nbr = '".$saison_nbr."'");
		}
		
		elseif($renco_type == 2) //Si c'est une rencontre amical
		{
			$requete = sql::update("UPDATE classement_joueur SET hcomp_crouge = hcomp_crouge + 1 WHERE player_id='".$defenseur1."' AND team_id= '".$team_id."' AND saison_nbr = '".$saison_nbr."'");
		}
	}

	function random_faute_moyenne($zone_select) //Random des fautes moyenne
	{
		srand ((double) microtime() * 10000000); 
			if($zone_select == 2) $input = array (1, 5, 6);
		elseif($zone_select == 3) $input = array (1, 3, 5, 6);
		elseif($zone_select == 4) $input = array (1, 2, 3, 4, 5, 6);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}

	function recuptireurpenalty($teamatk, $team_id1, $team_id2, $penalty1, $penalty2) //Recuperation du tireur de p�nalty (s'il existe)
	{
		if($teamatk == $team_id1) $tireur = $penalty1; else $tireur = $penalty2;
		if (isset($tireur) && $tireur != NULL) return $tireur; else return'noplayer';
	}

	function random_commentaire_faute_moyenne() //Random commentaire faute moyenne
	{
		srand ((double) microtime() * 10000000); $input = array (1, 2, 3);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}

	function equip_ajout_carton_jaune($saison_nbr, $defenseur1, $renco_type, $team_id) //Carton jaune
	{
		if($renco_type == 1) //Si c'est une rencontre de championnat
		{
			$requete = sql::update("UPDATE classement_joueur SET champ_cjaune = champ_cjaune + 1 WHERE player_id='".$defenseur1."' AND team_id= '".$team_id."' AND saison_nbr = '".$saison_nbr."'");
		}
		
		elseif($renco_type == 2) //Si c'est une rencontre amical
		{
			$requete = sql::update("UPDATE classement_joueur SET hcomp_cjaune = hcomp_cjaune + 1 WHERE player_id='".$defenseur1."' AND team_id= '".$team_id."' AND saison_nbr = '".$saison_nbr."'");
		}
	}

	//Faute Grave_______________________________________
	
	function equip_expulsion_carton_rouge($saison_nbr, $defenseur1, $renco_type, $team_id) //Expulsion du joueur (carton rouge)
	{
		if($renco_type == 1) //Si c'est une rencontre de championnat
		{
			$requete = sql::update("UPDATE classement_joueur SET champ_crouge = champ_crouge + 1 WHERE player_id='".$defenseur1."' AND team_id= '".$team_id."' AND saison_nbr = '".$saison_nbr."'");
		}
		
		elseif($renco_type == 2) //Si c'est une rencontre amical
		{
			$requete = sql::update("UPDATE classement_joueur SET hcomp_crouge = hcomp_crouge + 1 WHERE player_id='".$defenseur1."' AND team_id= '".$team_id."' AND saison_nbr = '".$saison_nbr."'");
		}
	}

	function random_faute_grave($zone_select) //Random des fautes grave
	{
		srand ((double) microtime() * 10000000); 
			if($zone_select == 2) $input = array (1, 5, 6);
		elseif($zone_select == 3) $input = array (1, 3, 5, 6);
		elseif($zone_select == 4) $input = array (1, 2, 3, 4, 5, 6);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}

	function random_commentaire_faute_grave() //Random commentaire faute grave
	{
		srand ((double) microtime() * 10000000); $input = array (1, 2, 3);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}

	//Tacle____________________________________________

	function random_commentaire_tacle() //Random commentaire tacle
	{
		srand ((double) microtime() * 10000000); $input = array (1, 2, 3, 4, 5, 6);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}

	//Passe Manquer______________________________________

	function random_commentaire_passe_manquer() //Random commentaire passe manquer
	{
		srand ((double) microtime() * 10000000); $input = array (1, 2, 3, 4, 5, 6);
		$rand_keys = array_rand ($input, 2); return $input[$rand_keys[0]];
	}
}

function infomatchjunction($date, $compet_id)
{
	$req = mysql_query("SELECT renco_id, saison_nbr, matchs.compet_id AS compet_id, timematch, team_id1, team_id2, renco_type, 
							   equipes1.team_shirt_dom AS team1_shirt_dom, equipes1.stade_name AS stade_name, equipes1.stade_infra AS stade_infra, 
							   pays_id, pays_file_nom, pays_file_prenom, pays_flag, 
							   equipes2.team_shirt_dom AS team2_shirt_dom, equipes2.team_shirt_ext AS team2_shirt_ext 
					    FROM matchs 
						LEFT JOIN equipes AS equipes1 ON matchs.team_id1 = equipes1.team_id 
						LEFT JOIN pays ON equipes1.team_country = pays.pays_id 
						LEFT JOIN equipes AS equipes2 ON matchs.team_id2 = equipes2.team_id 
						WHERE timematch <= '".$date."' 
						  AND score1 = ' ' 
						  AND matchs.compet_id IN(".$compet_id.", 0) 
						ORDER BY renco_id 
						LIMIT 1");
	
	return mysql_fetch_assoc($req);
}






?>