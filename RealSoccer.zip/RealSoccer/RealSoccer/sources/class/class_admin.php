<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
07/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

class admin
{
	function info_alljunction($pseudo)
	{ 
		return sql::fetch("SELECT * 
							FROM comptes 
							LEFT JOIN equipes ON comptes.account_id = equipes.account_id 
							LEFT JOIN joueurs ON equipes.team_id = joueurs.team_id 
							LEFT JOIN classement ON equipes.team_id = classement.team_id 
							LEFT JOIN competition ON equipes.compet_id = competition.compet_id 
							LEFT JOIN matchs ON competition.compet_id = matchs.compet_id 
							LEFT JOIN pays ON pays.pays_id = equipes.team_country 
							LEFT JOIN region ON equipes.team_region = region.region_id 
							LEFT JOIN sponsor ON equipes.sponsor_id = sponsor.sponsor_id 
							WHERE pseudo= '".$pseudo."'");
	}
	
	function menutab($zone, $tab) //Pour les onglets du menu
	{
		if ($zone == $tab) return'class="tabon-main"';
		elseif ($tab == 'main' AND $zone == NULL) return'class="tabon-main"';
		else return'class="taboff-main"';
	}
	
	// HOME _____________________________________________
	function nb_joueur_general() //Nombre de joueur au total
	{
		$nb = sql::fetch("SELECT COUNT(*) AS comptes FROM comptes");
		return $nb['comptes'];
	}

	function nb_joueur_online() //Nombre de joueur en ligne
	{
		$nb = sql::fetch("SELECT COUNT(*) AS comptesonline FROM whosonline");
		return $nb['comptesonline'];
	}

	function nb_joueur_banni() //Nombre de joueur banni
	{
		$nb = sql::fetch("SELECT COUNT(*) AS comptesbanni FROM comptes WHERE rang = 0");
		return $nb['comptesbanni'];
	}

	function nb_joueur_inactif() //Nombre de joueur inactif
	{
		$datetimestamp = time() - (14 * 24 * 60 * 60);
		
		$nb = sql::fetch("SELECT COUNT(*) AS comptesinactif FROM comptes WHERE lastlogin < '".$datetimestamp."'");
		return $nb['comptesinactif'];
	}

	function nb_valid_total() //Nombre de validation au total
	{
		$nbr1 = sql::fetch("SELECT COUNT(*) AS joueurs FROM joueurs WHERE photo != '".NULL."' AND photo_valid = 0");
		$nbr2 = sql::fetch("SELECT COUNT(*) AS fanion FROM equipes WHERE fanion != '".NULL."' AND fanion_valid = 0");
		
		return $nbr1['joueurs'] + $nbr2['fanion'];
	}
	
	function ajouteminimessage($canal, $minimessage, $account_id)
	{
		if (isset($minimessage) AND $minimessage != NULL)
		{
			$minimessage = htmlentities(addslashes($minimessage));
			
			$requete = sql::insert("INSERT INTO minichat(mnc_time, account_id, texte, canal) 
									VALUES('".time()."', '".$account_id."', '".$minimessage."', '".$canal."')");
		}
	}
	
	// MANAGEMENT__________________________________________

	function delete_member($account_id) //Script d'effacement de membre
	{
		//envoi d'un email
		
		$info = sql::fetch("SELECT * 
							FROM comptes
							LEFT JOIN equipes ON comptes.account_id = equipes.account_id
							LEFT JOIN competition ON equipes.compet_id = competition.compet_id
							WHERE comptes.account_id = '".$account_id."'");
		
		//On efface le compte
		$requete = sql::delete("DELETE FROM comptes WHERE account_id = '".$account_id."'");
		
		//On transforme l'�quipe en �quipe fictive
		$requete = sql::update("UPDATE equipes SET account_id = NULL, fictive = 1 WHERE team_id = '".$info['team_id']."'");
		
		//On enleve une �quipe r�el et on ajoute une �quipe fictive
		$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$info['compet_id']."'");
		
		//On enleve la tactique
		$requete = sql::delete("DELETE FROM entrainement WHERE team_id = '".$info['team_id']."'");
		
		//On enleve les jeunes joueurs
		$requete = sql::delete("DELETE FROM joueurs WHERE team_id = '".$info['team_id']."' AND age < 17");
		
		//On enleve le staff
		$requete = sql::delete("DELETE FROM staff WHERE team_id = '".$info['team_id']."'");
	}	
	
	function choice_valid_upload($id, $choix) //Script de validation / refus d'un upload
	{
		if($choix == 'acceptfanion')
		{
			//On update table equipe > fanion_valid = 1
			$requete = sql::update("UPDATE equipes SET fanion_valid = 1 WHERE team_id = '".$id."'");
			
			//On envoi le message d'acceptation
			$requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, mode) VALUES ('".$id."', '".time()."', 8)"); 
		}
		
		elseif($choix == 'refusefanion')
		{
			//On recup les donn�es via $id
			//$req = mysql_query("SELECT fanion FROM equipes WHERE team_id='".$id."'");
			//$view = mysql_fetch_assoc($req);
			
			//On efface le fichier ___ A VOIR CAR MARCHE PAS
			//$uploaddir = config('upload_dir') . 'fanion/' . $view['fanion'];
			//delete($uploaddir . $file);
			
			//On vide le champ fanion
			$requete = sql::update("UPDATE equipes SET fanion = '' WHERE team_id = '".$id."'");
			
			//On envoi le message de refus
			$requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, mode) VALUES ('".$id."', '".time()."', 9)"); 
		}
		
		elseif($choix == 'acceptphoto')
		{
			//On recup les donn�es via $id
			$view = sql::fetch("SELECT team_id, nom, prenom, photo FROM joueurs WHERE player_id='".$id."'");
			
			//On update table joueurs > photo_valid = 1
			$requete = sql::update("UPDATE joueurs SET photo_valid = 1 WHERE player_id = '".$id."'");
			
			//On envoi le message d'acceptation
			$requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, ch_1, ch_2, mode) 
									VALUES ('".$view['team_id']."', '".time()."', '".$view['prenom']."', '".$view['nom']."', 10)");
		}
		
		elseif($choix == 'refusephoto')
		{
			//On recup les donn�es via $id
			$view = sql::fetch("SELECT team_id, nom, prenom, photo FROM joueurs WHERE player_id='".$id."'");
			
			//On efface le fichier___ A VOIR
			//$uploaddir = config('upload_dir') . 'joueur/' . $view['photo'];
			//delete($uploaddir . $file);
			
			//On vide le champ fanion
			$requete = sql::update("UPDATE joueurs SET photo = '' WHERE player_id = '".$id."'");
			
			//On envoi le message de refus
			$requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, ch_1, ch_2, mode) 
									VALUES ('".$view['team_id']."', '".time()."', '".$view['prenom']."', '".$view['nom']."', 11)"); 
		}
	}

	function show_rang($number, $CONF) //Affiche le nom du rang
	{
		switch($number)
		{
			case 0: return $CONF['rang_0']; break;
			case 2: return $CONF['rang_2']; break;
			case 3: return $CONF['rang_3']; break;
			case 4: return $CONF['rang_4']; break;
			case 5: return $CONF['rang_5']; break;
			default : return $CONF['rang_1']; break;
		}
	}
	
	function crea_player($nom, $surnom, $prenom, $pays_id, $position, $choice_mdt, $age, $taille, $forme, $moral, $talent, $pression, $experience, $influence, $agressivite, $reflexes, $pdballe, $degagement, $marquage, $tacles, $tete, $centres, $passes, $vitesse, $tir, $creativite, $dribble, $cdpa, $CONF)
	{
		$age_min = $CONF['note_age_min']; $age_max = $CONF['note_age_max'];
		$tll_min = $CONF['note_tll_min']; $tll_max = $CONF['note_tll_max'];
		$tal_min = $CONF['note_tal_min']; 	$tal_max = $CONF['note_tal_max'];
		$pres_min = $CONF['note_pres_min']; 	$pres_max = $CONF['note_pres_max'];
		$p_min = $CONF['note_pri_min']; 	$p_max = $CONF['note_pri_max'];
		$s_min = $CONF['note_sec_min']; 	$s_max = $CONF['note_sec_max'];
		$multiple = $CONF['salaire_multiple'];
		$team_id = 0;
		
		if ($nom == NULL)
		{
			$data = sql::fetch("SELECT pays_name, pays_file_nom, pays_file_prenom 
								FROM pays 
								WHERE pays_id = '".$pays_id."'");
			
			//-------------------------------------------------------
			// Choix d'une liste de nom al�atoire selon le pays(pays_id)
			if ($data['pays_file_nom'] != NULL) $sourcefile = '../' . 'txt' . '/' . $data['pays_file_nom'];
			else $sourcefile = '../' . 'txt' . '/' . 'nom_france.txt';
			$bddfile = fopen($sourcefile, "r");
			$bddarray = array(); // Cr�ation du tableau qui contiendra toutes les phrases
			while ( $line = fgets($bddfile) ) { array_push($bddarray, $line); }// On la rajoute au tableau
			fclose ($bddfile); // On ferme le fichier
			srand((double)microtime(2) * 1000000) ;
			$nom = $bddarray[rand(0, count($bddarray)-1)];
			//-------------------------------------------------------
		}
		
		if ($prenom == NULL)
		{
			$data = sql::fetch("SELECT pays_name, pays_file_nom, pays_file_prenom 
								FROM pays 
								WHERE pays_id = '".$pays_id."'");
			
			//-------------------------------------------------------
			// Choix d'une liste de pr�nom al�atoire selon le pays(pays_id)
			if ($data['pays_file_prenom'] != NULL) $sourcefile = '../' . 'txt' . '/' . $data['pays_file_prenom'];
			else $sourcefile = '../' . 'txt' . '/' . 'prenom_france.txt';
			$bddfile = fopen($sourcefile, "r");
			$bddarray = array(); // Cr�ation du tableau qui contiendra toutes les phrases
			while ( $line = fgets($bddfile) ) { array_push($bddarray, $line); }// On la rajoute au tableau
			fclose ($bddfile); // On ferme le fichier
			srand((double)microtime(2) * 1000000) ;
			$prenom = $bddarray[rand(0, count($bddarray)-1)];
			//-------------------------------------------------------
		}
		
		if ($position == 1)
		{
			if($influence == NULL) $influence = rand($p_min, $p_max);
			if($reflexes == NULL) $reflexes = rand($p_min, $p_max);
			if($pdballe == NULL) $pdballe = rand($p_min, $p_max);
			if($degagement == NULL) $degagement = rand($p_min, $p_max);
			if($marquage == NULL) $marquage = rand($s_min, $s_max);
			if($tacles == NULL) $tacles = rand($s_min, $s_max);
			if($tete == NULL) $tete = rand($s_min, $s_max);
			if($centres == NULL) $centres = rand($s_min, $s_max);
			if($passes == NULL) $passes = rand($s_min, $s_max);
			if($vitesse == NULL) $vitesse = rand($s_min, $s_max);
			if($tir == NULL) $tir = rand($s_min, $s_max);
			if($creativite == NULL) $creativite = rand($s_min, $s_max);
			if($dribble == NULL) $dribble = rand($s_min, $s_max);
			if($cdpa == NULL) $cdpa = rand($p_min, $p_max);
			$salaire = $multiple * ($pdballe + $degagement + $reflexes + $influence); //Calcul du salaire gardien
		}
		
		elseif ($position == 2)
		{
			if($influence == NULL) $influence = rand($s_min, $s_max);
			if($reflexes == NULL) $reflexes = rand($s_min, $s_max);
			if($pdballe == NULL) $pdballe = rand($s_min, $s_max);
			if($degagement == NULL) $degagement = rand($p_min, $p_max);
			if($marquage == NULL) $marquage = rand($p_min, $p_max);
			if($tacles == NULL) $tacles = rand($p_min, $p_max);
			if($tete == NULL) $tete = rand($p_min, $p_max);
			if($centres == NULL) $centres = rand($s_min, $s_max);
			if($passes == NULL) $passes = rand($s_min, $s_max);
			if($vitesse == NULL) $vitesse = rand($s_min, $s_max);
			if($tir == NULL) $tir = rand($s_min, $s_max);
			if($creativite == NULL) $creativite = rand($s_min, $s_max);
			if($dribble == NULL) $dribble = rand($s_min, $s_max);
			if($cdpa == NULL) $cdpa = rand($p_min, $p_max);
			$salaire = $multiple * ($marquage + $tacles + $degagement + $tete); //Calcul du salaire d�fenseur
		}
		
		elseif ($position == 3)
		{
			if($influence == NULL) $influence = rand($s_min, $s_max);
			if($reflexes == NULL) $reflexes = rand($s_min, $s_max);
			if($pdballe == NULL) $pdballe = rand($s_min, $s_max);
			if($degagement == NULL) $degagement = rand($s_min, $s_max);
			if($marquage == NULL) $marquage = rand($s_min, $s_max);
			if($tacles == NULL) $tacles = rand($s_min, $s_max);
			if($tete == NULL) $tete = rand($s_min, $s_max);
			if($centres == NULL) $centres = rand($p_min, $p_max);
			if($passes == NULL) $passes = rand($p_min, $p_max);
			if($vitesse == NULL) $vitesse = rand($p_min, $p_max);
			if($tir == NULL) $tir = rand($p_min, $p_max);
			if($creativite == NULL) $creativite = rand($s_min, $s_max);
			if($dribble == NULL) $dribble = rand($s_min, $s_max);
			if($cdpa == NULL) $cdpa = rand($p_min, $p_max);
			$salaire = $multiple * ($centres + $passes + $vitesse + $tir); //Calcul du salaire milieu
		}
		
		elseif ($position == 4)
		{
			if($influence == NULL) $influence = rand($s_min, $s_max);
			if($reflexes == NULL) $reflexes = rand($s_min, $s_max);
			if($pdballe == NULL) $pdballe = rand($s_min, $s_max);
			if($degagement == NULL) $degagement = rand($s_min, $s_max);
			if($marquage == NULL) $marquage = rand($s_min, $s_max);
			if($tacles == NULL) $tacles = rand($s_min, $s_max);
			if($tete == NULL) $tete = rand($p_min, $p_max);
			if($centres == NULL) $centres = rand($s_min, $s_max);
			if($passes == NULL) $passes = rand($s_min, $s_max);
			if($vitesse == NULL) $vitesse = rand($s_min, $s_max);
			if($tir == NULL) $tir = rand($p_min, $p_max);
			if($creativite == NULL) $creativite = rand($p_min, $p_max);
			if($dribble == NULL) $dribble = rand($p_min, $p_max);
			if($cdpa == NULL) $cdpa = rand($p_min, $p_max);
			$salaire = $multiple * ($tir + $creativite + $tete + $dribble); //Calcul du salaire attaquant
		}
		
		if($age == NULL) $age = rand($age_min, $age_max);
		if($taille == NULL) $taille = rand($tll_min, $tll_max);
		if($talent == NULL) $talent = rand($tal_min, $tal_max);
		if($pression == NULL) $pression = rand($pres_min, $pres_max);
		if($experience == NULL) $experience = rand($s_min, $s_max);
		if($agressivite == NULL) $agressivite = rand($s_min, $s_max);
		if($forme == NULL) $forme = 100;
		if($moral == NULL) $moral = 100;
		if($choice_mdt == 'oui') $statut = 1; else $statut = 0;
		
		$requete = sql::insert("INSERT INTO joueurs
		(team_id, nom, surnom, prenom, age, taille, position, nationalite, forme, moral, talent, pression, experience, influence, agressivite, reflexes, 
		pdballe, degagement, marquage, tacles, tete, centres, passes, vitesse, tir, creativite, dribble, cdp_arrete, salaire, statut) 
		VALUES ('".$team_id."', '".addslashes($nom)."', '".addslashes($surnom)."',  '".addslashes($prenom)."', '".$age."', '".$taille."', '".$position."', '".$pays_id."'
		, '".$forme."', '".$moral."', '".$talent."', '".$pression."', '".$experience."', '".$influence."', '".$agressivite."', '".$reflexes."', '".$pdballe."', '".$degagement."', '".$marquage."'
		, '".$tacles."', '".$tete."', '".$centres."', '".$passes."', '".$vitesse."', '".$tir."', '".$creativite."'
		, '".$dribble."', '".$cdpa."', '".$salaire."', '".$statut."')");
		$player_id = mysql_insert_id();
		
		$transfert = time() . '/' . 0 . '/VIDE';
		
		$requete = sql::insert("INSERT INTO joueurs_historique(player_id, transfert) 
								VALUES ('".$player_id."', '".$transfert."')"); 
		
		$requete = sql::insert("INSERT INTO classement_joueur(player_id, team_id, compet_id, saison_nbr) 
								VALUES ('".$player_id."', '0', '0', '0')");
	}
	
	function compare_etoile($player_id, $position)
	{
		$data = sql::fetch("SELECT * FROM joueurs WHERE player_id= '".$player_id."'");
		
		if($position == 1)
		{
			$addi = $data['pdballe'] + $data['degagement'] + $data['reflexes'] + $data['influence'];
			$notesansround = $addi / 4;
			$note = round($notesansround);
		}
		
		elseif($position == 2)
		{
			$addi = $data['marquage'] + $data['tacles'] + $data['degagement'] + $data['tete'];
			$notesansround = $addi / 4;
			$note = round($notesansround);
		}
		
		elseif($position == 3)
		{
			$addi = $data['centres'] + $data['passes'] + $data['vitesse'] + $data['tir'];
			$notesansround = $addi / 4;
			$note = round($notesansround);
		}
		
		elseif($position == 4)
		{
			$addi = $data['tir'] + $data['creativite'] + $data['tete'] + $data['dribble'];
			$notesansround = $addi / 4;
			$note = round($notesansround);
		}
		
		switch($note)
		{
			case 0: return '<img src="../images/icone/0star.png" width="54" height="10" alt="0" border="0" />'; break;
			case 1: return '<img src="../images/icone/0-1star.png" width="54" height="10" alt="1" border="0" />'; break;
			case 2: return '<img src="../images/icone/0-1star.png" width="54" height="10" alt="2" border="0" />'; break;
			case 3: return '<img src="../images/icone/1star.png" width="54" height="10" alt="3" border="0" />'; break;
			case 4: return '<img src="../images/icone/1star.png" width="54" height="10" alt="4" border="0" />'; break;
			case 5: return '<img src="../images/icone/1-2star.png" width="54" height="10" alt="5" border="0" />'; break;
			case 6: return '<img src="../images/icone/1-2star.png" width="54" height="10" alt="6" border="0" />'; break;
			case 7: return '<img src="../images/icone/2star.png" width="54" height="10" alt="7" border="0" />'; break;
			case 8: return '<img src="../images/icone/2star.png" width="54" height="10" alt="8" border="0" />'; break;
			case 9: return '<img src="../images/icone/2-3star.png" width="54" height="10" alt="9" border="0" />'; break;
			case 10: return '<img src="../images/icone/2-3star.png" width="54" height="10" alt="10" border="0" />'; break;
			case 11: return '<img src="../images/icone/3star.png" width="54" height="10" alt="11" border="0" />'; break;
			case 12: return '<img src="../images/icone/3star.png" width="54" height="10" alt="12" border="0" />'; break;
			case 13: return '<img src="../images/icone/3-4star.png" width="54" height="10" alt="13" border="0" />'; break;
			case 14: return '<img src="../images/icone/3-4star.png" width="54" height="10" alt="14" border="0" />'; break;
			case 15: return '<img src="../images/icone/4star.png" width="54" height="10" alt="15" border="0" />'; break;
			case 16: return '<img src="../images/icone/4star.png" width="54" height="10" alt="16" border="0" />'; break;
			case 17: return '<img src="../images/icone/4-5star.png" width="54" height="10" alt="17" border="0" />'; break;
			case 18: return '<img src="../images/icone/4-5star.png" width="54" height="10" alt="18" border="0" />'; break;
			case 19: return '<img src="../images/icone/5star.png" width="54" height="10" alt="19" border="0" />'; break;
			case 20: return '<img src="../images/icone/5star.png" width="54" height="10" alt="20" border="0" />'; break;
			default : return 'Inconnu'; break;
		}
	}

	function player_delete($player_id) //Effacer un joueur sans club
	{
			$requete = sql::delete("DELETE FROM joueurs WHERE player_id = '".$player_id."'");
			$requete = sql::delete("DELETE FROM classement_joueur WHERE player_id = '".$player_id."'");
			$requete = sql::delete("DELETE FROM joueurs_historique WHERE player_id = '".$player_id."'");
	}

	function player_transfert($player_id)
	{
		$requete = sql::update("UPDATE joueurs SET statut = 1 WHERE player_id = '".$player_id."'");
	}
	
	//
	function newsaison_start($pays_id, $saison, $CONF)
	{
		$error;
	}
	
	function new_saison_promoreleg($pays_id, $CONF)
	{
		//_____________________________________ DIVISION 1 _____________________________________
		
		$data = sql::fetch("SELECT * FROM competition WHERE pays_id= '".$pays_id."' AND division= '1'");
		
		$nbr = sql::fetch("SELECT saison_nbr FROM classement WHERE compet_id='".$data['compet_id']."' ORDER BY saison_nbr DESC LIMIT 1");
		$eqpd1 = 1; 
		$saison_nbr = $nbr['saison_nbr'] + 1; //La derni�re saison en cours plus 1
		
		$classplus1 = 1;
		
		$req = sql::query("SELECT * FROM classement WHERE compet_id='".$data['compet_id']."' AND saison_nbr='".$nbr['saison_nbr']."' ORDER BY point DESC, BP-BC DESC");
		
		while($donnees4 = mysql_fetch_array($req))
		{
			$requete = sql::update("UPDATE classement SET classement='".$classplus1."' WHERE class_id='".$donnees4['class_id']."'");
			$classplus1++;
		}
		
		while (10 >= $eqpd1)
		{
			$clasmnt = sql::fetch("SELECT * FROM classement WHERE compet_id= '".$data['compet_id']."' AND saison_nbr = '".$nbr['saison_nbr']."' AND classement = '".$eqpd1."'");
			
			$data6 = sql::fetch("SELECT team_cup, team_history FROM equipes WHERE team_id= '".$clasmnt['team_id']."'");
			
			//On ajoute le classement de la saison � l'histoire de l'�quipe
			$classement = $data6['team_history'] . 'Saison ' . $clasmnt['saison_nbr'] . ' : Division ' . $data['division'] . '-' . $data['poule'] . ' #' . $clasmnt['classement'] . ';';
			$requete = sql::update("UPDATE equipes SET team_history = '".$classement."' WHERE team_id = '".$clasmnt['team_id']."'");
			
			//if classement = 1 on ajoute une coupe division1 dans le team_cup de l'�quipe
			if ($clasmnt['classement'] == 1)
			{
				$cup = $data6['team_cup'] . 'cup_champd1.gif;';
				$requete = sql::update("UPDATE equipes SET team_money = team_money + 300000, team_cup = '".$cup."' WHERE team_id = '".$clasmnt['team_id']."'");
			}
			$eqpd1++;
		}
		
		//Mon syst�me pour la cr�ation des rencontres, on modifie compet_name pour pouvoir selectionner ensuite plus facilement
		$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$data['compet_id']."'");
		
		//_____________________________________ DIVISION 2 _____________________________________
		
		$division2 = sql::fetch("SELECT COUNT(*) AS exist FROM competition WHERE pays_id= '".$pays_id."' AND division= '2'");
		
		if ($division2['exist'] >= 1) //Si les championnat de D2 existe on lance le script de promotion/relegation
		{
			$div2 = 1;
			while (3 >= $div2)
			{
				$data2 = sql::fetch("SELECT * FROM competition WHERE pays_id= '".$pays_id."' AND division= '2' AND poule= '".$div2."'");
				
				$eqpd2 = 1;
				$classplus1 = 1;
				
				$req = sql::query("SELECT * FROM classement WHERE compet_id='".$data2['compet_id']."' AND saison_nbr='".$nbr['saison_nbr']."' ORDER BY point DESC, BP-BC DESC");
				
				while ($donnees4 = mysql_fetch_array($req))
				{
					$requete = sql::update("UPDATE classement SET classement='".$classplus1."' WHERE class_id='".$donnees4['class_id']."'");
					$classplus1++;
				}
				
				while (10 >= $eqpd2)
				{
					$clasmnt = sql::fetch("SELECT * FROM classement WHERE compet_id= '".$data2['compet_id']."' AND saison_nbr = '".$nbr['saison_nbr']."' AND classement = '".$eqpd2."'");
					$data6 = sql::fetch("SELECT team_cup, team_history, fictive FROM equipes WHERE team_id= '".$clasmnt['team_id']."'");
					
					if ($clasmnt['classement'] == 1)
					{
						//On ajoute le classement de la saison � l'histoire de l'�quipe
						$classement = $data6['team_history'] . 'Saison ' . $clasmnt['saison_nbr'] . ' : Division ' . $data2['division'] . '-' . $data2['poule'] . ' #' . $clasmnt['classement'] . ';';
						$requete = sql::update("UPDATE equipes SET team_money = team_money + 150000, team_history = '".$classement."' WHERE team_id = '".$clasmnt['team_id']."'");
						
						//On monte l'�quipe en D1
						$requete = sql::update("UPDATE equipes SET compet_id = '".$data['compet_id']."' WHERE team_id = '".$clasmnt['team_id']."'");
						
						//On ajoute une coupe division2 dans le team_cup de l'�quipe
						$cup = $data6['team_cup'] . 'cup_champd2.gif;';
						$requete = sql::update("UPDATE equipes SET team_cup = '".$cup."' WHERE team_id = '".$clasmnt['team_id']."'");
						
						if ($data6['fictive'] == 0) //Si c'est une �quipe r�el on modifie competition
						{
							//On rajoute une �quipe r�el au nouveau championnat
							$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$data['compet_id']."'");
							
							//On enleve une �quipe r�el � l'ancien championnat
							$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$data2['compet_id']."'");
						}
					}
					
					else
					{
						//On ajoute le classement de la saison � l'histoire de l'�quipe
						$classement = $data6['team_history'] . 'Saison ' . $clasmnt['saison_nbr'] . ' : Division ' . $data2['division'] . '-' . $data2['poule'] . ' #' . $clasmnt['classement'] . ';';
						$requete = sql::update("UPDATE equipes SET team_history = '".$classement."' WHERE team_id = '".$clasmnt['team_id']."'");
					}
					
					$eqpd2++;
				}
				
				$div2++;
			}
			
			//Descente des 3 �quipes de division1 : On recupere les 3 team_id...
			$req = sql::query("SELECT team_id FROM classement WHERE compet_id= '".$data['compet_id']."' AND saison_nbr = '".$nbr['saison_nbr']."' AND classement IN(8, 9, 10)");
			$clubreleg1 = mysql_fetch_array($req);
			$clubreleg2 = mysql_fetch_array($req);
			$clubreleg3 = mysql_fetch_array($req);
			
			$infoclubreleg1 = sql::fetch("SELECT fictive FROM equipes WHERE team_id= '".$clubreleg1['team_id']."'");
			$infoclubreleg2 = sql::fetch("SELECT fictive FROM equipes WHERE team_id= '".$clubreleg2['team_id']."'");
			$infoclubreleg3 = sql::fetch("SELECT fictive FROM equipes WHERE team_id= '".$clubreleg3['team_id']."'");
			
			//...et les 3 championnat de D2
			$req = sql::query("SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '2'");
			$champd2a = mysql_fetch_array($req);
			$champd2b = mysql_fetch_array($req);
			$champd2c = mysql_fetch_array($req);
					
			//Mon syst�me pour la cr�ation des rencontres, on efface compet_name pour pouvoir selectionner ensuite plus facilement
			$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$champd2a['compet_id']."'");
			$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$champd2b['compet_id']."'");
			$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$champd2c['compet_id']."'");
			
			//On transfert les �quipes de D1 en D2 
			$requete = sql::update("UPDATE equipes SET compet_id = '".$champd2a['compet_id']."' WHERE team_id = '".$clubreleg1['team_id']."'");
			$requete = sql::update("UPDATE equipes SET compet_id = '".$champd2b['compet_id']."' WHERE team_id = '".$clubreleg2['team_id']."'");
			$requete = sql::update("UPDATE equipes SET compet_id = '".$champd2c['compet_id']."' WHERE team_id = '".$clubreleg3['team_id']."'");
			
			//On modifie competition si equipe fictive ou pas
			if ($infoclubreleg1['fictive'] == 0)
			{
				//On rajoute une �quipe r�el au nouveau championnat
				$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$champd2a['compet_id']."'");
				
				//On enleve une �quipe r�el � l'ancien championnat
				$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$data['compet_id']."'");
			}
			
			if ($infoclubreleg2['fictive'] == 0)
			{
				//On rajoute une �quipe r�el au nouveau championnat
				$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$champd2b['compet_id']."'");
				
				//On enleve une �quipe r�el � l'ancien championnat
				$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$data['compet_id']."'");
			}
			
			if ($infoclubreleg3['fictive'] == 0)
			{
				//On rajoute une �quipe r�el au nouveau championnat
				$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$champd2c['compet_id']."'");
				
				//On enleve une �quipe r�el � l'ancien championnat
				$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$data['compet_id']."'");
			}
		}
		
		//_____________________________________ DIVISION 3 _____________________________________
		
		$division3 = sql::fetch("SELECT COUNT(*) AS exist FROM competition WHERE pays_id= '".$pays_id."' AND division= '3'");
		
		if ($division3['exist'] >= 1) //Si les championnat de D3 existe on lance le script de promotion/relegation
		{
			$div3 = 1;
			while (9 >= $div3)
			{
				$data2 = sql::fetch("SELECT * FROM competition WHERE pays_id= '".$pays_id."' AND division= '3' AND poule= '".$div3."'");
				$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$data2['compet_id']."'");
				
				$eqpd3 = 1;
				$classplus1 = 1;
				
				$req = sql::query("SELECT * FROM classement WHERE compet_id='".$data2['compet_id']."' AND saison_nbr='".$nbr['saison_nbr']."' ORDER BY point DESC, BP-BC DESC");
				
				while ($donnees4 = mysql_fetch_array($req))
				{
					$requete = sql::update("UPDATE classement SET classement='".$classplus1."' WHERE class_id='".$donnees4['class_id']."'");
					$classplus1++;
				}
				
				while (10 >= $eqpd3)
				{
					$clasmnt = sql::fetch("SELECT * FROM classement WHERE compet_id= '".$data2['compet_id']."' AND saison_nbr = '".$nbr['saison_nbr']."' AND classement = '".$eqpd3."'");
					$data6 = sql::fetch("SELECT team_cup, team_history, fictive FROM equipes WHERE team_id= '".$clasmnt['team_id']."'");
					
					if ($clasmnt['classement'] == 1)
					{
						//On ajoute le classement de la saison � l'histoire de l'�quipe
						$classement = $data6['team_history'] . 'Saison ' . $clasmnt['saison_nbr'] . ' : Division ' . $data2['division'] . '-' . $data2['poule'] . ' #' . $clasmnt['classement'] . ';';
						$requete = sql::update("UPDATE equipes SET team_history = '".$classement."' WHERE team_id = '".$clasmnt['team_id']."'");
						
						//On ajoute une coupe division3 dans le team_cup de l'�quipe
						$cup = $data6['team_cup'] . 'cup_champd3.gif;';
						$requete = sql::update("UPDATE equipes SET team_cup = '".$cup."' WHERE team_id = '".$clasmnt['team_id']."'");
						
						if ($data6['fictive'] == 0) //Si c'est une �quipe r�el on modifie competition ------------ A VOIR
						{
							//On rajoute une �quipe r�el au nouveau championnat
							$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$data['compet_id']."'");
							
							//On enleve une �quipe r�el � l'ancien championnat
							$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$data2['compet_id']."'");
						}
					}
					
					else
					{
						//On ajoute le classement de la saison � l'histoire de l'�quipe
						$classement = $data6['team_history'] . 'Saison ' . $clasmnt['saison_nbr'] . ' : Division ' . $data2['division'] . '-' . $data2['poule'] . ' #' . $clasmnt['classement'] . ';';
						$requete = sql::update("UPDATE equipes SET team_history = '".$classement."' WHERE team_id = '".$clasmnt['team_id']."'");
					}
					
					$eqpd3++;
				}
				
				$div3++;
			}
			
			//Monter des 9 �quipes de division3 : On recupere les 9 team_id... 
			$data19 = sql::fetch("SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '3'");
			
			$champd3all = $data19['compet_id'];
			
			//pour ajouter les 9compet_id de d3 dans le IN du dessous
			$req = sql::query("SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '3'");
			$champd3 = array(); $champd3nbr = 1;
			while ($row = mysql_fetch_array($req)) { $champd3[] = $row; }
			while (8 >= $champd3nbr)
			{
				$champd3all = $champd3all . ', ' . $champd3[$champd3nbr]['compet_id'];
				$champd3nbr++;
			}
			
			//On recup les premiers de toutes les division 3
			$req = sql::query("SELECT team_id FROM classement WHERE compet_id IN ($champd3all) AND saison_nbr = '".$nbr['saison_nbr']."' AND classement= 1");
			$clubpromo = array();
			while ($row = mysql_fetch_array($req)) { $clubpromo[] = $row; }
			
			//...et les 3 championnat de D2
			$req = sql::query("SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '2'");
			$champd2 = array(); $nbzd2a = 0; $nbzd2b = 3; $nbzd2c = 6;
			while ($row = mysql_fetch_array($req)) { $champd2[] = $row; }
			while (2 >= $nbzd2a)
			{
				//On monte l'�quipe en D2
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd2[$nbzd2a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd2a]['team_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd2[$nbzd2a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd2b]['team_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd2[$nbzd2a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd2c]['team_id']."'");
				$nbzd2a++; $nbzd2b++; $nbzd2c++;
			}
			
			//Descente des 9 �quipes de division2 : On recupere les 9 team_id...
			$data18 = sql::fetch("SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '2'");
			
			$champd2all = $data18['compet_id'];
			
			//pour ajouter les 3compet_id de d2 dans le IN du dessous
			$req = sql::query("SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '2'");
			$champd2 = array(); $champd2nbr = 1;
			while ($row = mysql_fetch_array($req)) { $champd2[] = $row; }
			while (2 >= $champd2nbr)
			{
				$champd2all = $champd2all . ', ' . $champd2[$champd2nbr]['compet_id'];
				$champd2nbr++;
			}
			
			//On recup les 3 derniers de toutes les division 2
			$req = sql::query("SELECT team_id FROM classement WHERE compet_id IN($champd2all) AND saison_nbr = '".$nbr['saison_nbr']."' AND classement IN(8, 9, 10)");
			$clubreleg = array();
			while ($row = mysql_fetch_array($req)) { $clubreleg[] = $row; }
			
			//...et les 9 championnat de D3
			$req = sql::query("SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '3'");
			$champd3 = array(); $nbzd3 = 0;
			while ($row = mysql_fetch_array($req)) { $champd3[] = $row; }
			while (9 >= $nbzd3)
			{
				$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$champd2[$nbzd3]['compet_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd3[$nbzd3]['compet_id']."' WHERE team_id = '".$clubreleg[$nbzd3]['team_id']."'");
				$nbzd3++;
			}
			
			$teamreleg = 0;
			
			while (9 >= $teamreleg)
			{
				$infoclubreleg = sql::fetch("SELECT fictive FROM equipes WHERE team_id= '".$clubreleg[$teamreleg]['team_id']."'");
				
				if ($infoclubreleg['fictive'] == 0) //On modifie competition si equipe relegue fictive ou pas
				{
					//On rajoute une �quipe r�el au nouveau championnat (d3)
					$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$champd3[$teamreleg]['compet_id']."'");
					
					//On enleve une �quipe r�el � l'ancien championnat (d2)
					$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$champd2[$teamreleg]['compet_id']."'");
				}
				
				$teamreleg++;
			}
		}
		
		//_____________________________________ DIVISION 4 _____________________________________
		
		$sql = "SELECT COUNT(*) AS exist FROM competition WHERE pays_id= '".$pays_id."' AND division= '4'"; 
		$req = mysql_query($sql);
		$division4 = mysql_fetch_array($req);
		
		if ($division4['exist'] >= 1) //Si les championnat de d4 existe on lance le script de promotion/relegation
		{
			$div4 = 1;
			while (27 >= $div4)
			{
				$sql = "SELECT * FROM competition WHERE pays_id= '".$pays_id."' AND division= '4' AND poule= '".$div4."'"; 
				$req = mysql_query($sql);
				$data2 = mysql_fetch_array($req); $eqpd4 = 1;
				
				$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$data2['compet_id']."'");
				
				$classplus1 = 1;
				
				$sql7 = "SELECT * FROM classement WHERE compet_id='".$data2['compet_id']."' AND saison_nbr='".$nbr['saison_nbr']."' ORDER BY point DESC, BP-BC DESC";
				$req7 = mysql_query($sql7);
				while ($donnees4 = mysql_fetch_array($req7))
				{
					$requete = sql::update("UPDATE classement SET classement='".$classplus1."' WHERE class_id='".$donnees4['class_id']."'");
					
					$classplus1++;
				}
				
				while (10 >= $eqpd4)
				{
					$sql = "SELECT * FROM classement WHERE compet_id= '".$data2['compet_id']."' AND saison_nbr = '".$nbr['saison_nbr']."' AND classement = '".$eqpd4."'"; 
					$req = mysql_query($sql);
					$clasmnt = mysql_fetch_array($req);
					
					$sql = "SELECT team_cup, team_history, fictive FROM equipes WHERE team_id= '".$clasmnt['team_id']."'";
					$req = mysql_query($sql);
					$data6 = mysql_fetch_array($req);
					
					if ($clasmnt['classement'] == 1)
					{
						//On ajoute le classement de la saison � l'histoire de l'�quipe
						$classement = $data6['team_history'] . 'Saison ' . $clasmnt['saison_nbr'] . ' : Division ' . $data2['division'] . '-' . $data2['poule'] . ' #' . $clasmnt['classement'] . ';';
						$requete = sql::update("UPDATE equipes SET team_history = '".$classement."' WHERE team_id = '".$clasmnt['team_id']."'");
						
						//On ajoute une coupe division3 dans le team_cup de l'�quipe
						$cup = $data6['team_cup'] . 'cup_champd4.gif;';
						$requete = sql::update("UPDATE equipes SET team_cup = '".$cup."' WHERE team_id = '".$clasmnt['team_id']."'");
						
						if ($data6['fictive'] == 0) //Si c'est une �quipe r�el on modifie competition ------------ A VOIR
						{
							//On rajoute une �quipe r�el au nouveau championnat
							$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$data['compet_id']."'");
							
							//On enleve une �quipe r�el � l'ancien championnat
							$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$data2['compet_id']."'");
						}
					}
					
					else
					{
						//On ajoute le classement de la saison � l'histoire de l'�quipe
						$classement = $data6['team_history'] . 'Saison ' . $clasmnt['saison_nbr'] . ' : Division ' . $data2['division'] . '-' . $data2['poule'] . ' #' . $clasmnt['classement'] . ';';
						$requete = sql::update("UPDATE equipes SET team_history = '".$classement."' WHERE team_id = '".$clasmnt['team_id']."'");
					}
					
					$eqpd4++;
				}
				
				$div4++;
			}
			
			//Monter des 27 �quipes de division4 : On recupere les 27 team_id...
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '4'"; 
			$req = mysql_query($sql);
			$data19 = mysql_fetch_array($req); $champd4all = $data19['compet_id'];
			
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '4'"; //pour ajouter les 27compet_id de d4 dans le IN du dessous
			$req = mysql_query($sql);
			$champd4 = array(); $champd4nbr = 1;
			while ($row = mysql_fetch_array($req)) { $champd4[] = $row; }
			while (26 >= $champd4nbr)
			{
				$champd4all = $champd4all . ', ' . $champd4[$champd4nbr]['compet_id'];
				$champd4nbr++;
			}
			
			//On recup les premiers de toutes les division 4
			$sql = "SELECT team_id FROM classement WHERE compet_id IN($champd4all) AND saison_nbr = '".$nbr['saison_nbr']."' AND classement= 1"; 
			$req = mysql_query($sql);
			$clubpromo = array();
			while ($row = mysql_fetch_array($req)) { $clubpromo[] = $row; }
			
			//...et les 9 championnat de d3
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '3'";
			$req = mysql_query($sql);
			$champd3 = array(); $nbzd3a = 0; $nbzd3b = 9; $nbzd3c = 18;
			while ($row = mysql_fetch_array($req)) { $champd3[] = $row; }
			while (8 >= $nbzd3a)
			{
				//On monte les �quipes en d3
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd3[$nbzd3a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd3a]['team_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd3[$nbzd3a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd3b]['team_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd3[$nbzd3a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd3c]['team_id']."'");
				$nbzd3a++; $nbzd3b++; $nbzd3c++;
			}
			
			//Descente des 27 �quipes de division3 : On recupere les 27 team_id...
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '3'"; 
			$req = mysql_query($sql);
			$data18 = mysql_fetch_array($req); $champd3all = $data18['compet_id'];
			
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '3'"; //pour ajouter les 27compet_id de d3 dans le IN du dessous
			$req = mysql_query($sql);
			$champd3 = array(); $champd3nbr = 1;
			while ($row = mysql_fetch_array($req)) { $champd3[] = $row; }
			while (8 >= $champd3nbr)
			{
				$champd3all = $champd3all . ', ' . $champd3[$champd3nbr]['compet_id'];
				$champd3nbr++;
			}
			
			$sql = "SELECT team_id FROM classement WHERE compet_id IN($champd3all) AND saison_nbr = '".$nbr['saison_nbr']."' AND classement IN(8, 9, 10)"; //On recup les 3 derniers de toutes les division 2
			$req = mysql_query($sql);
			$clubreleg = array();
			while ($row = mysql_fetch_array($req)) { $clubreleg[] = $row; }
			
			//...et les 27 championnat de d4
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '4'";  //On recup les 27 compet_id des 27 division4
			$req = mysql_query($sql);
			$champd4 = array(); $nbzd4 = 0;
			while ($row = mysql_fetch_array($req)) { $champd4[] = $row; }
			while (26 >= $nbzd4)
			{
				$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$champd3[$nbzd4]['compet_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd4[$nbzd4]['compet_id']."' WHERE team_id = '".$clubreleg[$nbzd4]['team_id']."'");
				$nbzd4++;
			}
			
			$teamreleg = 0;
			
			while (27 >= $teamreleg)
			{
				$sql = mysql_query("SELECT fictive FROM equipes WHERE team_id= '".$clubreleg[$teamreleg]['team_id']."'");
				$infoclubreleg = mysql_fetch_array($sql);
				
				if ($infoclubreleg['fictive'] == 0) //On modifie competition si equipe relegue fictive ou pas
				{
					//On rajoute une �quipe r�el au nouveau championnat (d4)
					$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$champd4[$teamreleg]['compet_id']."'");
					
					//On enleve une �quipe r�el � l'ancien championnat (d3)
					$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$champd3[$teamreleg]['compet_id']."'");
				}
				
				$teamreleg++;
			}
		}
		
		//_____________________________________ DIVISION 5 _____________________________________
		
		$sql = "SELECT COUNT(*) AS exist FROM competition WHERE pays_id= '".$pays_id."' AND division= '5'"; 
		$req = mysql_query($sql);
		$division5 = mysql_fetch_array($req);
		
		if ($division5['exist'] >= 1) //Si les championnat de d5 existe on lance le script de promotion/relegation
		{
			$div5 = 1;
			while (81 >= $div5)
			{
				$sql = "SELECT * FROM competition WHERE pays_id= '".$pays_id."' AND division= '5' AND poule= '".$div5."'"; 
				$req = mysql_query($sql);
				$data2 = mysql_fetch_array($req); $eqpd5 = 1;
				
				$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$data2['compet_id']."'");
				
				$classplus1 = 1;
				
				$sql7 = "SELECT * FROM classement WHERE compet_id='".$data2['compet_id']."' AND saison_nbr='".$nbr['saison_nbr']."' ORDER BY point DESC, BP-BC DESC";
				$req7 = mysql_query($sql7);
				while ($donnees4 = mysql_fetch_array($req7))
				{
					$requete = sql::update("UPDATE classement SET classement='".$classplus1."' WHERE class_id='".$donnees4['class_id']."'");
					
					$classplus1++;
				}
				
				while (10 >= $eqpd5)
				{
					$sql = "SELECT * FROM classement WHERE compet_id= '".$data2['compet_id']."' AND saison_nbr = '".$nbr['saison_nbr']."' AND classement = '".$eqpd5."'"; 
					$req = mysql_query($sql);
					$clasmnt = mysql_fetch_array($req);
					
					$sql = "SELECT team_cup, team_history, fictive FROM equipes WHERE team_id= '".$clasmnt['team_id']."'";
					$req = mysql_query($sql);
					$data6 = mysql_fetch_array($req);
					
					if ($clasmnt['classement'] == 1)
					{
						//On ajoute le classement de la saison � l'histoire de l'�quipe
						$classement = $data6['team_history'] . 'Saison ' . $clasmnt['saison_nbr'] . ' : Division ' . $data2['division'] . '-' . $data2['poule'] . ' #' . $clasmnt['classement'] . ';';
						$requete = sql::update("UPDATE equipes SET team_history = '".$classement."' WHERE team_id = '".$clasmnt['team_id']."'");
						
						//On ajoute une coupe division5 dans le team_cup de l'�quipe
						$cup = $data6['team_cup'] . 'cup_champd5.gif;';
						$requete = sql::update("UPDATE equipes SET team_cup = '".$cup."' WHERE team_id = '".$clasmnt['team_id']."'");
						
						if ($data6['fictive'] == 0) //Si c'est une �quipe r�el on modifie competition ------------ A VOIR
						{
							//On rajoute une �quipe r�el au nouveau championnat
							$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$data['compet_id']."'");
							
							//On enleve une �quipe r�el � l'ancien championnat
							$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$data2['compet_id']."'");
						}
					}
					
					else
					{
						//On ajoute le classement de la saison � l'histoire de l'�quipe
						$classement = $data6['team_history'] . 'Saison ' . $clasmnt['saison_nbr'] . ' : Division ' . $data2['division'] . '-' . $data2['poule'] . ' #' . $clasmnt['classement'] . ';';
						$requete = sql::update("UPDATE equipes SET team_history = '".$classement."' WHERE team_id = '".$clasmnt['team_id']."'");
					}
					
					$eqpd5++;
				}
				
				$div5++;
			}
			
			//Monter des 81 �quipes de division5 : On recupere les 81 team_id...
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '5'"; 
			$req = mysql_query($sql);
			$data19 = mysql_fetch_array($req); $champd5all = $data19['compet_id'];
			
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '5'"; //pour ajouter les 81compet_id de d5 dans le IN du dessous
			$req = mysql_query($sql);
			$champd5 = array(); $champd5nbr = 1;
			while ($row = mysql_fetch_array($req)) { $champd5[] = $row; }
			while (80 >= $champd5nbr)
			{
				$champd5all = $champd5all . ', ' . $champd5[$champd5nbr]['compet_id'];
				$champd5nbr++;
			}
			
			//On recup les premiers de toutes les division 5
			$sql = "SELECT team_id FROM classement WHERE compet_id IN($champd5all) AND saison_nbr = '".$nbr['saison_nbr']."' AND classement= 1"; 
			$req = mysql_query($sql);
			$clubpromo = array();
			while ($row = mysql_fetch_array($req)) { $clubpromo[] = $row; }
			
			//...et les 9 championnat de d4
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '4'";
			$req = mysql_query($sql);
			$champd4 = array(); $nbzd4a = 0; $nbzd4b = 27; $nbzd4c = 54;
			while ($row = mysql_fetch_array($req)) { $champd4[] = $row; }
			while (26 >= $nbzd4a)
			{
				//On monte les �quipes en d4
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd4[$nbzd4a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd4a]['team_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd4[$nbzd4a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd4b]['team_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd4[$nbzd4a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd4c]['team_id']."'");
				$nbzd4a++; $nbzd4b++; $nbzd4c++;
			}
			
			//Descente des 81 �quipes de division4 : On recupere les 81 team_id...
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '4'"; 
			$req = mysql_query($sql);
			$data18 = mysql_fetch_array($req); $champd4all = $data18['compet_id'];
			
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '4'"; //pour ajouter les 81compet_id de d4 dans le IN du dessous
			$req = mysql_query($sql);
			$champd4 = array(); $champd4nbr = 1;
			while ($row = mysql_fetch_array($req)) { $champd4[] = $row; }
			while (26 >= $champd4nbr)
			{
				$champd4all = $champd4all . ', ' . $champd4[$champd4nbr]['compet_id'];
				$champd4nbr++;
			}
			
			$sql = "SELECT team_id FROM classement WHERE compet_id IN($champd4all) AND saison_nbr = '".$nbr['saison_nbr']."' AND classement IN(8, 9, 10)"; //On recup les 4 derniers de toutes les division 2
			$req = mysql_query($sql);
			$clubreleg = array();
			while ($row = mysql_fetch_array($req)) { $clubreleg[] = $row; }
			
			//...et les 81 championnat de d5
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '5'";  //On recup les 81 compet_id des 81 division5
			$req = mysql_query($sql);
			$champd5 = array(); $nbzd5 = 0;
			while ($row = mysql_fetch_array($req)) { $champd5[] = $row; }
			while (80 >= $nbzd5)
			{
				$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$champd4[$nbzd5]['compet_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd5[$nbzd5]['compet_id']."' WHERE team_id = '".$clubreleg[$nbzd5]['team_id']."'");
				$nbzd5++;
			}
			
			$teamreleg = 0;
			
			while (81 >= $teamreleg)
			{
				$sql = mysql_query("SELECT fictive FROM equipes WHERE team_id= '".$clubreleg[$teamreleg]['team_id']."'");
				$infoclubreleg = mysql_fetch_array($sql);
				
				if ($infoclubreleg['fictive'] == 0) //On modifie competition si equipe relegue fictive ou pas
				{
					//On rajoute une �quipe r�el au nouveau championnat (d5)
					$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$champd5[$teamreleg]['compet_id']."'");
					
					//On enleve une �quipe r�el � l'ancien championnat (d4)
					$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$champd4[$teamreleg]['compet_id']."'");
				}
				
				$teamreleg++;
			}
		}
		
		//_____________________________________ DIVISION 6 _____________________________________
		
		$sql = "SELECT COUNT(*) AS exist FROM competition WHERE pays_id= '".$pays_id."' AND division= '6'"; 
		$req = mysql_query($sql);
		$division6 = mysql_fetch_array($req);
		
		if ($division6['exist'] >= 1) //Si les championnat de d6 existe on lance le script de promotion/relegation
		{
			$div6 = 1;
			while (243 >= $div6)
			{
				$sql = "SELECT * FROM competition WHERE pays_id= '".$pays_id."' AND division= '6' AND poule= '".$div6."'"; 
				$req = mysql_query($sql);
				$data2 = mysql_fetch_array($req); $eqpd6 = 1;
				
				$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$data2['compet_id']."'");
				
				$classplus1 = 1;
				
				$sql7 = "SELECT * FROM classement WHERE compet_id='".$data2['compet_id']."' AND saison_nbr='".$nbr['saison_nbr']."' ORDER BY point DESC, BP-BC DESC";
				$req7 = mysql_query($sql7);
				while ($donnees4 = mysql_fetch_array($req7))
				{
					$requete = sql::update("UPDATE classement SET classement='".$classplus1."' WHERE class_id='".$donnees4['class_id']."'");
					
					$classplus1++;
				}
				
				while (10 >= $eqpd6)
				{
					$sql = "SELECT * FROM classement WHERE compet_id= '".$data2['compet_id']."' AND saison_nbr = '".$nbr['saison_nbr']."' AND classement = '".$eqpd6."'"; 
					$req = mysql_query($sql);
					$clasmnt = mysql_fetch_array($req);
					
					$sql = "SELECT team_cup, team_history, fictive FROM equipes WHERE team_id= '".$clasmnt['team_id']."'";
					$req = mysql_query($sql);
					$data6 = mysql_fetch_array($req);
					
					if ($clasmnt['classement'] == 1)
					{
						//On ajoute le classement de la saison � l'histoire de l'�quipe
						$classement = $data6['team_history'] . 'Saison ' . $clasmnt['saison_nbr'] . ' : Division ' . $data2['division'] . '-' . $data2['poule'] . ' #' . $clasmnt['classement'] . ';';
						$requete = sql::update("UPDATE equipes SET team_history = '".$classement."' WHERE team_id = '".$clasmnt['team_id']."'");
						
						//On ajoute une coupe division6 dans le team_cup de l'�quipe
						$cup = $data6['team_cup'] . 'cup_champd6.gif;';
						$requete = sql::update("UPDATE equipes SET team_cup = '".$cup."' WHERE team_id = '".$clasmnt['team_id']."'");
						
						if ($data6['fictive'] == 0) //Si c'est une �quipe r�el on modifie competition ------------ A VOIR
						{
							//On rajoute une �quipe r�el au nouveau championnat
							$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$data['compet_id']."'");
							
							//On enleve une �quipe r�el � l'ancien championnat
							$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$data2['compet_id']."'");
						}
					}
					
					else
					{
						//On ajoute le classement de la saison � l'histoire de l'�quipe
						$classement = $data6['team_history'] . 'Saison ' . $clasmnt['saison_nbr'] . ' : Division ' . $data2['division'] . '-' . $data2['poule'] . ' #' . $clasmnt['classement'] . ';';
						$requete = sql::update("UPDATE equipes SET team_history = '".$classement."' WHERE team_id = '".$clasmnt['team_id']."'");
					}
					
					$eqpd6++;
				}
				
				$div6++;
			}
			
			//Monter des 243 �quipes de division6 : On recupere les 243 team_id...
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '6'"; 
			$req = mysql_query($sql);
			$data19 = mysql_fetch_array($req); $champd6all = $data19['compet_id'];
			
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '6'"; //pour ajouter les 243compet_id de d6 dans le IN du dessous
			$req = mysql_query($sql);
			$champd6 = array(); $champd6nbr = 1;
			while ($row = mysql_fetch_array($req)) { $champd6[] = $row; }
			while (242 >= $champd6nbr)
			{
				$champd6all = $champd6all . ', ' . $champd6[$champd6nbr]['compet_id'];
				$champd6nbr++;
			}
			
			//On recup les premiers de toutes les division 6
			$sql = "SELECT team_id FROM classement WHERE compet_id IN($champd6all) AND saison_nbr = '".$nbr['saison_nbr']."' AND classement= 1"; 
			$req = mysql_query($sql);
			$clubpromo = array();
			while ($row = mysql_fetch_array($req)) { $clubpromo[] = $row; }
			
			//...et les 81 championnat de d5
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '5'";
			$req = mysql_query($sql);
			$champd5 = array(); $nbzd5a = 0; $nbzd5b = 81; $nbzd5c = 162;
			while ($row = mysql_fetch_array($req)) { $champd5[] = $row; }
			while (80 >= $nbzd5a)
			{
				//On monte les �quipes en d5
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd5[$nbzd5a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd5a]['team_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd5[$nbzd5a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd5b]['team_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd5[$nbzd5a]['compet_id']."' WHERE team_id = '".$clubpromo[$nbzd5c]['team_id']."'");
				$nbzd5a++; $nbzd5b++; $nbzd5c++;
			}
			
			//Descente des 81 �quipes de division5 : On recupere les 81 team_id...
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '5'"; 
			$req = mysql_query($sql);
			$data18 = mysql_fetch_array($req); $champd5all = $data18['compet_id'];
			
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '5'"; //pour ajouter les 81compet_id de d5 dans le IN du dessous
			$req = mysql_query($sql);
			$champd5 = array(); $champd5nbr = 1;
			while ($row = mysql_fetch_array($req)) { $champd5[] = $row; }
			while (80 >= $champd5nbr)
			{
				$champd5all = $champd5all . ', ' . $champd5[$champd5nbr]['compet_id'];
				$champd5nbr++;
			}
			
			$sql = "SELECT team_id FROM classement WHERE compet_id IN($champd5all) AND saison_nbr = '".$nbr['saison_nbr']."' AND classement IN(8, 9, 10)"; //On recup les 5 derniers de toutes les division 2
			$req = mysql_query($sql);
			$clubreleg = array();
			while ($row = mysql_fetch_array($req)) { $clubreleg[] = $row; }
			
			//...et les 243 championnat de d6
			$sql = "SELECT compet_id FROM competition WHERE pays_id= '".$pays_id."' AND division= '6'";  //On recup les 243 compet_id des 243 division6
			$req = mysql_query($sql);
			$champd6 = array(); $nbzd6 = 0;
			while ($row = mysql_fetch_array($req)) { $champd6[] = $row; }
			while (243 >= $nbzd6)
			{
				$requete = sql::update("UPDATE competition SET compet_name = 'misaison' WHERE compet_id = '".$champd5[$nbzd6]['compet_id']."'");
				$requete = sql::update("UPDATE equipes SET compet_id = '".$champd6[$nbzd6]['compet_id']."' WHERE team_id = '".$clubreleg[$nbzd6]['team_id']."'");
				$nbzd6++;
			}
			
			$teamreleg = 0;
			
			while (243 >= $teamreleg)
			{
				$sql = mysql_query("SELECT fictive FROM equipes WHERE team_id= '".$clubreleg[$teamreleg]['team_id']."'");
				$infoclubreleg = mysql_fetch_array($sql);
				
				if ($infoclubreleg['fictive'] == 0) //On modifie competition si equipe relegue fictive ou pas
				{
					//On rajoute une �quipe r�el au nouveau championnat (d6)
					$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe + 1, nb_equipe_fictive = nb_equipe_fictive - 1 WHERE compet_id = '".$champd6[$teamreleg]['compet_id']."'");
					
					//On enleve une �quipe r�el � l'ancien championnat (d5)
					$requete = sql::update("UPDATE competition SET nb_equipe = nb_equipe - 1, nb_equipe_fictive = nb_equipe_fictive + 1 WHERE compet_id = '".$champd5[$teamreleg]['compet_id']."'");
				}
				
				$teamreleg++;
			}
		}
		/*
			On recup classement division 	1 => Premier on lui ajoute une coupe (gif) dans team_cup (saison;cupd1.gif) + team_history
								2 � 7 => team_history
								8, 9, 10 => releguer  + team_history
			On recup les 3 classements division 2	1 => Premier on lui ajoute une coupe (gif) dans team_cup (saison;cupd2.gif) + team_history
									2 � 7 => team_history
									8, 9, 10 => releguer + team_history
			Si championnat inf�rieur => Update les equipes remplace D1-1 8eme par D2-1 1er, D1-1 9eme par D2-2 1er, D1-1 10eme par D2-3 1er
			
			On ajoute 1 an � tous les joueurs � partir de pays_id
			On update les salaires des joueurs selon leur notes
			
			On cr�e le classement avec les nouvelles �quipes
			
			On cr�e les rencontres avec saison_nbr + 1
			
		*/
	}
	
	function new_saison_rencontre($pays_id, $CONF)
	{
		//A partir de la c'est g�n�rique ------------------------
		$data = sql::fetch("SELECT * FROM competition WHERE pays_id= '".$pays_id."' AND division= '1'");
		
		$nbr = sql::fetch("SELECT saison_nbr FROM classement WHERE compet_id='".$data['compet_id']."' ORDER BY saison_nbr DESC LIMIT 1");
		$saison_id = $nbr['saison_nbr'] + 1; //La derni�re saison en cours plus 1
		
		//On recup toutes les �quipes du pays
		$req = sql::query("SELECT * FROM equipes WHERE team_country= '".$pays_id."'");
		
		while ($donnees4 = mysql_fetch_array($req))
		{
			//On cr�e tous les classements pour la saison � venir...
			$requete = sql::insert("INSERT INTO classement(compet_id, team_id, saison_nbr) 
									VALUES('".$donnees4['compet_id']."', '".$donnees4['team_id']."', '".$saison_id."')"); 
		}
		
		//On recup la derni�re division en cours pour le switch...
		$data5 = sql::fetch("SELECT division FROM competition WHERE pays_id = '".$pays_id."' ORDER BY division DESC LIMIT 1");
		
		switch($data5['division']) //...qui calcule le nombre de competition pour la boucle calendrier
		{
			case 1: $compet_nbr = 1; break; //Division 1 : 1 comp�tition
			case 2: $compet_nbr = 4; break; //Division 2 : 4 comp�titions (div1 + 3 div2)
			case 3: $compet_nbr = 13; break; //...
			case 4: $compet_nbr = 40; break;
			case 5: $compet_nbr = 121; break;
			case 6: $compet_nbr = 364; break;
			default : $compet_nbr = 1; break;
		}
		
		$calend = 1;
		
		//les infos du pays
		$view = sql::fetch("SELECT pays_champ, pays_file_nom, pays_file_prenom, config_nbteam_perchamp, config_heurematch, config_tpsentre2match 
							FROM pays 
							WHERE pays_id = '".$pays_id."'");
		
		$hourmatch = explode(':', $view['config_heurematch']); //Heure des matchs
		$delaimatch = $view['config_tpsentre2match']; //delai entre 2 matchs (jours)
		
		$stampday1 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + $delaimatch, date("Y"));
		$stampday2 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 2), date("Y"));
		$stampday3 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 3), date("Y"));
		$stampday4 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 4), date("Y"));
		$stampday5 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 5), date("Y"));
		$stampday6 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 6), date("Y"));
		$stampday7 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 7), date("Y"));
		$stampday8 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 8), date("Y"));
		$stampday9 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 9), date("Y"));
		$stampday10 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 10), date("Y"));
		$stampday11 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 11), date("Y"));
		$stampday12 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 12), date("Y"));
		$stampday13 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 13), date("Y"));
		$stampday14 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 14), date("Y"));
		$stampday15 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 15), date("Y"));
		$stampday16 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 16), date("Y"));
		$stampday17 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 17), date("Y"));
		$stampday18 = mktime($hourmatch[0], $hourmatch[1], 0, date("m"), date("d") + ($delaimatch * 18), date("Y"));
		
		//Cr�ation du calendrier pour la nouvelle saison
		while ($compet_nbr >= $calend)
		{
			$misaison = sql::fetch("SELECT compet_id 
									FROM competition 
									WHERE compet_name = 'misaison' 
									ORDER BY compet_id LIMIT 1");
			
			$compet_id = $misaison['compet_id'];
			
			//Recuperation de toutes les �quipes du championnat
			$req = sql::query("SELECT team_id 
							   FROM equipes 
							   WHERE compet_id = '".$compet_id."' 
							   ORDER BY rand(team_id)");
			
			while($renc = mysql_fetch_assoc($req))
			{ $equipe[] = $renc['team_id']; }
			
			//Cr�ation des matchs du championnat � 10
			$requete = sql::insert("INSERT INTO matchs(saison_nbr, compet_id, timematch, journee, team_id1, team_id2) 
						VALUES('".$saison_id."', '".$compet_id."', '".$stampday1."', 1, '".$equipe[0]."', '".$equipe[1]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday1."', 1, '".$equipe[2]."', '".$equipe[3]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday1."', 1, '".$equipe[4]."', '".$equipe[5]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday1."', 1, '".$equipe[6]."', '".$equipe[7]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday1."', 1, '".$equipe[8]."', '".$equipe[9]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday2."', 2, '".$equipe[5]."', '".$equipe[8]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday2."', 2, '".$equipe[7]."', '".$equipe[9]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday2."', 2, '".$equipe[2]."', '".$equipe[0]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday2."', 2, '".$equipe[1]."', '".$equipe[4]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday2."', 2, '".$equipe[3]."', '".$equipe[6]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday3."', 3, '".$equipe[9]."', '".$equipe[3]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday3."', 3, '".$equipe[0]."', '".$equipe[4]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday3."', 3, '".$equipe[8]."', '".$equipe[1]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday3."', 3, '".$equipe[6]."', '".$equipe[2]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday3."', 3, '".$equipe[7]."', '".$equipe[5]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday4."', 4, '".$equipe[3]."', '".$equipe[5]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday4."', 4, '".$equipe[2]."', '".$equipe[9]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday4."', 4, '".$equipe[6]."', '".$equipe[0]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday4."', 4, '".$equipe[1]."', '".$equipe[7]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday4."', 4, '".$equipe[4]."', '".$equipe[8]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday5."', 5, '".$equipe[7]."', '".$equipe[4]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday5."', 5, '".$equipe[3]."', '".$equipe[1]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday5."', 5, '".$equipe[5]."', '".$equipe[2]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday5."', 5, '".$equipe[0]."', '".$equipe[8]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday5."', 5, '".$equipe[9]."', '".$equipe[6]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday6."', 6, '".$equipe[1]."', '".$equipe[2]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday6."', 6, '".$equipe[8]."', '".$equipe[7]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday6."', 6, '".$equipe[9]."', '".$equipe[0]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday6."', 6, '".$equipe[6]."', '".$equipe[5]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday6."', 6, '".$equipe[4]."', '".$equipe[3]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday7."', 7, '".$equipe[0]."', '".$equipe[7]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday7."', 7, '".$equipe[5]."', '".$equipe[9]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday7."', 7, '".$equipe[3]."', '".$equipe[8]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday7."', 7, '".$equipe[2]."', '".$equipe[4]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday7."', 7, '".$equipe[1]."', '".$equipe[6]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday8."', 8, '".$equipe[9]."', '".$equipe[1]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday8."', 8, '".$equipe[8]."', '".$equipe[2]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday8."', 8, '".$equipe[6]."', '".$equipe[4]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday8."', 8, '".$equipe[7]."', '".$equipe[3]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday8."', 8, '".$equipe[5]."', '".$equipe[0]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday9."', 9, '".$equipe[8]."', '".$equipe[6]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday9."', 9, '".$equipe[0]."', '".$equipe[3]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday9."', 9, '".$equipe[1]."', '".$equipe[5]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday9."', 9, '".$equipe[4]."', '".$equipe[9]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday9."', 9, '".$equipe[2]."', '".$equipe[7]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday10."', 10, '".$equipe[1]."', '".$equipe[0]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday10."', 10, '".$equipe[3]."', '".$equipe[2]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday10."', 10, '".$equipe[5]."', '".$equipe[4]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday10."', 10, '".$equipe[7]."', '".$equipe[6]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday10."', 10, '".$equipe[9]."', '".$equipe[8]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday11."', 11, '".$equipe[8]."', '".$equipe[5]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday11."', 11, '".$equipe[9]."', '".$equipe[7]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday11."', 11, '".$equipe[0]."', '".$equipe[2]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday11."', 11, '".$equipe[4]."', '".$equipe[1]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday11."', 11, '".$equipe[6]."', '".$equipe[3]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday12."', 12, '".$equipe[3]."', '".$equipe[9]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday12."', 12, '".$equipe[4]."', '".$equipe[0]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday12."', 12, '".$equipe[1]."', '".$equipe[8]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday12."', 12, '".$equipe[2]."', '".$equipe[6]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday12."', 12, '".$equipe[5]."', '".$equipe[7]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday13."', 13, '".$equipe[5]."', '".$equipe[3]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday13."', 13, '".$equipe[9]."', '".$equipe[2]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday13."', 13, '".$equipe[0]."', '".$equipe[6]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday13."', 13, '".$equipe[7]."', '".$equipe[1]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday13."', 13, '".$equipe[8]."', '".$equipe[4]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday14."', 14, '".$equipe[4]."', '".$equipe[7]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday14."', 14, '".$equipe[1]."', '".$equipe[3]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday14."', 14, '".$equipe[2]."', '".$equipe[5]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday14."', 14, '".$equipe[8]."', '".$equipe[0]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday14."', 14, '".$equipe[6]."', '".$equipe[9]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday15."', 15, '".$equipe[2]."', '".$equipe[1]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday15."', 15, '".$equipe[7]."', '".$equipe[8]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday15."', 15, '".$equipe[0]."', '".$equipe[9]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday15."', 15, '".$equipe[5]."', '".$equipe[6]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday15."', 15, '".$equipe[3]."', '".$equipe[4]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday16."', 16, '".$equipe[7]."', '".$equipe[0]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday16."', 16, '".$equipe[9]."', '".$equipe[5]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday16."', 16, '".$equipe[8]."', '".$equipe[3]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday16."', 16, '".$equipe[4]."', '".$equipe[2]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday16."', 16, '".$equipe[6]."', '".$equipe[1]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday17."', 17, '".$equipe[1]."', '".$equipe[9]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday17."', 17, '".$equipe[2]."', '".$equipe[8]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday17."', 17, '".$equipe[4]."', '".$equipe[6]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday17."', 17, '".$equipe[3]."', '".$equipe[7]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday17."', 17, '".$equipe[0]."', '".$equipe[5]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday18."', 18, '".$equipe[6]."', '".$equipe[8]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday18."', 18, '".$equipe[3]."', '".$equipe[0]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday18."', 18, '".$equipe[5]."', '".$equipe[1]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday18."', 18, '".$equipe[9]."', '".$equipe[4]."'),
							  ('".$saison_id."', '".$compet_id."', '".$stampday18."', 18, '".$equipe[7]."', '".$equipe[2]."')");
			
			$requete = sql::update("UPDATE competition SET compet_name = '".$view['pays_champ']."' WHERE compet_id = '".$compet_id."'");
			
			$calend++;
		}
		
		//Partie joueurs
		$req = sql::query("SELECT * FROM equipes WHERE team_country= '".$pays_id."'");
		while ($donnees5 = mysql_fetch_array($req))
		{
			//On ajoute 1 an � chaque joueur
			$requete = sql::update("UPDATE joueurs SET age = age + 1 WHERE team_id = '".$donnees5['team_id']."'");
			
			//On vide le champ sponsor_id de equipes
			$requete = sql::update("UPDATE equipes SET sponsor_id = 'NULL' WHERE team_id = '".$donnees5['team_id']."'"); 
		}
		
		$req = mysql_query("SELECT player_id FROM joueurs 
							LEFT JOIN equipes ON joueurs.team_id = equipes.team_id
							WHERE team_country= '".$pays_id."'");
		
		while ($donnees6 = mysql_fetch_array($req))
		{
			//Classement des joueurs
			$requete = sql::insert("INSERT INTO classement_joueur(player_id, saison_nbr) 
									VALUES ('".$donnees6['player_id']."', '".$saison_id."')");
			
			//Calcul des nouveaux salaires
		}
		
		//Tous les joueurs qui ont plus de 34 ans partent � la retraite (effacer)
		$requete = sql::delete("DELETE FROM joueurs WHERE age > 35");
	}
	
	// BASE DE DONNEE____________________________________________

	function crea_country($pays_name, $pays_champ, $pays_zone, $pays_file_nom, $pays_file_prenom, $pays_flag, $pays_money, $pays_select, $pays_actif, $config_nbteam_perchamp, $config_heurematch, $config_tpsentre2match)
	{
		$requete = sql::insert("INSERT INTO pays
		VALUES ('', '".addslashes($pays_name)."', '".addslashes($pays_champ)."', '".$pays_zone."', '".$pays_file_nom."', '".$pays_file_prenom."', '".$pays_flag."', 
				'".$pays_money."', '".$pays_select."', '".$pays_actif."', '".$config_nbteam_perchamp."', '".$config_heurematch."', '".$config_tpsentre2match."', '')"); 
		$resultat = mysql_query($requete);
	}

	// CONFIGURATION____________________________________________

	function updateconfig($value, $name)
	{
		if ($value != NULL)
		{
			$requete = sql::update("UPDATE configuration SET config_value = '".$value."' WHERE config_name = '".$name."'");
		}
	}
}
?>