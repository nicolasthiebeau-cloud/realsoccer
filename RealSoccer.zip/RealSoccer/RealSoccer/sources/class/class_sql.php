<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
15/05/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

define('BDD_PORT', 3306);

class sql
{
    function connect()
    {
        mysql_connect(BDD_HOST.':'.BDD_PORT, BDD_USER, BDD_PASS) 
				or die('<font color="red">IMPOSSIBLE DE SE CONNECTER AU SERVEUR SQL
						<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;HOST :</font> '.BDD_HOST.'
						<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">PORT :</font> '.BDD_PORT.'
						<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">UTILISATEUR :</font> '.BDD_USER.'
						<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">PASS :</font> ********
						<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">ERREUR : </font>'.mysql_error()
					  );
					   
        mysql_select_db(BDD_NOM) 
				or die('<font color="red">IL EST IMPOSSIBLE DE SELECTIONNER LA BASE DE DONN�ES
						<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;BASE DEMAND� : </font>'.BDD_NOM.'
						<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">ERREUR : </font>'.mysql_error()
					  );
    }

    function close()
    {
        mysql_close()
						or die(mysql_error());
    }
	
	function chrono()
	{
		$temps = explode(' ', microtime());
		return $temps[0]+$temps[1];
	}
	
    function fetch($texte)
    {
        global $nombrerequetes, $timer_requetes;
		$nombrerequetes++;
		$debut = sql::chrono();
		
        $query = mysql_query($texte) 
						or die(mysql_error());
        $row = mysql_fetch_array($query);
		
		$timer_requetes += round(sql::chrono()-$debut,6);
        
        return $row;
    }
	
	function query($texte)
    {
        global $nombrerequetes, $timer_requetes;
		$nombrerequetes++;
		$debut = sql::chrono();
		
        $query = mysql_query($texte) 
						or die(mysql_error());
        
		$timer_requetes += round(sql::chrono()-$debut,6);
		
        return $query;
    }
	
	function update($texte)
    {
        global $nombrerequetes, $timer_requetes;
		$nombrerequetes++;
		$debut = sql::chrono();
		
        mysql_query($texte) 
						or die(mysql_error());
        
		$timer_requetes += round(sql::chrono()-$debut,6);
    }
	
	function delete($texte)
    {
        global $nombrerequetes, $timer_requetes;
		$nombrerequetes++;
		$debut = sql::chrono();
		
        mysql_query($texte) 
						or die(mysql_error());
        
		$timer_requetes += round(sql::chrono()-$debut,6);
    }
	
	function insert($texte)
    {
        global $nombrerequetes, $timer_requetes;
		$nombrerequetes++;
		$debut = sql::chrono();
		
        mysql_query($texte) 
						or die(mysql_error());
        
		$timer_requetes += round(sql::chrono()-$debut,6);
    }
}
?>