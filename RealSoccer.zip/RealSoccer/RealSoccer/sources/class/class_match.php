<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
15/05/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

class match
{
	function match_start($compet, $match, $team, $mode, $CONF)
	{
		$date = time() + ($CONF['decal_time'] * 60 * 60); //L'heure actuelle avec l'option decalage (timestamp)
		
		if($mode == 1) //Page match (1 match)
		{
			$infomatch = sql::fetch("SELECT matchs.renco_id renco_id, saison_nbr, matchs.compet_id compet_id, timematch, team_id1, team_id2, renco_type, 
											 equipes1.team_shirt_dom team1_shirt_dom, equipes1.stade_name stade_name, equipes1.stade_infra stade_infra, 
											 pays_id, pays_file_nom, pays_file_prenom, pays_flag, 
											 equipes2.team_shirt_dom team2_shirt_dom, equipes2.team_shirt_ext team2_shirt_ext,  
											 tactik1.tact_id tact_id1, tactik1.tact_using tact_using1, 
											 tactik2.tact_id tact_id2, tactik2.tact_using tact_using2,  
											 match_id 
									  FROM matchs 
									  LEFT JOIN equipes equipes1 ON equipes1.team_id = matchs.team_id1 
									  LEFT JOIN pays ON pays.pays_id = equipes1.team_country 
									  LEFT JOIN equipes equipes2 ON equipes2.team_id = matchs.team_id2 
									  LEFT JOIN tactiques tactik1 ON tactik1.id_team = matchs.team_id1 
									  LEFT JOIN tactiques tactik2 ON tactik2.id_team = matchs.team_id2 
									  LEFT JOIN matchs_encours ON matchs_encours.renco_id = matchs.renco_id 
									  WHERE timematch <= {$date} 
										AND score1 = ' ' 
										AND matchs.compet_id IN ({$compet}, 0) 
										AND ((team_id1 = {$team} OR team_id2 = {$team}) 
										 OR (team_id1 != {$team} OR team_id2 != {$team}))
									  LIMIT 1");
		}
		
		if(isset($infomatch['renco_id']) && !isset($infomatch['match_id']))
		{
			// Partie M�t�o (Al�atoire pour l'instant ensuite selon la r�gion)
			$meteo = match_apl::meteo();
			
			//Partie Stade
			$stadename = explode(';', $infomatch['stade_name']);
			$affluence = match_apl::stade($infomatch['stade_infra'], $infomatch['renco_type'], $infomatch['team_id1'], $infomatch['team_id2'], $meteo, $CONF);
			
			// Partie Arbitre
			$arbitre_name = match_apl::arbitre($infomatch['pays_file_nom'], $infomatch['pays_file_prenom'], $infomatch['pays_flag']);
			
			//Partie Maillot
			$maillot_team1 = $infomatch['team1_shirt_dom'];
			$maillot_team2 = $infomatch['team2_shirt_ext'];
			
			if($maillot_team1 == $maillot_team2) $maillot_team2 = $infomatch['team2_shirt_dom'];
			
			//Partie Tactique
			if(isset($infomatch['tact_using1']))
			{
				if($infomatch['tact_using1'] == "442" OR $infomatch['tact_using1'] == "442etoile")
				{ $position1 = 1; $position2 = $position3 = $position4 = $position5 = 2; $position6 = $position7 = $position8 = $position9 = 3; $position10 = $position11 = 4; }
				elseif($infomatch['tact_using1'] == "433")
				{ $position1 = 1; $position2 = $position3 = $position4 = $position5 = 2; $position6 = $position7 = $position8 = 3; $position9 = $position10 = $position11 = 4; }
				elseif($infomatch['tact_using1'] == "451")
				{ $position1 = 1; $position2 = $position3 = $position4 = $position5 = 2; $position6 = $position7 = $position8 = $position9 = $position10 = 3; $position11 = 4; }
				elseif($infomatch['tact_using1'] == "352")
				{ $position1 = 1; $position2 = $position3 = $position4 = 2; $position5 = $position6 = $position7 = $position8 = $position9 = 3; $position10 = $position11 = 4; }
				elseif($infomatch['tact_using1'] == "541")
				{ $position1 = 1; $position2 = $position3 = $position4 = $position5 = $position6 = 2; $position7 = $position8 = $position9 = $position10 = 3; $position11 = 4; }
				elseif($infomatch['tact_using1'] == "343")
				{ $position1 = 1; $position2 = $position3 = $position4 = 2; $position5 = $position6 = $position7 = $position8 = 3; $position9 = $position10 = $position11 = 4; }
				elseif($infomatch['tact_using1'] == "352")
				{ $position1 = 1; $position2 = $position3 = $position4 = 2; $position5 = $position6 = $position7 = $position8 = $position9 = 3; $position10 = $position11 = 4; }
				
				$infojoueur = sql::fetch("SELECT joueur1.player_id player_id1, joueur1.nom nom1, joueur1.prenom prenom1, joueur1.position position1, joueur1.forme forme1, joueur1.moral moral1, joueur1.talent talent1, joueur1.influence influence1, joueur1.reflexes reflexes1, joueur1.pdballe pdballe1, joueur1.degagement degagement1, joueur1.marquage marquage1, joueur1.tacles tacles1, joueur1.tete tete1, joueur1.centres centres1, joueur1.passes passes1, joueur1.vitesse vitesse1, joueur1.tir tir1, joueur1.creativite creativite1, joueur1.dribble dribble1, 
												 joueur2.player_id player_id2, joueur2.nom nom2, joueur2.prenom prenom2, joueur2.position position2, joueur2.forme forme2, joueur2.moral moral2, joueur2.talent talent2, joueur2.influence influence2, joueur2.reflexes reflexes2, joueur2.pdballe pdballe2, joueur2.degagement degagement2, joueur2.marquage marquage2, joueur2.tacles tacles2, joueur2.tete tete2, joueur2.centres centres2, joueur2.passes passes2, joueur2.vitesse vitesse2, joueur2.tir tir2, joueur2.creativite creativite2, joueur2.dribble dribble2, 
												 joueur3.player_id player_id3, joueur3.nom nom3, joueur3.prenom prenom3, joueur3.position position3, joueur3.forme forme3, joueur3.moral moral3, joueur3.talent talent3, joueur3.influence influence3, joueur3.reflexes reflexes3, joueur3.pdballe pdballe3, joueur3.degagement degagement3, joueur3.marquage marquage3, joueur3.tacles tacles3, joueur3.tete tete3, joueur3.centres centres3, joueur3.passes passes3, joueur3.vitesse vitesse3, joueur3.tir tir3, joueur3.creativite creativite3, joueur3.dribble dribble3, 
												 joueur4.player_id player_id4, joueur4.nom nom4, joueur4.prenom prenom4, joueur4.position position4, joueur4.forme forme4, joueur4.moral moral4, joueur4.talent talent4, joueur4.influence influence4, joueur4.reflexes reflexes4, joueur4.pdballe pdballe4, joueur4.degagement degagement4, joueur4.marquage marquage4, joueur4.tacles tacles4, joueur4.tete tete4, joueur4.centres centres4, joueur4.passes passes4, joueur4.vitesse vitesse4, joueur4.tir tir4, joueur4.creativite creativite4, joueur4.dribble dribble4, 
												 joueur5.player_id player_id5, joueur5.nom nom5, joueur5.prenom prenom5, joueur5.position position5, joueur5.forme forme5, joueur5.moral moral5, joueur5.talent talent5, joueur5.influence influence5, joueur5.reflexes reflexes5, joueur5.pdballe pdballe5, joueur5.degagement degagement5, joueur5.marquage marquage5, joueur5.tacles tacles5, joueur5.tete tete5, joueur5.centres centres5, joueur5.passes passes5, joueur5.vitesse vitesse5, joueur5.tir tir5, joueur5.creativite creativite5, joueur5.dribble dribble5, 
												 joueur6.player_id player_id6, joueur6.nom nom6, joueur6.prenom prenom6, joueur6.position position6, joueur6.forme forme6, joueur6.moral moral6, joueur6.talent talent6, joueur6.influence influence6, joueur6.reflexes reflexes6, joueur6.pdballe pdballe6, joueur6.degagement degagement6, joueur6.marquage marquage6, joueur6.tacles tacles6, joueur6.tete tete6, joueur6.centres centres6, joueur6.passes passes6, joueur6.vitesse vitesse6, joueur6.tir tir6, joueur6.creativite creativite6, joueur6.dribble dribble6, 
												 joueur7.player_id player_id7, joueur7.nom nom7, joueur7.prenom prenom7, joueur7.position position7, joueur7.forme forme7, joueur7.moral moral7, joueur7.talent talent7, joueur7.influence influence7, joueur7.reflexes reflexes7, joueur7.pdballe pdballe7, joueur7.degagement degagement7, joueur7.marquage marquage7, joueur7.tacles tacles7, joueur7.tete tete7, joueur7.centres centres7, joueur7.passes passes7, joueur7.vitesse vitesse7, joueur7.tir tir7, joueur7.creativite creativite7, joueur7.dribble dribble7, 
												 joueur8.player_id player_id8, joueur8.nom nom8, joueur8.prenom prenom8, joueur8.position position8, joueur8.forme forme8, joueur8.moral moral8, joueur8.talent talent8, joueur8.influence influence8, joueur8.reflexes reflexes8, joueur8.pdballe pdballe8, joueur8.degagement degagement8, joueur8.marquage marquage8, joueur8.tacles tacles8, joueur8.tete tete8, joueur8.centres centres8, joueur8.passes passes8, joueur8.vitesse vitesse8, joueur8.tir tir8, joueur8.creativite creativite8, joueur8.dribble dribble8, 
												 joueur9.player_id player_id9, joueur9.nom nom9, joueur9.prenom prenom9, joueur9.position position9, joueur9.forme forme9, joueur9.moral moral9, joueur9.talent talent9, joueur9.influence influence9, joueur9.reflexes reflexes9, joueur9.pdballe pdballe9, joueur9.degagement degagement9, joueur9.marquage marquage9, joueur9.tacles tacles9, joueur9.tete tete9, joueur9.centres centres9, joueur9.passes passes9, joueur9.vitesse vitesse9, joueur9.tir tir9, joueur9.creativite creativite9, joueur9.dribble dribble9, 
												 joueur10.player_id player_id10, joueur10.nom nom10, joueur10.prenom prenom10, joueur10.position position10, joueur10.forme forme10, joueur10.moral moral10, joueur10.talent talent10, joueur10.influence influence10, joueur10.reflexes reflexes10, joueur10.pdballe pdballe10, joueur10.degagement degagement10, joueur10.marquage marquage10, joueur10.tacles tacles10, joueur10.tete tete10, joueur10.centres centres10, joueur10.passes passes10, joueur10.vitesse vitesse10, joueur10.tir tir10, joueur10.creativite creativite10, joueur10.dribble dribble10, 
												 joueur11.player_id player_id11, joueur11.nom nom11, joueur11.prenom prenom11, joueur11.position position11, joueur11.forme forme11, joueur11.moral moral11, joueur11.talent talent11, joueur11.influence influence11, joueur11.reflexes reflexes11, joueur11.pdballe pdballe11, joueur11.degagement degagement11, joueur11.marquage marquage11, joueur11.tacles tacles11, joueur11.tete tete11, joueur11.centres centres11, joueur11.passes passes11, joueur11.vitesse vitesse11, joueur11.tir tir11, joueur11.creativite creativite11, joueur11.dribble dribble11 
										  FROM tactiques 
										  LEFT JOIN joueurs joueur1 ON joueur1.player_id = tactiques.N1 
										  LEFT JOIN joueurs joueur2 ON joueur2.player_id = tactiques.N2 
										  LEFT JOIN joueurs joueur3 ON joueur3.player_id = tactiques.N3 
										  LEFT JOIN joueurs joueur4 ON joueur4.player_id = tactiques.N4 
										  LEFT JOIN joueurs joueur5 ON joueur5.player_id = tactiques.N5 
										  LEFT JOIN joueurs joueur6 ON joueur6.player_id = tactiques.N6 
										  LEFT JOIN joueurs joueur7 ON joueur7.player_id = tactiques.N7 
										  LEFT JOIN joueurs joueur8 ON joueur8.player_id = tactiques.N8 
										  LEFT JOIN joueurs joueur9 ON joueur9.player_id = tactiques.N9 
										  LEFT JOIN joueurs joueur10 ON joueur10.player_id = tactiques.N10 
										  LEFT JOIN joueurs joueur11 ON joueur11.player_id = tactiques.N11 
										  WHERE tact_id = {$infomatch['tact_id1']}");
				
				$count_eq1 = 1;
				$eq1_note = 0;
				$eq1_id = array();
				$eq1_name = array();
				
				while($count_eq1 <= 11)
				{
					switch($count_eq1)
					{
						case 1 : $position = $position1; break;
						case 2 : $position = $position2; break;
						case 3 : $position = $position3; break;
						case 4 : $position = $position4; break;
						case 5 : $position = $position5; break;
						case 6 : $position = $position6; break;
						case 7 : $position = $position7; break;
						case 8 : $position = $position8; break;
						case 9 : $position = $position9; break;
						case 10 : $position = $position10; break;
						case 11 : $position = $position11; break;
						default : echo'erreur'; break;
					}
					
					if($infojoueur['player_id' . $count_eq1] != 0)
					{
						$eq1_id[] = $infojoueur['player_id' . $count_eq1];
						$eq1_name[] = match_apl::prmslettre($infojoueur['prenom' . $count_eq1]) . ' ' . $infojoueur['nom' . $count_eq1];
						$eq1_note += match_apl::note($position, $infojoueur['forme' . $count_eq1], $infojoueur['moral' . $count_eq1], $infojoueur['talent' . $count_eq1], $infojoueur['influence' . $count_eq1], $infojoueur['reflexes' . $count_eq1], $infojoueur['pdballe' . $count_eq1], $infojoueur['degagement' . $count_eq1], $infojoueur['marquage' . $count_eq1], $infojoueur['tacles' . $count_eq1], $infojoueur['tete' . $count_eq1], $infojoueur['centres' . $count_eq1], $infojoueur['passes' . $count_eq1], $infojoueur['vitesse' . $count_eq1], $infojoueur['tir' . $count_eq1], $infojoueur['creativite' . $count_eq1], $infojoueur['dribble' . $count_eq1]);
					}
					
					else
					{
						$newplayer = match_apl::recup_randplayer($infomatch['team_id1'], $infojoueur['player_id1'], $infojoueur['player_id2'], $infojoueur['player_id3'], $infojoueur['player_id4'], $infojoueur['player_id5'], $infojoueur['player_id6'], $infojoueur['player_id7'], $infojoueur['player_id8'], $infojoueur['player_id9'], $infojoueur['player_id10'], $infojoueur['player_id11']);
						$eq1_id[] = $newplayer['player_id'];
						$eq1_name[] = match_apl::prmslettre($newplayer['prenom']) . ' ' . $newplayer['nom'];
						$eq1_note += match_apl::note($position, $newplayer['forme'], $newplayer['moral'], $newplayer['talent'], $newplayer['influence'], $newplayer['reflexes'], $newplayer['pdballe'], $newplayer['degagement'], $newplayer['marquage'], $newplayer['tacles'], $newplayer['tete'], $newplayer['centres'], $newplayer['passes'], $newplayer['vitesse'], $newplayer['tir'], $newplayer['creativite'], $newplayer['dribble']);
					}
					
					$count_eq1++;
				}
			}
			
			else
			{
				$position1 = 1; $position2 = $position3 = $position4 = $position5 = 2; $position6 = $position7 = $position8 = $position9 = 3; $position10 = $position11 = 4;
				
				$req = sql::query("SELECT player_id, nom, prenom, position, forme, moral, talent, influence, reflexes, pdballe, degagement, marquage, tacles, tete, centres, passes, vitesse, tir, creativite, dribble 
								   FROM joueurs 
								   WHERE team_id = {$infomatch['team_id1']} 
									 AND indisponible = 0 
								   ORDER BY position, RAND()");
				
				$count_eq1 = 1;
				$eq1_note = 0;
				$eq1_id = array();
				$eq1_name = array();
				
				while($infojoueur = mysql_fetch_assoc($req))
				{
					switch($count_eq1)
					{
						case 1 : $position = $position1; break;
						case 2 : $position = $position2; break;
						case 3 : $position = $position3; break;
						case 4 : $position = $position4; break;
						case 5 : $position = $position5; break;
						case 6 : $position = $position6; break;
						case 7 : $position = $position7; break;
						case 8 : $position = $position8; break;
						case 9 : $position = $position9; break;
						case 10 : $position = $position10; break;
						case 11 : $position = $position11; break;
						default : $position = 0; break;
					}
					
					if($position == $infojoueur['position'])
					{
						$eq1_id[] = $infojoueur['player_id'];
						$eq1_name[] = match_apl::prmslettre($infojoueur['prenom']) . ' ' . $infojoueur['nom'];
						$eq1_note += match_apl::note($position, $infojoueur['forme'], $infojoueur['moral'], $infojoueur['talent'], $infojoueur['influence'], $infojoueur['reflexes'], $infojoueur['pdballe'], $infojoueur['degagement'], $infojoueur['marquage'], $infojoueur['tacles'], $infojoueur['tete'], $infojoueur['centres'], $infojoueur['passes'], $infojoueur['vitesse'], $infojoueur['tir'], $infojoueur['creativite'], $infojoueur['dribble']);
						$count_eq1++;
					}
				}
			}
			
			if(isset($infomatch['tact_using2']))
			{
				if($infomatch['tact_using2'] == "442" OR $infomatch['tact_using2'] == "442etoile")
				{ $position1 = 1; $position2 = $position3 = $position4 = $position5 = 2; $position6 = $position7 = $position8 = $position9 = 3; $position10 = $position11 = 4; }
				elseif($infomatch['tact_using2'] == "433")
				{ $position1 = 1; $position2 = $position3 = $position4 = $position5 = 2; $position6 = $position7 = $position8 = 3; $position9 = $position10 = $position11 = 4; }
				elseif($infomatch['tact_using2'] == "451")
				{ $position1 = 1; $position2 = $position3 = $position4 = $position5 = 2; $position6 = $position7 = $position8 = $position9 = $position10 = 3; $position11 = 4; }
				elseif($infomatch['tact_using2'] == "352")
				{ $position1 = 1; $position2 = $position3 = $position4 = 2; $position5 = $position6 = $position7 = $position8 = $position9 = 3; $position10 = $position11 = 4; }
				elseif($infomatch['tact_using2'] == "541")
				{ $position1 = 1; $position2 = $position3 = $position4 = $position5 = $position6 = 2; $position7 = $position8 = $position9 = $position10 = 3; $position11 = 4; }
				elseif($infomatch['tact_using2'] == "343")
				{ $position1 = 1; $position2 = $position3 = $position4 = 2; $position5 = $position6 = $position7 = $position8 = 3; $position9 = $position10 = $position11 = 4; }
				elseif($infomatch['tact_using2'] == "352")
				{ $position1 = 1; $position2 = $position3 = $position4 = 2; $position5 = $position6 = $position7 = $position8 = $position9 = 3; $position10 = $position11 = 4; }
				
				$infojoueur = sql::fetch("SELECT joueur1.player_id player_id1, joueur1.nom nom1, joueur1.prenom prenom1, joueur1.position position1, joueur1.forme forme1, joueur1.moral moral1, joueur1.talent talent1, joueur1.influence influence1, joueur1.reflexes reflexes1, joueur1.pdballe pdballe1, joueur1.degagement degagement1, joueur1.marquage marquage1, joueur1.tacles tacles1, joueur1.tete tete1, joueur1.centres centres1, joueur1.passes passes1, joueur1.vitesse vitesse1, joueur1.tir tir1, joueur1.creativite creativite1, joueur1.dribble dribble1, 
												 joueur2.player_id player_id2, joueur2.nom nom2, joueur2.prenom prenom2, joueur2.position position2, joueur2.forme forme2, joueur2.moral moral2, joueur2.talent talent2, joueur2.influence influence2, joueur2.reflexes reflexes2, joueur2.pdballe pdballe2, joueur2.degagement degagement2, joueur2.marquage marquage2, joueur2.tacles tacles2, joueur2.tete tete2, joueur2.centres centres2, joueur2.passes passes2, joueur2.vitesse vitesse2, joueur2.tir tir2, joueur2.creativite creativite2, joueur2.dribble dribble2, 
												 joueur3.player_id player_id3, joueur3.nom nom3, joueur3.prenom prenom3, joueur3.position position3, joueur3.forme forme3, joueur3.moral moral3, joueur3.talent talent3, joueur3.influence influence3, joueur3.reflexes reflexes3, joueur3.pdballe pdballe3, joueur3.degagement degagement3, joueur3.marquage marquage3, joueur3.tacles tacles3, joueur3.tete tete3, joueur3.centres centres3, joueur3.passes passes3, joueur3.vitesse vitesse3, joueur3.tir tir3, joueur3.creativite creativite3, joueur3.dribble dribble3, 
												 joueur4.player_id player_id4, joueur4.nom nom4, joueur4.prenom prenom4, joueur4.position position4, joueur4.forme forme4, joueur4.moral moral4, joueur4.talent talent4, joueur4.influence influence4, joueur4.reflexes reflexes4, joueur4.pdballe pdballe4, joueur4.degagement degagement4, joueur4.marquage marquage4, joueur4.tacles tacles4, joueur4.tete tete4, joueur4.centres centres4, joueur4.passes passes4, joueur4.vitesse vitesse4, joueur4.tir tir4, joueur4.creativite creativite4, joueur4.dribble dribble4, 
												 joueur5.player_id player_id5, joueur5.nom nom5, joueur5.prenom prenom5, joueur5.position position5, joueur5.forme forme5, joueur5.moral moral5, joueur5.talent talent5, joueur5.influence influence5, joueur5.reflexes reflexes5, joueur5.pdballe pdballe5, joueur5.degagement degagement5, joueur5.marquage marquage5, joueur5.tacles tacles5, joueur5.tete tete5, joueur5.centres centres5, joueur5.passes passes5, joueur5.vitesse vitesse5, joueur5.tir tir5, joueur5.creativite creativite5, joueur5.dribble dribble5, 
												 joueur6.player_id player_id6, joueur6.nom nom6, joueur6.prenom prenom6, joueur6.position position6, joueur6.forme forme6, joueur6.moral moral6, joueur6.talent talent6, joueur6.influence influence6, joueur6.reflexes reflexes6, joueur6.pdballe pdballe6, joueur6.degagement degagement6, joueur6.marquage marquage6, joueur6.tacles tacles6, joueur6.tete tete6, joueur6.centres centres6, joueur6.passes passes6, joueur6.vitesse vitesse6, joueur6.tir tir6, joueur6.creativite creativite6, joueur6.dribble dribble6, 
												 joueur7.player_id player_id7, joueur7.nom nom7, joueur7.prenom prenom7, joueur7.position position7, joueur7.forme forme7, joueur7.moral moral7, joueur7.talent talent7, joueur7.influence influence7, joueur7.reflexes reflexes7, joueur7.pdballe pdballe7, joueur7.degagement degagement7, joueur7.marquage marquage7, joueur7.tacles tacles7, joueur7.tete tete7, joueur7.centres centres7, joueur7.passes passes7, joueur7.vitesse vitesse7, joueur7.tir tir7, joueur7.creativite creativite7, joueur7.dribble dribble7, 
												 joueur8.player_id player_id8, joueur8.nom nom8, joueur8.prenom prenom8, joueur8.position position8, joueur8.forme forme8, joueur8.moral moral8, joueur8.talent talent8, joueur8.influence influence8, joueur8.reflexes reflexes8, joueur8.pdballe pdballe8, joueur8.degagement degagement8, joueur8.marquage marquage8, joueur8.tacles tacles8, joueur8.tete tete8, joueur8.centres centres8, joueur8.passes passes8, joueur8.vitesse vitesse8, joueur8.tir tir8, joueur8.creativite creativite8, joueur8.dribble dribble8, 
												 joueur9.player_id player_id9, joueur9.nom nom9, joueur9.prenom prenom9, joueur9.position position9, joueur9.forme forme9, joueur9.moral moral9, joueur9.talent talent9, joueur9.influence influence9, joueur9.reflexes reflexes9, joueur9.pdballe pdballe9, joueur9.degagement degagement9, joueur9.marquage marquage9, joueur9.tacles tacles9, joueur9.tete tete9, joueur9.centres centres9, joueur9.passes passes9, joueur9.vitesse vitesse9, joueur9.tir tir9, joueur9.creativite creativite9, joueur9.dribble dribble9, 
												 joueur10.player_id player_id10, joueur10.nom nom10, joueur10.prenom prenom10, joueur10.position position10, joueur10.forme forme10, joueur10.moral moral10, joueur10.talent talent10, joueur10.influence influence10, joueur10.reflexes reflexes10, joueur10.pdballe pdballe10, joueur10.degagement degagement10, joueur10.marquage marquage10, joueur10.tacles tacles10, joueur10.tete tete10, joueur10.centres centres10, joueur10.passes passes10, joueur10.vitesse vitesse10, joueur10.tir tir10, joueur10.creativite creativite10, joueur10.dribble dribble10, 
												 joueur11.player_id player_id11, joueur11.nom nom11, joueur11.prenom prenom11, joueur11.position position11, joueur11.forme forme11, joueur11.moral moral11, joueur11.talent talent11, joueur11.influence influence11, joueur11.reflexes reflexes11, joueur11.pdballe pdballe11, joueur11.degagement degagement11, joueur11.marquage marquage11, joueur11.tacles tacles11, joueur11.tete tete11, joueur11.centres centres11, joueur11.passes passes11, joueur11.vitesse vitesse11, joueur11.tir tir11, joueur11.creativite creativite11, joueur11.dribble dribble11 
										  FROM tactiques 
										  LEFT JOIN joueurs joueur1 ON joueur1.player_id = tactiques.N1 
										  LEFT JOIN joueurs joueur2 ON joueur2.player_id = tactiques.N2 
										  LEFT JOIN joueurs joueur3 ON joueur3.player_id = tactiques.N3 
										  LEFT JOIN joueurs joueur4 ON joueur4.player_id = tactiques.N4 
										  LEFT JOIN joueurs joueur5 ON joueur5.player_id = tactiques.N5 
										  LEFT JOIN joueurs joueur6 ON joueur6.player_id = tactiques.N6 
										  LEFT JOIN joueurs joueur7 ON joueur7.player_id = tactiques.N7 
										  LEFT JOIN joueurs joueur8 ON joueur8.player_id = tactiques.N8 
										  LEFT JOIN joueurs joueur9 ON joueur9.player_id = tactiques.N9 
										  LEFT JOIN joueurs joueur10 ON joueur10.player_id = tactiques.N10 
										  LEFT JOIN joueurs joueur11 ON joueur11.player_id = tactiques.N11 
										  WHERE tact_id = {$infomatch['tact_id2']}");
				
				$count_eq2 = 1;
				$eq2_note = 0;
				$eq2_id = array();
				$eq2_name = array();
				
				while($count_eq2 <= 11)
				{
					switch($count_eq2)
					{
						case 1 : $position = $position1; break;
						case 2 : $position = $position2; break;
						case 3 : $position = $position3; break;
						case 4 : $position = $position4; break;
						case 5 : $position = $position5; break;
						case 6 : $position = $position6; break;
						case 7 : $position = $position7; break;
						case 8 : $position = $position8; break;
						case 9 : $position = $position9; break;
						case 10 : $position = $position10; break;
						case 11 : $position = $position11; break;
						default : echo'erreur'; break;
					}
					
					if($infojoueur['player_id' . $count_eq2] != 0)
					{
						$eq2_id[] = $infojoueur['player_id' . $count_eq2];
						$eq2_name[] = match_apl::prmslettre($infojoueur['prenom' . $count_eq2]) . ' ' . $infojoueur['nom' . $count_eq2];
						$eq2_note += match_apl::note($position, $infojoueur['forme' . $count_eq2], $infojoueur['moral' . $count_eq2], $infojoueur['talent' . $count_eq2], $infojoueur['influence' . $count_eq2], $infojoueur['reflexes' . $count_eq2], $infojoueur['pdballe' . $count_eq2], $infojoueur['degagement' . $count_eq2], $infojoueur['marquage' . $count_eq2], $infojoueur['tacles' . $count_eq2], $infojoueur['tete' . $count_eq2], $infojoueur['centres' . $count_eq2], $infojoueur['passes' . $count_eq2], $infojoueur['vitesse' . $count_eq2], $infojoueur['tir' . $count_eq2], $infojoueur['creativite' . $count_eq2], $infojoueur['dribble' . $count_eq2]);
					}
					
					else
					{
						$newplayer = match_apl::recup_randplayer($infomatch['team_id2'], $infojoueur['player_id1'], $infojoueur['player_id2'], $infojoueur['player_id3'], $infojoueur['player_id4'], $infojoueur['player_id5'], $infojoueur['player_id6'], $infojoueur['player_id7'], $infojoueur['player_id8'], $infojoueur['player_id9'], $infojoueur['player_id10'], $infojoueur['player_id11']);
						$eq2_id[] = $newplayer['player_id'];
						$eq2_name[] = match_apl::prmslettre($newplayer['prenom']) . ' ' . $newplayer['nom'];
						$eq2_note += match_apl::note($position, $newplayer['forme'], $newplayer['moral'], $newplayer['talent'], $newplayer['influence'], $newplayer['reflexes'], $newplayer['pdballe'], $newplayer['degagement'], $newplayer['marquage'], $newplayer['tacles'], $newplayer['tete'], $newplayer['centres'], $newplayer['passes'], $newplayer['vitesse'], $newplayer['tir'], $newplayer['creativite'], $newplayer['dribble']);
					}
					
					$count_eq2++;
				}
			}
			
			else
			{
				$position1 = 1; $position2 = $position3 = $position4 = $position5 = 2; $position6 = $position7 = $position8 = $position9 = 3; $position10 = $position11 = 4;
				
				$req = sql::query("SELECT player_id, nom, prenom, position, forme, moral, talent, influence, reflexes, pdballe, degagement, marquage, tacles, tete, centres, passes, vitesse, tir, creativite, dribble 
								   FROM joueurs 
								   WHERE team_id = {$infomatch['team_id2']} 
									 AND indisponible = 0 
								   ORDER BY position, RAND()");
				
				$count_eq2 = 1;
				$eq2_note = 0;
				$eq2_id = array();
				$eq2_name = array();
				
				while($infojoueur = mysql_fetch_assoc($req))
				{
					switch($count_eq2)
					{
						case 1 : $position = $position1; break;
						case 2 : $position = $position2; break;
						case 3 : $position = $position3; break;
						case 4 : $position = $position4; break;
						case 5 : $position = $position5; break;
						case 6 : $position = $position6; break;
						case 7 : $position = $position7; break;
						case 8 : $position = $position8; break;
						case 9 : $position = $position9; break;
						case 10 : $position = $position10; break;
						case 11 : $position = $position11; break;
						default : $position = 0; break;
					}
					
					if($position == $infojoueur['position'])
					{
						$eq2_id[] = $infojoueur['player_id'];
						$eq2_name[] = match_apl::prmslettre($infojoueur['prenom']) . ' ' . $infojoueur['nom'];
						$eq2_note += match_apl::note($position, $infojoueur['forme'], $infojoueur['moral'], $infojoueur['talent'], $infojoueur['influence'], $infojoueur['reflexes'], $infojoueur['pdballe'], $infojoueur['degagement'], $infojoueur['marquage'], $infojoueur['tacles'], $infojoueur['tete'], $infojoueur['centres'], $infojoueur['passes'], $infojoueur['vitesse'], $infojoueur['tir'], $infojoueur['creativite'], $infojoueur['dribble']);
						$count_eq2++;
					}
				}
			}
			
			//On enleve un match aux joueurs suspendu de la competition
			$requete = sql::update("UPDATE stamp_suspension 
									SET suspension = suspension - 1 
									WHERE id_compet = {$compet} 
									  AND id_team IN ({$infomatch['team_id1']}, {$infomatch['team_id2']})");
			
			//Pour la composition des �quipes
			$all_name = $eq1_id[0] . ';' . $eq1_name[0] . ';' . $eq1_id[1] . ';' . $eq1_name[1] . ';' . $eq1_id[2] . ';' . $eq1_name[2] . ';' . 
						$eq1_id[3] . ';' . $eq1_name[3] . ';' . $eq1_id[4] . ';' . $eq1_name[4] . ';' . $eq1_id[5] . ';' . $eq1_name[5] . ';' . 
						$eq1_id[6] . ';' . $eq1_name[6] . ';' . $eq1_id[7] . ';' . $eq1_name[7] . ';' . $eq1_id[8] . ';' . $eq1_name[8] . ';' . 
						$eq1_id[9] . ';' . $eq1_name[9] . ';' . $eq1_id[10] . ';' . $eq1_name[10] . ';' . 
						$eq2_id[0] . ';' . $eq2_name[0] . ';' . $eq2_id[1] . ';' . $eq2_name[1] . ';' . $eq2_id[2] . ';' . $eq2_name[2] . ';' . 
						$eq2_id[3] . ';' . $eq2_name[3] . ';' . $eq2_id[4] . ';' . $eq2_name[4] . ';' . $eq2_id[5] . ';' . $eq2_name[5] . ';' . 
						$eq2_id[6] . ';' . $eq2_name[6] . ';' . $eq2_id[7] . ';' . $eq2_name[7] . ';' . $eq2_id[8] . ';' . $eq2_name[8] . ';' . 
						$eq2_id[9] . ';' . $eq2_name[9] . ';' . $eq2_id[10] . ';' . $eq2_name[10];
			
			//Ajout d'info dans matchinfo : nom du stade, m�t�o, affluence du stade, maillot equipe 1, maillot equipe 2
			$matchinfo = $stadename[0] . ';' . $meteo . ';' . $affluence . ';' . $maillot_team1 . ';' . $maillot_team2 . ';' . $arbitre_name;
			
			if($infomatch['renco_type'] == 2) //Si match amical, commentaire de debut de match special
			{
				//Ajout de Apparition du match amical ( partie hors competition)
				$requete = sql::update("UPDATE classement_joueur 
										SET hcomp_sel = hcomp_sel + 1 
										WHERE player_id IN ({$eq1_id[0]}, {$eq1_id[1]}, {$eq1_id[2]}, {$eq1_id[3]}, {$eq1_id[4]}, {$eq1_id[5]}, 
															{$eq1_id[6]}, {$eq1_id[7]}, {$eq1_id[8]}, {$eq1_id[9]}, {$eq1_id[10]}, 
															{$eq2_id[0]}, {$eq2_id[1]}, {$eq2_id[2]}, {$eq2_id[3]}, {$eq2_id[4]}, {$eq2_id[5]}, 
															{$eq2_id[6]}, {$eq2_id[7]}, {$eq2_id[8]}, {$eq2_id[9]}, {$eq2_id[10]}) 
										AND saison_nbr = {$infomatch['saison_nbr']}");
				
				//On ajoute la composition des equipes et le commentaire de d�but de match
				srand ((double) microtime() * 10000000); $input = array ("KK1", "KK2", "KK3", "KK4", "KK5", "KK6");
				$rand_keys = array_rand ($input, 2); $randcomm = $input[$rand_keys[0]];
				
				$choice_comm = date('H:i', $infomatch['timematch']) . '_' . $randcomm . '_' . $stadename[0] . '_' . $infomatch['team_id1'] . '_' . $infomatch['team_id2'];
				
				$requete = sql::update("UPDATE matchs 
										SET score1 = 0, score2 = 0, 
											matchinfo = '{$matchinfo}', 
											compoinfo = '".addslashes($all_name)."', 
											commentinfo = '{$choice_comm}' 
										WHERE renco_id = {$infomatch['renco_id']}");
			}
			
			else
			{
				//Ajout de Apparition du championnat ( partie championnat)
				$requete = sql::update("UPDATE classement_joueur 
										SET champ_sel = champ_sel + 1 
										WHERE player_id IN ({$eq1_id[0]}, {$eq1_id[1]}, {$eq1_id[2]}, {$eq1_id[3]}, {$eq1_id[4]}, {$eq1_id[5]}, 
															{$eq1_id[6]}, {$eq1_id[7]}, {$eq1_id[8]}, {$eq1_id[9]}, {$eq1_id[10]}, 
															{$eq2_id[0]}, {$eq2_id[1]}, {$eq2_id[2]}, {$eq2_id[3]}, {$eq2_id[4]}, {$eq2_id[5]}, 
															{$eq2_id[6]}, {$eq2_id[7]}, {$eq2_id[8]}, {$eq2_id[9]}, {$eq2_id[10]}) 
										AND saison_nbr = {$infomatch['saison_nbr']}");
				
				//On ajoute la composition des equipes et le commentaire de d�but de match
				srand ((double) microtime() * 10000000); $input = array ("S1", "S2", "S3", "S4", "S5", "S6");
				$rand_keys = array_rand ($input, 2); $randcomm = $input[$rand_keys[0]];
				
				$choice_comm = date('H:i', $infomatch['timematch']) . '_' . $randcomm . '_' . $stadename[0] . '_' . $infomatch['team_id1'] . '_' . $infomatch['team_id2'] . '___' . 1;
				
				$requete = sql::update("UPDATE matchs 
										SET score1 = 0, score2 = 0, 
											matchinfo = '{$matchinfo}', 
											compoinfo = '".addslashes($all_name)."', 
											commentinfo = '{$choice_comm}' 
										WHERE renco_id = {$infomatch['renco_id']}");
			}
			
			$joueur_eq1 = $eq1_id[0] . ';' . $eq1_id[1] . ';' . $eq1_id[2] . ';' . $eq1_id[3] . ';' . $eq1_id[4] . ';' . $eq1_id[5] . ';' . $eq1_id[6] . ';' . $eq1_id[7] . ';' . $eq1_id[8] . ';' . $eq1_id[9] . ';' . $eq1_id[10];
			$joueur_eq2 = $eq2_id[0] . ';' . $eq2_id[1] . ';' . $eq2_id[2] . ';' . $eq2_id[3] . ';' . $eq2_id[4] . ';' . $eq2_id[5] . ';' . $eq2_id[6] . ';' . $eq2_id[7] . ';' . $eq2_id[8] . ';' . $eq2_id[9] . ';' . $eq2_id[10];
			
			//On ajoute une ligne pour declar� le match en cours
			$requete = sql::insert("INSERT INTO matchs_encours(renco_id, compet_id, timematch_dep, id_team1, id_team2, joueur_eq1, joueur_eq2, note_eq1, note_eq2)
									VALUES({$infomatch['renco_id']}, {$infomatch['compet_id']}, {$infomatch['timematch']}, {$infomatch['team_id1']}, {$infomatch['team_id2']}, '{$joueur_eq1}', '{$joueur_eq2}', {$eq1_note}, {$eq2_note})");
		}	
	}
	
	function match_action($compet, $match, $team, $mode, $CONF)
	{
		$timestmp_actu = time() + ($CONF['decal_time'] * 60 * 60); //L'heure actuelle avec l'option decalage (timestamp)
		
		if($mode == 1) //Page match (1 match)
		{
			$infomatch = sql::fetch("SELECT matchs.renco_id, saison_nbr, matchs.compet_id, team_id1, team_id2, score1, score2, matchinfo, eq1_info, eq2_info, commentinfo, renco_type, 
											match_id, timematch_dep, match_min, match_adj, combien_adj, joueur_eq1, joueur_eq2, note_eq1, note_eq2, carton_jaune, carton_rouge, expulsion, blesse, 
											tactik1.penalty penalty1, tactik1.cfranc cfranc1, tactik2.penalty penalty2, tactik2.cfranc cfranc2 
									 FROM matchs 
									 LEFT JOIN matchs_encours ON matchs_encours.renco_id = matchs.renco_id 
									 LEFT JOIN tactiques tactik1 ON tactik1.id_team = matchs.team_id1 
									 LEFT JOIN tactiques tactik2 ON tactik2.id_team = matchs.team_id2 
									 WHERE timematch_dep <= {$timestmp_actu}
									   AND matchs.compet_id IN ({$compet}, 0) 
									   AND ((team_id1 = {$team} OR team_id2 = {$team}) 
										OR (team_id1 != {$team} OR team_id2 != {$team})) 
									 LIMIT 1");
		}
		
		//Variable pour la boucle (les variable qui peuvent changer si plusieurs action jouer)
		$timematch_dep = $infomatch['timematch_dep'];
		$mi_temps = $infomatch['match_min'];
		$arretdejeu = $infomatch['match_adj'];
		$combien_adj = $infomatch['combien_adj'];
		$score1 = $infomatch['score1'];
		$score2 = $infomatch['score2'];
		$joueur_eq1 = $infomatch['joueur_eq1'];
		$joueur_eq2 = $infomatch['joueur_eq2'];
		$note_eq1 = $infomatch['note_eq1'];
		$note_eq2 = $infomatch['note_eq2'];
		$matchinfo = $infomatch['matchinfo'];
		$eq1_info = $infomatch['eq1_info'];
		$eq2_info = $infomatch['eq2_info'];
		$commentinfo = $infomatch['commentinfo'];
		$carton_jaune = $infomatch['carton_jaune'];
		$carton_rouge = $infomatch['carton_rouge'];
		$expulsion = $infomatch['expulsion'];
		
		if(isset($infomatch['match_id']))
		{
			while($timematch_dep <= $timestmp_actu)
			{
				//On recup tous les joueurs du match
				$eq1_j = explode(';', $joueur_eq1); $nb_eq1 = count($eq1_j); $nb_eq1--;
				$eq2_j = explode(';', $joueur_eq2); $nb_eq2 = count($eq2_j); $nb_eq2--;
				
				//On verifie que les equipe on plus de 7 joueurs
				if($nb_eq1 > 7 AND $nb_eq2 > 7)
				{
					//Lancement des commentaires
					//On verifie si c'est les arret de jeu ou le match normal
					if($mi_temps != 45 OR $mi_temps != 90)
					{
						$modematch = 0; 
						$arretdejeu = 0;
						$combien_adj = 0;
					}
					
					else
					{
						//Si le temps d'arr�t de jeu n'est pas d�finit
						if(!isset($combien_adj) OR $combien_adj == 0)
						{
							srand ((double) microtime() * 10000000); $input = array (1, 2, 3, 4, 5);
							$rand_keys = array_rand ($input, 2); 
							
							$combien_adj = $input[$rand_keys[0]];
							$arretdejeu = 1;
						}
						
						$modematch = 1;
					}
					
					//Petite magouille pour avoir toujours un nombre positif
					if($note_eq1 < $note_eq2)
					{
						$difference = $note_eq2 - $note_eq1;
						$teamchoice = 2;
					}
					
					else 
					{ 
						$difference = $note_eq1 - $note_eq2; 
						$teamchoice = 1; 
					}
					
					//On recup l'�quipe qui va jouer l'action (Equipe+) selon la diff�rence note_eq1 <=> note_eq2
					$ratio = match_apl::choice_eqp($difference);
					
					if($ratio == 'eqp+' OR $ratio == 'eqp-')
					{
						//On recup les joueurs qui feront l'action 2 de chaque + gardien
						//Equipe+ Joueur1 : toujours buteur (si buteur)
						//Equipe+ Joueur2 : toujours passeur (si passeur) - toujous bless� (si bless�)
						//Equipe+ Gardien
						//Equipe- Joueur1 : toujours buteur (si buteur et contre-attaque), auteur de la faute (si faute)
						//Equipe- Joueur2
						//Equipe- Gardien
					
						if($teamchoice == 1 AND $ratio == 'eqp+' OR $teamchoice == 2 AND $ratio == 'eqp-')
						{
							srand ((double) microtime() * 10000000);
								if($nb_eq1 == 10) $input = array ($eq1_j[1], $eq1_j[2], $eq1_j[3], $eq1_j[4], $eq1_j[5], $eq1_j[6], $eq1_j[7], $eq1_j[8], $eq1_j[9], $eq1_j[10]);
							elseif($nb_eq1 == 9)  $input = array ($eq1_j[1], $eq1_j[2], $eq1_j[3], $eq1_j[4], $eq1_j[5], $eq1_j[6], $eq1_j[7], $eq1_j[8], $eq1_j[9]);
							elseif($nb_eq1 == 8)  $input = array ($eq1_j[1], $eq1_j[2], $eq1_j[3], $eq1_j[4], $eq1_j[5], $eq1_j[6], $eq1_j[7], $eq1_j[8]);
							elseif($nb_eq1 == 7)  $input = array ($eq1_j[1], $eq1_j[2], $eq1_j[3], $eq1_j[4], $eq1_j[5], $eq1_j[6], $eq1_j[7]);
							$rand_keys = array_rand ($input, 2);
							
							$gardien1 = $eq1_j[0]; $attaquant1 = $input[$rand_keys[0]]; $attaquant2 = $input[$rand_keys[1]];
							
							srand ((double) microtime() * 10000000);
								if($nb_eq2 == 10) $input = array ($eq2_j[1], $eq2_j[2], $eq2_j[3], $eq2_j[4], $eq2_j[5], $eq2_j[6], $eq2_j[7], $eq2_j[8], $eq2_j[9], $eq2_j[10]);
							elseif($nb_eq2 == 9)  $input = array ($eq2_j[1], $eq2_j[2], $eq2_j[3], $eq2_j[4], $eq2_j[5], $eq2_j[6], $eq2_j[7], $eq2_j[8], $eq2_j[9]);
							elseif($nb_eq2 == 8)  $input = array ($eq2_j[1], $eq2_j[2], $eq2_j[3], $eq2_j[4], $eq2_j[5], $eq2_j[6], $eq2_j[7], $eq2_j[8]);
							elseif($nb_eq2 == 7)  $input = array ($eq2_j[1], $eq2_j[2], $eq2_j[3], $eq2_j[4], $eq2_j[5], $eq2_j[6], $eq2_j[7]);
							$rand_keys = array_rand ($input, 2); 
							
							$gardien2 = $eq2_j[0]; $defenseur1 = $input[$rand_keys[0]]; $defenseur2 = $input[$rand_keys[1]];
							
							$teamatk = $infomatch['team_id1']; $teamdef = $infomatch['team_id2'];
						}
						
						elseif($teamchoice == 2 AND $ratio == 'eqp+' OR $teamchoice == 1 AND $ratio == 'eqp-')
						{
							srand ((double) microtime() * 10000000);
								if($nb_eq2 == 10) $input = array ($eq2_j[1], $eq2_j[2], $eq2_j[3], $eq2_j[4], $eq2_j[5], $eq2_j[6], $eq2_j[7], $eq2_j[8], $eq2_j[9], $eq2_j[10]);
							elseif($nb_eq2 == 9)  $input = array ($eq2_j[1], $eq2_j[2], $eq2_j[3], $eq2_j[4], $eq2_j[5], $eq2_j[6], $eq2_j[7], $eq2_j[8], $eq2_j[9]);
							elseif($nb_eq2 == 8)  $input = array ($eq2_j[1], $eq2_j[2], $eq2_j[3], $eq2_j[4], $eq2_j[5], $eq2_j[6], $eq2_j[7], $eq2_j[8]);
							elseif($nb_eq2 == 7)  $input = array ($eq2_j[1], $eq2_j[2], $eq2_j[3], $eq2_j[4], $eq2_j[5], $eq2_j[6], $eq2_j[7]);
							$rand_keys = array_rand ($input, 2);
							
							$gardien1 = $eq2_j[0]; $attaquant1 = $input[$rand_keys[0]]; $attaquant2 = $input[$rand_keys[1]];
							
							srand ((double) microtime() * 10000000);
								if($nb_eq1 == 10) $input = array ($eq1_j[1], $eq1_j[2], $eq1_j[3], $eq1_j[4], $eq1_j[5], $eq1_j[6], $eq1_j[7], $eq1_j[8], $eq1_j[9], $eq1_j[10]);
							elseif($nb_eq1 == 9)  $input = array ($eq1_j[1], $eq1_j[2], $eq1_j[3], $eq1_j[4], $eq1_j[5], $eq1_j[6], $eq1_j[7], $eq1_j[8], $eq1_j[9]);
							elseif($nb_eq1 == 8)  $input = array ($eq1_j[1], $eq1_j[2], $eq1_j[3], $eq1_j[4], $eq1_j[5], $eq1_j[6], $eq1_j[7], $eq1_j[8]);
							elseif($nb_eq1 == 7)  $input = array ($eq1_j[1], $eq1_j[2], $eq1_j[3], $eq1_j[4], $eq1_j[5], $eq1_j[6], $eq1_j[7]);
							$rand_keys = array_rand ($input, 2);
							
							$gardien2 = $eq1_j[0]; $defenseur1 = $input[$rand_keys[0]]; $defenseur2 = $input[$rand_keys[1]];
							
							$teamatk = $infomatch['team_id2']; $teamdef = $infomatch['team_id1'];
						}
						
						$req = sql::query("SELECT * FROM joueurs WHERE player_id IN ({$gardien1}, {$attaquant1}, {$attaquant2}, {$gardien2}, {$defenseur1}, {$defenseur2})");
						
						$atk_gardien = mysql_fetch_assoc($req);
							$eq1_pl1 = mysql_fetch_assoc($req);
							$eq1_pl2 = mysql_fetch_assoc($req);
						$def_gardien = mysql_fetch_assoc($req);
							$eq2_pl1 = mysql_fetch_assoc($req);
							$eq2_pl2 = mysql_fetch_assoc($req);
						
						//Equipe+ Joueur1 Equipe+ Joueur2 - Equipe- Joueur1 => function a lancer
						
						//Si 3 2 - 4 => function passe zone2, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 3 2 - 3 => function passe zone2, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 2 2 - 4 => function passe zone2, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 2 2 - 3 => function passe zone2, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 4 2 - 4 => function passe zone2, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 4 2 - 3 => function passe zone2, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						if(($eq1_pl1['position'] == 3 AND $eq1_pl2['position'] == 2 AND $eq2_pl1['position'] == 4) OR 
						   ($eq1_pl1['position'] == 3 AND $eq1_pl2['position'] == 2 AND $eq2_pl1['position'] == 3) OR 
						   ($eq1_pl1['position'] == 2 AND $eq1_pl2['position'] == 2 AND $eq2_pl1['position'] == 4) OR 
						   ($eq1_pl1['position'] == 2 AND $eq1_pl2['position'] == 2 AND $eq2_pl1['position'] == 3) OR 
						   ($eq1_pl1['position'] == 4 AND $eq1_pl2['position'] == 2 AND $eq2_pl1['position'] == 4) OR 
						   ($eq1_pl1['position'] == 4 AND $eq1_pl2['position'] == 2 AND $eq2_pl1['position'] == 3))
						{
							$zone_select = 2;
							$res_passe = match_apl::passe_zone2($infomatch['renco_id'], $eq1_pl2, $eq2_pl1);
						}
						
						//Si 4 2 - 2 => function passe zone3, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 3 3 - 4 => function passe zone3, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 3 3 - 3 => function passe zone3, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 3 2 - 2 => function passe zone3, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 2 2 - 2 => function passe zone3, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 4 4 - 4 => function passe zone3, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 4 4 - 3 => function passe zone3, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 4 3 - 4 => function passe zone3, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 4 3 - 3 => function passe zone3, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						elseif(($eq1_pl1['position'] == 4 AND $eq1_pl2['position'] == 2 AND $eq2_pl1['position'] == 2) OR 
							   ($eq1_pl1['position'] == 3 AND $eq1_pl2['position'] == 3 AND $eq2_pl1['position'] == 4) OR 
							   ($eq1_pl1['position'] == 3 AND $eq1_pl2['position'] == 3 AND $eq2_pl1['position'] == 3) OR 
							   ($eq1_pl1['position'] == 3 AND $eq1_pl2['position'] == 2 AND $eq2_pl1['position'] == 2) OR 
							   ($eq1_pl1['position'] == 2 AND $eq1_pl2['position'] == 2 AND $eq2_pl1['position'] == 2) OR 
							   ($eq1_pl1['position'] == 4 AND $eq1_pl2['position'] == 4 AND $eq2_pl1['position'] == 4) OR 
							   ($eq1_pl1['position'] == 4 AND $eq1_pl2['position'] == 4 AND $eq2_pl1['position'] == 3) OR 
							   ($eq1_pl1['position'] == 4 AND $eq1_pl2['position'] == 3 AND $eq2_pl1['position'] == 4) OR 
							   ($eq1_pl1['position'] == 4 AND $eq1_pl2['position'] == 3 AND $eq2_pl1['position'] == 3))
						{
							$zone_select = 3;
							$res_passe = match_apl::passe_zone3($infomatch['renco_id'], $eq1_pl2, $eq2_pl1);
						}
						
						//Si 3 3 - 2 => function passe zone4, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 4 3 - 2 => function passe zone4, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						//Si 4 4 - 2 => function passe zone4, Commentaire sportif, Commentaire hors-jeu (si Equipe- a choisi)
						elseif(($eq1_pl1['position'] == 3 AND $eq1_pl2['position'] == 3 AND $eq2_pl1['position'] == 2) OR 
							   ($eq1_pl1['position'] == 4 AND $eq1_pl2['position'] == 3 AND $eq2_pl1['position'] == 2) OR 
							   ($eq1_pl1['position'] == 4 AND $eq1_pl2['position'] == 4 AND $eq2_pl1['position'] == 2))
						{
							$zone_select = 4;
							$res_passe = match_apl::passe_zone4($infomatch['renco_id'], $eq1_pl2, $eq2_pl1);
						}
						
						else
						{
							$zone_select = 3;
							$res_passe = match_apl::passe_zone3($infomatch['renco_id'], $eq1_pl2, $eq2_pl1);
						}
						
						if($res_passe == 'action_off')
						{
							//On lance le script du duel tireur <> gardien
							$resultat_tir = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'tir');
							
							if($resultat_tir == 'but')
							{
								//On choisi le commentaire et on inscrit toutes les infos dans matchs
								$num = match_apl::random_commentaire_attaque_reussi();
								$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_B', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
								
								//On update les classements des buteur/passeur
								match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
								match_apl::classement_passeur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant2, $teamatk);
								
								//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
								if($teamatk == $infomatch['team_id1']) 
								{
									$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
									$score1++;
								} 
								
								else 
								{
									$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
									$score2++;
								}
							}
							
							else
							{
								//On choisi le commentaire et on inscrit toutes les infos dans matchs
								$num = match_apl::random_commentaire_attaque_manquer();
								$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_A', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
							}
						}
						
						elseif($res_passe == 'faute_pet')
						{
							//Choix al�atoire du type de faute selon le zone select
							$petitefaute = match_apl::random_faute_simple($zone_select);
							
							if ($petitefaute == 2)
							{
								//Simple faute + coup-franc direct pr�s des buts = > on recup tireur de cf => on compare tireur(forme+moral+cdparrete+creativite) contre gardien(forme+moral+reflexe+pdballe)
								$tireur = match_apl::recuptireurcfranc($teamatk, $infomatch['team_id1'], $infomatch['team_id2'], $infomatch['cfranc1'], $infomatch['cfranc2']);
								if ($tireur != 'noplayer' AND $attaquant2 != $tireur) $attaquant1 = $tireur;
								elseif ($tireur != 'noplayer' AND $attaquant2 == $tireur) { $attaquant2 = $attaquant1; $attaquant1 = $tireur; }
								
								//On lance le script du duel tireur <> gardien
								$resultat_cfr = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'cfranc');
								
								if ($resultat_cfr == 'but')
								{
									//On choisi le commentaire et on inscrit toutes les infos dans matchs
									$num = match_apl::random_commentaire_faute_simple();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_H', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
									
									//On update les classements du buteur
									match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
									
									//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
									if($teamatk == $infomatch['team_id1']) 
									{
										$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
										$score1++;
									} 
									
									else 
									{
										$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
										$score2++;
									}
								}
								
								else
								{
									//On choisi le commentaire et on inscrit toutes les infos dans matchs
									$num = match_apl::random_commentaire_faute_simple();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_I', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
								}
							}
							
							elseif ($petitefaute == 3)
							{
								//Simple faute + coup-franc indirect pr�s des but => on recup tireur de cf => but ou pas but
								$tireur = match_apl::recuptireurcfranc($teamatk, $infomatch['team_id1'], $infomatch['team_id2'], $infomatch['cfranc1'], $infomatch['cfranc2']);
								if ($tireur != 'noplayer' AND $attaquant1 != $tireur) $attaquant2 = $tireur;
								elseif ($tireur != 'noplayer' AND $attaquant1 == $tireur) { $attaquant1 = $attaquant2; $attaquant2 = $tireur; }
								
								//On lance le script du duel tireur <> gardien
								$resultat_cfr = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'cfranc');
								
								if ($resultat_cfr == 'but')
								{
									//On choisi le commentaire et on inscrit toutes les infos dans matchs
									$num = match_apl::random_commentaire_faute_simple();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_J', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
									
									//On update les classements des buteur/passeur
									match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
									match_apl::classement_passeur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant2, $teamatk);
									
									//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
									if($teamatk == $infomatch['team_id1']) 
									{
										$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
										$score1++;
									} 
									
									else 
									{
										$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
										$score2++;
									}
								}
								
								else
								{
									//On choisi le commentaire et on inscrit toutes les infos dans matchs
									$num = match_apl::random_commentaire_faute_simple();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_L', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
								}
							}
							
							else
							{
								//Simple faute + coup-franc
								//On choisi le commentaire et on inscrit toutes les infos dans matchs
								$num = match_apl::random_commentaire_faute_simple();
								$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_E', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
							}
						}
						
						elseif($res_passe == 'faute_moy')
						{
							//On verifie si le defenseur1 � d�j� un carton jaune
							$dejacarton = match_apl::verif_carton_jaune($defenseur1, $carton_jaune);
							
							if ($dejacarton == 'dejacarton')
							{
								//On expulse le joueur : ajout dans carton_jaune + expulsion de matchs_encours
								match_apl::equip_expulsion_doublecarton_jaune($infomatch['saison_nbr'], $defenseur1, $infomatch['renco_type'], $eq2_pl1['team_id']);
								
								//On modifie les variables
								$carton_jaune .= '/' . $defenseur1;
								$expulsion .= '/' . $defenseur1;
								
								if($teamchoice == 1 AND $ratio == 'eqp+' OR $teamchoice == 2 AND $ratio == 'eqp-')
								{
									$note_eq2 = $note_eq2 - $CONF['expulsion_penalite'];
									$joueur_eq2 = match_apl::expulsejoueur($defenseur1, $joueur_eq2);
								}
								
								else
								{
									$note_eq1 = $note_eq1 - $CONF['expulsion_penalite'];
									$joueur_eq1 = match_apl::expulsejoueur($defenseur1, $joueur_eq1);
								}
								
								//Choix al�atoire du type de faute selon le zone select
								$moyennefaute = match_apl::random_faute_moyenne($zone_select);
								
								if ($moyennefaute == 2)
								{
									//Faute moyenne + deuxi�me carton jaune + expulsion + coup-franc direct pr�s des buts = > on recup tireur de cf => on compare tireur(forme+moral+cdparrete+creativite) contre gardien(forme+moral+reflexe+pdballe)
									$tireur = match_apl::recuptireurcfranc($teamatk, $infomatch['team_id1'], $infomatch['team_id2'], $infomatch['cfranc1'], $infomatch['cfranc2']);
									if ($tireur != 'noplayer' AND $attaquant2 != $tireur) $attaquant1 = $tireur;
									elseif ($tireur != 'noplayer' AND $attaquant2 == $tireur) { $attaquant2 = $attaquant1; $attaquant1 = $tireur; }
									
									//On lance le script du duel tireur <> gardien
									$resultat_cfr = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'cfranc');
									
									if ($resultat_cfr == 'but')
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_W', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
										
										//On update les classements du buteur
										match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
										
										//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
										if($teamatk == $infomatch['team_id1']) 
										{
											$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
											$score1++;
										} 
										
										else 
										{
											$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
											$score2++;
										}
									}
									
									else
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_X', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
									}
								}
								
								elseif ($moyennefaute == 3)
								{
									//Faute moyenne + deuxi�me carton jaune + expulsion + coup-franc indirect pr�s des but => on recup tireur de cf => but ou pas but
									$tireur = match_apl::recuptireurcfranc($teamatk, $infomatch['team_id1'], $infomatch['team_id2'], $infomatch['cfranc1'], $infomatch['cfranc2']);
									if ($tireur != 'noplayer' AND $attaquant1 != $tireur) $attaquant2 = $tireur;
									elseif ($tireur != 'noplayer' AND $attaquant1 == $tireur) { $attaquant1 = $attaquant2; $attaquant2 = $tireur; }
									
									//On lance le script du duel tireur <> gardien
									$resultat_cfr = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'cfranc');
									
									if ($resultat_cfr == 'but')
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_Y', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
										
										//On update les classements des buteur/passeur
										match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
										match_apl::classement_passeur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant2, $teamatk);
										
										//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
										if($teamatk == $infomatch['team_id1']) 
										{
											$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
											$score1++;
										} 
										
										else 
										{
											$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
											$score2++;
										}
									}
									
									else
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_Z', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
									}
								}
								
								elseif ($moyennefaute == 4)
								{
									//Faute moyenne + deuxi�me carton jaune + expulsion + penalty => on recup tireur de penalty => but ou pas but
									$tireur = match_apl::recuptireurpenalty($teamatk, $infomatch['team_id1'], $infomatch['team_id2'], $infomatch['penalty1'], $infomatch['penalty2']);
									if ($tireur != 'noplayer' AND $attaquant1 != $tireur) $attaquant2 = $tireur;
									elseif ($tireur != 'noplayer' AND $attaquant1 == $tireur) { $attaquant1 = $attaquant2; $attaquant2 = $tireur; }
									
									//On lance le script du duel tireur <> gardien
									$resultat_pen = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'penalty');
									
									if ($resultat_pen == 'but')
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_AA', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
										
										//On update les classements du buteur
										match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
										
										//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
										if($teamatk == $infomatch['team_id1']) 
										{
											$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
											$score1++;
										} 
										
										else 
										{
											$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
											$score2++;
										}
									}
									
									else
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_BB', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
									}
								}
								
								else
								{
									//Faute moyenne + deuxi�me carton jaune + expulsion + coup-franc
									$num = match_apl::random_commentaire_faute_moyenne();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_V', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
								}
							}
							
							else
							{
								//Ajout dans carton_jaune dans matchs_encours
								match_apl::equip_ajout_carton_jaune($infomatch['saison_nbr'], $defenseur1, $infomatch['renco_type'], $eq2_pl1['team_id']);
								$carton_jaune .= '/' . $defenseur1;
								
								//Choix al�atoire du type de faute selon le zone select
								$moyennefaute = match_apl::random_faute_moyenne($zone_select);
								
								if ($moyennefaute == 2)
								{
									//Faute moyenne + carton jaune + coup-franc direct pr�s des buts = > on recup tireur de cf => on compare tireur(forme+moral+cdparrete+creativite) contre gardien(forme+moral+reflexe+pdballe)
									$tireur = match_apl::recuptireurcfranc($teamatk, $infomatch['team_id1'], $infomatch['team_id2'], $infomatch['cfranc1'], $infomatch['cfranc2']);
									if ($tireur != 'noplayer' AND $attaquant2 != $tireur) $attaquant1 = $tireur;
									elseif ($tireur != 'noplayer' AND $attaquant2 == $tireur) { $attaquant2 = $attaquant1; $attaquant1 = $tireur; }
									
									//On lance le script du duel tireur <> gardien
									$resultat_cfr = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'cfranc');
									
									if ($resultat_cfr == 'but')
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_P', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
										
										//On update les classements des buteur/passeur
										match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
										
										//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
										if($teamatk == $infomatch['team_id1']) 
										{
											$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
											$score1++;
										} 
										
										else 
										{
											$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
											$score2++;
										}
									}
									
									else
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_Q', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
									}
								}
								
								elseif ($moyennefaute == 3)
								{
									//Faute moyenne + carton jaune + coup-franc indirect pr�s des but => on recup tireur de cf => but ou pas but
									$tireur = match_apl::recuptireurcfranc($teamatk, $infomatch['team_id1'], $infomatch['team_id2'], $infomatch['cfranc1'], $infomatch['cfranc2']);
										if ($tireur != 'noplayer' AND $attaquant1 != $tireur) $attaquant2 = $tireur;
									elseif ($tireur != 'noplayer' AND $attaquant1 == $tireur) { $attaquant1 = $attaquant2; $attaquant2 = $tireur; }
									
									//On lance le script du duel tireur <> gardien
									$resultat_cfr = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'cfranc');
									
									if ($resultat_cfr == 'but')
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_R', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
										
										//On update les classements des buteur/passeur
										match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
										match_apl::classement_passeur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant2, $teamatk);
										
										//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
										if($teamatk == $infomatch['team_id1']) 
										{
											$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
											$score1++;
										} 
										
										else 
										{
											$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
											$score2++;
										}
									}
								
									else
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_K', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
									}
								}
								
								elseif ($moyennefaute == 4)
								{
									//Faute moyenne + carton jaune + penalty => on recup tireur de penalty => but ou pas but
									$tireur = match_apl::recuptireurpenalty($teamatk, $infomatch['team_id1'], $infomatch['team_id2'], $infomatch['penalty1'], $infomatch['penalty2']);
									if ($tireur != 'noplayer' AND $attaquant1 != $tireur) $attaquant2 = $tireur;
									elseif ($tireur != 'noplayer' AND $attaquant1 == $tireur) { $attaquant1 = $attaquant2; $attaquant2 = $tireur; }
									
									//On lance le script du duel tireur <> gardien
									$resultat_pen = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'penalty');
									
									if ($resultat_pen == 'but')
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_T', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
										
										//On update les classements du buteur
										match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
										
										//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
										if($teamatk == $infomatch['team_id1']) 
										{
											$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
											$score1++;
										} 
										
										else 
										{
											$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
											$score2++;
										}
									}
									
									else
									{
										//On choisi le commentaire et on inscrit toutes les infos dans matchs
										$num = match_apl::random_commentaire_faute_moyenne();
										$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_U', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
									}
								}
								
								else
								{
									//Faute moyenne + deuxi�me carton jaune + expulsion + coup-franc
									$num = match_apl::random_commentaire_faute_moyenne();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_O', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
								}
							}
						}
						
						elseif($res_passe == 'faute_gro')
						{
							//On expulse le joueur : ajout dans carton_rouge + expulsion de matchs_encours
							match_apl::equip_expulsion_carton_rouge($infomatch['saison_nbr'], $defenseur1, $infomatch['renco_type'], $eq2_pl1['team_id']);
						
							//On modifie les variables
							$carton_rouge .= '/' . $defenseur1;
							$expulsion .= '/' . $defenseur1;
							
							if($teamchoice == 1 AND $ratio == 'eqp+' OR $teamchoice == 2 AND $ratio == 'eqp-')
							{
								$note_eq2 = $note_eq2 - $CONF['expulsion_penalite'];
								$joueur_eq2 = match_apl::expulsejoueur($defenseur1, $joueur_eq2);
							}
							
							else
							{
								$note_eq1 = $note_eq1 - $CONF['expulsion_penalite'];
								$joueur_eq1 = match_apl::expulsejoueur($defenseur1, $joueur_eq1);
							}
							
							//Choix al�atoire du type de faute selon le zone select
							$grossefaute = match_apl::random_faute_grave($zone_select);
							
							if ($grossefaute == 2)
							{
								//Faute grave + expulsion + coup-franc direct pr�s des buts = > on recup tireur de cf => on compare tireur(forme+moral+cdparrete+creativite) contre gardien(forme+moral+reflexe+pdballe)
								$tireur = match_apl::recuptireurcfranc($teamatk, $infomatch['team_id1'], $infomatch['team_id2'], $infomatch['cfranc1'], $infomatch['cfranc2']);
									if ($tireur != 'noplayer' AND $attaquant1 != $tireur) $attaquant2 = $tireur;
								elseif ($tireur != 'noplayer' AND $attaquant1 == $tireur) { $attaquant1 = $attaquant2; $attaquant2 = $tireur; }
								
								//On lance le script du duel tireur <> gardien
								$resultat_cfr = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'cfranc');
								
								if ($resultat_cfr == 'but')
								{
									//On choisi le commentaire et on inscrit toutes les infos dans matchs
									$num = match_apl::random_commentaire_faute_grave();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_DD', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
									
									//On update les classements des buteur/passeur
									match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
									
									//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
									if($teamatk == $infomatch['team_id1']) 
									{
										$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
										$score1++;
									} 
									
									else 
									{
										$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
										$score2++;
									}
								}
								
								else
								{
									//On choisi le commentaire et on inscrit toutes les infos dans matchs
									$num = match_apl::random_commentaire_faute_grave();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_EE', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
								}
							}
							
							elseif ($grossefaute == 3)
							{
								$tireur = match_apl::recuptireurcfranc($teamatk, $infomatch['team_id1'], $infomatch['team_id2'], $infomatch['cfranc1'], $infomatch['cfranc2']);
									if ($tireur != 'noplayer' AND $attaquant1 != $tireur) $attaquant2 = $tireur;
								elseif ($tireur != 'noplayer' AND $attaquant1 == $tireur) { $attaquant1 = $attaquant2; $attaquant2 = $tireur; }
								
								//On lance le script du duel tireur <> gardien
								$resultat_cfr = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'cfranc');
								
								if ($resultat_cfr == 'but')
								{
									//On choisi le commentaire et on inscrit toutes les infos dans matchs
									$num = match_apl::random_commentaire_faute_grave();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_FF', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
									
									//On update les classements des buteur/passeur
									match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
									match_apl::classement_passeur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant2, $teamatk);
									
									//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
									if($teamatk == $infomatch['team_id1']) 
									{
										$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
										$score1++;
									} 
									
									else 
									{
										$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
										$score2++;
									}
								}
								
								else
								{
									//On choisi le commentaire et on inscrit toutes les infos dans matchs
									$num = match_apl::random_commentaire_faute_grave();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_GG', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
								}
							}
							
							elseif ($grossefaute == 4)
							{
								//Faute grave + expulsion + penalty => on recup tireur de penalty => but ou pas but
								$tireur = match_apl::recuptireurpenalty($teamatk, $infomatch['team_id1'], $infomatch['team_id2'], $infomatch['penalty1'], $infomatch['penalty2']);
								if ($tireur != 'noplayer' AND $attaquant1 != $tireur) $attaquant2 = $tireur;
								elseif ($tireur != 'noplayer' AND $attaquant1 == $tireur) { $attaquant1 = $attaquant2; $attaquant2 = $tireur; }
								
								//On lance le script du duel tireur <> gardien
								$resultat_pen = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $def_gardien, $eq1_pl1, 'penalty');
								
								if ($resultat_pen == 'but')
								{
									//On choisi le commentaire et on inscrit toutes les infos dans matchs
									$num = match_apl::random_commentaire_faute_grave();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_HH', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
									
									//On update les classements du buteur
									match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $attaquant1, $teamatk);
									
									//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
									if($teamatk == $infomatch['team_id1']) 
									{
										$eq1_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq1_info);
										$score1++;
									} 
									
									else 
									{
										$eq2_info = match_apl::ajout_eq_info($mi_temps, $attaquant1, $eq2_info);
										$score2++;
									}
								}
								
								else
								{
									//On choisi le commentaire et on inscrit toutes les infos dans matchs
									$num = match_apl::random_commentaire_faute_grave();
									$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_II', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
								}
							}
							
							else
							{
								//Faute grave + expulsion + coup-franc
								$num = match_apl::random_commentaire_faute_grave();
								$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_CC', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
							}
						}
						
						elseif($res_passe == 'contre')
						{
							//On lance le script du duel tireur <> gardien
							$resultat_tir = match_apl::compare_gardien_tireur($infomatch['team_id1'], $infomatch['team_id2'], $score1, $score2, $atk_gardien, $eq2_pl1, 'tir');
							
							if($resultat_tir == 'but')
							{
								//On choisi le commentaire et on inscrit toutes les infos dans matchs
								$num = match_apl::random_commentaire_contreattaque_reussi();
								if($teamchoice == 1) $teamchoice = 2; else $teamchoice = 1;
								$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_OO', $num, $teamdef, $teamatk, $score2, $score1, $defenseur1, $defenseur2, $gardien1, $attaquant1, $commentinfo, $ratio, $teamchoice, $modematch);
								
								//On update les classements des buteur/passeur
								match_apl::classement_buteur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $defenseur1, $teamatk);
								match_apl::classement_passeur($infomatch['compet_id'], $infomatch['renco_id'], $infomatch['renco_type'], $infomatch['saison_nbr'], $defenseur2, $teamatk);
								
								//On incremente les variable score et on ajoute le buteur a eq#_info pour eviter de nouvelle requete
								if($teamatk == $infomatch['team_id1']) 
								{
									$eq1_info = match_apl::ajout_eq_info($mi_temps, $defenseur1, $eq1_info);
									$score1++;
								} 
								
								else 
								{
									$eq2_info = match_apl::ajout_eq_info($mi_temps, $defenseur1, $eq2_info);
									$score2++;
								}
							}
							
							else
							{
								//On choisi le commentaire et on inscrit toutes les infos dans matchs
								$num = match_apl::random_commentaire_contreattaque_manquer();
								$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_PP', $num, $teamdef, $teamatk, $score2, $score1, $defenseur1, $defenseur2, $gardien1, $attaquant1, $commentinfo, $ratio, $teamchoice, $modematch);
							}
						}
						
						elseif($res_passe == 'tacle')
						{
							//On choisi le commentaire et on inscrit toutes les infos dans matchs
							$num = match_apl::random_commentaire_tacle();
							$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_MM', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
						}
						
						elseif($res_passe == 'pass_manquer')
						{
							//On choisi le commentaire et on inscrit toutes les infos dans matchs
							$num = match_apl::random_commentaire_passe_manquer();
							$commentinfo = match_apl::ajout_commentaire($mi_temps, $arretdejeu, '_LL', $num, $teamatk, $teamdef, $score1, $score2, $attaquant1, $attaquant2, $gardien2, $defenseur1, $commentinfo, $ratio, $teamchoice, $modematch);
						}
					}
					
					//Mi-temps
					if($mi_temps == 45 && $arretdejeu >= $combien_adj)
					{
						//On choisi le commentaire
						srand ((double) microtime() * 10000000); $input = array (1, 2, 3);
						$rand_keys = array_rand ($input, 2); $num = $input[$rand_keys[0]];
						
						//On l'inscrit dans la base
						$score = $score1 . '-' . $score2;
							if($score1 > $score2) $commentinfo .= ';' . $mi_temps . '+' . $arretdejeu . '_M' . $num . '_' . $score . '_' . $infomatch['team_id1'] . '_' . $infomatch['team_id2'] . '___' . 1;
						elseif($score1 < $score2) $commentinfo .= ';' . $mi_temps . '+' . $arretdejeu . '_M' . $num . '_' . $score . '_' . $infomatch['team_id2'] . '_' .  $infomatch['team_id1'] . '___' . 2;
						else 					  $commentinfo .= ';' . $mi_temps . '+' . $arretdejeu . '_N' . $num . '_' . $score . '_' .  $infomatch['team_id1'] . '_' . $infomatch['team_id2'] . '___' . 1;
						
						$timematch_dep = $timematch_dep + (5 * 60);
						$mi_temps++;
					}
					
					//Fin du match
					elseif($mi_temps == 90 && $arretdejeu >= $combien_adj)
					{
						//On choisi le commentaire
						srand ((double) microtime() * 10000000); $input = array (1, 2, 3);
						$rand_keys = array_rand ($input, 2); $num = $input[$rand_keys[0]];
						
						$score = $score1 . '-' . $score2;
							
							if($score1 > $score2) $commentinfo .= ';' . $mi_temps . '+' . $arretdejeu . '_F' . $num . '_' . $score . '_' . $infomatch['team_id1'] . '_' . $infomatch['team_id2'] . '___' . 1;
						elseif($score1 < $score2) $commentinfo .= ';' . $mi_temps . '+' . $arretdejeu . '_F' . $num . '_' . $score . '_' . $infomatch['team_id2'] . '_' . $infomatch['team_id1'] . '___' . 2;
						else 					  $commentinfo .= ';' . $mi_temps . '+' . $arretdejeu . '_G' . $num . '_' . $score . '_' . $infomatch['team_id1'] . '_' . $infomatch['team_id2'] . '___' . 1;
						
						//On ajoute les carton dans le matchinfo
						$matchinfo .= ';' . $carton_jaune . ';' . $carton_rouge;
						
						//On verifie si il y a des joueurs expuls�s, et que ce n'est pas un match amical
						if($expulsion != NULL AND $infomatch['renco_type'] != 2)
						{
							$expulser = explode("/", $expulsion);
							$nb_expulser = count($expulser);
							
							for($inc_expulser = 1; $nb_expulser > $inc_expulser; $inc_expulser++)
							{
								$team = sql::fetch("SELECT team_id FROM joueurs WHERE player_id='".$expulser[$inc_expulser]."'");
								
								//On ajoute une nouvelle ligne dans stamp_suspension pour annoncer que le joueur est indisponible tant de match
								$requete = sql::insert("INSERT INTO stamp_suspension(id_player, id_team, id_compet, suspension) VALUES('{$expulser[$inc_expulser]}', '{$team['team_id']}', '{$infomatch['compet_id']}', '{$CONF['suspension']}')");
								
								//On rend le joueur indisponible pour l'entraineur (tactique)
								$requete = sql::update("UPDATE joueurs SET indisponible = 1 WHERE player_id = '".$expulser[$inc_expulser]."'");
								
								club::verif_player_ontactik($expulser[$inc_expulser], $team['team_id']);
							}
						}
						
						//On efface les matchs en cours 
						$requete = sql::delete("DELETE FROM matchs_encours WHERE renco_id='".$infomatch['renco_id']."'");
						
						if($infomatch['renco_type'] == 1) //Si c'est une rencontre de championnat
						{
							if ($score1 > $score2) //Si equipe1 gagne
							{
								//Mise � jour du gagnant
								$resultat = sql::update("UPDATE classement 
														 SET MJ= MJ + 1, 
															 V= V + 1, 
															 BP= BP + '".$score1."', 
															 BC= BC + '".$score2."', 
															 point= point + 3 
														 WHERE team_id='".$infomatch['team_id1']."' 
														 AND saison_nbr='".$infomatch['saison_nbr']."'");
								
								//Mise � jour du perdant
								$resultat = sql::update("UPDATE classement 
														 SET MJ= MJ + 1, 
															 D= D + 1, 
															 BP= BP + '".$score2."', 
															 BC= BC + '".$score1."' 
														 WHERE team_id='".$infomatch['team_id2']."' 
														 AND saison_nbr='".$infomatch['saison_nbr']."'");
							}
							
							elseif ($score1 < $score2) //Si team2 gagne le match
							{
								//Mise � jour du gagnant
								$resultat = sql::update("UPDATE classement 
														 SET MJ= MJ + 1, 
															 V= V + 1, 
															 BP= BP + '".$score2."', 
															 BC= BC + '".$score1."', 
															 point= point + 3 
														 WHERE team_id='".$infomatch['team_id2']."' 
														 AND saison_nbr='".$infomatch['saison_nbr']."'");
								
								//Mise � jour du perdant
								$resultat = sql::update("UPDATE classement 
														 SET MJ= MJ + 1, 
															 D= D + 1, 
															 BP= BP + '".$score1."', 
															 BC= BC + '".$score2."' 
														 WHERE team_id='".$infomatch['team_id1']."' 
														 AND saison_nbr='".$infomatch['saison_nbr']."'");
							}
							
							else //match nul
							{
								//Mise � jour de l'�quipe 1
								$resultat = sql::update("UPDATE classement 
														 SET MJ= MJ + 1, 
															 N= N + 1, 
															 BP= BP + '".$score1."', 
															 BC= BC + '".$score2."', 
															 point= point + 1 
														 WHERE team_id='".$infomatch['team_id1']."' 
														 AND saison_nbr='".$infomatch['saison_nbr']."'");
								
								//Mise � jour de l'�quipe 2
								$resultat = sql::update("UPDATE classement 
														 SET MJ= MJ + 1, 
															 N= N + 1, 
															 BP= BP + '".$score2."', 
															 BC= BC + '".$score1."', 
															 point= point + 1 
														 WHERE team_id='".$infomatch['team_id2']."' 
														 AND saison_nbr='".$infomatch['saison_nbr']."'");
							}
						}
						
						//On sort de la boucle
						break 1;
					}
					
					//On incremente certaines variables pour la prochaine action
					if($mi_temps != 45 OR $mi_temps != 90)
					{
						$modematch = 0; 
						$timestmp_actu += 60;
						$mi_temps++;
					}
					
					else
					{
						$modematch = 1;
						$timestmp_actu += 60;
						$arretdejeu++;
					}
				}
			
				elseif($nb_eq1 <= 7)
				{
					$error; //Si �quipe 1 a moins de 8 joueurs => match perdu d'office 3-0
				}
				
				elseif($nb_eq2 <= 7)
				{
					$error; //Si �quipe 2 a moins de 8 joueurs => match perdu d'office 0-3
				}
			}
			
			//On update match en cours
			$requete = sql::update("UPDATE matchs 
									LEFT JOIN matchs_encours ON matchs_encours.renco_id = matchs.renco_id 
									SET matchs.score1 = '{$score1}', 
										matchs.score2 = '{$score2}', 
										matchs.matchinfo = '{$matchinfo}', 
										matchs.eq1_info = '{$eq1_info}', 
										matchs.eq2_info = '{$eq2_info}', 
										matchs.commentinfo = '{$commentinfo}', 
										matchs_encours.timematch_dep = '{$timestmp_actu}', 
										matchs_encours.match_min = '{$mi_temps}', 
										matchs_encours.match_adj = '{$arretdejeu}', 
										matchs_encours.combien_adj = '{$combien_adj}', 
										matchs_encours.joueur_eq1 = '{$joueur_eq1}', 
										matchs_encours.joueur_eq2 = '{$joueur_eq2}', 
										matchs_encours.note_eq1 = '{$note_eq1}', 
										matchs_encours.note_eq2 = '{$note_eq2}', 
										matchs_encours.carton_jaune = '{$carton_jaune}', 
										matchs_encours.carton_rouge = '{$carton_rouge}', 
										matchs_encours.expulsion = '{$expulsion}' 
									WHERE matchs.renco_id = '{$infomatch['renco_id']}'");
		}
	}
}
?>