<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
15/05/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

define('BDD_HOST', 'mysql51zfs-42.perso'); // Host du serveur MySQL
define('BDD_USER', 'realsoccrs1'); // Nom d'utilisateur pour acceder a MySQL
define('BDD_PASS', 'iv3dWOFc'); // Mot de passe pour MySQL
define('BDD_NOM', 'realsoccrs1'); // Nom de la base de donn�es
define('PREFIX', '');

?>