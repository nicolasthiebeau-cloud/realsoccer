<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
30/10/09	Cr�ation
*/

function player($player_id, $color, $info)
{
	$req = mysql_query("SELECT player_id, team_id, nom, prenom FROM joueurs WHERE player_id= '".$player_id."'") or die();
	$player = mysql_fetch_assoc($req);
	
	if($color == 1)
	{
		if($player['team_id'] == $info['team_id']) return '<a href="club.php?zone=management&amp;page=joueur&id='.$player['player_id'].'"><span style="color: red"><strong>'.$player['prenom'].' '.$player['nom'].'</strong></span></a>';
		else return '<a href="club.php?zone=public&amp;page=joueur&id='.$player['player_id'].'"><span style="color: red"><strong>'.$player['prenom'].' '.$player['nom'].'</strong></span></a>';
	}
	
	elseif($color == 2)
	{
		if($player['team_id'] == $info['team_id']) return '<a href="club.php?zone=management&amp;page=joueur&id='.$player['player_id'].'"><span style="color: blue"><strong>'.$player['prenom'].' '.$player['nom'].'</strong></span></a>';
		else return '<a href="club.php?zone=public&amp;page=joueur&id='.$player['player_id'].'"><span style="color: blue"><strong>'.$player['prenom'].' '.$player['nom'].'</strong></span></a>';
	}
	
	else
	{
		if($player['team_id'] == $info['team_id']) return '<a href="club.php?zone=management&amp;page=joueur&id='.$player['player_id'].'"><strong>'.$player['prenom'].' '.$player['nom'].'</strong></a>';
		else return '<a href="club.php?zone=public&amp;page=joueur&id='.$player['player_id'].'"><strong>'.$player['prenom'].' '.$player['nom'].'</strong></a>';
	}
	
	
}

function teamname($team_id, $color)
{
	$req = mysql_query("SELECT team_name FROM equipes WHERE team_id= '".$team_id."'") or die();
	$team = mysql_fetch_assoc($req);
	
		if($color == 1) return '<span style="color: red"><strong>' . $team['team_name'] . '</strong></span>';
	elseif($color == 2) return '<span style="color: blue"><strong>' . $team['team_name'] . '</strong></span>';
	else				return '<strong>' . $team['team_name'] . '</strong>';
}

function recupcartonfor($player, $carton_jaune, $carton_rouge)
{
	$cartonj = explode('/', $carton_jaune); $nb_cartonj = count($cartonj); $nbj = 0; $cartonjj = 0;
	while($nb_cartonj > $nbj) { if ($player == $cartonj[$nbj]) { $cartonjj++; } $nbj++; }
	
	$cartonr = explode('/', $carton_rouge); $nb_cartonr = count($cartonr); $nbr = 0; $cartonrr = 0;
	while($nb_cartonr > $nbr) { if ($player == $cartonr[$nbr]) { $cartonrr++; } $nbr++; }
	
	if ($cartonjj == 1 AND $cartonrr == 0) return'<img src="images/icone/cjaune.gif" width="12" height="10" border="0" />';
	elseif ($cartonjj == 1 AND $cartonrr == 1) return'<img src="images/icone/cjaune.gif" width="12" height="10" border="0" /><img src="images/icone/crouge.gif" width="12" height="10" border="0" />';
	elseif ($cartonjj == 2 AND $cartonrr == 0) return'<img src="images/icone/2cjaune.gif" width="12" height="10" border="0" />';
	elseif ($cartonjj == 0 AND $cartonrr == 1) return'<img src="images/icone/crouge.gif" width="12" height="10" border="0" />';
	else return'&nbsp;';
}

function but() { return'<img src="images/icone/but.gif" width="12" height="10" border="0" /> '; }

function faute() { return'<img src="images/icone/faute.gif" width="12" height="10" border="0" /> '; }

function cjaune() { return'<img src="images/icone/cjaune.gif" width="12" height="10" border="0" /> '; }

function cjaune2() { return'<img src="images/icone/2cjaune.gif" width="12" height="10" border="0" /> '; }

function crouge() { return'<img src="images/icone/crouge.gif" width="12" height="10" border="0" /> '; }

function rempla() { return'<img src="images/icone/.gif" width="12" height="10" border="0" /> '; }

function blessure() { return'<img src="images/icone/blessure.gif" width="12" height="10" border="0" /> '; }

function commentaire($number,$score,$teamatk,$teamdef,$play1,$play2,$col,$info) //Commentaire - Score - equipeatk - equipedef - Joueur �quipe1 - Joueur �quipe2 - couleur
{
	$tm1play = explode('/', $play1);
	$tm2play = explode('/', $play2);
	
	if(isset($col) && $col == 1) { $col1 = 1; $col2 = 2; } elseif(isset($col) && $col = 2) { $col1 = 2; $col2 = 1; } else $col1 = $col2 = NULL;

	switch($number)
	{
		/*R�gle
		$tm1play toujours attaquant	$tm2play toujours defenseur
		$tm1play[0] toujours buteur	$tm2play[0] toujours gardien
		$tm1play[1] toujours passeur (si passeur)
		d�but de match_______________
		score et remplacer par nom du stade
		mi-temps et fin de match_______________
		$teamatk = l'�quipe gagnante ou qui mene au score
		$teamdef = l'�quipe perdante ou qui est mener au score
		*/

// Partie D�but de Match_______________________________

		//D�but de match championnat
		case 'S1' : return "Le match entre <strong>".teamname($teamatk, $col1)."</strong> et <strong>".teamname($teamdef, $col2)."</strong> va d�buter dans quelques instants, nous esp�rons tous un superbe spectacle !"; break;
		case 'S2' : return "Enfin le d�but de ce super derby entre <strong>".teamname($teamatk, $col1)."</strong> et <strong>".teamname($teamdef, $col2)."</strong> ! Bonne chance au 2 �quipes !"; break;
		case 'S3' : return "Bienvenue � tous, Ce match opposant ".teamname($teamatk, $col1)." et ".teamname($teamdef, $col2)." risque de finir sur une avalanche de but"; break;
		case 'S4' : return "Bienvenue au ".$score.", Pour ce match qui oppose ".teamname($teamatk, $col1)." et ".teamname($teamdef, $col2).", l'arbitre signe le d�but du match"; break;
		case 'S5' : return "Bienvenue au ".$score.", Nous nous retrouvons ce soir pour le match opposant ".teamname($teamatk, $col1)." et ".teamname($teamdef, $col2)." qui nous l'esperons tous, sera fantastique"; break;
		case 'S6' : return "Bonsoir, Le ".$score." est complet ce soir, pour la rencontre qui oppose ".teamname($teamatk, $col1)." et ".teamname($teamdef, $col2)." Bon match � tous !"; break;
		
		//D�but de match amical
		case 'KK1' : return "Le match amical entre <strong>".teamname($teamatk, $col1)."</strong> et <strong>".teamname($teamdef, $col2)."</strong> va d�buter dans quelques instants, nous esp�rons tous un superbe spectacle !"; break;
		case 'KK2' : return "Enfin le d�but de ce super match amical entre <strong>".teamname($teamatk, $col1)."</strong> et <strong>".teamname($teamdef, $col2)."</strong> ! Bonne chance au 2 �quipes !"; break;
		case 'KK3' : return "Bienvenue � tous, Ce match amical opposant ".teamname($teamatk, $col1)." et ".teamname($teamdef, $col2)." risque de finir sur une avalanche de but, bonne chance au 2 �quipes !"; break;
		case 'KK4' : return "Bienvenue au ".$score.", Pour ce match amical qui oppose ".teamname($teamatk, $col1)." et ".teamname($teamdef, $col2).", l'arbitre signe le d�but du match"; break;
		case 'KK5' : return "Bienvenue au ".$score.", Nous nous retrouvons ce soir pour le match amical opposant ".teamname($teamatk, $col1)." et ".teamname($teamdef, $col2)." qui nous l'esperons tous, sera fantastique"; break;
		case 'KK6' : return "Bonsoir, Le ".$score." est bouillant, pour la rencontre amical qui oppose ".teamname($teamatk, $col1)." et ".teamname($teamdef, $col2)." Bon match � tous !"; break;
		
		//D�but de match => dans la m�me r�gion (derby)
		
// Partie Passe manquer_____________________________________

		case 'LL1' : return "Ca joue vite du cot� de ".teamname($teamatk, $col1).", ".player($tm1play[1], $col1, $info)." Dribble 2 adversaires avant de servir ".player($tm1play[0], $col1, $info)." dans la surface adverse, � non ! quel mauvaise passe !"; break;
		case 'LL2' : return "Enorme pression offensif de ".teamname($teamatk, $col1)." ! ".player($tm1play[1], $col1, $info)." tente sa chance ! Mais il manque sa passe."; break;
		case 'LL3' : return "Attention!!!! la contre-attaque!! ".player($tm1play[0], $col1, $info)." r�cup�re le ballon!!!! Attention 3 contre 2!!! il lance ".player($tm1play[1], $col1, $info)." mais c'est recup�r� par ".player($tm2play[1], $col2, $info); break;
		case 'LL4' : return "Excellente feinte, � gauche de la surface de ".player($tm1play[0], $col1, $info).", il tente une passe, mais ".player($tm2play[1], $col2, $info)." intercepte."; break;
		case 'LL5' : return "nocomment"; break;
		case 'LL6' : return "nocomment"; break;

// Partie Tacle _____________________________________

		case 'MM1' : return player($tm1play[0], $col1, $info)." lance ".player($tm1play[1], $col1, $info)." mais tr�s beau tacle de ".player($tm2play[1], $col2, $info); break;
		case 'MM2' : return "Excellente feinte de ".player($tm1play[0], $col1, $info)." qui se met dans le sens du but, face au poteau. Il va centrer ! mais ".player($tm2play[1], $col2, $info)." �tait la pour sauver les meubles !"; break;
		case 'MM3' : return "Quel tacle de ".player($tm2play[1], $col2, $info)." dans la surface ! c'�tait os� et c'est r�ussi !"; break;
		case 'MM4' : return "Grosse acc�l�ration de ".player($tm1play[1], $col1, $info)." qui cherche du soutien, il temporise, mais se fait tacler proprement par ".player($tm2play[1], $col2, $info)." qui relance imm�diatement."; break;
		case 'MM5' : return "Enorme pression offensif de ".teamname($teamatk, $col1)." ! ".player($tm1play[1], $col1, $info)." tente sa chance ! Mais il se fait tacler par ".player($tm2play[1], $col2, $info); break;
		case 'MM6' : return "Ca joue vite du cot� de ".teamname($teamatk, $col1).", ".player($tm1play[1], $col1, $info)." Dribble 2 adversaires avant de servir ".player($tm1play[0], $col1, $info)." dans la surface adverse, mais ".player($tm2play[1], $col2, $info)." �tait sur le coup en effectuant un superbe tacle !"; break;

// Partie Attaque _____________________________________

		//Attaque manqu�
		case 'A1' : return "Excellente feinte, � gauche de la surface de ".player($tm1play[0], $col1, $info)." qui se met dans le sens du but, face au poteau. Il centre mais c'est beaucoup trop sortant, Dommage."; break;
		case 'A2' : return "Port� vers l'offensive, ".player($tm1play[0], $col1, $info)." tente une frappe lointaine. C'est largement � c�t� des cages de ".player($tm2play[0], $col2, $info); break;
		case 'A3' : return player($tm1play[0], $col1, $info)." combine avec ".player($tm1play[1], $col1, $info)." sur le flanc droit. Le joueur de ".teamname($teamatk, $col1)." centre au second poteau mais ".player($tm1play[0], $col1, $info)." est devanc� par ".player($tm2play[0], $col2, $info)." qui �loigne le danger."; break;
		case 'A4' : return "Acc�l�ration de ".player($tm1play[0], $col1, $info)." ! Personne n'arrive a le suivre ! Il se pr�sente face � ".player($tm2play[0], $col2, $info)." ! Non, c'est au dessus !! Quel occasion manqu� !"; break;
		case 'A5' : return "Attention contre-attaque ! ".player($tm1play[0], $col1, $info)." fonce en direction des cages adverses, mais il est vite rattrap� par la d�fense"; break;
		case 'A6' : return player($tm1play[0], $col1, $info)." lance ".player($tm1play[1], $col1, $info)." sur l'aile ! Non c'est Hors-jeu !!"; break;
		case 'A7' : return "Port� vers l'offensive, ".player($tm1play[0], $col1, $info)." tente une frappe lointaine. Ah non ! C'est au dessus."; break;
		case 'A8' : return "Longue touche de ".player($tm1play[1], $col1, $info)." directement dans la surface mais le portier de ".teamname($teamdef, $col2)." est sur le coup et relance directement"; break;
		case 'A9' : return "Longue balle de ".player($tm1play[1], $col1, $info)." sur ".player($tm1play[0], $col1, $info)." dans la surface adverse !... mais ".player($tm2play[0], $col2, $info)." intervient sereinement"; break;
		case 'A10' : return "Ca joue vite du cot� de ".teamname($teamatk, $col1).", ".player($tm1play[1], $col1, $info)." Dribble 2 adversaires avant de servir ".player($tm1play[0], $col1, $info)." dans la surface adverse, mais son controle est hasardeux"; break;
		case 'A11' : return "Enorme pression offensif de ".teamname($teamatk, $col1)." ! mais l'action ne donne rien."; break;
		case 'A12' : return "Grosse acc�l�ration de ".player($tm1play[1], $col1, $info)." qui cherche du soutien, il temporise, mais se fait tacler proprement par ".player($tm2play[1], $col2, $info)." qui relance imm�diatement."; break;
		case 'A13' : return player($tm1play[0], $col1, $info)." lance ".player($tm1play[1], $col1, $info)." qui dribble facilement ".player($tm2play[1], $col2, $info)." mais il pousse trop son ballon et ".player($tm2play[0], $col2, $info)." intercepte facilement."; break;
		case 'A14' : return "Le gardien de ".teamname($teamdef, $col2)." tranquille, saute dans les airs par dessus la d�fense, le corner ne donne rien"; break;
		case 'A15' : return "Waouh!! Tr�s belle arr�t du Gardien de ".teamname($teamdef, $col2)."!"; break;
		//Attaque r�ussi sans passeur
		case 'B1' : return but() . "Port� vers l'offensive, ".player($tm1play[0], $col1, $info)." tente une frappe lointaine. En pleine lucarne ! BUUUUUT !!."; break;
		case 'B2' : return but() . "BUT de ".teamname($teamatk, $col1)." !!! Il est sign�e ".player($tm1play[0], $col1, $info)." qui trompe ".player($tm2play[0], $col2, $info)." sur coup franc direct, un coup franc jou� aux vingt m�tres. ".$score." d�sormais au tableau d'affichage!"; break;
		case 'B3' : return but() . "Quel erreur ! ".player($tm2play[1], $col2, $info)." perd le ballon dans sa surface, ".player($tm1play[0], $col1, $info)." en profite pour tir� droit dans les buts ! ".player($tm2play[0], $col2, $info)." le portier de ".teamname($teamdef, $col2)." n'en crois pas ses yeux !!"; break;
		case 'B4' : return but() . "D�gagement de ".player($tm2play[0], $col2, $info)." sur ... Non ! ".player($tm1play[0], $col1, $info)." r�cup�re le ballon et fonce en direction des cages, il tire ! BUUUT"; break;
		case 'B5' : return but() . "Quel BUT !!! Un tir de 30 m�tres de ".player($tm1play[0], $col1, $info)." en pleine lucarne ! ".player($tm2play[0], $col2, $info)." n'a rien vu venir."; break;
		case 'B6' : return but() . "Longue touche de ".player($tm1play[1], $col1, $info)." directement dans la surface mais le portier de ".teamname($teamdef, $col2)." est sur le coup... NON !!, ".player($tm1play[0], $col1, $info)." plonge !! BUUUT !!!"; break;
		//Attaque r�ussi avec passeur
		case 'C1' : return but() . "Belle acc�l�ration sur l'aile par ".player($tm1play[1], $col1, $info).", attention ! ".player($tm1play[0], $col1, $info)." est tout seul dans l'axe ! Oui il l'a vu ! il centre ! BUUUUT !!!"; break;
		case 'C2' : return but() . "Longue balle de ".player($tm1play[1], $col1, $info)." sur ".player($tm1play[0], $col1, $info)." dans la surface adverse !... Reprise de vol�e !! BUUUT !!!"; break;
		case 'C3' : return but() . "Attention!!!! la contre-attaque!! ".player($tm1play[0], $col1, $info)." r�cup�re le ballon!!!! Attention 3 contre 2!!! Une grosse occasion de marqu�!!! Une deux avec ".player($tm1play[1], $col1, $info)."!!! en retrait GOALLLLLLLLLL!"; break;
		case 'C4' : return but() . "Acc�l�ration de ".player($tm1play[0], $col1, $info)." ! Qui est servi par ".player($tm2play[1], $col2, $info)." ! Personne n'arrive � le suivre ! Il se pr�sente face � ".player($tm2play[0], $col2, $info)." ! BUUUUUT !!"; break;
		case 'C5' : return but() . "Ca joue vite du cot� de ".teamname($teamatk, $col1).", ".player($tm1play[1], $col1, $info)." Dribble 2 adversaires avant de servir ".player($tm1play[0], $col1, $info)." dans la surface adverse, il est seul face � ".player($tm2play[0], $col2, $info)." ! BUUUT"; break;
		case 'C6' : return but() . "Corner tir� par ".player($tm1play[1], $col1, $info)." au second poteau mais c'est trop long... Non !!! ".player($tm1play[0], $col1, $info)." coupe la trajectoire et BUUUUUT !!!  "; break;

// Partie Contre Attaque ________________________________

		//Contre attaque r�ussi
		case 'OO1' : return player($tm2play[1], $col2, $info)." perd le ballon, ".player($tm1play[0], $col1, $info)." en profite ! il tire ! BUUUUT !!!!"; break;
		case 'OO2' : return "Quel erreur ! ".player($tm2play[1], $col2, $info)." perd le ballon dans sa surface, ".player($tm1play[0], $col1, $info)." en profite pour tir� droit dans les buts ! ".player($tm2play[0], $col2, $info)." le portier de ".teamname($teamdef, $col2)." n'en crois pas ses yeux !!"; break;
		case 'OO3' : return "Attention!!!! la contre-attaque!! ".player($tm1play[0], $col1, $info)." r�cup�re le ballon!!!! Attention 3 contre 2!!! Une grosse occasion de marqu�!!! Une deux avec ".player($tm1play[1], $col1, $info)."!!! en retrait GOALLLLLLLLLL!"; break;
		case 'OO4' : return "Le gardien de ".teamname($teamdef, $col2)." joue cette relance au pied vers ".player($tm2play[1], $col2, $info).", attention ! il perd le ballon ! ".player($tm1play[0], $col1, $info)." tente sa chance ! BUUUT !!!"; break;
		case 'OO5' : return "La d�fense de ".teamname($teamdef, $col2)." � l'air f�brile ces derni�res minutes. ".player($tm2play[1], $col2, $info)." fait une passe, mais ".player($tm1play[0], $col1, $info)." et sur le coup ! Il tire !! BUT !!!"; break;
		case 'OO6' : return "Enfin de l'action ! ".player($tm1play[0], $col1, $info)." est sur tous les ballon et il r�ussi � suptiliser le ballon ! Il tire !! BUUUT !!!"; break;
		
		//Contre attaque manqu�
		case 'PP1' : return player($tm2play[1], $col2, $info)." perd le ballon, ".player($tm1play[0], $col1, $info)." en profite ! il tire ! Olala quel occasion !!!!"; break;
		case 'PP2' : return "Quel erreur ! ".player($tm2play[1], $col2, $info)." perd le ballon dans sa surface, ".player($tm1play[0], $col1, $info)." en profite pour tir� droit dans les buts ! Wouhou c'�tait juste"; break;
		case 'PP3' : return "Attention!!!! la contre-attaque!! ".player($tm1play[0], $col1, $info)." r�cup�re le ballon!!!! Attention 3 contre 2!!! Une grosse occasion de marqu�!!! Une deux avec ".player($tm1play[1], $col1, $info)."!!! en retrait ah non 6 m�tres !"; break;
		case 'PP4' : return "Le gardien de ".teamname($teamdef, $col2)." joue cette relance au pied vers ".player($tm2play[1], $col2, $info).", attention ! il perd le ballon ! ".player($tm1play[0], $col1, $info)." tente sa chance ! C'est manquer de tr�s peu !!!"; break;
		case 'PP5' : return "La d�fense de ".teamname($teamdef, $col2)." � l'air f�brile ces derni�res minutes. ".player($tm2play[1], $col2, $info)." fait une passe, mais ".player($tm1play[0], $col1, $info)." et sur le coup ! Il tire !! Oh non il ne devait pas la manquer celle la !!!"; break;
		case 'PP6' : return "Enfin de l'action ! ".player($tm1play[0], $col1, $info)." est sur tous les ballon et il r�ussi � suptiliser le ballon ! Il tire !! Ah !! il avait fait le plus dur, mais c'est � cot� !!!"; break;

// Partie Faute Simple____________________________________

		//Simple faute + coup-franc
		case 'E1' : return faute() . "Faute de ".player($tm2play[1], $col2, $info)." sur ".player($tm1play[0], $col1, $info).", rien de bien grave les joueurs se sert la main."; break;
		case 'E2' : return faute() . "Faute de ".player($tm2play[1], $col2, $info)." qui a crocheter ".player($tm1play[0], $col1, $info)." en pleine course, ca m�ritait un carton."; break;
		case 'E3' : return faute() . "L'arbitre siffle une faute, ".player($tm1play[0], $col1, $info)." joue vite le coup-franc."; break;
		
		//Simple faute + coup-franc directe pr�s des buts => BUT
		case 'H1' : return but() . "Coup-franc � une vingtaine de m�tre, c'est la sp�cialit� de ".player($tm1play[0], $col1, $info).", va t'il le tir� ? oui ! Tous les supporters retiennent leurs souffles... BUUUUT !!"; break;
		case 'H2' : return but() . "L'arbitre siffle la faute, le coup-franc est surement trop excentr� pour ".player($tm1play[0], $col1, $info).", et ".player($tm2play[0], $col2, $info)." � tr�s bien plac� ces d�fenseurs... Olala BUUUT dans un mouchoir de poche !!!"; break;
		case 'H3' : return but() . "Faute ! c'est ce genre de coup-franc qu'il faut �viter d'offrir � ".teamname($teamatk, $col1).", et � son buteur ".player($tm1play[0], $col1, $info).", Les supporters retiennent leurs souffles... BUUUT !!!"; break;
		
		//Simple faute + coup-franc directe pr�s des buts => MANQUER
		case 'I1' : return faute() . "Coup-franc � une vingtaine de m�tre, c'est la sp�cialit� de ".player($tm1play[0], $col1, $info).", va t'il le tir� ? oui ! Tous les supporters retiennent leurs souffles... C'est � cot� !!"; break;
		case 'I2' : return faute() . "L'arbitre siffle la faute, le coup-franc est surement trop excentr� pour ".player($tm1play[0], $col1, $info).", et ".player($tm2play[0], $col2, $info)." � tr�s bien plac� ces d�fenseurs... C'est trop haut ! Quel occasion !"; break;
		case 'I3' : return faute() . "Faute ! c'est ce genre de coup-franc qu'il faut �viter d'offrir � ".teamname($teamatk, $col1).", et � son buteur ".player($tm1play[0], $col1, $info).", Les supporters retiennent leur souffle... POOOTEAUX, ils ont eu de la chance !!!"; break;
		
		//Simple faute + coup-franc indirecte pr�s des but => BUT
		case 'J1' : return but() . "Coup-franc indirect de ".player($tm1play[1], $col1, $info)." suite � une faute de ".player($tm2play[1], $col2, $info).", c'est bien jouer ! sur la t�te de ".player($tm1play[0], $col1, $info)." BUUUT ! ".player($tm2play[0], $col2, $info)." n'a rien pu faire !"; break;
		case 'J2' : return but() . "Faute de ".player($tm2play[1], $col2, $info).", le joueur de ".teamname($teamdef, $col2).", qui � crochet� le pauvre ".player($tm1play[1], $col1, $info)." pr�s du poteau de corner, il va lui m�me le tir�... reprise de ".player($tm1play[0], $col1, $info)." ! BUUUUT !!!"; break;
		case 'J3' : return but() . "Faute pas du tout �vidente de ".player($tm2play[1], $col2, $info)." sur ".player($tm1play[1], $col1, $info)." qui donnais plus l'impression d'avoir plonger, le coup-franc est tr�s bien plac�, ".player($tm1play[1], $col1, $info)." tire... sur la t�te de ".player($tm1play[0], $col1, $info)." !! BUUUT !!!"; break;
		
		//Simple faute + coup-franc indirecte pr�s des but => MANQUER
		case 'L1' : return faute() . "Faute sur ".player($tm1play[1], $col1, $info)." de ".player($tm2play[1], $col2, $info)." qui l'a compl�tement �jecter du terrain, les joueurs de ".teamname($teamatk, $col1)." protestent, mais l'arbitre d�cide un coup-franc indirect, qui ne donne rien"; break;
		case 'L2' : return faute() . "Coup-franc indirect de ".player($tm1play[1], $col1, $info).", c'est bien jouer ! sur la t�te de ".player($tm1play[0], $col1, $info)." ! Mais ".player($tm2play[0], $col2, $info)." ce saisi du ballon !"; break;
		case 'L3' : return faute() . "Ola quel faute ! la tension monte entre les joueurs de ".teamname($teamdef, $col2)." et ".teamname($teamatk, $col1).", mais l'arbitre calme le jeu, ".player($tm1play[1], $col1, $info)." tire le coup-franc mais c'est beaucoup trop fort... 6 m�tres."; break;

// Partie Faute moyenne____________________________________

		//Faute moyenne + carton jaune + coup-franc
		case 'O1' : return cjaune() . "Oulala, ".player($tm1play[0], $col1, $info)." c'est fait violement fauch�, l'arbitre court vers ".player($tm2play[1], $col2, $info)." pour lui mettre un carton jaune bien m�rit�."; break;
		case 'O2' : return cjaune() . "Les fautes d�viennent de plus en plus s�v�re, c'est le moment de s�vir monsieur l'arbitre !? Voila carton jaune pour ".player($tm2play[1], $col2, $info).""; break;
		case 'O3' : return cjaune() . "Ouch, il a d�coll� les deux pieds la non ? ca m�rite le rouge ? Monsieur l'arbitre d�cide le jaune, ".player($tm2play[1], $col2, $info)." � de la chance cette fois !"; break;
		
		//Faute moyenne + carton jaune + coup-franc directe pr�s des buts => BUT
		case 'P1' : return cjaune() . "Un carton jaune bien m�rit� pour ".player($tm2play[1], $col2, $info)." ! Voyons le coup-franc � une vingtaine de m�tre des cages de ".player($tm2play[0], $col2, $info).", c'est la sp�cialit� de ".player($tm1play[0], $col1, $info).", va t'il le tir� ? oui ! Tous les supporters retiennent leurs souffles... BUUUUT !!"; break;
		case 'P2' : return cjaune() . "De toute �vidence ".player($tm2play[1], $col2, $info)." va prendre un carton ! Oui ce sera un carton jaune ! A une trentaine de m�tres des buts, le coup-franc est peut-�tre trop loin pour ".player($tm1play[0], $col1, $info)."... Il rebondit sur le poteau ! BUUUT"; break;
		case 'P3' : return cjaune() . "Vilaine faute de ".player($tm2play[1], $col2, $info)." qui prend un carton ! ".player($tm1play[0], $col1, $info)." s'avance pour tir� le coup franc, ext�rieur du pied mais c'est dehors... NON ! BUUUT !"; break;
		
		//Faute moyenne + carton jaune + coup-franc directe pr�s des buts => MANQUER
		case 'Q1' : return cjaune() . "Un carton jaune bien m�rit� pour ".player($tm2play[1], $col2, $info)." ! Voyons le coup-franc � une vingtaine de m�tre des cages de ".player($tm2play[0], $col2, $info).", c'est la sp�cialit� de ".player($tm1play[0], $col1, $info).", va t'il le tir� ? oui ! Tous les supporters retiennent leurs souffles... C'est � cot� !!"; break;
		case 'Q2' : return cjaune() . "De toute �vidence ".player($tm2play[1], $col2, $info)." va prendre un carton ! Oui ce sera un carton jaune ! A une trentaine de m�tres des buts, le coup-franc est peut-�tre trop loin pour ".player($tm1play[0], $col1, $info)."... C'est beaucoup trop haut."; break;
		case 'Q3' : return cjaune() . "Ola quel faute ! la tension monte entre les joueurs de ".teamname($teamdef, $col2)." et ".teamname($teamatk, $col1).", mais l'arbitre calme le jeu et sanctionne ".player($tm2play[1], $col2, $info).", ".player($tm1play[0], $col1, $info)." tire le coup-franc mais c'est beaucoup trop fort... 6 m�tres."; break;
		
		//Faute moyenne + carton jaune + coup-franc indirecte pr�s des but => BUT
		case 'R1' : return cjaune() . "nocomment"; break;
		case 'R2' : return cjaune() . "nocomment"; break;
		case 'R3' : return cjaune() . "nocomment"; break;
		
		//Faute moyenne + carton jaune + coup-franc indirecte pr�s des but => MANQUER
		case 'JJ1' : return cjaune() . "nocomment"; break;
		case 'JJ2' : return cjaune() . "nocomment"; break;
		case 'JJ3' : return cjaune() . "nocomment"; break;
		
		//Faute moyenne + carton jaune + penalty => BUT
		case 'T1' : return cjaune() . "Penalty ! Oh non c'�tait la grosse panique dans la surface, et ".player($tm2play[1], $col2, $info)." n'a rien pu faire d'autre que de crochet� ".player($tm1play[0], $col1, $info)." dans la surface ! ".player($tm2play[0], $col2, $info)." va t'il l'arret� ?... BUUUT !!!"; break;
		case 'T2' : return cjaune() . "Le penalty n'est pas �vident du tout sur cette action, ".player($tm1play[0], $col1, $info)." donne plus l'impression de glisser qu'autre chose. ".player($tm2play[1], $col2, $info)." se tient la t�te, tandis que ces co�quipiers essai de convaincre l'arbitre, mais rien n'y fait. ".player($tm1play[0], $col1, $info)." tire... BUUUT !"; break;
		case 'T3' : return cjaune() . "Aie aie aie, l'arbitre d�signe le point de p�nalty, ".player($tm2play[1], $col2, $info)." doit regretter ce geste absurde qui peut couter ch�re pour son �quipe. ".player($tm1play[0], $col1, $info)." place le ballon sur le point de p�nalty... BUUUT"; break;
		
		//Faute moyenne + carton jaune + penalty => MANQUER
		case 'U1' : return cjaune() . "Penalty ! Oh non c'�tait la grosse panique dans la surface, et ".player($tm2play[1], $col2, $info)." n'a rien pu faire d'autre que de crochet� ".player($tm1play[0], $col1, $info)." dans la surface ! ".player($tm2play[0], $col2, $info)." va t'il l'arret� ?... OUI IL L'A ARRETER !!!"; break;
		case 'U2' : return cjaune() . "Le penalty n'est pas �vident du tout sur cette action, ".player($tm1play[0], $col1, $info)." donne plus l'impression de glisser qu'autre chose. ".player($tm2play[1], $col2, $info)." se tient la t�te, tandis que ces co�quipiers essai de convaincre l'arbitre, mais rien n'y fait. ".player($tm1play[0], $col1, $info)." tire... C'est manquer !!!"; break;
		case 'U3' : return cjaune() . "Aie aie aie, l'arbitre d�signe le point de p�nalty, ".player($tm2play[1], $col2, $info)." doit regretter ce geste absurde qui peut couter ch�re pour son �quipe. ".player($tm1play[0], $col1, $info)." place le ballon sur le point de p�nalty... AU DESSUS !!!"; break;
		
		//Faute moyenne + deuxi�me carton jaune + expulsion + coup-franc
		case 'V1' : return cjaune2() . "C'est son deuxi�me carton du match, pour ".player($tm2play[1], $col2, $info)." le match se termine maintenant."; break;
		case 'V2' : return cjaune2() . "Le sort s'acharne sur ".teamname($teamdef, $col2).", son joueur ".player($tm2play[1], $col2, $info)." vient de prendre son deuxi�me carton du match, il est donc expuls�."; break;
		case 'V3' : return cjaune2() . "Expulsion de ".player($tm2play[1], $col2, $info)." ! C'est son deuxi�me carton jaune, direction les vestiaires pour lui"; break;
		
		//Faute moyenne + deuxi�me carton jaune + expulsion + coup-franc directe pr�s des buts => BUT
		case 'W1' : return cjaune2() . "Le sort s'acharne sur ".teamname($teamdef, $col2).", son joueur ".player($tm2play[1], $col2, $info)." vient de prendre son deuxi�me carton du match, ".player($tm1play[0], $col1, $info)." tire le coup-franc... BUUUT !!"; break;
		case 'W2' : return cjaune2() . "Expulsion de ".player($tm2play[1], $col2, $info)." ! C'est son deuxi�me carton jaune, c'est un avantage pour ".teamname($teamatk, $col1).". ".player($tm1play[0], $col1, $info)." se charge du coup-franc... BUUT !!"; break;
		case 'W3' : return cjaune2() . "nocomment"; break;
		
		//Faute moyenne + deuxi�me carton jaune + expulsion + coup-franc directe pr�s des buts => MANQUER
		case 'X1' : return cjaune2() . "Expulsion de ".player($tm2play[1], $col2, $info)." ! C'est son deuxi�me carton jaune, c'est un avantage pour ".teamname($teamatk, $col1).". ".player($tm1play[0], $col1, $info)." se charge du coup-franc... directement dans les bras de ".player($tm2play[0], $col2, $info)." !!"; break;
		case 'X2' : return cjaune2() . "Le sort s'acharne sur ".teamname($teamdef, $col2).", son joueur ".player($tm2play[1], $col2, $info)." vient de prendre son deuxi�me carton du match, ".player($tm1play[0], $col1, $info)." tire le coup-franc... C'est loin du cadre"; break;
		case 'X3' : return cjaune2() . "nocomment"; break;
		
		//Faute moyenne + deuxi�me carton jaune + expulsion + coup-franc indirecte pr�s des but => BUT
		case 'Y1' : return cjaune2() . "nocomment"; break;
		case 'Y2' : return cjaune2() . "nocomment"; break;
		case 'Y3' : return cjaune2() . "nocomment"; break;
		
		//Faute moyenne + deuxi�me carton jaune + expulsion + coup-franc indirecte pr�s des but => MANQUER
		case 'Z1' : return cjaune2() . "nocomment"; break;
		case 'Z2' : return cjaune2() . "nocomment"; break;
		case 'Z3' : return cjaune2() . "nocomment"; break;
		
		//Faute moyenne + deuxi�me carton jaune + expulsion + penalty => BUT
		case 'AA1' : return cjaune2() . "nocomment"; break;
		case 'AA2' : return cjaune2() . "nocomment"; break;
		case 'AA3' : return cjaune2() . "nocomment"; break;
		
		//Faute moyenne + deuxi�me carton jaune + expulsion + penalty => MANQUER
		case 'BB1' : return cjaune2() . "nocomment"; break;
		case 'BB2' : return cjaune2() . "nocomment"; break;
		case 'BB3' : return cjaune2() . "nocomment"; break;		

// Partie Faute Grave____________________________________

		//Faute grave + expulsion + coup-franc
		case 'CC1' : return crouge() . "Expulsion de ".player($tm2play[1], $col2, $info)." ! C'est m�rit� ! Suite � ce tacle par derri�re sur ".player($tm1play[0], $col1, $info).", il rejoint les vestiaires sous les sifflements du public"; break;
		case 'CC2' : return crouge() . "Alala, surement un coup dur pour ".teamname($teamdef, $col2).", L'arbitre a �t� dur sur ce coup la, ".player($tm2play[1], $col2, $info)." doit s'en vouloir."; break;
		case 'CC3' : return crouge() . "Et voila ca devait arriver, carton rouge pour ".player($tm2play[1], $col2, $info).", qui l'a m�rit� sur ce coup la."; break;
		
		//Faute grave + expulsion + coup-franc directe pr�s des buts => BUT
		case 'DD1' : return crouge() . "Coup dur pour ".teamname($teamdef, $col2).", qui perd son joueur ".player($tm2play[1], $col2, $info)." sur expulsion et qui offre un tr�s bon coup-franc � ".player($tm1play[0], $col1, $info)."... BUUUUT !"; break;
		case 'DD2' : return crouge() . "nocomment"; break;
		case 'DD3' : return crouge() . "nocomment"; break;
		
		//Faute grave + expulsion + coup-franc directe pr�s des buts => MANQUER
		case 'EE1' : return crouge() . "Coup dur pour ".teamname($teamdef, $col2).", qui perd son joueur ".player($tm2play[1], $col2, $info)." sur expulsion et qui offre un tr�s bon coup-franc � ".player($tm1play[0], $col1, $info)."... Non c'est au dessus !"; break;
		case 'EE2' : return crouge() . "nocomment"; break;
		case 'EE3' : return crouge() . "nocomment"; break;
		
		//Faute grave + expulsion + coup-franc indirecte pr�s des but => BUT
		case 'FF1' : return crouge() . "nocomment"; break;
		case 'FF2' : return crouge() . "nocomment"; break;
		case 'FF3' : return crouge() . "nocomment"; break;
		
		//Faute grave + expulsion + coup-franc indirecte pr�s des but => MANQUER
		case 'GG1' : return crouge() . "nocomment"; break;
		case 'GG2' : return crouge() . "nocomment"; break;
		case 'GG3' : return crouge() . "nocomment"; break;
		
		//Faute grave + expulsion + penalty => BUT
		case 'HH1' : return crouge() . "NOOOOON !! Penalty !!! Quel erreur de ".player($tm2play[1], $col2, $info)." qui � crocheter ".player($tm1play[0], $col1, $info)." dans la surface ! ".player($tm1play[0], $col1, $info)." va t'il se faire justice lui m�me ?... BUUUUT !!"; break;
		case 'HH2' : return crouge() . "nocomment"; break;
		case 'HH3' : return crouge() . "nocomment"; break;
		
		//Faute grave + expulsion + penalty => MANQUER
		case 'II1' : return crouge() . "NOOOOON !! Penalty !!! Quel erreur de ".player($tm2play[1], $col2, $info)." qui � crocheter ".player($tm1play[0], $col1, $info)." dans la surface ! ".player($tm1play[0], $col1, $info)." va t'il se faire justice lui m�me ?... NOOON !! ".player($tm2play[0], $col2, $info)." l'a arr�ter ! quel r�flexe !"; break;
		case 'II2' : return crouge() . "nocomment"; break;
		case 'II3' : return crouge() . "nocomment"; break;

// Partie Blessure _____________________________________

		case 'NN1' : return bless() . "nocomment"; break;
		case 'NN2' : return bless() . "nocomment"; break;
		case 'NN3' : return bless() . "nocomment"; break;

// Partie Remplacement _____________________________________

		case 'LL1' : return rempla() . "nocomment"; break;
		case 'LL2' : return rempla() . "nocomment"; break;
		case 'LL3' : return rempla() . "nocomment"; break;

// Partie Autre commentaire_________________________

		//Commentaire de match
		case 'D1' : return "Le bloc d�fensif de ".teamname($teamdef, $col2)." est surprenant, il n'y a aucune faille apparente."; break;
		case 'D2' : return player($tm1play[0], $col1, $info)." , le joueur de ".teamname($teamatk, $col1)." est vraiment en forme aujourd'hui, il est sur tous les ballons."; break;
		case 'D3' : return teamname($teamdef, $col2)." domine le match, mais rien n'est gagn� encore."; break;
		case 'D4' : return "Le manager de ".teamname($teamdef, $col2)." esp�re des r�sultats  de son �quipe dans ce match"; break;
		case 'D5' : return "Le manager de ".teamname($teamdef, $col2)." hurle sur ces joueurs qui ont du mal � ce replacer"; break;
		case 'D6' : return player($tm2play[1], $col2, $info)." a vraiment la cote aujourd'hui, il intercepte toutes les attaques de ".teamname($teamatk, $col1)."."; break;
		
		//Commentaire d�fensif
		case 'K1' : return "Hors jeu de ".player($tm1play[0], $col1, $info)." apr�s un �ni�me appel."; break;
		case 'K2' : return "Hors-Jeu flagrant de la part de ".player($tm1play[0], $col1, $info)." qui est � plus d'un m�tre du dernier d�fenseur."; break;
		case 'K3' : return "Tr�s beau tacle de ".player($tm2play[1], $col2, $info).", quel classe !"; break;
		case 'K4' : return "C'est un hors-jeu ! La d�fense de ".teamname($teamdef, $col2)." � bien jou� le coup, et ".player($tm1play[0], $col1, $info)." c'est laisser prendre"; break;
		case 'K5' : return "Quel tacle de ".player($tm2play[1], $col2, $info)." dans la surface ! c'�tait os� et c'est r�ussi !"; break;
		case 'K6' : return "Tr�s beau tacle de ".player($tm2play[1], $col2, $info).", ".player($tm1play[0], $col1, $info)." essai de simuler une faute, mais l'arbitre ne c'est pas laisser prendre"; break;
		
		//Annonce de l'arbitre sur le temps additionnel

// Partie Fin de Match et Mi-Temps_______________________

		//Mi-temps = Si scores �gaux
		case 'N1' : return "C'est la mi-temps sur le score de ".$score.". Direction les vestiaires pour les joueurs."; break;
		case 'N2' : return "Mi-temps sur le score nul de ".$score.". Tout le stade esp�rent plus de spectacle pour la seconde mi-temps !"; break;
		case 'N3' : return "Mi-temps pour le match opposant ".teamname($teamatk, $col1)." et ".teamname($teamdef, $col2)." sur le score de ".$score; break;
		
		//Mi-temps = Si scores diff�rents
		case 'M1' : return "C'est la pause sur le score de ".$score.". ".teamname($teamatk, $col1)." a r�alis� 45 minutes de folie, avec un esprit offensif de tous les instants. ".teamname($teamdef, $col2)." va avoir �norm�ment de mal � revenir dans le match."; break;
		case 'M2' : return "L'arbitre renvoit tous le monde au vestiaire! C'�tait temps! depuis que ".teamname($teamdef, $col2)." s'est pris un but! Ils sont compl�tement perdu! Le coach va vite les recadr�!!"; break;
		case 'M3' : return "Mi-temps ! ".teamname($teamatk, $col1)." � dominer toute cette premi�re mi-temps, petite pause pour les joueurs avant la reprise du match"; break;
		
		//Fin de match = Si scores �gaux
		case 'G1' : return "Fin du match sur le score nul de ".$score.". Les supporters de ".teamname($teamatk, $col1)." sont tr�s d�cu que leur �quipe soit tenu en �chec � domicile !"; break;
		case 'G2' : return $score." et c'est la fin du match ! ".teamname($teamdef, $col2)." a rempli sa mission en tenant en �chec ".teamname($teamatk, $col1); break;
		case 'G3' : return "Enfin la fin du match, les 2 �quipes se quittent sur le score nul de ".$score; break;
		
		//Fin de match = Si scores diff�rents
		case 'F1' : return "Cette deuxi�me mi-temps �tait moins attractive que la premi�re mi-temps, ".teamname($teamatk, $col1)." qui avait le match en main, n'a pas forc� et attendu la fin du match mais c'est bien jou� tous de m�me!"; break;
		case 'F2' : return "Le match ce termine sur ce score de ".$score.". Une magnifique prestation de ".teamname($teamatk, $col1).", qui a facilement g�r� le match"; break;
		case 'F3' : return "Une d�faite qui risque de couter ch�re pour ".teamname($teamdef, $col2).", esperons qu'ils se reprennent en main pour le prochain rendez-vous"; break;
		
		default : return 'error'; break;
	}
}

?>