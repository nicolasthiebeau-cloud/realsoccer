<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
17/05/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }


define("SITE", "RealSoccer ");
define("TITLE", "RealSoccer ! D�couvrez le foot en ligne !");
define("TT_INDEX", "Administration");
define("LANGUE", "fr");  // On en profite pour d�finir une autre constante... la langue du site !

//index.php
define("TAB_1", "HOME");
define("TAB_2", "MANAGEMENT");
define("TAB_3", "BASE DE DONNEE");
define("TAB_4", "CONFIGURATION");
define("TAB_5", "AIDE ET SUPPORT");
define("BIENVENUE", "Bienvenue");
define("DECO", "D�connexion");
define("RETURNGAME", "Retour sur le jeu");
define("NEW_MEM", "Nouveau membre dans");
define("SANSCLUB", "Sans club");
define("LASTNEWS", "Derni�res news du serveur");
define("PLUS", "Plus...");
define("JOUEUR", "Joueur");
define("SERVEUR", "Serveur");
define("TACHESTAT", "Taches et Statistiques");
define("INFORMA", "Information");
define("SMOSVERS", "Version");
define("MEMBRE", "Membres");
define("VOIR", "Voir");
define("VOIRLST", "Voir liste");
define("ENLIGNE", "En ligne");
define("INACTIF", "Inactif");
define("BANNI", "Banni");
define("VALIDFANION", "Nombre de fanion/photo � valider");
define("ACTIONRAP", "Action Rapide");
define("SEARCHMEM", "Trouver/Editer un membre");
define("AJOUTPLY", "Ajouter un nouveau joueur");
define("EDITFORUM", "Editer un Forum");
define("GO", "Go...");
define("RECHIP", "Recherche d'adresse IP");
define("COMM", "Communication");
define("ADNOTES", "ADMIN Notes");
define("ADNOTES_INFO", "Vous pouvez laisser des messages dans le bloc notes pour les autres admin");
define("ADMNOTES_BUT", "Sauvegarder la note");
define("PURGEMINICHAT", "Purger le minichat");

//minichat.php 
define("MINICHATMESS", "Envoyer le message");
define("CANALADMIN", "Annonce Administrateur");

//Position
define("ATTAQUANT", "Attaquant");
define("MILIEU", "Milieu");
define("DEFENSEUR", "D�fenseur");
define("GARDIEN", "Gardien");

//Management
define("MENU1", "Membres et Groupes");
define("MENU2", "Rechercher un membre");
define("MENU3", "Tous les membres");
define("MENU4", "Membres en ligne");
define("MENU5", "Membre inactif");
define("MENU6", "Membre banni");
define("MENU7", "Joueurs et Clubs");
define("MENU8", "Nouveau joueur");
define("MENU9", "Suivi des joueurs");
define("MENU10", "Championnats et Coupes");
define("MENU11", "Nouveau championnat");
define("MENU12", "Suivi des championnats");
define("MENU13", "Nouvelle saison");
define("MENU14", "Forum");

define("SUIVICHAMP", "Suivi des championnats");
define("PAYS", "Pays");
define("COMPETNAME", "Nom de la Comp�tition");
define("DIVPOUL", "Division / Poule");
define("EQFICREE", "Nb. �quipes r�els / �quipes fictives");
define("SAISONENCOURS", "Saison en cours");
define("FINCOMPET", "Fin comp�tition");
define("MAJOUTOT", "Matchs jou�s / Total");
define("CHAMPEND", "championnat termin�");
define("PLAYMATCH", "Jouer les matchs");

define("CREANEWCHAMP", "Cr�ation d'un nouveau championnat");
define("CREZNEWCHAMP", "Cr�ez un nouveau championnat");
define("CHOICHAMP", "Choisir un championnat");
define("CRERNEWCHAMP", "Cr�er un nouveau championnat");

define("SUIVIPLAY", "Suivi des joueurs Sans Club");
define("IDENT", "Identit�");
define("AGE", "Age");
define("NATIO", "Nationalit�");
define("NOTG", "Note GAR");
define("NOTD", "Note DEF");
define("NOTM", "Note MIL");
define("NOTA", "Note ATK");
define("NBJDV", "NB jour de vente");
define("TRANS", "Transfert");

define("MODIFPLAY", "Modifier un joueur");
define("NOM", "Nom");
define("SURNOM", "Surnom");
define("PRENOM", "Pr�nom");
define("POSIT", "Position");
define("NOTEALL", "Vous devez allou� une note de 0 � 20 (sauf indication contraire).");
define("AGE_INF", "L'age du joueur, en ann�e");
define("TAILLE", "Taille");
define("TAILLE_INF", "La taille du joueur, en centim�tre");
define("FORME", "Forme");
define("FORME_INF", "La forme du joueur, de 0 � 100");
define("MORAL", "Moral");
define("MORA_INFO", "Le moral du joueur, de 0 � 100");
define("TALENT", "Talent");
define("TALENT_INFO", "Note entre 0 et 100, plus la note est �lev� plus le joueur aura du talent");
define("PRESSION", "Pression");
define("PRESSION_INFO", "Note entre 0 et 100, plus la note est basse, plus le joueur resitera � la pression");
define("EXPERIENCE", "Experience");
define("AGRESSIVITE", "Agressivit�");
define("INFLUENCE", "Influence");
define("REFLEXES", "Reflexes");
define("PDBALLE", "Prise de balle");
define("DEGAGEMENT", "D�gagement");
define("MARQUAGE", "Marquage");
define("TACLES", "Tacles");
define("TETE", "T�te");
define("CENTRES", "Centres");
define("PASSES", "Passes");
define("VITESSE", "Vitesse");
define("TIR", "Tir");
define("CREATIVITE", "Cr�ativit�");
define("DRIBBLE", "Dribble");
define("CDPARRETE", "Coup de pied arr�t�");
define("MODIFPLAYER", "Modifier le joueur");
define("ERROR_NOEDIT_PLAYER", "Vous ne pouvez pas modifier un joueur qui n'est pas Sans Club");
define("INFO_NIVEAU", "Le niveau vous donne une estimation du joueur pour chaque poste, selon ces notes.");

define("CREANEWPLAY", "Cr�ation de nouveau joueur");
define("NOLSTNAMEALE", "Laisser vide pour un nom al�atoire");
define("FACLT", "Facultatif");
define("NONAMEALE", "Laisser vide pour un pr�nom al�atoire");
define("POSTEDEP", "Poste de d�part, peut �tre modifier apr�s");
define("NOTEALL2", "Vous pouvez allou� une note de 0 � 20 (sauf indication contraire), ou laisser vide pour une note al�atoire.");
define("CREANEWPLAY2", "Cr�ation du nouveau joueur");
define("MARCHTRANS", "March� des transferts");
define("MARCHTRANS_INFO1", "Voulez-vous mettre le joueur directement ?");
define("MARCHTRANS_INFO2", "Si oui, nombre de jour de mise en vente");
define("YES", "Oui");
define("NO", "Non");

define("MEM_SEARCH", "Rechercher un Membre");
define("MEM_ONLINE", "Membre en Ligne");
define("MEM_BANNED", "Membre Banni");
define("BIENTOT", "Bient�t...");

define("MEM_INACTIF", "Membres inactifs");
define("COMPET", "Comp�tition");
define("PSEUDO", "Pseudo");
define("EQUIPE", "Equipes");
define("LANGU", "Langue");
define("DELETEMEM", "Effacer le membre");

define("EDITMEM", "Edition d'un membre");
define("EMAIL", "Email");
define("LANGUEPRIN", "Langue principale");
define("AUTRELANG", "Autres langues");
define("RANG", "Rang");
define("BANRAISON", "Raison du ban");
define("BANRAISON_INFO", "Si le membre est banni, vous pouvez donner une raison");
define("COACHNAME", "Nom de l'entraineur");
define("INSCRIPDATE", "Inscription le ...");
define("INSCRIPIP", "IP d'inscription");
define("LASTCODATE", "Derni�re connection le ...");
define("LASTCOIP", "IP de la derni�re connexion");
define("MODIFMEM", "Modifier le membre");

define("ALLMEM", "Tous les membres");
define("MANAG", "Manager");
define("INSCRIP", "Inscription");
define("LASTCONNEC", "Dern. Connection");
define("IP", "IP");

define("CREANS", "Cr�ation d'une nouvelle saison");
define("CREANS_INFO", "ATTENTION<br />Avant de lancer le script de nouvelle saison, assurez-vous que les championnats du pays soit bien termin�s dans la page suivi des championnats (matchs jou�s �gal � matchs totals pour toutes les divisions), ensuite lancez le script en commencant par la partie 1 puis la partie 2 en respectant bien les chargements entre les deux.");
define("PART1", "Partie 1 : Promotion / Relegation");
define("PART2", "Partie 2 : Rencontre - Joueur");

//Base de donn�e
define("EDITCO", "Edition d'un pays");
define("CO_NAME", "Nom du pays");
define("CO_CHAMP", "Nom du championnat");
define("CO_ZONE", "Zone du pays");
define("CO_LST_NOM", "Liste de Nom");
define("CO_LST_PRENOM", "Liste de Pr�nom");
define("CO_DRAP", "Drapeau du pays");
define("CO_MONN", "Monnaie du pays");
define("CO_SELECT", "Pays s�lectionnable");
define("CO_SELECT_INFO", "1 : Les managers peuvent cr�er des joueurs de cette nation (centre formation).<br />0 : Les managers ne peuvent pas cr�er des joueurs de cette nation.");
define("CO_ACTIF", "Pays actif");
define("CO_ACTIF_INFO", "1 : Le championnat est actif, l'inscription sur ce championnat est possible.<br />0 : Le championnat est inactif, personne ne peut s'y inscrire.");
define("CO_NBTEAM", "Nombre d'�quipe par division / poule");
define("CO_NBTEAM_INFO", "ATTENTION, ne pas modifier pour l'instant");
define("CO_HMATCH", "Heure des matchs");
define("CO_TPS2M", "Temps entre 2 matchs");
define("CO_CLASS", "Classement du pays");
define("CO_SELACT", "Select/Actif");
define("ZONE1", "Europe - Zone 1");
define("ZONE2", "Europe - Zone 2");
define("ZONE3", "Europe - Zone 3");
define("ZONE4", "Europe - Zone 4");
define("ZONE5", "Europe - Zone 5");
define("ZONE6", "Am�rique du nord");
define("ZONE7", "Am�rique centrale");
define("ZONE8", "Am�rique du sud");
define("ZONE9", "Afrique");
define("ZONE10", "Asie");
define("ZONE11", "Oc�anie");
define("MODIFCO", "Modifier le pays");
define("CREATECO", "Cr�er le pays");

//Configuration
define("GLO_TIT", "Global");
define("GLO_1", "Modification du rang");
define("GLO_2", "(membre de base)");
define("GLO_3", "(membre banni)");
define("GLO_4", "decalage de l'heure (si les match ne commence pas � la bonne heure), heure actuelle du serveur : ");
define("INS_TIT", "Inscription");
define("INS_1", "1 = Inscription ouverte, 0 = Inscription ferm�");
define("INS_2", "C'est le maillot de base pour tous les nouveaux inscrits (match � domicile)");
define("INS_3", "C'est le maillot de base pour tous les nouveaux inscrits (match � l'ext�rieur)");
define("INS_4", "L'argent de d�part pour tous les nouveaux joueurs");
define("INS_5", "Les infrastructures de d�part du joueur");
define("INS_6", "Il y a 8 parties qui correspondent aux id de la tribune, s�par�es par des ; : nord-ouest, nord, nord_est, ouest, est, sud-ouest, sud, sud_est");
define("INS_7", "Le niveau de d�part du centre de formation (0 pour un centre non construit, et jusqu'� 10)");
define("INS_8", "Le niveau de d�part du centre d'entrainement (0 pour un centre non construit, et jusqu'� 10)");
define("INS_9", "Note al�atoire principale (4 note de la position + influence et coup de pied arret�) des joueurs � la cr�ation des championnats, minimum et maximum");
define("INS_10", "Note al�atoire secondaire des joueurs � la cr�ation des championnats, minimum et maximum");
define("INS_11", "Age al�atoire des joueurs � la cr�ation des championnats, minimum et maximum");
define("INS_12", "Taille al�atoire des joueurs � la cr�ation des championnats, minimum et maximum");
define("INS_13", "Multiple des salaires des joueurs, multiplier ce nombre � la somme des 4 notes principales du joueur selon sa position");
define("STA_TIT", "Stade");
define("STA_1", "Le prix du billet pour les places non assises");
define("STA_2", "Le prix du billet pour les places assises");
define("STA_3", "Le prix du billet pour les places non assises couvertes");
define("STA_4", "Le prix du billet pour les places assises couvertes");
define("STA_5", "Le prix du billet pour les places de la tribune pr�sidentielle");
define("STA_6", "La recette d'une buvette (Addition des 4 prix du billet de dessus et multiplier par la valeur du champ � droite)");
define("STA_7", "Le prix que coute le changement du nom du stade");
define("STA_8", "Le prix que coute le changement du nom d'une tribune");
define("MDT_TIT", "March� des transferts");
define("MDT_1", "Nombre de jour de vente par d�faut");
define("MAT_TIT", "Match");
define("MAT_1", "Nombre d'action par x secondes, par d�faut 60 secondes (1 minute)");
define("MAT_2", "Penalit� sur la note de l'�quipe du joueur expuls�");
define("MAT_3", "Jour d'expulsion suite � un carton rouge");
define("FON_TIT", "Fonction Automatique");
define("FON_1", "0 = dimanche, 1 = Lundi, 2 = Mardi, 3 = Mercredi, 4 = Jeudi, 5 = Vendredi, 6 = Samedi");
define("FON_2", "Le jour du pr�l�vement des salaires");
define("FON_3", "Le jour de la reception des recettes");
define("FON_4", "Le jour de l'entrainement");
define("CONF_BUTTON", "Modification des options");
define("ACC_RAP", "Acc�s rapide");

?>