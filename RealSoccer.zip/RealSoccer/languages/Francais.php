<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
17/05/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }


define("SITE", "RealSoccer ");
define("TITLE", "RealSoccer ! D�couvrez le foot en ligne !");
define("TT_CONNEC", "Connectez-vous !");
define("TT_INSCRIP", "Inscription");
define("TT_INDEX", "");
define("LANGUE", "fr");  // On en profite pour d�finir une autre constante... la langue du site !

//index.php
define("GAME_INFO", "RealSoccer est un jeu de management d'�quipe de football qui est enti�rement gratuit.
	  Pour jouer, il suffit d'avoir un navigateur internet, inscrivez-vous est devenez le meilleur manager !");
define("MEM_ONLINE", "Joueurs en ligne");
define("LAST_MEM", "Dernier inscrit");
define("MEM_TOT", "Joueurs inscrits");

//login.php
define("TT_LOGIN", "Connectez-vous !");
define("BANNED_ACCOUNT", "Votre comptes � �t� banni");
define("ERROR_ACCOUNT", "Mauvais mot de passe ou compte inexistant");
define("LOST_ACCOUNT", "Inscrivez votre login et mot de passe");
define("INFOLARGE", "Si vous �tes inscrit, veuillez inscrire votre login et votre mot de passe.<br />Sinon inscrivez-vous.");
define("CONNEX", "Connexion");
define("PSEUDO", "Nom");
define("MDP", "Mot de passe");
define("SOUVENIR", " Se souvenir de moi");
define("INSCRIPT", "Inscrivez-vous maintenant !");
define("BUTTON_CONNEX", "Connexion");

//newaccount.php
define("STOP_INSCRIPT", "Les inscriptions sont momentanement interompu");
define("ERROR_PSEUDO_NCONF", "Votre nom d'utilisateur n'est pas conforme");
define("ERROR_PSEUDO_EXIST", "Ce pseudo existe d�j�");
define("ERROR_MDP_NCONF", "Votre mot de passe n'est pas conforme");
define("ERROR_MDP_NIDENT", "Les 2 mots de passes ne sont pas identiques");
define("ERROR_MAIL_NCONF", "Votre e-mail n'est pas conforme");
define("ERROR_MAIL_EXIST", "Votre e-mail existe d�j�");
define("ERROR_MANAG_NCONF", "Votre nom d'entraineur n'est pas conforme");
define("ERROR_TEAM_NCONF", "Votre nom d'�quipe n'est pas conforme");
define("ERROR_TEAM_EXIST", "Votre nom d'�quipe est d�j� pris");
define("ERROR_NO_COUNTRY", "Vous devez choisir un pays et une r�gion pour votre �quipe");
define("ERROR_REGLEM", "Vous n'avez pas valider le r�glement");
define("INFO_CONNEX", "Info connexion");
define("PSEUDO2", "Nom d'utilisateur");
define("MDP2", "Mot de passe");
define("MDP2BIS", "Retaper votre mot de passe");
define("EMAIL2", "E-mail");
define("INFOMANAGTEAM", "Info manager et �quipe");
define("MANAGERNAME", "Nom de l'entraineur");
define("LANG2", "Langue Principal");
define("LANG2OTHER", "Autres langues parl�es (s�parer par un espace)");
define("TEAMNAME", "Nom de l'�quipe");
define("PLAY_COUNTRY", "Pays dans lequel vous voulez jouer");
define("SELECT_COUNTRY", "S�lection du pays");
define("REGION", "R�gion");
define("SELECT_REGION", "S�lection de la r�gion");
define("PERSO_PLAYER", "Personnalisation des noms de joueurs ?");
define("YES", "Oui");
define("NO", "Non");
define("INFO_REGLEMENT", "Pour validez votre inscription vous accepter <a href=\"\">ce r�glement (� faire)</a>");
define("REGLEMENT", " J'ai lu et j'accepte les conditions g�n�rales d'utilisation du site .");
define("INSCRIP", "inscription");
define("STADEDE", "Stade de ");

//menu.php
define("ADMIN", "Administration");
define("BURMANAG", "Bureau du manager");
define("ALLJOURN", "Tous les journaux");
define("EFFECTIF", "Joueurs");
define("TACTIQUE", "Tactique");
define("TRAINING", "Entrainement");
define("FORMACENTRE", "Centre de formation");
define("INFIRMERIE", "Infirmerie");
define("CHAMP", "Championnat");
define("CALEND", "Rencontres");
define("TRANSMARK", "March� des Transferts");
define("APROPOS", "A propos du jeu PHP");
define("AIDE", "Aide / Manuel");
define("LASTMAJ", "Derni�res mises � jour");
define("SITEOFF", "Site officiel");
define("DIVERS", "Divers");
define("PROFIL", "Votre profil");
define("DECO", "D�connexion");

//minichat.php 
define("MINICHAT", "Minichat");
define("MINICHATMESS", "Envoyer le message");

//main.php, bureaumanager.php
define("MANAGER", "Manager");
define("LOCALI", "Localisation");
define("DATEINSCRIP", "Depuis le");
define("LAST_CONNEC", "Derni�re connexion");
define("LANG", "Langue");
define("LANG_OTHER", "Autres langues");
define("CLASMENT", "Classement");
define("COMPTA", "Comptabilit�");
define("FINANCE", "Situation financiere");
define("SALAIRE1", "Montant des salaires hebdomadaires de vos ");
define("SALAIRE2", " joueurs");
define("EQUIPEM", "Equipement");
define("DOMI", "Domicile");
define("EXTE", "Ext�rieur");
define("FICTIEQ", "Equipe Fictive");
define("INFOGEN", "Infos g�n�rales");
define("MA_DMD", "Demande de match amical");
define("MA_ORG", "Organiser un match amical");
define("PLAYAT", "Vous voulez jouer � ...");
define("CHOOSEDATE", "Choisir une date");
define("FAIRE_DMD", "Faire votre demande");
define("BUDGET", "Budget");
define("EQUIPEMENT", "Equipement");
define("FANION", "Fanion");
define("MESSAGERIE", "Messagerie");
define("MESSAGERIECLUB", "Messagerie interne du Club");
define("PLUS", "Plus...");
define("POUR", "pour");
define("ACHAT_DMD", "Demande d'achat de joueur");
define("COMMAILLOTDOMOK", "La commande des nouveaux maillots pour les matchs � domicile, a �t� envoyer au fournisseur");
define("COMMAILLOTEXTOK", "La commande des nouveaux maillots pour les matchs � l'ext�rieur, a �t� envoyer au fournisseur");

//Budget
define("RECHEBDO", "Recettes Hebdomadaire");
define("SPONAFF", "Sponsor");
define("ESTIMSATADE", "Stade (estimation)");
define("TOTAL", "Total");
define("DEPHEBDO", "D�penses Hebdomadaire");
define("PLAYSALAIRE", "Salaire joueurs");
define("STAFFSALAIRE", "Salaire staff");
define("SPONCHOICE", "Choix du sponsor");
define("SPONINFO", "Pour augmenter vos recettes, vous pouvez choisir un sponsor qui s'affichera sur vos maillots. Le contrat dure une saison, donc chaque ann�e vous pourrez choisir un nouveau sponsor.");
define("SPONCHOICE2", "Choisir ce sponsor");
define("CONTRA1", "Votre contrat avec");
define("CONTRA2", "prendra fin � la fin de la saison, vous touchez actuellement");
define("CONTRA3", "euros pour ce contrat.");
define("NOSPONSORS", "Vous n'avez actuellement aucun sponsor");

//Historique
define("HISTOCLUB", "Historique du club");

//Equipement
define("PREMCOLOR", "Selection de la couleur principal");
define("SECCOLOR", "Selection de la couleur secondaire");
define("SHCHOICE", "Pour les matchs � ...");
define("SHDOM", "Domicile");
define("SHEXT", "L'ext�rieur");
define("VALIDCHOICE", "Valider votre choix");
define("CHOICECOLOR", "Couleur choisi");

//Teaminfo
define("TROPHY", "Galerie des troph�es");
define("INFOMANAG", "Info manager");
define("INFOSTAFF", "Info staff");
define("TRAINER", "Entraineur");
define("CONSTENCOURS", "Construction en cours");
define("CONSTRUCTRIB", "Tribune");
define("CONSTRUCCFORMA", "Centre de Formation");
define("NIV", "Niveau");
define("CONSTRUCCENTR", "Centre d'entrainement");
define("CONSTRUCNO", "Aucune construction");
define("ENDIN", "Termin� dans");
define("INFOEQUIP", "Info �quipe");
define("NAME", "Nom");
define("DIV", "Division");
define("POUL", "Poule");
define("STADE", "Stade");
define("CAPACITY", "Capacit�");
define("DEVISE", "Devise du club");

//Mainright
define("POINTFORT", "point(s) fort(s)");
define("CALENDRIER", "Calendrier");
define("EFFECT", "Effectif");
define("PALMA", "Palmar�s");
define("YEARS", "ans");
define("TAILLE", "Taille");
define("POIDS", "Poids");
define("POSTE_ACTU", "Poste actuel");
define("LE", "Le ");
define("A", " � ");

//Position
define("ATTAQUANT", "Attaquant");
define("MILIEU", "Milieu");
define("DEFENSEUR", "D�fenseur");
define("GARDIEN", "Gardien");

//Match
define("D", "D");
define("E", "E");
define("PROGRAMATCHLE", "Match programmer le");

//effectif.php
define("NATIO", "Nat.");
define("INFO", "Info.");
define("IDENTITE", "Identit�");
define("POSITION", "Position");
define("AGE", "Age");
define("FORME", "Forme");
define("MORAL", "Moral");
define("APPAR", "Apparition");
define("BUT", "But");
define("PASDEC", "Passe d�cisive");
define("COMPO", "Compo");

//championnat.php
define("CLASSEMENT", "Classement");
define("SAISON", "Saison");
define("DIVI", "Division");
define("TEAM", "Equipe");
define("MJ", "MJ");
define("V", "V");
define("N", "N");
define("BP", "BP");
define("BC", "BC");
define("DIFF", "DIFF");
define("POINT", "Point");
define("INFO_VIC", "(V)ictoire - 3 pts");
define("INFO_NUL", "(N)ul - 1 pt");
define("INFO_DEF", "(D)�faite - 0 pt");
define("CLASSPASSEUR", "Classement des Passeurs");
define("CLASSBUTEUR", "Classement des Buteurs");
define("NONPLAYER", "Nom du joueur");
define("NBBUT", "But");
define("NBPD", "P.Dec");
define("CALEN1", "CALENDRIER Partie 1");
define("CALEN2", "CALENDRIER Partie 2");
define("DAYMATCH", "Journ�e");

//Carac
define("AGRESSIVITE", "Agressivit�");
define("EXPERIENCE", "Exp�rience");
define("CENTRES", "Centres");
define("CDPARRETE", "Coup de pied arr�t�");
define("CREATIVITE", "Cr�ativit�");
define("DEGAGEMENT", "D�gagement");
define("DRIBBLE", "Dribble");
define("INFLUENCE", "Influence");
define("MARQUAGE", "Marquage");
define("PASSES", "Passes");
define("PDBALLE", "Prise de balle");
define("REFLEXES", "Reflexes");
define("TACLES", "Tacles");
define("TETE", "T�te");
define("TIR", "Tir");
define("VITESSE", "Vitesse");

//match.php
define("ARBITRE", "Arbitre");

//calendrier.php
define("AMICAL", "Match Amical");
define("CALENDMATCH", "Calendrier des matchs");

//entrainement.php
define("CONST_NO1", "Vous n'avez pas encore construit de centre d'entrainement<br />Pour commencer la construction vous devez payer");
define("CONST_NO2", "euros, et la construction durera 3 jours.");
define("CONST_SUBMIT", "Construire un centre d'entrainement.");
define("CONST_NOMONEY", "Pas assez d'argent pour construire le centre d'entrainement.");
define("TRCONSTRUCOK", "Votre centre d'entrainement est en cours de construction !");
define("TRUPGRAOK", "Votre centre d'entrainement est en cours d'agrandissement !");
define("TRNIVMAX", "Vous avez atteint le niveau maximum");
define("TRENTRAIRECRUT", "Entraineur recrut�");
define("TRHAVETRAININDIVI", "Un joueur ne peut avoir qu'un entrainement individuel");
define("TRTITLE", "Centre d'entrainement");
define("TRSTAFFINFRA", "Staff & Infrastructure");
define("TRENTRAICOLLEC", "Entrainement collectif");
define("TRENTRAIINDIVI", "Entrainement individuel");
define("TRENTRAIJEUN", "Entrainement des jeunes");
define("TRPROGRESS", "Progression");
define("TRAINACTU", "Entrainement Actuel");
define("TRAINSUBMIT", "Modifier l'entrainement");
define("INDIV_INFO", "L'entrainement individuel, dirig� par l'entraineur, permet d'augmenter 1 comp�tence pour 5 joueurs et cela toutes les semaines. Seulement les joueurs de plus de 16ans seront entrain�s ici.");
define("INDIV_INFO2", "Pour utiliser l'entrainement individuel, il faut d'abord construire un centre d'entrainement de niveau 2.");
define("COLLEC_INFO", "L'entrainement collectif, dirig� par l'entraineur, permet d'augmenter 1 comp�tence pour l'ensemble de l'�quipe et cela toutes les semaines. Seulement les joueurs de 17ans et plus seront entrain�s.");
define("COLLEC_INFO2", "Pour utiliser l'entrainement collectif, il faut d'abord construire un centre d'entrainement et recruter un entraineur.");
define("JEUNE_INFO", "Pour entrainer les jeunes joueurs, il faut d'abord construire un centre de formation.");

//centreformation.php
define("NATIONALITY", "Nationalit�");
define("FCMAXJEUNE1", "Vous ne pouvez pas avoir plus de");
define("FCMAXJEUNE2", "jeunes dans votre effectif au niveau");
define("FCNOMONEY", "Vous n'avez pas assez d'argent pour former un joueur");
define("FCJEUNERECRUT", "Joueur form�");
define("FCCONSTRUCOK", "Votre centre de formation est en cours de construction !");
define("FCUPGRAOK", "Votre centre de formation est en cours d'agrandissement !");
define("FCNIVMAX", "Vous avez atteint le niveau maximum");
define("FCTITLE", "Centre de Formation");
define("FCFORMERJEUNE", "Former un jeune");
define("FCFORMERJOUEUR", "Former un joueur");
define("FCINFORECRUT", "Pour recruter un jeune, vous devez payer une certaine somme indiqu�e � cot� du pays.<br />Plus vous recruter loin, plus la somme sera �lev�e.<br />Les jeunes ont entre 14 et 16 ans, <br />vous ne pouvez choisir leur age.");
define("FCNOCENTRE", "Pas de centre de formation");
define("FCINFORMA", "Information");
define("FCTRAVTIME", "Les travaux se termine dans");
define("FCNOMONEYCENT", "Pas assez d'argent pour agrandir le centre de formation");
define("FCNOMONEYCONSTR", "Pas assez d'argent pour construire le centre de formation");
define("FCHOWMUCHCNTR1", "Votre centre de formation est actuellement au niveau");
define("FCHOWMUCHCNTR2", "Pour l'am�liorer vous devez payer");
define("FCHOWMUCHCNTR3", "euros, et la construction durera 3 jours");
define("FCAGRANDCENTR", "Agrandir le centre de formation");
define("FCCONSTRUCCENTR", "Construire le centre de formation");
define("FCHOWMUCHCONSTRUC1", "Vous n'avez pas encore construit de centre de formation <br />Pour commencer la construction vous devez payer");
define("FCHOWMUCHCONSTRUC2", "euros, et la construction durera 3 jours");

//stade.php, stade_infra.php
define("NOMONEY", "Vous n'avez pas assez d'argent pour construire");
define("NOMONEY2", "Vous n'avez pas assez d'argent pour renommer votre tribune");
define("COUT", "Cout");
define("NONDEFINI", "Non d�fini");
define("JOURCONST", "jours de construction");
define("PL_DEBOUT", "Place debout");
define("PL_ASSIS", "Plase assise");
define("PL_DEBOUTC", "Place debout couverte");
define("PL_ASSISC", "Place assise couverte");
define("TRI_PRESI", "Tribune pr�sidentielle");
define("BUVET", "Buvette");
define("CONST_TRIB", "Construction de la tribune");
define("CHX_TRIB", "Choix de la tribune");
define("CONST_END", "Construction termin�e dans");
define("TRIB_ACTU", "Info tribune actuelle");
define("TRIB_NAME", "Nom de la tribune");
define("TRIB_MODIF", "Modifier le nom de la tribune");
define("TRIB_MODIFINFO", "Vous avez la possibilit� de changer le nom de la tribune, cela vous coutera");
define("TRIB_MODIFRETURN", "Etes vous sur de vouloir changer le nom de la tribune ?");
define("LEGEND", "L�gende");
define("LEG_CONST", "Construction en cours");
define("STADE_MODIF", "Modifier le nom du stade");
define("STADE_MODIFINFO", "Vous avez la possibilit� de changer le nom de votre stade, cela vous coutera");
define("STADE_MODIFRETURN", "Etes vous sur de vouloir changer le nom de votre stade ?");

//marchetransfert.php
define("ZONE1", "Europe - Zone 1");
define("ZONE2", "Europe - Zone 2");
define("ZONE3", "Europe - Zone 3");
define("ZONE4", "Europe - Zone 4");
define("ZONE5", "Europe - Zone 5");
define("ZONE6", "Am�rique du nord");
define("ZONE7", "Am�rique centrale");
define("ZONE8", "Am�rique du sud");
define("ZONE9", "Afrique");
define("ZONE10", "Asie");
define("ZONE11", "Oc�anie");

//forums
define("INDEX", "Index du forum");
define("MODIFPROFIL", "Modifier mon profil");
define("COMESS", "Consulter mes messages priv�s");
define("TITLEFOFO", "Forum");
define("NOFORUM", "Il n'existe actuellement aucun forum.");
define("COENTANTQUE", "Vous �tes connect� en tant que");
define("SUJET", "Sujets");
define("MESS", "Messages");
define("LASTMESS", "Dernier message");
define("NOMESS", "Pas de message");
define("WHOONLINE", "Qui est en ligne:");
define("TOTALMESS", "Le total des messages du forum est");
define("MBCOUNT", "Le site et le forum comptent");
define("MEMBER", "membres");
define("LASTMB", "Le dernier membre est");
define("ILYA", "Il y a");
define("CONNECTED", "connect�s");
define("MBET", "membres et");
define("INVIT", "invit�s");
define("LSTONLINE", "Liste des personnes en ligne");
define("PAGE", "Page");
define("SURR", "sur");
define("TOPICS", "topics");
define("ALLERPAGE", "Aller � la Page");
define("TITRE", "Titre");
define("AUTEUR", "Auteur");
define("REPONSE", "R�ponses");
define("VU", "Vus");
define("ANNONCE", "Annonce : ");
define("TOPICSTART", "Topic commenc� �");
define("BY", "Par");
define("POSTLE", "Post� le");
define("TOP", "Top");
define("SUPP", "supprimer");
define("EDIT", "editer");
define("SUPPINF", "Supprimer ce message");
define("EDITINF", "Editer ce message");
define("DEVEROUIL", "D�verrouiller ce sujet");
define("VEROUIL", "Verrouiller ce sujet");
define("DEPLAVERS", "D�placer vers");
define("ENVOI", "Envoyer");
define("ERRORPOST", "Il n'y a aucun post sur ce topic, v�rifiez l'url et reessayez");
?>