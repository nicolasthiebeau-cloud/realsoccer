<?php
$titre = 'Index du forum';
include('includes/debut.php');
?>


<?php
//----------------------------------------------------------------------
//										
// SMOP Sport Manager Open Source					
// Le projet est open source - sous license GPL			
// Vous �tes libre de l'utiliser mais pas � des fins commercial	
//										
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@emu-fr.com	
//										
//----------------------------------------------------------------------
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo SITE . ' - ' . TT_INDEX;  ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Pragma" content="no-cache" />
<meta name="description" content="Projet open source de cr�ation d'un script php de management d��quipe qui peut �tre adapt� � n�importe quel sport (d��quipe).">
<meta name="keywords" content="jeu, jeux, php, sql, foot, rugby, hockey, sport, �quipe, team, management, manager, script, open, source, free, gratuit, libre">
<meta name="author" content="Yannick San Nicolas">
<meta name=identifier-url content="http://snyzone.fr/smop">
<meta name="reply-to" content="ysn38@emu-fr.com">
<meta name="revisit-after" content="7 days">
<meta name="category" content="Jeux PHP">
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="blokprincipal">
	<div id="page_haut">
	<br /><h1>&nbsp;&nbsp;&nbsp;Sport Manager Open Source</h1>
	</div>
	<div id="menu">
	<table>
	  <tr>
		<td><a href="index.php">Connexion</a></td>
	  </tr>
	  <tr>
		<td><a href="index.php?page=newaccount">Inscription</a></td>
	  </tr>
	  <tr>
		<td><a href="http://emu-fr.com/index.php?showforum=156" target="new">Forum</a></td>
	  </tr>
	</table>
	</div>
	<div id="corps">
	
<?
include("includes/config.php");
mysql_connect($host, $user, $mdp);
mysql_select_db($db);

$i = 0;

//V�rification du pseudo
$nombrepseudo = mysql_result(mysql_query("SELECT COUNT(*) FROM comptes WHERE pseudo = '".$_POST['pseudo']."'"), 0);
if($nombrepseudo != 0)
{
        $pseudo_erreur1 = "Votre pseudo est d�j� utilis� par un membre";
        $i++;
}
if (strlen($_POST['pseudo']) < 3 || strlen($_POST['pseudo']) > 15)
{
        $pseudo_erreur2 = "Votre pseudo est soit trop grand, soit trop petit";
        $i++;
}
//V�rification du mdp
if ($_POST['mdp'] != $_POST['confirm'] || empty($_POST['confirm']) || empty($_POST['mdp']))
{
        $mdp_erreur = "Votre mot de passe et votre confirmation diff�rent, ou sont vides";
        $i++;
}

//V�rification de l'adresse email

//Il faut que l'adresse email n'ait jamais �t� utilis�e

$nombremail = mysql_result(mysql_query("SELECT COUNT(*) FROM comptes WHERE email = '".$_POST['email']."'"), 0);

if ($nombremail!= 0)
{
        $email_erreur1 = "Votre adresse email est d�j� utilis�e par un membre";
        $i++;
}
//On v�rifie la forme maintenant
if (!preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#", $_POST['email']) || empty($_POST['email']))
{
        $email_erreur2 = "Votre adresse E-Mail n'a pas un format valide";
        $i++;
}
//V�rification de l'adresse MSN
if (!preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#", $_POST['msn']) && !empty($_POST['msn']))
{
        $msn_erreur = "Votre adresse MSN n'a pas un format valide";
        $i++;
}
//V�rification de la signature
if (strlen($_POST['signature']) > 200)
{
        $signature_erreur = "Votre signature est trop longue";
        $i++;
}

// Verification du captcha !
   $girilen = $_REQUEST["captcha"];
   if($_SESSION['captcha'] == $girilen){
   echo "";
   }else{
   $captcha_erreur = "Le Code De S�curit� Est Invalide";
   $i++;   
   } 
   

//V�rification de l'avatar :
if (!empty($_FILES['avatar']['size']))
{
        //On d�finit les variables :
        $maxsize = 10024; //Poid de l'image
        $maxwidth = 100; //Largeur de l'image
        $maxheight = 100; //Longueur de l'image
        $extensions_valides = array( 'jpg' , 'jpeg' , 'gif' , 'png', 'bmp' ); //Liste des extensions valides
        
        if ($_FILES['avatar']['error'] > 0)
        {
                $avatar_erreur = "Erreur lors du tranfsert de l'avatar : ";
        }
        if ($_FILES['avatar']['size'] > $maxsize)
        {
                $i++;
                $avatar_erreur1 = "Le fichier est trop gros : (<strong>".$_FILES['avatar']['size']." Octets</strong>    contre <strong>".$maxsize." Octets</strong>)";
        }

        $image_sizes = getimagesize($_FILES['avatar']['tmp_name']);
        if ($image_sizes[0] > $maxwidth OR $image_sizes[1] > $maxheight)
        {
                $i++;
                $avatar_erreur2 = "Image trop large ou trop longue : (<strong>".$image_sizes[0]."x".$image_sizes[1]."</strong> contre <strong>".$maxwidth."x".$maxheight."</strong>)";
        }
        
        $extension_upload = strtolower(substr(  strrchr($_FILES['avatar']['name'], '.')  ,1));
        if (!in_array($extension_upload,$extensions_valides) )
        {
                $i++;
                $avatar_erreur3 = "Extension de l'avatar incorrecte";
        }
}

if ($i == 0) // Si i est vide, il n'y a pas d'erreur
{

        echo'<h1>Inscription termin�e</h1>';
        echo'<p>Bienvenue '.$_POST['pseudo'].' vous �tes maintenant inscrit sur le forum</p>';
        echo'<p>Cliquez <a href="./index.php">ici</a> pour revenir � la page d accueil</p>';

        if (isset($_FILES['avatar']['size']))
        {
                //On d�place l'avatar
                $avatar = time();
                $nomavatar = str_replace(' ','',$avatar).".".$extension_upload;
                $avatar = "./images/avatars/".str_replace(' ','',$avatar).".".$extension_upload;
                move_uploaded_file($_FILES['avatar']['tmp_name'],$avatar);
        }
       
        //On v�rifie que les champs ne continennent pas de html
        //Puis on crypte le mot de passe
        $temps = time();
        $signature = htmlspecialchars($_POST['signature'], ENT_QUOTES);
        $signature = nl2br($signature);
        $pseudo = htmlspecialchars($_POST['pseudo'], ENT_QUOTES);
        $email = htmlspecialchars($_POST['email'], ENT_QUOTES);
        $msn = htmlspecialchars($_POST['msn'], ENT_QUOTES);
        $website = htmlspecialchars($_POST['website'], ENT_QUOTES);
        $localisation = htmlspecialchars($_POST['localisation'], ENT_QUOTES);
        $pass = $_POST['mdp'];
       
        //On balance le tout dans notre table
        mysql_query("
        INSERT INTO comptes (pseudo, mdp, email,             
        membre_msn, membre_siteweb, membre_avatar,
        membre_signature, membre_localisation, joindate,   
        membre_derniere_visite)
        VALUES ('".$pseudo."' , '".$pass."' , '".$email."' ,
        '".$msn."' , '".$website."' , '".$nomavatar."' ,
        '".$signature."' , '".$localisation."' ,  '".$temps."' ,
        '".$temps."' ) ");
       
       
        //Et on d�finit les variables de sessions
        $_SESSION['pseudo'] = $pseudo;
        $_SESSION['id'] = mysql_insert_id();
        $_SESSION['level'] = 1;

}
else
{
        echo'<h1>Inscription interrompue</h1>';
        echo'<p>Une ou plusieurs erreurs se sont produites pendant l incription</p>';
        echo'<p>'.$i.' erreur(s)</p>';
        echo'<p>'.$pseudo_erreur1.'</p>';
        echo'<p>'.$pseudo_erreur2.'</p>';
        echo'<p>'.$mdp_erreur.'</p>';
        echo'<p>'.$email_erreur1.'</p>';
        echo'<p>'.$email_erreur2.'</p>';
        echo'<p>'.$msn_erreur.'</p>';
        echo'<p>'.$signature_erreur.'</p>';
		echo'<p>'.$captcha_erreur.'</p>';
        echo'<p>'.$avatar_erreur.'</p>';
        echo'<p>'.$avatar_erreur1.'</p>';
        echo'<p>'.$avatar_erreur2.'</p>';
        echo'<p>'.$avatar_erreur3.'</p>';

       
        echo'<p>Cliquez <a href="./register.php">ici</a> pour recommencer</p>';
}
mysql_close();
?>
		
		</p>
		
	</div>
	<div id="page_bas">
	<?php include('includes/pages/bas.php'); ?>
	</div>
</div>
</body>
</html>

	