<?php
//-------------------------------------------------------------------------------------//
//											//
// SMOP Sport Manager Open Source					//
// Le projet est open source - sous license GPL				//
// Vous �tes libre de l'utiliser mais pas � des fins commercial		//
//											//
// 											//
//											//
//-------------------------------------------------------------------------------------//

include('forums/includes/config.php');
include('forums/includes/debut.php');
include('forums/protection/auth.php');
mysql_connect($host,$user,$mdp);
mysql_select_db($db);

//On r�cup�re la valeur de f
$forum = $_GET['f'];

//A partir d'ici, on va compter le nombre de messages
//pour n'afficher que les 25 premiers
$requete1 = mysql_query("SELECT forum_name, forum_topic, auth_view, auth_topic FROM forum_forum WHERE forum_id = '".$forum."'") or die (mysql_error());
$data1 = mysql_fetch_assoc($requete1);

if (!verif_auth($data1['auth_view']))
{
exit("Vous n avez pas le droit de vous trouver ici ! (sale gosse :p )");
}

$totalDesMessages = $data1['forum_topic'];
$nombreDeMessagesParPage = $config['topic_par_page'];
$nombreDePages = ceil($totalDesMessages / $nombreDeMessagesParPage);
?>
<table class="tablebg" width="99%" cellspacing="1" cellpadding="0">
 <tr>
  <td class="row1">
  <p class="breadcrumbs"><a href ="./club.php?zone=forums"><?php echo INDEX; ?></a> &#187; <a href="./club.php?zone=forums&amp;page=viewforum&amp;f=<?php echo $forum.'">'.$data1['forum_name'].'</a>'; ?></p>
  <p class="datetime">
<?php
if (isset($_SESSION['pseudo'])) // Si le membre est connect�
{
	echo'<p>' . COENTANTQUE . ' <a href="./club.php?zone=forums&amp;page=profil&amp;m='.intval($_SESSION['id']).'&action=consulter">'.stripslashes(htmlspecialchars($_SESSION['pseudo'])).'</a>';
?>
  &nbsp;&nbsp;<a href="./club.php?zone=forums&amp;page=profil&amp;action=modifier"><?php echo MODIFPROFIL; ?></a>
  &nbsp;&nbsp;<a href="./club.php?zone=bureaumanager&amp;page=mp"><?php echo COMESS; ?></a>
  &nbsp;&nbsp;<a href ="./club.php?zone=deconnexion"><?php echo DECO; ?></a></p>
<?php
}
?>
  </p></td>
 </tr>
</table>
<br />
<div id="pageheader"><h1><?php  echo $data1['forum_name'];//Le titre du forum ?></h1></div>
<table width="99%" cellspacing="1">
 <tr>
  <td align="left" valign="middle">
<?php
if (verif_auth($data1['auth_topic']))
{
//Et le bouton pour poster
echo'<a href="./club.php?zone=forums&amp;page=poster&amp;action=nouveautopic&amp;f='.$forum.'">
<img src="./images/forums/nouveau.gif" alt="Nouveau topic" title="Poster un nouveau topic" border="0"></a>';
}

//Nombre de pages
if (isset($_GET['p'])) $page = intval($_GET['p']);
else $page = 1;
?>
  </td>
  <td class="nav" valign="middle" nowrap="nowrap">&nbsp;<?php echo PAGE; ?> <strong><?php echo $page; ?></strong> <?php echo SUR; ?> <strong><?php echo $nombreDePages; ?></strong><br /></td>
  <td class="gensmall" nowrap="nowrap">&nbsp;[ <?php echo $totalDesMessages . ' ' . TOPICS; ?>  ]&nbsp;</td>
  <td class="gensmall" width="99%" align="right" nowrap="nowrap"><b><?php echo ALLERPAGE; ?> : 
<?php
//On affiche les pages 1-2-3, etc.


//Comptage des message sur SMOP 0.5
function get_list_page($page, $nb_page, $link, $nb = 2){
$list_page = array();
for ($i=1; $i <= $nb_page; $i++){
if (($i < $nb) OR ($i > $nb_page - $nb) OR (($i < $page + $nb) AND ($i > $page -$nb)))
$list_page[] = ($i==$page)?'<strong>'.$i.'</strong>':'<a href="'.$link.'&amp;p='.$i.'">'.$i.'</a>'; 
else{
if ($i >= $nb AND $i <= $page - $nb)
$i = $page - $nb;
elseif ($i >= $page + $nb AND $i <= $nb_page - $nb)
$i = $nb_page - $nb;
$list_page[] = '...';
}
}
$print= implode('-', $list_page);
return $print;
}

echo '<p>Page : ';
echo get_list_page($page, $nombreDePages, './club.php?zone=forums&amp;page=viewforum&f='.$forum.'&p=');
echo'</p>';


?>
  </b></td>
 </tr>
</table>
<?php
$premierMessageAafficher = ($page - 1) * $nombreDeMessagesParPage;

$requete3 = mysql_query('SELECT forum_topic.topic_id, topic_titre, topic_createur, topic_vu, topic_post, topic_time, topic_last_post,
Mb.pseudo AS pseudo_createur, post_createur, post_time, Ma.pseudo AS pseudo_last_posteur FROM forum_topic 
LEFT JOIN comptes Mb ON Mb.account_id = forum_topic.topic_createur
LEFT JOIN forum_post ON forum_topic.topic_last_post = forum_post.post_id
LEFT JOIN comptes Ma ON Ma.account_id = forum_post.post_createur    
WHERE topic_genre = "Annonce" AND forum_topic.forum_id = "'.$forum.'" 
ORDER BY topic_last_post DESC');

//On lance notre tableau seulement s'il y a des requ�tes !
if (mysql_num_rows($requete3) > 0)
{
?>
<table class="tablebg" width="99%" cellspacing="1">
 <tr>
  <td class="cat" colspan="7">
  </td>
 </tr>
 <tr>
  <td colspan="3" class="fotitre" align="center">&nbsp;<?php echo TITRE; ?>&nbsp;</td>
  <td class="fotitre" align="center">&nbsp;<?php echo AUTEUR; ?>&nbsp;</td>
  <td class="fotitre" align="center">&nbsp;<?php echo REPONSE; ?>&nbsp;</td>
  <td class="fotitre" align="center">&nbsp;<?php echo VU; ?>&nbsp;</td>
  <td class="fotitre" align="center">&nbsp;<?php echo LASTMESS; ?>&nbsp;</td>
 </tr>
<?php
	//On commence la boucle
	while ($data3 = mysql_fetch_assoc($requete3))
	{
		//Pour chaque topic :
		//Si le topic est une annonce on l'affiche en haut
		//mega echo de bourrain pour tout remplir
?>
 <tr>
  <td class="row1" width="25" align="center"><img src="./images/forums/annonce.gif" alt="Annonce" /></td>
  <td class="row1" width="25" align="center"></td>
  <td class="row1"><strong><?php echo ANNONCE; ?><a href="./club.php?zone=forums&amp;page=viewtopic&amp;t=<?php echo $data3['topic_id']; ?>" title=" <?php echo TOPICSTART . ' ' . date('H\hi \l\e d M,y',$data3['topic_time']) . '">'.$data3['topic_titre']; ?></a></strong></td>
  <td class="row2" width="130" align="center"><a href="./club.php?zone=forums&amp;page=profil&amp;m=<?php echo $data3['topic_createur']; ?>&amp;action=consulter"><?php echo $data3['pseudo_createur']; ?></a></td>
  <td class="row1" width="50" align="center"><?php echo $data3['topic_post']; ?></td>
  <td class="row2" width="50" align="center"><?php echo $data3['topic_vu']; ?></td>
  <td class="row1" width="140" align="center"><?php echo BY; ?> <a href="./club.php?zone=forums&amp;page=profil&amp;m=<?php echo $data3['post_createur'].'&amp;action=consulter">'.$data3['pseudo_last_posteur'].'</a><br />'.date('H\hi \l\e d M y',$data3['post_time']); ?></td>
 </tr>
<?php
	}
 echo'
 <tr align="center">
  <td class="cat" colspan="7"></td>
 </tr>
</table><br />';
}

$requete3 = mysql_query("SELECT forum_topic.topic_id, topic_titre, topic_createur, topic_vu, topic_post, topic_time, topic_last_post,
Mb.pseudo AS pseudo_createur, post_createur, post_time, Ma.pseudo AS pseudo_last_posteur FROM forum_topic
LEFT JOIN comptes Mb ON Mb.account_id = forum_topic.topic_createur
LEFT JOIN forum_post ON forum_topic.topic_last_post = forum_post.post_id
LEFT JOIN comptes Ma ON Ma.account_id = forum_post.post_createur   
WHERE topic_genre <> 'Annonce' AND forum_topic.forum_id = '".$forum."'
ORDER BY topic_last_post DESC LIMIT $premierMessageAafficher, $nombreDeMessagesParPage") 
or die (mysql_error());

if (mysql_num_rows($requete3) > 0)
{
?>
<table class="tablebg" width="99%" cellspacing="1">
 <tr>
  <td class="cat" colspan="7">
  </td>
 </tr>
 <tr>
  <td colspan="3" class="fotitre" align="center">&nbsp;<?php echo TITRE; ?>&nbsp;</td>
  <td class="fotitre" align="center">&nbsp;<?php echo AUTEUR; ?>&nbsp;</td>
  <td class="fotitre" align="center">&nbsp;<?php echo REPONSE; ?>&nbsp;</td>
  <td class="fotitre" align="center">&nbsp;<?php echo VU; ?>&nbsp;</td>
  <td class="fotitre" align="center">&nbsp;<?php echo LASTMESS; ?>&nbsp;</td>
 </tr>
<?php
	//On lance la boucle
	while ($data3 = mysql_fetch_assoc($requete3))
	{
?>
 <tr>
  <td class="row1" width="25" align="center"><img src="./images/forums/message.gif" alt="Message" /></td>
  <td class="row1" width="25" align="center"></td>
  <td class="row1"><strong><a href="./club.php?zone=forums&amp;page=viewtopic&amp;t=<?php echo $data3['topic_id']; ?>" title="<?php echo TOPICSTART . ' ' . date('H\hi \l\e d M,y',$data3['topic_time']) . '">'.$data3['topic_titre']; ?></a></strong></td>
  <td class="row2" width="130" align="center"><a href="./club.php?zone=forums&amp;page=profil&amp;m=<?php echo $data3['topic_createur']; ?>&amp;action=consulter"><?php echo $data3['pseudo_createur']; ?></a></td>
  <td class="row1" width="50" align="center"><?php echo $data3['topic_post']; ?></td>
  <td class="row2" width="50" align="center"><?php echo $data3['topic_vu']; ?></td>
  <td class="row1" width="140"><?php echo BY; ?> <a href="./club.php?zone=forums&amp;page=profil&amp;m=<?php echo $data3['post_createur'].'&amp;action=consulter">'.$data3['pseudo_last_posteur'].'</a><br />'.date('H\hi \l\e d M y',$data3['post_time']); ?></td>
 </tr>
<?php
	}
echo'
 <tr align="center">
  <td class="cat" colspan="7"></td>
 </tr>
</table>
';
}

else //S'il n'y a pas de message
{
	echo'<p>Ce forum ne contient aucun sujet actuellement</p>';
}
?>
<table width="99%" cellspacing="1">
 <tr>
  <td align="left" valign="middle">
<?php
if (verif_auth($data1['auth_topic']))
{
//Et le bouton pour poster
echo'<a href="./club.php?zone=forums&amp;page=poster&amp;action=nouveautopic&amp;f='.$forum.'">
<img src="./images/forums/nouveau.gif" alt="Nouveau topic" title="Poster un nouveau topic" border="0"></a>';
}
?>
  </td>
  <td class="nav" valign="middle" nowrap="nowrap">&nbsp;<?php echo PAGE; ?> <strong><?php echo $page; ?></strong> <?php echo SUR; ?> <strong><?php echo $nombreDePages; ?></strong><br /></td>
  <td class="gensmall" nowrap="nowrap">&nbsp;[ <?php echo $totalDesMessages . ' ' . TOPICS; ?>  ]&nbsp;</td>
  <td class="gensmall" width="99%" align="right" nowrap="nowrap"><b><?php echo ALLERPAGE; ?> : 
<?php


echo '<p>Page : ';
echo get_list_page($page, $nombreDePages, './club.php?zone=forums&amp;page=viewforum&f='.$forum.'&p=');
echo'</p>';


?>
  </b></td>
 </tr>
</table>
<br clear="all" />
<table class="tablebg" width="99%" cellspacing="1" cellpadding="0" style="margin-top: 5px;">
 <tr>
  <td class="row1">
  <p class="breadcrumbs"><a href ="./club.php?zone=forums"><?php echo INDEX; ?></a> &#187; <a href="./club.php?zone=forums&amp;page=viewforum&amp;f=<?php echo $forum.'">'.$data1['forum_name'].'</a>'; ?></p></td>
 </tr>
</table>
<br clear="all" />