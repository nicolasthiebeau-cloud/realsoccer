<?php
$titre = 'Index du forum';
include('includes/debut.php');
include('includes/config.php');
mysql_connect($host,$user,$mdp);
mysql_select_db($db)
?>


<?php
//----------------------------------------------------------------------
//										
// SMOP Sport Manager Open Source					
// Le projet est open source - sous license GPL			
// Vous �tes libre de l'utiliser mais pas � des fins commercial	
//										
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@emu-fr.com	
//										
//----------------------------------------------------------------------
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo SITE . ' - ' . TT_INDEX;  ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Pragma" content="no-cache" />
<meta name="description" content="Projet open source de cr�ation d'un script php de management d��quipe qui peut �tre adapt� � n�importe quel sport (d��quipe).">
<meta name="keywords" content="jeu, jeux, php, sql, foot, rugby, hockey, sport, �quipe, team, management, manager, script, open, source, free, gratuit, libre">
<meta name="author" content="Yannick San Nicolas">
<meta name=identifier-url content="http://snyzone.fr/smop">
<meta name="reply-to" content="ysn38@emu-fr.com">
<meta name="revisit-after" content="7 days">
<meta name="category" content="Jeux PHP">
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="blokprincipal">
	<div id="page_haut">
	<br /><h1>&nbsp;&nbsp;&nbsp;Sport Manager Open Source</h1>
	</div>
	<div id="menu">
	<table>
	  <tr>
		<td><a href="index.php">Connexion</a></td>
	  </tr>
	  <tr>
		<td><a href="index.php?page=newaccount">Inscription</a></td>
	  </tr>
	  <tr>
		<td><a href="http://emu-fr.com/index.php?showforum=156" target="new">Forum</a></td>
	  </tr>
	</table>
	</div>
	<div id="corps">
	
<?
		$page = "index";
		
		if(isset($_GET['page']))
			{$page = $_GET['page']; include('includes/pages/'.$page.'.htm');
				if(!file_exists("includes/pages/".$page.".htm"))
					{ include('includes/pages/404-red.htm');}
			}
		if($page == "index")
			{ include('includes/pages/news.htm'); }
			
		?>
		
		</p>
		
	</div>
	<div id="page_bas">
	<?php include('includes/pages/bas.php'); ?>
	</div>
</div>
</body>
</html>

	