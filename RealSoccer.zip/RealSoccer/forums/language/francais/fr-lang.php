
 <?php
//Voir Topic

define('INDEX', 'Index Du Forum !');
define('AUTEUR', 'Auteurs');
define('MESS', 'Message');

//Voir Profile

define('IDENT', 'Identifiants');
define('PSEUDO', 'Pseudo');
define('NEWPASS', 'Nouveaux Password');
define('CONFNEWPASS', 'Retaper Nouveaux Password');
define('CONTACT', 'Contacts');
define('MAIL', 'Votre Adresse E-Mail');
define('MSN', 'Votre Adresse MSN');
define('SWEB', 'Votre Site Web');
define('INFOSUP', 'Informations Suppl�mentaire');
define('LOCAL', 'Localisation');
define('PROFIL', 'Profil sur le Forum');
define('CAVATAR', 'Changer votre Avatar');
define('TAILLM', 'Taille maximum 10Ko !');
define('SUPAV', 'Supprimer Avatar !');
define('AVACTU', 'Avatar Actu�lle !');
define('SIGN', 'Signature !');
define('MODIFP', 'Modifier Sont Profil !');

//Include Page
// Conexion
define('TITREPC', 'Connexion !');
define('PSEUDOC', 'Pseudo:');
define('PASS', 'Password:');
define('CONNEXION', 'Connexion !');
define('PASINSCRIT', 'Pas Encore Inscrit ?');
?>