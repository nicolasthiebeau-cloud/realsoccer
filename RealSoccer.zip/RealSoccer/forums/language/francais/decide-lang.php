
<?php
if ($lang=='fr') { // si la langue est 'fr' (fran�ais) on inclut le fichier fr-lang.php
include('fr-lang.php');
}
else if ($lang=='en') { // si la langue est 'en' (anglais) on inclut le fichier en-lang.php
include('en-lang.php');
}
else { // si aucune langue n'est d�clar�e on inclut le fichier fr-lang.php par d�faut
include('fr-lang.php');
}
?> 