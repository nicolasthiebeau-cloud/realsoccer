<?php
//-------------------------------------------------------------------------------------//
//											//
// SMOP Sport Manager Open Source					//
// Le projet est open source - sous license GPL				//
// Vous �tes libre de l'utiliser mais pas � des fins commercial		//
//											//
// 											//
//											//
//-------------------------------------------------------------------------------------//

include('forums/includes/config.php');
include('forums/includes/debut.php');
include('forums/protection/auth.php');
mysql_connect($host,$user,$mdp);
mysql_select_db($db);

$action = htmlspecialchars($_GET['action']);
$membre = (int) $_GET['m'];

switch($action)
{
//Si c'est "consulter"
case "consulter":
       //On r�cup�re les infos du membre
       $requete1 = mysql_query('SELECT pseudo, membre_avatar,
       email, membre_msn, membre_signature, membre_siteweb, membre_post,
       joindate, membre_localisation
       FROM comptes WHERE account_id='.$membre.'');
       if ($data1 = mysql_fetch_assoc($requete1))
       {
       //On affiche les infos sur le membre

       echo'<h1>' . PROFILOF . ' '.$data1['pseudo'].'</h1>';
       
       echo'<img src="./images/forums/avatars/'.$data1['membre_avatar'].'"
       alt="' . NOAVATAR . '" /><br><br>';
       
       echo'<p><strong>' . MAIL . ' : </strong>
       <a href="mailto:'.$data1['email'].'">
       '.$data1['email'].'</a><br />';
       
       echo'<strong>' . MSN . ' : </strong>'.$data1['membre_msn'].'<br />';
       
       echo'<strong>' . SITEWEB . ' : </strong>
       <a href="'.$data1['membre_siteweb'].'">'.$data1['membre_siteweb'].'</a>
       <br /><br />';

       echo INSCDEPUIS . ' 
       <strong>'.date('d/m/Y',$data1['joindate']).'</strong>
       ' . POSTER . ' <strong>'.$data1['membre_post'].'</strong> ' . MESS . '
       <br /><br />';
       echo'<strong>' . LOCA . ' : </strong>'.$data1['membre_localisation'].'
       </p>';
	   
		if($data1['pseudo'] == $_SESSION['pseudo'])
		{ echo '<a href="club.php?zone=forums&amp;page=profil&amp;m='.$_SESSION['id'].'&action=modifier">' . MODIFPROFIL . '</a><br><br>'; }		
}
//Si on ne trouve pas d'info
else
{
echo'<p>' . MEMBERDONTEXIST . '</p>';
}
break;
//Si on choisit de mofifier son profil
case "modifier":
      //On prend les infos du membre
      $requete2 = mysql_query('SELECT pseudo, email,
      membre_siteweb, membre_signature, membre_msn, membre_localisation,
      membre_avatar
      FROM comptes WHERE account_id="'.$_SESSION['id'].'"');
      if ($data2 = mysql_fetch_assoc($requete2))
      {


      ?>
      <h1><?php echo MODIFPROFIL; ?></h1>
      <form method="post" action="club.php?zone=forums&amp;page=modifprofil" enctype="multipart/form-data">
       

      <fieldset><legend><?php echo IDENT; ?></legend>
      <?php echo PSEUDO; ?>: <?php echo'<strong>'.$data2['pseudo'].'</strong>'?><br />       
      <label for="mdp"><?php echo NEWPASS; ?></label>
      <input type="mdp" name="mdp" id="mdp" /><br />
      <label for="confirm"><?php echo CONFNEWPASS; ?> :</label>
      <input type="mdp" name="confirm" id="confirm"  />
      </fieldset>

      <fieldset><legend><?php echo CONTACT; ?></legend>
      <label for="email"><?php echo MAIL; ?> :</label>
      <input type="text" name="email" id="email"
      value="<?php echo $data2['email'] ?>" /><br />

      <label for="msn"><?php echo MSN; ?> :</label>
      <input type="text" name="msn" id="msn"
      value="<?php echo $data2['membre_msn'] ?>" /><br />

      <label for="website"><?php echo SITEWEB; ?></label>
      <input type="text" name="website" id="website"
      value="<?php echo $data2['membre_siteweb'] ?>" /><br />
      </fieldset>

      <fieldset><legend><?php echo INFOSUP; ?></legend>
      <label for="localisation"><?php echo LOCA; ?></label>
      <input type="text" name="localisation" id="localisation"
      value="<?php echo $data2['membre_localisation'] ?>" /><br />
      </fieldset>
               
      <fieldset><legend><?php echo PROFIL; ?></legend>
      <label for="avatar"><?php echo CAVATAR; ?></label>
      <input type="file" name="avatar" id="avatar" />
      <?php echo TAILLM; ?><br /><br />
      <label><input type="checkbox" name="delete" value="Delete" />
      <?php echo SUPAV; ?></label>
      <?php echo AVACTU; ?>
      <?php echo'
      <img src="./images/avatars/'.$data2['membre_avatar'].'"
      alt="pas d avatar" />' ?>
     
      <br /><br />
      <label for="signature"> <?php echo SIGN; ?></label>
      <textarea cols="40" rows="4" name="signature" id="signature">
      <?php echo $data2['membre_signature'] ?></textarea>
     
     
      </fieldset>
      <p>
      <input type="submit" value="<?php echo MODIFP; ?>" />
      </p></form>
      <?php
      }
      else echo'<p>' . ERRORPROF . '</p>';
break;

default; //Si jamais c'est aucun de ceux l� c'est qu'il y a eu un probl�me :o
echo'<p>' . ACTIONIMPOSS . '</p>';

} //Fin du switch

?>