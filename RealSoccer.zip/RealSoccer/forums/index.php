<?php
//----------------------------------------------------------------------
//										
// SMOP Sport Manager Open Source					
// Le projet est open source - sous license GPL			
// Vous �tes libre de l'utiliser mais pas � des fins commercial	
//										
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@emu-fr.com	
//										
//----------------------------------------------------------------------

$titre = 'Index du forum';
include('forums/includes/debut.php');
include('forums/includes/config.php');
mysql_connect($host,$user,$mdp);
mysql_select_db($db);

include('forums/includes/forum/corp.php');

?>
	