<?php
//-------------------------------------------------------------------------------------//
//											//
// SMOP Sport Manager Open Source					//
// Le projet est open source - sous license GPL				//
// Vous �tes libre de l'utiliser mais pas � des fins commercial		//
//											//
// 											//
//											//
//-------------------------------------------------------------------------------------//

include('forums/includes/config.php');
include('forums/includes/debut.php');
include('forums/protection/auth.php');
include("includes/javascript.php");
include("includes/bbcode.php");
require("language/decide-lang.php"); 
mysql_connect($host,$user,$mdp);
mysql_select_db($db);

//On r�cup�re la valeur de t
$topic = (int) $_GET['t'];
 
//A partir d'ici, on va compter le nombre de messages pour n'afficher que les 15 premiers
$requete1 = mysql_query("
SELECT topic_titre, topic_post, forum_topic.forum_id, 
forum_name, auth_view, auth_topic, auth_post 
FROM forum_topic 
LEFT JOIN forum_forum ON forum_topic.forum_id = forum_forum.forum_id 
WHERE topic_id = '".$topic."'") or die (mysql_error());
$data1 = mysql_fetch_assoc($requete1);

if (!verif_auth($data1['auth_view']))
{
	exit("Vous n avez pas le droit de vous trouver ici !");
}
 
$totalDesMessages = $data1['topic_post'];
$nombreDeMessagesParPage = $config['post_par_page'];
$nombreDePages = ceil($totalDesMessages / $nombreDeMessagesParPage);
?>
<table class="tablebg" width="99%" cellspacing="1" cellpadding="0">
 <tr>
  <td class="row1">
  <p class="breadcrumbs"><a href ="./club.php?zone=forums"><?php echo INDEX; ?></a> &#187; <a href="./club.php?zone=forums&amp;page=viewforum&amp;f=<?php echo $data1['forum_id'] ?>"><?php echo $data1['forum_name'] ?></a> &#187; <a href="./club.php?zone=forums&amp;page=viewtopic&amp;t=<?php echo $topic ?>"><?php echo $data1['topic_titre'] ?></a></p>
  <p class="datetime">
<?php
if (isset($_SESSION['pseudo'])) // Si le membre est connect�
{
	echo'<p>' . COENTANTQUE . ' <a href="./club.php?zone=forums&amp;page=profil&amp;m='.intval($_SESSION['id']).'&action=consulter">'.stripslashes(htmlspecialchars($_SESSION['pseudo'])).'</a>';
?>
  &nbsp;&nbsp;<a href="./club.php?zone=forums&amp;page=profil&amp;action=modifier"><?php echo MODIFPROFIL; ?></a>
  &nbsp;&nbsp;<a href="./club.php?zone=bureaumanager&amp;page=mp"><?php echo COMESS; ?></a>
  &nbsp;&nbsp;<a href ="./club.php?zone=deconnexion"><?php echo DECO; ?></a></p>
<?php
}
?>
  </p></td>
 </tr>
</table>
<br />
<div id="pageheader"><h1><?php  echo $data1['topic_titre'];//Le titre du forum ?></h1></div>
<table width="99%" cellspacing="1">
 <tr>
  <td align="left" valign="middle" nowrap="nowrap">
<?php
if (verif_auth($data1['auth_post']))
{
	//On affiche l'image r�pondre
	echo'<a href="./club.php?zone=forums&amp;page=poster&amp;action=repondre&amp;t='.$topic.'">
	<img src="./images/forums/repondre.gif" alt="R�pondre" title="R�pondre � ce topic" border="0"></a>';
}

if (verif_auth($data1['auth_topic']))
{
	//On affiche l'image nouveau topic
	echo'<a href="./club.php?zone=forums&amp;page=poster&amp;action=nouveautopic&amp;f='.$data1['forum_id'].'">
	<img src="./images/forums/nouveau.gif" alt="Nouveau topic" title="Poster un nouveau topic" border="0"></a>';
}

//Nombre de pages
if (isset($_GET['p'])) $page = intval($_GET['p']);
else $page = 1;

$premierMessageAafficher = ($page - 1) * $nombreDeMessagesParPage;
?>
  </td>
  <td class="nav" valign="middle" nowrap="nowrap">&nbsp;<?php echo PAGE; ?> <strong><?php echo $page; ?></strong> <?php echo SUR; ?> <strong><?php echo $nombreDePages; ?></strong><br /></td>
  <td class="gensmall" nowrap="nowrap">&nbsp;[ <?php echo $totalDesMessages . ' ' . MESS; ?>  ]&nbsp;</td>
  <td class="gensmall" width="99%" align="right" nowrap="nowrap"><b><?php echo ALLERPAGE; ?> : 
<?php


//Comptage des message sur SMOP 0.5
function get_list_page($page, $nb_page, $link, $nb = 2){
$list_page = array();
for ($i=1; $i <= $nb_page; $i++){
if (($i < $nb) OR ($i > $nb_page - $nb) OR (($i < $page + $nb) AND ($i > $page -$nb)))
$list_page[] = ($i==$page)?'<strong>'.$i.'</strong>':'<a href="'.$link.'&amp;p='.$i.'">'.$i.'</a>'; 
else{
if ($i >= $nb AND $i <= $page - $nb)
$i = $page - $nb;
elseif ($i >= $page + $nb AND $i <= $nb_page - $nb)
$i = $nb_page - $nb;
$list_page[] = '...';
}
}
$print= implode('-', $list_page);
return $print;
}

//On affiche les pages 1-2-3, etc.
echo '<p>Page : ';
echo get_list_page($page, $nombreDePages, './club.php?zone=forums&amp;page=viewtopic&t='.$topic.'&p=');
echo'</p>';


?>
  </b></td>
 </tr>
</table>
<?php
//Enfin on commence la boucle !

$requete2 = mysql_query('
SELECT post_id , post_createur , post_texte , post_time ,
account_id, pseudo, joindate, membre_avatar, membre_localisation, membre_post, membre_signature
FROM forum_post
LEFT JOIN comptes ON comptes.account_id = forum_post.post_createur
WHERE topic_id ="'.$topic.'"
ORDER BY post_id
LIMIT ' . $premierMessageAafficher . ', ' . $nombreDeMessagesParPage . '')
or die(mysql_error());
 
//On v�rifie que la requ�te a bien retourn� des messages
if (mysql_num_rows($requete2) < 1)
{
	echo'<p>' . ERRORPOST . '</p>';
}
else
{
	//Si tout roule on affiche notre tableau puis on remplit avec une boucle
?>
<table class="tablebg" width="99%" cellspacing="1">
 <tr>
  <th class="fotitre" width="20%"><strong><?php echo AUTEUR; ?></strong></th>
  <th class="fotitre" width="80%"><strong><?php echo MESS; ?></strong></th>
 </tr>
<?php
	while ($data2 = mysql_fetch_assoc($requete2))
	{
		//On commence � afficher le pseudo du cr�ateur du message :
        //On v�rifie les droits du membre
        //(partie du code comment�e plus tard)
?>
 <tr class="row1">
  <td align="center" valign="middle"><center><strong><a href="./club.php?zone=forums&amp;page=profil&amp;m=<?php echo $data2['account_id'].'&amp;action=consulter">'.$data2['pseudo'].'</a></strong></center></td>'; ?>
  <td width="100%" height="25">
   <table width="100%" cellspacing="0">
    <tr>
     <td class="gensmall" width="100%">
	  <div style="float: left;">&nbsp;<b><?php echo SUJET; ?> : </b><?php  echo $data1['topic_titre'];//Le titre du forum ?></div>
	  <div style="float: right;"><b><?php echo POSTLE; ?> : </b><?php echo date('d M y \� H\hi ',$data2['post_time']); ?>&nbsp;</div>
	 </td>
    </tr>
   </table>
  </td>
 </tr>
 <tr class="row1">
  <td valign="top" class="profile">
   <?php echo'<img src="./images/forums/avatars/'.$data2['membre_avatar'].'" alt="" /><br />'; ?>
   <span class="postdetails"><?php echo'
        Membre inscrit le '.date('d/m/Y',$data2['joindate']).'
        <br />Messages : '.$data2['membre_post'].'<br />
        Localisation : '.$data2['membre_localisation']; ?></span>
  </td>
   <td valign="top">
    <table width="100%" cellspacing="5">
     <tr>
      <td>
	  <div class="postbody">
<?php

      //Message pour BBCode (Version du forum 0.5)
		//Message
        echo''.code($data2['post_texte']).'<br /><hr>'.code($data2['membre_signature']).'';
	   
		 ?>
	  </div>
	 </td>
    </tr>
   </table>
  </td>
 </tr>
 <tr class="row1">
  <td><strong><a href="#wrapheader"><center><?php echo TOP; ?></center></a></strong></td>
  <td><div class="gensmall" style="float: left;" ><a href="./club.php?zone=forums&amp;page=profil&amp;m=<?php echo $data2['account_id'].'&amp;action=consulter">' . PROFIL . '</a></div>'; ?>
<?php
/* Si on est l'auteur du message, on affiche des liens pour
Mod�rer celui-ci.
Les mod�rateurs pourront aussi le faire, il faudra donc revenir sur ce           
code un peu plus tard ! */     
if ($_SESSION['id'] == $data2['post_createur'])
echo'<div style="float: right;"><a href="./club.php?zone=forums&amp;page=poster&amp;p='.$data2['post_id'].'&amp;action=delete"><img src="./images/forums/' . SUPP . '.gif" alt="Supprimer" title="' . SUPPINF . '" border="0" /></a>   
								<a href="./club.php?zone=forums&amp;page=poster&amp;p='.$data2['post_id'].'&amp;action=edit"><img src="./images/forums/' . EDIT . '.gif" alt="Editer" title="' . EDITINF . '" border="0" /></a></align></div>';

?>
  </td>
 </tr>
 <tr>
  <td class="spacer" colspan="2" height="1"><img src="images/spacer.gif" alt="" width="1" height="1" /></td>
 </tr>
<?php
	} //Fin de la boucle ! \o/
?>
</table>
<?php

//On affiche les pages 1-2-3, etc.
echo '<p>Page : ';
echo get_list_page($page, $nombreDePages, './club.php?zone=forums&amp;page=viewtopic&t='.$topic.'&p=');
echo'</p>';
       
	   
	   
	   
	   	
		// Ici on place les options de mod�ration !!
	   
	//Supprimer
	
	//V�rouiller
$requete3 = mysql_query('SELECT topic_locked FROM forum_topic WHERE topic_id = '.$topic);
$data3 = mysql_fetch_assoc($requete3);
 
 
if ($data3['topic_locked'] == 1) // Topic verrouill� !
{
//On v�rifie que la p�rsonne est MODO !

if (!verif_auth($data1['auth_modo']))
{
echo'<a href="./club.php?zone=forums&amp;page=postok&amp;action=unlock&t='.$amp;topic.'">
<img src="./images/forums/unlock.gif" alt="' . DEVEROUIL . '" 
title="' . DEVEROUIL . '" /></a>';
}
}
else //Sinon le topic est d�verrouill� !
{
if (!verif_auth($data1['auth_modo']))
{
echo'<a href="./club.php?zone=forums&amp;page=postok&amp;action=lock&amp;t='.$topic.'">
<img src="./images/forums/lock.gif" alt="' . VEROUIL . '" 
title="' . VEROUIL . '" /></a>';
}
}


// D�placer

$requete = mysql_query('SELECT forum_id, forum_name FROM forum_forum WHERE forum_id <> '.$data1['forum_id'].'');
//Data 1 a �t� d�finie tout en haut de la page !

if (!verif_auth($data1['auth_modo']))
{
echo'<p>' . DEPLAVERS . ' :</p>
<form method="post" action=club.php?zone=forums&amp;page=postok&amp;action=deplacer&amp;t='.$topic.'>
<select name="dest">';               
while($data = mysql_fetch_assoc($requete))
{
     echo'<option value='.$data['forum_id'].' id='.$data['forum_id'].'>'.$data['forum_name'].'</option>';
}

echo'
</select>
<input type="hidden" name="from" value='.$data1['forum_id'].'>
<input type="submit" name="submit" value="' . ENVOI . '" />
</form>'; }



        //On ajoute 1 au nombre de visites de ce topic
        mysql_query('UPDATE forum_topic
        SET topic_vu = topic_vu + 1 WHERE topic_id = '.$topic.'');
 
} //Fin du if qui v�rifiait si le topic contenait au moins un message
?>