<?php
//identifiants
$host = 'localhost';
$user = 'root';
$mdp = '';
$db = 'sportmanager';

//Configuration INDX
$TonTitre = 'SMOP-Forum';
?>