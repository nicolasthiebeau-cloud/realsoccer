<br /><br />
<div align="center">SMOP Sport manager Open Source 2008 - Tous droits r&eacute;serv&eacute;<br />
<div align="center">SMOP Forum - Copyright Benjamin 2008  - Tous droits r&eacute;serv&eacute;<br />
<a href="http://www.xiti.com/xiti.asp?s=372941" title="WebAnalytics">
<script type="text/javascript">
<!--
Xt_param = 's=372941&p=SMOP-Serveur';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="80" height="15" border="0" alt="" ';
Xt_i += 'src="http://logv3.xiti.com/vcg.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
<img width="80" height="15" src="http://logv3.xiti.com/vcg.xiti?s=372941&p=SMOP-Serveur" alt="WebAnalytics" />
</noscript></a></div>
<br />