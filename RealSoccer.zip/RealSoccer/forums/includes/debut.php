<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
<head>
<?php
if(!empty($titre))
{
echo '<title> '.$titre.' </title>';
}
else
{
echo '<title> '.$TonTitre.' </title>';
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="style.css" />
</head>

<?php
include("forums/includes/config.php");
mysql_connect($host,$user,$mdp);
mysql_select_db($db);

//Cr�ation des variables
$ip = ip2long($_SERVER['REMOTE_ADDR']);
if (!isset($_SESSION['id'])) $id=0;
else $id = intval($_SESSION['id']);

//Requ�te
mysql_query('INSERT INTO whosonline VALUES('.$id.', '.time().','.$ip.')
ON DUPLICATE KEY UPDATE
online_time = '.time().' , online_id = '.$id.'');

$time_max = time() - (60 * 5);
mysql_query('DELETE FROM whosonline WHERE online_time < '.$time_max);
?>

<?php
include("forums/includes/config.php");
mysql_connect($host,$user,$mdp);
mysql_select_db($db);

//R�cup�ration des variables de configuration
$recup = mysql_query('SELECT * FROM forum_config');
$config = array();
while($data_recup = mysql_fetch_assoc($recup))
{
$config[$data_recup['config_nom']] = $data_recup['config_valeur']; 
}
?>
