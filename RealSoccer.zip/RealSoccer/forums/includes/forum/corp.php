<?php
//-------------------------------------------------------------------------------------//
//											//
// SMOP Sport Manager Open Source					//
// Le projet est open source - sous license GPL				//
// Vous �tes libre de l'utiliser mais pas � des fins commercial		//
//											//
// 											//
//											//
//-------------------------------------------------------------------------------------//

include('forums/includes/config.php');
include('forums/includes/debut.php');
include('forums/protection/auth.php');
mysql_connect($host,$user,$mdp);
mysql_select_db($db);
?>
<table class="tablebg" width="99%" cellspacing="1" cellpadding="0">
 <tr>
  <td class="row1">
  <p class="breadcrumbs"><a href ="./club.php?zone=forums&amp;page=forums"><?php echo INDEX; ?></a></p>
  <p class="datetime">
<?php
if (isset($_SESSION['pseudo'])) // Si le membre est connect�
{
	echo'<p>' . COENTANTQUE . ' <a href="./club.php?zone=forums&amp;page=profil&amp;m='.intval($_SESSION['id']).'&action=consulter">'.stripslashes(htmlspecialchars($_SESSION['pseudo'])).'</a>';
?>
  &nbsp;&nbsp;<a href="./club.php?zone=forums&amp;page=profil&amp;action=modifier"><?php echo MODIFPROFIL; ?></a>
  &nbsp;&nbsp;<a href="./club.php?zone=forums&amp;page=mp"><?php echo COMESS; ?></a>
  &nbsp;&nbsp;<a href ="./club.php?zone=forums&amp;page=logout"><?php echo DECO; ?></a></p>
<?php
}
?>
  </p></td>
 </tr>
</table>
<br />
<center><h1><?php echo TITLEFOFO; ?></h1></center>
<br /><br />
<?php
//Cette requete permet d'obtenir tout sur le forum
$requete2 = mysql_query('
SELECT cat_id, cat_nom, 
forum_forum.forum_id, forum_name, forum_desc, forum_post, forum_topic, auth_view, forum_topic.topic_id, 
post_time, post_createur, pseudo, 
account_id 
FROM forum_categorie
LEFT JOIN forum_forum ON forum_categorie.cat_id = forum_forum.forum_cat_id
LEFT JOIN forum_post ON forum_post.post_id = forum_forum.forum_last_post_id
LEFT JOIN forum_topic ON forum_topic.topic_id = forum_post.topic_id
LEFT JOIN comptes ON comptes.account_id = forum_post.post_createur 
ORDER BY cat_ordre, forum_ordre DESC');

//Dans un premier temps, on v�rifie s'il y a des forums � lister
if (mysql_num_rows($requete2) < 1)
{
        echo'<p style="color: red">' . NOFORUM . '</p>';
}
else
{
?>
<table class="tablebg" width="99%" cellspacing="1">
 <tr>
  <td class="cat" colspan="7">
  </td>
 </tr>
<?php
//D�but de la boucle
	while($data2 = mysql_fetch_assoc($requete2))
	{
	//On affiche chaque cat�gorie
		if( $categorie != $data2['cat_id'] )
		{
			//Si c'est une nouvelle cat�gorie on l'affiche
			$categorie = $data2['cat_id'];
?>
 <tr>
  <td class="fotitre" align="center" width="5%"></td>
  <td class="fotitre" align="center" width="45%"><?php echo $data2['cat_nom']; ?></td>
  <td class="fotitre" align="center" width="10%"><?php echo SUJET; ?></td>
  <td class="fotitre" align="center" width="10%"><?php echo MESS; ?></td>
  <td class="fotitre" align="center" width="30%"><?php echo LASTMESS; ?></td>
 </tr>
<?php
		}
		
		//Ici, on met le contenu de chaque cat�gorie
		//Syst�me pour les grade (1 inviter,  2 membre, 3modo,4  admin)
		if (verif_auth($data2['auth_view']))
		{
			//Affichage des forums
			// les forums en d�tail : description, nombre de r�ponses etc...
?>
 <tr>
  <td class="row1" align="center"><img src="./images/forums/pas_nouveau.gif" alt="message" /></td>
  <td class="row1"><B><a href="./club.php?zone=forums&amp;page=viewforum&amp;f=<?php echo $data2['forum_id'].'">'.$data2['forum_name'].'</a></b><br />'.$data2['forum_desc'].'</td>'; ?>
  <td class="row2" align="center"><?php echo $data2['forum_topic']; ?></td>
  <td class="row2" align="center"><?php echo $data2['forum_post']; ?></td>

 <?php
			// Deux cas possibles :
			// Soit il y a un nouveau message, soit le forum est vide
			if (!empty($data2['forum_post']))
			{
				echo'<td class="row1">Le '.date('d M y, \� H\hi ',$data2['post_time']).'<br />Par 
					 <a href="./club.php?zone=forums&amp;page=profil&amp;m='.$data2['post_createur'].'&amp;action=consulter">'.$data2['pseudo'].'</a>
					 <a href="./club.php?zone=forums&amp;page=viewtopic&amp;t='.$data2['topic_id'].'">+</a></td></tr>';
			}
	      
			else
			{
				echo'<td class="row1">' . NOMESS . '</td></tr>';
			}
		} //Fin de la v�rification d'autorisation
		
		//Cette variable stock le nombre de message, on la met � jour
		$totaldesmessages = $totaldesmessages + $data2['forum_post'];
		
		//On ferme notre boucle et nos balises
	} //fin de la boucle
	echo '
	 <tr align="center">
  <td class="cat" colspan="7"></td>
 </tr>
</table>
<br /><br />';
} //fin du else  

//Initialisation de la variable
$count_online = 0;

//D�compte des visiteurs
$count_visiteurs= mysql_result(mysql_query('SELECT COUNT(*) AS nbr_visiteurs FROM whosonline WHERE online_id = 0'),0);

//D�compte des membres
$time_max = time() - (60 * 5);
$requete_count_membres = mysql_query('SELECT account_id, pseudo
FROM whosonline
LEFT JOIN comptes ON account_id = online_id
WHERE online_time > '.$time_max);
$count_membres = mysql_num_rows($requete_count_membres);

$count_online = $count_visiteurs + $count_membres;




?>
<table class="tablebg" width="99%" cellspacing="1" cellpadding="0" style="margin-top: 5px;">
 <tr>
  <td class="row1"><p class="breadcrumbs">L�gende</p>

<img src="./images/forums/pas_nouveau.gif"/> Pas de nouveaux m�ssage </br>
</br><img src="./images/forums/annonce.gif"/> Annonce </br>
</br><img src="./images/forums/message.gif"/> Nouveaux M�ssage </br>

</tr>
</td>
</table>
<table class="tablebg" width="99%" cellspacing="1" cellpadding="0" style="margin-top: 5px;">
 <tr>
  <td class="row1"><p class="breadcrumbs"><?php echo WHOONLINE; ?></p>
<?php
//Le pied de page ici :

$requete3 = mysql_query('
SELECT account_id  
FROM comptes');

$TotalDesMembres = mysql_num_rows($requete3);

$requete4 = mysql_query('
SELECT pseudo, account_id 
FROM comptes 
ORDER BY account_id DESC LIMIT 0, 1');

$data4 = mysql_fetch_assoc($requete4);
$derniermembre = $data4['pseudo'];

//On n'a plus qu'� utiliser echo
echo'<p>' . TOTALMESS . ' <strong>'.$totaldesmessages.'</strong><br />';
echo MBCOUNT . ' <strong>'.$TotalDesMembres.'</strong> ' . MEMBER . '.<br />';
echo LASTMB . ' <a href="./club.php?zone=forums&amp;page=profil&amp;m='.$data4['account_id'].'&amp;action=consulter">'.$derniermembre.'</a><br /></p>';
echo '<p>' . ILYA . ' ' . $count_online . ' ' . CONNECTED . '('.$count_membres.' ' . MBET . ' '.$count_visiteurs.' ' . INVIT . ')';
?>
<?php
$texte_a_afficher = "<br />" . LSTONLINE . " : ";
while ($data_count_membres = mysql_fetch_assoc($requete_count_membres))
{
$texte_a_afficher .= '<a href="./club.php?zone=forums&amp;page=profil&amp;='.$data_count_membres['account_id'].'&amp;action=consulter">
'.stripslashes(htmlspecialchars($data_count_membres['pseudo'])).'</a> ,';
}
$texte_a_afficher = substr($texte_a_afficher, 0, -1);
echo $texte_a_afficher.'</p>';

?>

</td>
 </tr>
</table>
</br><div align="center">SMOP Forum - Copyright 2008-2009 Pour Sport Manager Open Source By Benjamin - Tous droits r&eacute;serv&eacute;<br />
<br clear="all" />