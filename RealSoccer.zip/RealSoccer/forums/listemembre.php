<?php
//----------------------------------------------------------------------
//										
// SMOP Sport Manager Open Source					
// Le projet est open source - sous license GPL			
// Vous �tes libre de l'utiliser mais pas � des fins commercial	
//										
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@emu-fr.com	
//										
//----------------------------------------------------------------------
//Cette fonction doit �tre appel�e avant tout code html

//On donne ensuite un titre � la page, puis on appelle notre fichier debut.php
$titre = "Liste des membres";
include("includes/debut.php");

//Maintenant, on se connecte � la base de donn�es
include("includes/config.php");
mysql_connect($host,$user,$mdp);
mysql_select_db($db);

//A partir d'ici, on va compter le nombre de members
//pour n'afficher que les 25 premiers
$requete1 = mysql_query("SELECT COUNT(*) AS nbr FROM comptes");
$data1 = mysql_fetch_assoc($requete1);

$total = $data1['nbr'] +1;
$MembreParPage = 25;
$NombreDePages = ceil($total / $MembreParPage);
?>
<div id="corps_forum">
<?php
echo'<a href ="./club.php?zone=forums">Index du forum</a> /
<a href="./club.php?zone=forums&amp;page=listemembre">Liste des membres</a>';

if (isset($_SESSION['pseudo'])) // Si le membre est connect�
{
       
        //Voici les options
        echo'<p>Vous �tes connect� en tant que
        <a href="./club.php?zone=forums&amp;page=profil&amp;m='.intval($_SESSION['id']).'&action=consulter">
        '.stripslashes(htmlspecialchars($_SESSION['pseudo'])).'</a><br />
        <a href="./club.php?zone=forums&amp;page=profil&amp;action=modifier">Modifier mon profil</a><br />
        <a href="./club.php?zone=bureaumanager&amp;page=mp">Consulter mes messages priv�s</a><br />
        <a href ="./club.php?zone=deconnexion">Se d�connecter</a><br /></p>';

}
// Sinon, on propose de se connecter ou de s'enregistrer
else
{
        echo'<p>Vous n �tes pas connect� <br />
        <a href="./index.php?page=login">Se connecter</a><br />
        <a href="./register.php">Pas encore inscrit ?</a><br /></p>';
}
//Nombre de pages

if (isset($_GET['page']))
{
$page = intval($_GET['page']);
}
else
{
$page = 1;
}
//On affiche les pages 1-2-3, etc.
echo 'Page : ';
for ($i = 1 ; $i <= $NombreDePages ; $i++)
{
    if ($i == $page) //On ne met pas de lien sur la page actuelle
    {
    echo $i;
    }
    else
    {
    echo '<p>
    <a href="club.php?zone=forums&amp;page=listemembre&amp;f='.$forum.'&amp;page='.$i.'">'.$i.'</a>
    </p>';
    }
}


$premier = ($page - 1) * $MembreParPage;

//Le titre de la page
echo '<h1>Liste des membres</h1><br /><br />';
?>

<?
//Tri

$convert_order = array('pseudo', 'membre_inscrit', 'membre_post', 'membre_derniere_visite'); 
$convert_tri = array('ASC', 'DESC');
//On r�cup�re la valeur de s
if (isset ($_POST['s'])) $sort = $convert_order[$_POST['s']];
else $sort = $convert_order[0];
//On r�cup�re la valeur de t
if (isset ($_POST['t'])) $tri = $convert_tri[$_POST['t']];
else $tri = $convert_tri[0];

?>
<form action="memberlist.php" method="post">
<p><label for="s">Trier par : </label>

<select name="s" id="s">
<option value="0" name="0">Pseudo</option>
<option value="1" name="1">Inscription</option>
<option value="2" name="2">Messages</option>
<option value="3" name="3">Derni�re visite</option>
</select>

<select name="t" id="t">
<option value="0" name="0">Croissant</option>
<option value="1" name="1">D�croissant</option>
</select>
<input type="submit" value="Trier" /></p>
</form>
<?php
//Requ�te

$requete2 = mysql_query('SELECT account_id, pseudo, membre_inscrit, membre_post, membre_derniere_visite, online_id
FROM comptes
LEFT JOIN forum_whosonline ON online_id = account_id
ORDER BY '.$sort.', online_id '.$tri.'
LIMIT ' . $premier . ', ' . $MembreParPage .'')
or die (mysql_error());

if (mysql_num_rows($requete2) > 0)
{
?>
       <table>
       <tr>
       <th class="pseudo"><strong>Pseudo</strong></th>             
       <th class="posts"><strong>Messages</strong></th>
       <th class="inscrit"><strong>Inscrit depuis le</strong></th>
       <th class="derniere_visite"><strong>Derni�re visite</strong></th>                       
       <th><strong>Connect�</strong></th>             

       </tr>
       <?php
       //On lance la boucle
       
       while ($data2 = mysql_fetch_assoc($requete2))
       {
       echo '<tr><td>
       <a href="./voirprofil.php?m='.$data2['account_id'].'&amp;action=consulter">
       '.stripslashes(htmlspecialchars($data2['pseudo'])).'</a></td>
       <td>'.$data2['membre_post'].'</td>
       <td>'.date('d/m/Y',$data2['membre_inscrit']).'</td>
       <td>'.date('d/m/Y',$data2['membre_derniere_visite']).'</td>';
       if (empty($data2['online_id'])) echo '<td>non</td>'; 
       else echo '<td>oui</td>';
       echo '</tr>';
       }
       ?>
       </table>
       <?php
}
else //S'il n'y a pas de message
{
        echo'<p>Ce forum ne contient aucun membre actuellement</p>';
}

	