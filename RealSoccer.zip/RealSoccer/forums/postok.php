<?php
//----------------------------------------------------------------------
//										
// SMOP Sport Manager Open Source					
// Le projet est open source - sous license GPL			
// Vous �tes libre de l'utiliser mais pas � des fins commercial	
//										
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@emu-fr.com	
//										
//----------------------------------------------------------------------

include('forums/includes/config.php');
include('forums/includes/debut.php');
include('forums/protection/auth.php');
mysql_connect($host,$user,$mdp);
mysql_select_db($db);

//On r�cup�re la valeur de la variable action
$action = htmlspecialchars($_GET['action']);

// Si le membre n'est pas connect�, il est ariv� ici par erreur
if (!isset($_SESSION['pseudo']))
{
echo'<p>Erreur : Vous n �tes plus connect�</p>';
}
else //Sinon on lance la suite
{

switch($action)
{
//Premier cas : nouveau topic

case "nouveautopic":

//On passe le message dans une s�rie de fonction
$message = htmlspecialchars($_POST['message'], ENT_QUOTES);
$message = nl2br($message);

//Pareil pour le titre
$titre = htmlspecialchars($_POST['titre'], ENT_QUOTES);

//ici seulement, maintenant qu'on est sur qu'elle existe, on r�cup�re la valeur de la variable f
$forum = $_GET['f'];
$temps = time();

if (empty($_POST['message']) || empty($_POST['titre']))
{
echo'<p>Votre message ou votre titre est vide, cliquez <a href="./club.php?zone=forums&amp;page=poster&amp;action=nouveautopic&amp;f='.$forum.'">ici</a> pour recommencer</p>';
}
else //Si jamais le message n'est pas vide
{

//On entre le topic dans la base de donn�e en laissant
//le champ topic_last_post � 0
mysql_query("INSERT INTO forum_topic
(forum_id, topic_titre, topic_createur, topic_vu, topic_time, topic_genre, topic_last_post, topic_post)
VALUES('".$forum."', '".$titre."', '".$_SESSION['id']."', '1', '".$temps."','".$_POST['mess']."', '0', '0'  )")
or die ("Un probl�me est survenu lors de l'envoi du message (erreur 01)");

$nouveautopic = mysql_insert_id();

//Puis on entre le message
mysql_query("INSERT INTO forum_post
(post_id, post_createur, post_texte, post_time, topic_id, post_forum_id)
VALUES(',' ,'".$_SESSION['id']."', '".$message."', '".$temps."', '".$nouveautopic."', '".$forum."')")
or die ("Un probl�me est survenu lors de l'envoi du message (erreur 02)");

$nouveaupost = mysql_insert_id();

//Ici on update comme pr�vu la valeur de topic_last_post et de topic_first_post
mysql_query("UPDATE forum_topic
SET topic_last_post = '".$nouveaupost."',
topic_first_post = '".$nouveaupost."'
WHERE topic_id = '".$nouveautopic."'")
or die ("Un probl�me est survenu lors de l'envoi du message (erreur 03)");


//Enfin on met � jour les tables forum_forum et comptes
mysql_query("UPDATE forum_forum
SET forum_post = forum_post + 1 ,
forum_topic = forum_topic + 1,
forum_last_post_id = '".$nouveaupost."'
WHERE forum_id = '".$forum."'")
or die ("Un probl�me est survenu lors de l'envoi du message (erreur 04)");

mysql_query("UPDATE comptes
SET membre_post = membre_post + 1
WHERE account_id  = '".$_SESSION['id']."'")
or die ("Un probl�me est survenu lors de l'envoi du message (erreur 05)");

//Et un petit message
echo'<p>Votre message a bien �t� ajout�!<br /><br />Cliquez <a href="./club.php?zone=forums">ici</a> pour revenir � l index du forum<br />Cliquez <a href="./club.php?zone=forums&amp;page=viewtopic&amp;t='.$nouveautopic.'">ici</a> pour le voir</p>';
}
break; //Houra !


//Deuxi�me cas : r�pondre
case "repondre":

//On passe le message dans une s�rie de fonction
$message = htmlspecialchars($_POST['message'], ENT_QUOTES);
$message = nl2br($message);

//ici seulement, maintenant qu'on est sur qu'elle existe, on r�cup�re la valeur de la variable t
$topic = $_GET['t'];
$temps = time();

if (empty($_POST['message']))
{
echo'<p>Votre message est vide, cliquez <a href="./club.php?zone=forums&amp;page=poster&amp;action=repondre&amp;t='.$topic.'">ici</a> pour recommencer</p>';
}
else //Sinon, si le message n'est pas vide
{

//On r�cup�re l'id du forum
$requete2 = mysql_query('SELECT forum_id
FROM forum_topic
WHERE topic_id = "'.$topic.'"');

$data2= mysql_fetch_assoc($requete2) or die ("Une erreur semble �tre survenue lors de l'envoi du message (erreur 06)");
$forum = $data2['forum_id'];

//Puis on entre le message
mysql_query("INSERT INTO forum_post
(post_id, post_createur, post_texte, post_time, topic_id, post_forum_id)
VALUES(',' ,'".$_SESSION['id']."', '".$message."', '".$temps."', '".$topic."', '".$forum."')")
or die ("Une erreur semble avoir survenu lors de l'envoi du message (erreur 07)");

$nouveaupost = mysql_insert_id();

//On change un peu la table forum_topic
mysql_query("UPDATE forum_topic
SET topic_post = topic_post + 1,
topic_last_post = '".$nouveaupost."'
WHERE topic_id ='".$topic."'")
or die ("Une erreur semble avoir survenu lors de l'envoi du message (erreur 08)");

//Puis m�me combat sur les 2 autres tables
mysql_query("UPDATE forum_forum
SET forum_post = forum_post + 1 ,
forum_last_post_id = '".$nouveaupost."'
WHERE forum_id = '".$forum."'")
or die ("Une erreur semble avoir survenu lors de l'envoi du message (erreur 09)");

mysql_query("UPDATE comptes
SET membre_post = membre_post + 1
WHERE account_id  = '".$_SESSION['id']."'")
or die ("Une erreur semble avoir survenu lors de l'envoi du message (erreur 10)");

//$nombre_mess = mysql_query('SELECT * FROM forum_post WHERE post_createur = '.$_SESSION['id'].' AND post_forum_id = '.$forum.' AND post_time > '.(time() - $config['temps_flood']).'ORDER BY post_id DESC LIMIT 1');
//if($nombre_mess = true) 
//{
//echo 'Contr�le anti flood, vous ne pouvez r�ponde au m�ssage que toutes les '.$config['temps_flood'].' sec<br />
//attendez un peu et cliquez <a href=".club.php?page=postok&action=nouveautopic&amp;f='.$topic.'">ici</a> pour recommencer</p>';
//exit();
//}

//Et un petit message
echo'<p>Votre message a bien �t� ajout�!<br /><br />Cliquez <a href="./club.php?zone=forums">ici</a> pour revenir � l index du forum<br />Cliquez <a href="./club.php?zone=forums&amp;page=viewtopic&amp;t='.$topic.'">ici</a> pour le voir</p>';
}
break;




case "edit": //Si on veut �diter le post
//On r�cup�re la valeur de p
$post = (int) $_GET['p'];
 
//On check le message
$message = mysql_real_escape_string($_POST['message']);

 
//Ensuite on v�rifie que le membre a le droit d'�tre ici (soit le cr�ateur soit un modo/admin)
$requete2 = mysql_query('
SELECT post_createur, post_texte, post_time, topic_id, auth_modo
FROM forum_post
LEFT JOIN forum_forum ON forum_post.post_forum_id = forum_forum.forum_id
WHERE post_id='.$post.'');
$data2 = mysql_fetch_assoc($requete2);
$topic = $data2['topic_id'];

//On r�cup�re la place du message dans le topic (pour le lien)
$requete3 = mysql_query('SELECT COUNT(*) AS nbr FROM forum_post 
WHERE topic_id = '.$topic.' AND post_time < '.$data2['post_time']);
$data3 = mysql_fetch_assoc($requete3);

if (!verif_auth($data2['auth_modo'])&& $data2['post_createur'] != $_SESSION['id'])
{
// Si cette condition n'est pas remplie �a va barder :o
echo'<p>Vous n\'avez aucun droit d\'�tre ici</p></div></body></html>';
exit();
}
else //Sinon �a roule et on continue
{
mysql_query("UPDATE forum_post SET post_texte =  '".$message."' WHERE post_id = '".$post."'");
$nombreDeMessagesParPage = 15;
$nbr_post = $data3['nbr']+1;
$page = ceil($nbr_post / $nombreDeMessagesParPage);
echo'<p>Votre message a bien �t� �dit�!<br /><br />
Cliquez <a href="./club.php?zone=forums">ici</a> pour revenir � l index du forum<br />
Cliquez <a href="./club.php?zone=forums&amp;page=viewtopic&amp;t='.$topic.'&amp;page='.$page.'#p_'.$post.'">ici</a> pour le voir</p>';
}
break;


//Ici il y aura la suppr�ssion.
//Mais il y a encore quelque probl�me ;p



case "lock": //Si on veut verrouiller le topic
//On r�cup�re la valeur de t
$topic = (int) $_GET['t'];
$requete1 = mysql_query('
SELECT forum_topic.forum_id, auth_modo
FROM forum_topic
LEFT JOIN forum_forum ON forum_forum.forum_id = forum_topic.forum_id
WHERE topic_id = '.$topic);
$data1 = mysql_fetch_assoc($requete1);
//Ensuite on v�rifie que le membre a le droit d'�tre ici
if (!verif_auth($data1['auth_modo']))
{
// Si cette condition n'est pas remplie �a va barder :o
echo'<p>Vous n\'avez aucun droit d\'�tre ici</p></div></body></html>';
exit();
}
else //Sinon �a roule et on continue
{
//On met � jour la valeur de topic_locked
mysql_query("UPDATE forum_topic
SET topic_locked = '1'
WHERE topic_id = '".$topic."'");
 
echo'<p>Le topic a bien �t� verrouill� ! <br />
Cliquez <a href="./voirtopic.php?t='.$topic.'">ici</a> pour retourner au topic<br />
Cliquez <a href="./index.php">ici</a> pour revenir � l index du forum</p>';
}
break;
 
case "unlock": //Si on veut d�verrouiller le topic
//On r�cup�re la valeur de t
$topic = (int) $_GET['t'];
$requete1 = mysql_query('
SELECT forum_topic.forum_id, auth_modo
FROM forum_topic
LEFT JOIN forum_forum ON forum_forum.forum_id = forum_topic.forum_id
WHERE topic_id = '.$topic.'');
$data1 = mysql_fetch_assoc($requete1);
 
//Ensuite on v�rifie que le membre a le droit d'�tre ici
if (!verif_auth($data1['auth_modo']))
{
// Si cette condition n'est pas remplie �a va barder :o
echo'<p>Vous n\'avez aucun droit d\'�tre ici</p></div></body></html>';
exit();
}
else //Sinon �a roule et on continue
{
//On met � jour la valeur de topic_locked
mysql_query("UPDATE forum_topic
SET topic_locked = '0'
WHERE topic_id = '".$topic."'");
 
echo'<p>Le topic a bien �t� d�verrouill� !<br />
Cliquez <a href="./club.php?zone=forums&amp;page=viewtopic&amp;t='.$topic.'">ici</a> pour retourner au topic<br />
Cliquez <a href="./club.php?zone=forums">ici</a> pour revenir � l index du forum</p>';
}
break;



case "delete": //Si on veut supprimer le post
        //On r�cup�re la valeur de p
        $post = (int) $_GET['p'];
        $requete1 = mysql_query('
        SELECT post_createur, post_texte, forum_id, topic_id, auth_modo
        FROM forum_post
        LEFT JOIN forum_forum ON forum_post.post_forum_id = forum_forum.forum_id
        WHERE post_id='.$post.'');
        $data1 = mysql_fetch_assoc($requete1);
        $topic = $data1['topic_id'];
        $forum = $data1['forum_id'];
       
        //Ensuite on v�rifie que le membre a le droit d'�tre ici 
        //(soit le cr�ateur soit un modo/admin)
        if (!verif_auth($data1['auth_modo']))
        {
                // Si cette condition n'est pas remplie �a va barder :o
                echo'<p>Vous n\'avez aucun droit d\'�tre ici</p></div></body></html>';
                exit();
        }
        else //Sinon �a roule et on continue
        {
                //Ici on v�rifie plusieurs choses :
                //est-ce un premier post ? Dernier post ou post classique ?
 
                $requete_first_post = mysql_query("SELECT COUNT(*)
                AS first_post
                FROM forum_topic
                WHERE topic_first_post = $post");
 
                $requete_last_post = mysql_query("SELECT COUNT(*)
                AS last_post
                FROM forum_topic
                WHERE topic_last_post = $post");
               
                $first_post = mysql_fetch_assoc($requete_first_post);
                $last_post = mysql_fetch_assoc($requete_last_post);
               
               
                //On distingue maintenant les cas
                if ($first_post['first_post'] != 0) 
                //Si le message est le premier
                {
 
                        //Les autorisations ont chang� !
                        if (!verif_auth($data1['auth_modo']))
                        {
                                echo'<p>
                                Vous n\'avez aucun droit d\'�tre ici</p></div></body></html>';
                                exit();
                        }
                        //Il faut s'assurer que ce n'est pas une erreur
 
                        echo'<p>Vous avez choisi de supprimer un post.
                        Cependant ce post est le premier du topic. 
                        Voulez vous supprimer le topic ? <br />
             <a href="./postok.php?action=delete_topic&amp;t='.$topic.'">oui</a> 
                        - <a href="./voirtopic.php?t='.$topic.'">non</a></p>';
 
                     
                }
 
                elseif ($last_post['last_post'] != 0) 
                //Si le message est le dernier
 
                {
 
                        //On supprime le post
                        mysql_query("DELETE FROM forum_post
                        WHERE post_id = '".$post."'");
                       
                        //On modifie la valeur de topic_last_post pour cela on
                        //r�cup�re l'id du plus r�cent  message de ce topic
                        $requete4 = mysql_query('SELECT post_id
                        FROM forum_post
                        WHERE topic_id = '.$topic.'
                        ORDER BY post_id DESC
                        LIMIT 0,1');
                        $data4 = mysql_fetch_assoc($requete4);

 
                        //On fait de m�me pour forum_last_post_id
                        $requete5 = mysql_query('SELECT post_id
                        FROM forum_post
                        WHERE post_forum_id = '.$forum.'
                        ORDER BY post_id DESC
                        LIMIT 0,1');
                        $data5 = mysql_fetch_assoc($requete5);

                       
                        //On met � jour la valeur de topic_last_post
                        mysql_query("UPDATE forum_topic
                        SET topic_last_post = '".$data4['post_id']."'
                        WHERE topic_last_post = '".$post."'");
 
                        //On enl�ve 1 au nombre de messages du forum et on met �       
                        //jour forum_last_post
                        mysql_query("UPDATE forum_forum
                        SET forum_post = '.forum_post - 1.',
                        forum_last_post_id = '".$data5['post_id']."'
                        WHERE forum_id = '".$forum."'");
 
                        //On enl�ve 1 au nombre de messages du topic
                        mysql_query("UPDATE forum_topic
                        SET  topic_post = topic_post - 1
                        WHERE topic_id = $topic");
                       
                        //On enl�ve 1 au nombre de messages du membre
                        mysql_query("UPDATE comptes
                        SET  membre_post = membre_post - 1
                        WHERE account_id = '".$data1['post_createur']."'");
 
                        //Enfin le message
                        echo'<p>Le message a bien �t� supprim� !<br />
                        Cliquez <a href="./voirtopic.php?t='.$topic.'">ici</a> 
                        pour retourner au topic<br />
                        Cliquez <a href="./index.php">ici</a> 
                        pour revenir � l index du forum</p>';
 
                }
 
                elseif ($last_post['last_post'] == 0 
                && $first_post['first_post'] == 0) // Si c'est un post classique
 
                {
 
                        //On supprime le post
                        mysql_query("DELETE FROM forum_post
                        WHERE post_id = $post");
                       
                        //On enl�ve 1 au nombre de messages du forum
                        mysql_query("UPDATE forum_forum
                        SET  forum_post = forum_post - 1
                        WHERE forum_id ='".$forum."'");
                       
                        //On enl�ve 1 au nombre de messages du topic
                        mysql_query("UPDATE forum_topic
                        SET  topic_post = topic_post - 1
                        WHERE topic_id = $topic");
                       
                        //On enl�ve 1 au nombre de messages du membre
                        mysql_query("UPDATE comptes
                        SET  membre_post = membre_post - 1
                        WHERE account_id = '".$data1['post_createur']."'");
                       
                        //Enfin le message
                        echo'<p>Le message a bien �t� supprim� !<br />
                        Cliquez <a href="./voirtopic.php?t='.$topic.'">ici</a> pour retourner au topic<br />
                        Cliquez <a href="./index.php">ici</a> pour revenir � l index du forum</p>';
                }
               
        }
break;



case "deplacer":

	$topic = (int) $_GET['t'];
	$requete1 = mysql_query('
	SELECT forum_topic.forum_id, auth_modo
	FROM forum_topic
	LEFT JOIN forum_forum 
        ON forum_forum.forum_id = forum_topic.forum_id
	WHERE topic_id = '.$topic.'');
	$data1 = mysql_fetch_assoc($requete1);
        if (!verif_auth($data1['auth_modo']))
        {
                // Si cette condition n'est pas remplie �a va barder :o
                echo'<p>Vous n\'avez aucun droit d\'�tre ici</p></div></body></html>';
                exit();
        }
        else //Sinon �a roule et on continue
        {
                $destination = (int) $_POST['dest'];
                $origine = (int ) $_POST['from'];
               
                //On d�place le topic
                mysql_query("UPDATE forum_topic
                SET forum_id = '".$destination."'
                WHERE topic_id = '".$topic."'")
                or die ("Un probl�me est survenu lors du d�placement");
 
                //On d�place les posts
                mysql_query("UPDATE forum_post
                SET post_forum_id = '".$destination."'
                WHERE topic_id = '".$topic."'")
                or die ("Un probl�me est survenu lors du d�placement");
               
                //On s'occupe d'ajouter / enlever les nombres de post / topic aux
                //forum d'origine et de destination
                //Pour cela on compte le nombre de post d�plac�
               
                $post_number_requete = mysql_query("SELECT COUNT(*)
                AS nombre_post
                FROM forum_post
                WHERE topic_id = '".$topic."'")
                or die ("Un probl�me est survenu lors du d�placement");
 
                $data_post_number = mysql_fetch_assoc($post_number_requete);
                $nombrepost = $data_post_number['nombre_post'];
               
                //Il faut �galement v�rifier qu'on a pas d�plac� un post qui �t�
                //l'ancien premier post du forum (champ forum_last_post_id)
 
                $requete1 = mysql_query('SELECT post_id
                FROM forum_post
                WHERE post_forum_id = '.$origine.'
                ORDER BY post_id DESC
                LIMIT 0,1')
                or die ("Un probl�me est survenu lors du d�placement");
 
                $data1 = mysql_fetch_assoc($requete1);
               
                //Puis on met � jour le forum d'origine
                mysql_query("UPDATE forum_forum
                SET forum_post = forum_post - '".$nombrepost."',
                forum_topic = forum_topic - 1,
                forum_last_post_id = '".$data1['post_id']."'
                WHERE forum_id = '".$origine."'");
 
                //Avant de mettre � jour le forum de destination il faut
                //v�rifier la valeur de forum_last_post_id
                $requete2 = mysql_query('SELECT post_id
                FROM forum_post WHERE post_forum_id = '.$destination.'
                ORDER BY post_id DESC
                LIMIT 0,1')
                or die ("Un probl�me est survenu lors du d�placement");
 
                $data2 = mysql_fetch_assoc($requete2);
 
                //Et on met � jour enfin !
                mysql_query("UPDATE forum_forum
                SET forum_post = forum_post + '".$nombrepost."',
                forum_topic = forum_topic + 1,
                forum_last_post_id = '".$data2['post_id']."'
                WHERE forum_id = '".$destination."'")
                or die ("Un probl�me est survenu lors du d�placement");
 
                //C'est gagn� ! On affiche le message
                echo'<p>Le topic a bien �t� d�plac� <br />
                Cliquez <a href="./club.php?zone=forums&amp;page=viewtopic&amp;t='.$topic.'">ici</a> 
                pour revenir au topic<br />
                Cliquez <a href="./club.php?zone=forums">ici</a> 
                pour revenir � l index du forum</p>';
        }
break;

default;
echo'<p>Cette action est impossible</p>';
} //Fin du Switch
} //Fin du else, le membre est connect�
?>