<?php
//----------------------------------------------------------------------
//										
// SMOP Sport Manager Open Source					
// Le projet est open source - sous license GPL			
// Vous �tes libre de l'utiliser mais pas � des fins commercial	
//										
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@emu-fr.com	
//										
//----------------------------------------------------------------------

include('forums/includes/config.php');
include('forums/includes/debut.php');
include('forums/protection/auth.php');
include("includes/javascript.php");
include("includes/bbcode.php");
mysql_connect($host,$user,$mdp);
mysql_select_db($db);

//Qu'est ce qu'on veut faire ? poster, r�pondre ou �diter ?
$action = htmlspecialchars($_GET['action']);
 
//Si on veut poster un nouveau topic, la variable f se trouve dans l'url,
//On r�cup�re certaines valeurs
if (isset($_GET['f']))
{
$forum = (int) $_GET['f'];
$requete1 = mysql_query('
SELECT forum_name, auth_view, auth_post, auth_topic, auth_annonce, auth_modo
FROM forum_forum
WHERE forum_id ="'.$forum.'"') or die(mysql_error());
$data1 = mysql_fetch_array($requete1);
if (!verif_auth($data1['auth_view']))
{
exit("Vous n avez pas le droit de vous trouver ici ! </div></body></html>");
}


?>
 
<p>
<a href ="./club.php?zone=forums">Index du forum</a> /
<a href="./club.php?zone=forums&amp;page=viewforum&amp;f=<?php echo ''.$forum.''; ?>"><?php echo ''.$data1['forum_name'].''; ?></a></p>
 
<?php
}
 
//Sinon c'est un nouveau message, on a la variable t et
//On r�cup�re f gr�ce � une requ�te
elseif (isset($_GET['t']))
{
$topic = (int) $_GET['t'];
$requete1 = mysql_query('
SELECT topic_titre, forum_topic.forum_id,
forum_name, auth_view, auth_post, auth_topic, auth_annonce, auth_modo
FROM forum_topic
LEFT JOIN forum_forum ON forum_forum.forum_id = forum_topic.forum_id
WHERE topic_id ="'.$topic.'"')or die(mysql_error());
$data1 = mysql_fetch_array($requete1);
$forum = $data1['forum_id'];
?>
 
<p>
<a href ="./club.php?zone=forums">Index du forum</a> /
<a href="./club.php?zone=forums&amp;page=viewforum&amp;f=<?php echo $data1['forum_id'] ?>"><?php echo $data1['forum_name'] ?></a> /
<a href="./club.php?zone=forums&amp;page=viewtopic&amp;t=<?php echo $topic ?>"><?php echo $data1['topic_titre'] ?></a></p>
<?php
}
 
//Enfin sinon c'est au sujet de la mod�ration(on verra plus tard en d�tail)
//On ne connait que le post, il faut chercher le reste
elseif (isset ($_GET['p']))
{
$post = $_GET['p'];
$requete1 = mysql_query('
SELECT forum_post.topic_id, topic_titre, forum_topic.forum_id,
forum_name, auth_view, auth_post, auth_topic, auth_annonce, auth_modo
FROM forum_post
LEFT JOIN forum_topic ON forum_topic.topic_id = forum_post.topic_id
LEFT JOIN forum_forum ON forum_forum.forum_id = forum_topic.forum_id
WHERE forum_post.post_id ="'.$post.'"')or die(mysql_error());
$data1 = mysql_fetch_array($requete1);
$topic = $data1['topic_id'];
$forum = $data1['forum_id'];
?>
<a href ="./club.php?zone=forums">Index du forum</a> /
<a href="./club.php?zone=forums&amp;page=viewforum&amp;f=<?php echo $data1['forum_id'] ?>"><?php echo $data1['forum_name'] ?></a> /
<a href="./club.php?zone=forums&amp;page=viewtopic&amp;t=<?php echo $topic ?>"><?php echo $data1['topic_titre'] ?></a></p>
<?php
}
 
 
//Ici on s'int�resse au visiteur
if (isset($_SESSION['pseudo'])) // Si le membre est connect�
{
       
        //Voici les options
        echo'<p>Vous �tes connect� en tant que
        <a href="./club.php?zone=forums&amp;page=profil&amp;m='.$_SESSION['id'].'&action=consulter">
        '.$_SESSION['pseudo'].'</a><br />
        <a href="./club.php?zone=forums&amp;page=profil&amp;action=modifier">Modifier mon profil</a><br />
        <a href="./club.php?zone=bureaumanager&amp;page=mp">Consulter mes messages priv�s</a><br />
        <a href ="./club.php?zone=deconnexion">Se d�connecter</a><br /></p>';
 
}
 
// Sinon l'acc�s � cette page est interdit ! ^^
else
{
        exit("D�sol�, vous devez �tre enregistr� pour poster");
}
switch($action)
{

case "repondre": //Premier cas : on souhaite r�pondre
if (!verif_auth($data1['auth_view']))
{
exit("Vous n avez pas le droit de vous trouver ici ! </div></body></html>");
}
//Ici, on affiche le formulaire de r�ponse
break;
 
case "nouveautopic": //Deuxi�me cas : on souhaite cr�er un nouveau topic
//Ici, on affiche le formulaire de nouveau topic
if (!verif_auth($data1['auth_view']))
{
exit("Vous n avez pas le droit de vous trouver ici ! </div></body></html>");
}
break;
 
//D'autres cas viendront s'ajouter l� plus tard :p
 
default; //Si jamais c'est aucun de ceux-l�, c'est qu'il y a eu un probl�me :o
echo'<h2>Cette action est impossible</h2>';
 
} //Fin du switch
switch($action)
{
case "repondre": //Premier cas on souhaite r�pondre
?>
<h1>Poster une r�ponse</h1>
 
<form method="post" action="club.php?zone=forums&amp;page=postok&amp;action=repondre&amp;t=<?php echo $topic ?>" name="formulaire">
 
<fieldset><legend>Mise en forme</legend>
<input type="button" id="gras" name="gras" value="Gras" onClick="javascript:bbcode('[g]', '[/g]');return(false)" />
<input type="button" id="italic" name="italic" value="Italic" onClick="javascript:bbcode('[i]', '[/i]');return(false)" />
<input type="button" id="soulign�" name="soulign�" value="Soulign�" onClick="javascript:bbcode('[s]', '[/s]');return(false)" />
<input type="button" id="lien" name="lien" value="Lien" onClick="javascript:bbcode('[url]', '[/url]');return(false)" />
<input type="button" id="Centr�" name="Centr�" value="Centr�" onClick="javascript:bbcode('[c]', '[/c]');return(false)" />
<br /><br />
<img src="./images/smileys/heureux.gif" title="heureux" alt="heureux" onClick="javascript:smilies(' :D ');return(false)" />
<img src="./images/smileys/lol.gif" title="lol" alt="lol" onClick="javascript:smilies(' :lol: ');return(false)" />
<img src="./images/smileys/triste.gif" title="triste" alt="triste" onClick="javascript:smilies(' :triste: ');return(false)" />
<img src="./images/smileys/cool.gif" title="cool" alt="cool" onClick="javascript:smilies(' :frime: ');return(false)" />
<img src="./images/smileys/rire.gif" title="rire" alt="rire" onClick="javascript:smilies(' XD ');return(false)" />
<img src="./images/smileys/confus.gif" title="confus" alt="confus" onClick="javascript:smilies(' :s ');return(false)" />
<img src="./images/smileys/choc.gif" title="choc" alt="choc" onClick="javascript:smilies(' :o ');return(false)" />
<img src="./images/smileys/question.gif" title="?" alt="?" onClick="javascript:smilies(' :interrogation: ');return(false)" />
<img src="./images/smileys/exclamation.gif" title="!" alt="!" onClick="javascript:smilies(' :exclamation: ');return(false)" />
</fieldset>
 
<fieldset><legend>Message</legend><textarea cols="80" rows="8" id="message" name="message"></textarea></fieldset>
 
<input type="submit" name="submit" value="Envoyer" />
<input type="reset" name = "Effacer" value = "Effacer"/>
</p></form>
<?php
break;
 
case "nouveautopic":
?>
 
<h1>Nouveau topic</h1>
<form method="post" action="club.php?zone=forums&amp;page=postok&amp;action=nouveautopic&amp;f=<?php echo $forum ?>" name="formulaire">
 
<fieldset><legend>Titre</legend>
<input type="text" size="80" id="titre" name="titre" /></fieldset>
 
<fieldset><legend>Mise en forme</legend>
<input type="button" id="gras" name="gras" value="Gras" onClick="javascript:bbcode('[g]', '[/g]');return(false)" />
<input type="button" id="italic" name="italic" value="Italic" onClick="javascript:bbcode('[i]', '[/i]');return(false)" />
<input type="button" id="soulign�" name="soulign�" value="Soulign�" onClick="javascript:bbcode('[s]', '[/s]');return(false)" />
<input type="button" id="lien" name="lien" value="Lien" onClick="javascript:bbcode('[url]', '[/url]');return(false)" />
<input type="button" id="Centr�" name="Centr�" value="Centr�" onClick="javascript:bbcode('[c]', '[/c]');return(false)" />
<br /><br />
<img src="./images/smileys/heureux.gif" title="heureux" alt="heureux" onClick="javascript:smilies(':D');return(false)" />
<img src="./images/smileys/lol.gif" title="lol" alt="lol" onClick="javascript:smilies(':lol:');return(false)" />
<img src="./images/smileys/triste.gif" title="triste" alt="triste" onClick="javascript:smilies(':triste:');return(false)" />
<img src="./images/smileys/cool.gif" title="cool" alt="cool" onClick="javascript:smilies(':frime:');return(false)" />
<img src="./images/smileys/rire.gif" title="rire" alt="rire" onClick="javascript:smilies('XD');return(false)" />
<img src="./images/smileys/confus.gif" title="confus" alt="confus" onClick="javascript:smilies(':s');return(false)" />
<img src="./images/smileys/choc.gif" title="choc" alt="choc" onClick="javascript:smilies(':O');return(false)" />
<img src="./images/smileys/question.gif" title="?" alt="?" onClick="javascript:smilies(':interrogation:');return(false)" />
<img src="./images/smileys/exclamation.gif" title="!" alt="!" onClick="javascript:smilies(':exclamation:');return(false)" /></fieldset>
 
<fieldset><legend>Message</legend>
<textarea cols=80 rows=8 id="message" name="message"></textarea>
<br />
<?php
if (verif_auth($data1['auth_annonce']))
{
?>
<label><input type="radio" name="mess" value="Annonce" />Annonce</label>
<label><input type="radio" name="mess" value="Message" checked="checked" />Topic</label><br />
<?php
}
?>
<input type="submit" name="submit" value="Envoyer" />
<input type="reset" name ="Effacer" value ="Effacer" />
</form></p>
<?php
break;
 





case "edit": //Si on veut �diter le post

//On r�cup�re la valeur de p
$post = (int) $_GET['p'];
echo'<h1>Edition</h1>';
 
//On lance enfin notre requ�te
 
$requete2 = mysql_query('
SELECT post_createur, post_texte, auth_modo
FROM forum_post
LEFT JOIN forum_forum ON forum_post.post_forum_id = forum_forum.forum_id
WHERE post_id='.$post.'');
$data2 = mysql_fetch_assoc($requete2);
$text_edit = $data2['post_texte'];
//on utilise la fonction cr��e dans le fichier fonction (pensez � l'inclure)
 
//Ensuite on v�rifie que le membre a le droit d'�tre ici (soit le cr�ateur soit un modo/admin)
 
if (!verif_auth($data2['auth_modo']) && $data2['post_createur'] != $_SESSION['id'] )
{
// Si cette condition n'est pas remplie �a va barder :o
echo'<p>Vous n\'avez aucun droit d\'�tre ici</p></div></body></html>';
exit();
}
else //Sinon �a roule et on affiche la suite
{
//Le formulaire de postage
?>

<form method="post" action="club.php?zone=forums&amp;page=postok&amp;action=edit&amp;p=<?php echo $post ?>" name="formulaire">
<fieldset><legend>Mise en forme</legend>
<input type="button" id="gras" name="gras" value="Gras" onClick="javascript:bbcode('[g]', '[/g]');return(false)" />
<input type="button" id="italic" name="italic" value="Italic" onClick="javascript:bbcode('[i]', '[/i]');return(false)" />
<input type="button" id="soulign�" name="soulign�" value="Soulign�" onClick="javascript:bbcode('[s]', '[/s]');return(false)" />
<input type="button" id="lien" name="lien" value="Lien" onClick="javascript:bbcode('[url]', '[/url]');return(false)" />
<br /><br />
<img src="./images/smileys/heureux.gif" title="heureux" alt="heureux" onClick="javascript:smilies(':D');return(false)" />
<img src="./images/smileys/lol.gif" title="lol" alt="lol" onClick="javascript:smilies(':lol:');return(false)" />
<img src="./images/smileys/triste.gif" title="triste" alt="triste" onClick="javascript:smilies(':triste:');return(false)" />
<img src="./images/smileys/cool.gif" title="cool" alt="cool" onClick="javascript:smilies(':frime:');return(false)" />
<img src="./images/smileys/rire.gif" title="rire" alt="rire" onClick="javascript:smilies('XD');return(false)" />
<img src="./images/smileys/confus.gif" title="confus" alt="confus" onClick="javascript:smilies(':s');return(false)" />
<img src="./images/smileys/choc.gif" title="choc" alt="choc" onClick="javascript:smilies(':O');return(false)" />
<img src="./images/smileys/question.gif" title="?" alt="?" onClick="javascript:smilies(':interrogation:');return(false)" />
<img src="./images/smileys/exclamation.gif" title="!" alt="!" onClick="javascript:smilies(':exclamation:');return(false)" /></fieldset>
 
<fieldset><legend>Message</legend><textarea cols="80" rows="8" id="message" name="message">
<?php echo $text_edit  ?>
</textarea></fieldset>
<p>
<input type="submit" name="submit" value="Editer !" />
<input type="reset" name = "Effacer" value = "Effacer"/></p>
</form>
<?php
}
break; //Fin de ce cas :o

case "delete": //Si on veut supprimer le post
//On r�cup�re la valeur de p
$post = (int) $_GET['p'];
//Ensuite on v�rifie que le membre a le droit d'�tre ici
echo'<h1>Suppression</h1>';
$requete2 = mysql_query('
SELECT post_createur, auth_modo
FROM forum_post
LEFT JOIN forum_forum ON forum_post.post_forum_id = forum_forum.forum_id
WHERE post_id='.$post.'');
$data2 = mysql_fetch_assoc($requete2);
 
if (!verif_auth($data2['auth_modo']) && $data2['post_createur'] != $_SESSION['id'])
{
// Si cette condition n'est pas remplie �a va barder :o
echo'<p>Vous n\'avez aucun droit d\'�tre ici</p></div></body></html>';
exit();
}
else //Sinon �a roule et on affiche la suite
{
echo'<p>�tes vous certains de vouloir supprimer ce post ?</p>';
echo'<p><a href="./club.php?zone=forums&amp;page=postok&amp;action=delete&amp;p='.$post.'">Oui</a> ou <a href="./club.php?zone=forums">Non</a></p>';
}
break;



//D'autres cas viendront s'ajouter ici par la suite
default; //Si jamais c'est aucun de ceux l� c'est qu'il y a eu un probl�me :o
echo'<p>Cette action est impossible</p>';

} //Fin du switch
?>