<?php
function verif_auth($auth_necessaire)
{
//Dans un premier temps, on v�rifie si le membre est connect�
if(isset($_SESSION['id'])) $auth = intval($_SESSION['level']);
else $auth = 1;
if ($auth_necessaire < $auth) return true;
else return false;
}
?>

<?php
if(verif_auth(1))
{
//Afficher le forum
}
else
{
//Laisser tomber :p
}
?>