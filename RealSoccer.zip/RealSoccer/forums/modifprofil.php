<?php
//-------------------------------------------------------------------------------------//
//											//
// SMOP Sport Manager Open Source					//
// Le projet est open source - sous license GPL				//
// Vous �tes libre de l'utiliser mais pas � des fins commercial		//
//											//
// 											//
//											//
//-------------------------------------------------------------------------------------//

$titre = 'Index du forum';
include('forums/includes/config.php');
include('forums/includes/debut.php');
include('forums/protection/auth.php');
mysql_connect($host,$user,$mdp);
mysql_select_db($db);

//Encore est toujours notre belle variable $i :p
$i = 0;

//V�rification du mdp
if ($_POST['mdp'] != $_POST['confirm'] || empty($_POST['confirm']) || empty($_POST['mdp']))
{
$mdp_erreur = ERRORMDP;
$i++;
}

//V�rification de l'adresse email

//Il faut que l'adresse email n'ait jamais �t� utilis�e (sauf si elle n'a pas �t� modifi�e)
$requete1 = mysql_query('SELECT email FROM comptes WHERE account_id = '.$_SESSION['id'].'');
$data1 = mysql_fetch_assoc($requete1);
if (strtolower($data1['email']) != strtolower($_POST['email']))
{
        $nombremail = mysql_result(mysql_query("SELECT COUNT(*) FROM comptes WHERE email = '".$_POST['email']."'"), 0);

        if ($nombremail!= 0)
        {
        $email_erreur1 = MAILEXIST;
        $i++;
        }

        //On v�rifie la forme maintenant
        if (!preg_match("#^[a-z0-9A-Z._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#", $_POST['email']) || empty($_POST['email']))
        {
        $email_erreur2 = MAILNOTVALID;
        $i++;
        }
}
//V�rification de l'adrese msn
if (!preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#", $_POST['msn']) && !empty($_POST['msn']))
{
$msn_erreur = MSNNOTVALID;
$i++;
}

//V�rification de la signature
if (strlen($_POST['signature']) > 200)
{
$signature_erreur = SIGNTOOLONG;
$i++;
}


//V�rification de l'avatar

        if (!empty($_FILES['avatar']['size']))
        {
        //On d�finit les variables :
        $maxsize = 30072; //Poid de l'image
        $maxwidth = 100; //Largeur de l'image
        $maxheight = 100; //Longueur de l'image
        //Liste des extensions valides
        $extensions_valides = array( 'jpg' , 'jpeg' , 'gif' , 'png', 'bmp' );

        if ($_FILES['avatar']['error'] > 0)
        {
        $avatar_erreur = ERRORTRANSAVAT;
        }
        if ($_FILES['avatar']['size'] > $maxsize)
        {
        $i++;
        $avatar_erreur1 = FILETROGROS . " 
        (<strong>".$_FILES['avatar']['size']. OCTET . "</strong>" . CONTRE . "
         <strong>".$maxsize. OCTET . "</strong>)";
        }

        $image_sizes = getimagesize($_FILES['avatar']['tmp_name']);
        if ($image_sizes[0] > $maxwidth OR $image_sizes[1] > $maxheight)
        {
        $i++;
        $avatar_erreur2 = IMAGENOTVALID . " 
        (<strong>".$image_sizes[0]."x".$image_sizes[1]."</strong>" . CONTRE . " 
        <strong>".$maxwidth."x".$maxheight."</strong>)";
        }

        $extension_upload = strtolower(substr(  strrchr($_FILES['avatar']['name'], '.')  ,1));
        if (!in_array($extension_upload,$extensions_valides) )
        {
                $i++;
                $avatar_erreur3 = EXTNOTVALID;
        }
}
if ($i == 0) // Si $i est vide, il n'y a pas d'erreur
{
        if (!empty($_FILES['avatar']['size']))
        {
                //On d�place l'avatar
                $avatar = time();
                $nomavatar = str_replace(' ','',$avatar).".".$extension_upload;
                $avatar = "./images/forums/avatars/".str_replace(' ','',$avatar).".".$extension_upload;
                move_uploaded_file($_FILES['avatar']['tmp_name'],$avatar);
                mysql_query("UPDATE comptes
                SET membre_avatar = '".$nomavatar."' 
                WHERE account_id = '".$_SESSION['id']."'");
        }

        //Une nouveaut� ici : on peut choisisr de supprimer l'avatar
        if (isset($_POST['Delete']))
        {
                mysql_query("DELETE membre_avatar 
                FROM comptes WHERE account_id = '".$_SESSION['id']."'");
        }

        echo'<h1>' . MODIFEND . '</h1>';
        echo'<p>' . SUCESS . '</p>';
        echo'<p>' . CLICK . ' <a href="./club.php?zone=forums">' . HERE . '</a>' . REVACC . '</p>';

        //On v�rifie que les champs ne contiennent pas de html 
        //et on crypte le mot de passe

        $pass = md5($_POST['mdp']);
        $signature = htmlentities($_POST['signature'], ENT_QUOTES);
        $signature = nl2br($signature);
        $email = htmlspecialchars($_POST['email'], ENT_QUOTES);
        $msn = htmlspecialchars($_POST['msn'], ENT_QUOTES);
        $website = htmlspecialchars($_POST['website'], ENT_QUOTES);
        $localisation = htmlspecialchars($_POST['localisation'], ENT_QUOTES);

        //On modifie la table

        mysql_query("
        UPDATE comptes
        SET  mdp ='".$pass."' , email = '".$email."' ,
        membre_msn = '".$msn."' , membre_siteweb = '".$website."',
        membre_signature = '".$signature."' ,
        membre_localisation = '".$localisation."'
        WHERE account_id = '".$_SESSION['id']."'") or die (mysql_error());

        //Et on d�finit de nouvelles variables de sesssion
        //Pour cel� on a besoin de la bdd
        $requete = mysql_query('
        SELECT account_id, rang
        FROM comptes
        WHERE account_id = '.$_SESSION['id'].'');

        if ($data = mysql_fetch_assoc($requete))
        {
        $_SESSION['id'] = $data['account_id'];
        $_SESSION['level'] = $data['rang'];
        }
}
else
{
        echo'<h1>' . ERRORMODIF . '</h1>';
        echo'<p>' . ERRORMODIFPROFIL . '</p>';
        echo'<p>'.$i.' ' . ERROR . '</p>';
        echo'<p>'.$mdp_erreur.'</p>';
        echo'<p>'.$email_erreur1.'</p>';
        echo'<p>'.$email_erreur2.'</p>';
        echo'<p>'.$msn_erreur.'</p>';
        echo'<p>'.$signature_erreur.'</p>';
        echo'<p>'.$avatar_erreur.'</p>';
        echo'<p>'.$avatar_erreur1.'</p>';
        echo'<p>'.$avatar_erreur2.'</p>';
        echo'<p>'.$avatar_erreur3.'</p>';
        echo'<p> ' . CLICK . '
 <a href="./club.php?zone=forums&amp;page=profil&amp;action=modifier">' . HERE . '</a> ' . RECOM . '</p>';
}