<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }
?>
<table width="100%" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
	  <td valign="top">
		<div class="homepage_border">
		<div class="homepage_sub_header"><?php echo MESSAGERIECLUB; ?></div>
		<table width="100%" cellpadding="0" cellspacing="0">
		  <tbody>
		   <?php
			  $req = sql::query("SELECT * FROM equipes_mess_interne WHERE team_id IN('".$info['team_id']."', 0) ORDER BY date DESC");
			  while($view = mysql_fetch_assoc($req))
			  {
		   ?>
		   <tr>
			<td class="homepage_sub_row">
			 <?php echo $club->mess_interne_choose($view['date'], $view['ch_1'], $view['ch_2'], $view['ch_3'], $view['ch_4'], $view['ch_5'], $view['mode'], $view['url'], $info); ?>
			</td>
		   </tr>
		   <?php
			  }
		   ?>
		   <tr>
		    <td class="homepage_sub_row">
			 <div align="right"><a href="club.php?zone=bureaumanager&amp;page=messagerieclub"><?php echo PLUS; ?></a></div>
			</td>
		  </tr>
		  </tbody>
		 </table>
		</div>
	  </td>
	</tr>
  </tbody>
</table>