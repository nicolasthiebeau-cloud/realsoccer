<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

$demande = sql::fetch("SELECT COUNT(*) AS exist FROM joueurs_achat_demande WHERE team_accept= '".$info['team_id']."'");
if($demande['exist'] >= 1)
{
?>
  <tr>
   <td valign="top" width="100%">
    <div class="homepage_border">
	<div class="homepage_sub_header"><?php echo ACHAT_DMD; ?></div>
	 <table width="100%" cellpadding="1" cellspacing="0">
	  <tbody>
	   <?php
		  $req = sql::query("SELECT dmd_id, team_dmd, new_price, 
									joueurs.player_id, nom, prenom, 
									equipes.team_id, team_name 
							 FROM joueurs_achat_demande 
							 LEFT JOIN joueurs ON joueurs.player_id = joueurs_achat_demande.player_id 
							 LEFT JOIN equipes ON equipes.team_id = joueurs_achat_demande.team_dmd 
							 WHERE team_accept= '".$info['team_id']."' 
							 ORDER BY player_id");
		  
		  while($view = mysql_fetch_assoc($req))
		  {
	   ?>
	   <tr>
	    <td class="homepage_sub_row" width="80%">
		 <?php echo'
		 <a href="club.php?zone=public&amp;page=teaminfo&amp;id=' . $view['team_id'] . '">' . $view['team_name'] . '</a> : 
		 <a href="club.php?zone=management&page=joueur&id=' . $view['player_id'] . '">' . $view['nom'] . ' ' . $view['prenom'] . '</a> 
		 pour ' . $view['new_price'] . ' Euros'; ?>
	    </td>
		<td class="homepage_sub_row" width="20%">
		 <?php echo '<a href="club.php?page=bureaumanager&amp;mode=acceptoffre&amp;demande='. $view['dmd_id'] .'"><img src="images/icone/tick.gif" border="0" /></a>&nbsp;&nbsp;
		 <a href="club.php?page=bureaumanager&amp;mode=refuseoffre&amp;demande='. $view['dmd_id'] .'"><img src="images/icone/cross.gif" border="0" /></a>'; ?>
		</td>
	   </tr>
		 <?php } ?>
	  </tbody>
	 </table>
	</div>
   </td>
  </tr>
  <tr>
	<td>&nbsp;</td>
  </tr>
<?php
}
?>