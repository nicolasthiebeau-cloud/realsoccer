<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

$demande = sql::fetch("SELECT COUNT(*) AS exist FROM matchs_amical_demande WHERE team_accept= '".$info['team_id']."'");
if($demande['exist'] >= 1)
{
?>
  <tr>
   <td valign="top" width="100%">
    <div class="homepage_border">
	<div class="homepage_sub_header"><?php echo 'Demande de match amical'; ?></div>
	 <table width="100%" cellpadding="0" cellspacing="0">
	  <tbody>
	   <?php
		  $req = sql::query("SELECT * 
							 FROM matchs_amical_demande 
							 LEFT JOIN equipes ON equipes.team_id = matchs_amical_demande.team_dmd
							 WHERE team_accept= '".$info['team_id']."' 
							 ORDER BY timematch");
		  
		  while($view = mysql_fetch_assoc($req))
		  {
	   ?>
	   <tr>
	    <td class="homepage_sub_row" width="80%">
		 <?php echo date($info['dateformat_choice'], $view['timematch']) . ' ' . date($info['timeformat_choice'], $view['timematch']) . ' - ' . 
		$club->choosematchextdom($info['team_id'], $view['team_dom'], $view['team_ext']) . ' <a href="club.php?page=teaminfo&amp;id=' . $view['team_dmd'] . '">' . $view['team_name'] . '</a>'; ?>
		</td>
		<td class="homepage_sub_row" width="20%">
		 <?php echo '<a href="club.php?page=bureaumanager&amp;mode=acceptamical&amp;demande='. $view['dmd_id'] .'"><img src="images/icone/tick.gif" border="0" /></a>&nbsp;&nbsp;
		 <a href="club.php?page=bureaumanager&amp;mode=refuseamical&amp;demande='. $view['dmd_id'] .'"><img src="images/icone/cross.gif" border="0" /></a>'; ?>
		</td>
	   </tr>
	   <?php } ?>
	  </tbody>
	 </table>
	</div>
   </td>
  </tr>
  <tr>
	<td>&nbsp;</td>
  </tr>
<?php
}
?>