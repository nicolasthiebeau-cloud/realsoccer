<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

$req = sql::query("SELECT type, id, position, timestamp_fin FROM stamp_construction WHERE id_team ='".$info['team_id']."'");

if(isset($req['type']))
{
?>
    <div class="homepage_border">
	<div class="homepage_sub_header"><?php echo CONSTENCOURS; ?></div>
	<table width="100%" cellpadding="1" cellspacing="0">
	  <tbody>
	   <?php
		  while ($donnees = mysql_fetch_assoc($req))
		  {
	   ?>
	   <tr>
	    <td class="homepage_sub_row" width="30%">
		 <?php 	if($donnees['type'] == 'tribune') echo CONSTRUCTRIB . ' ' . $donnees['position'] . '';
			elseif($donnees['type'] == 'centreformation') echo CONSTRUCCFORMA . '<br />(' . NIV . ' ' . $donnees['id'] . ')';
			elseif($donnees['type'] == 'centreentrainement') echo CONSTRUCCENTR . "<br />(" . NIV . " " . $donnees['id'] . ")";
			else echo NOCONTRUC; ?>
		</td>
		<td class="homepage_sub_row" width="70%">
		 <?php echo ENDIN . ' ' . comparetimestamp($donnees['timestamp_fin']); ?>
		</td>
	   </tr>
	   <?php } ?>
	  </tbody>
	 </table>
	</div>
<?php
}
?>