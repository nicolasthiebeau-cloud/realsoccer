<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

?>
    <div class="homepage_border">
	<div class="homepage_sub_header"><?php echo 'Organiser un match'; ?></div>
	<table width="100%" cellpadding="1" cellspacing="0">
	  <tbody>
	   <tr>
	    <td class="homepage_sub_row" width="30%">
		<form action="" method="post">
		<input type="hidden" name="team_id" value="<?php echo $info2['team_id']; ?>" />
		<div align="center"><?php echo PLAYAT; ?>
		<select name="choixdomext">
		<option value="domicile"><?php echo DOMI; ?></option>
		<option value="exterieur"><?php echo EXTE; ?></option>
		</select><br /><br />
		<select name="datematch">
		<option value=""><?php echo CHOOSEDATE; ?></option>
		<?php
		//timestamp actuel
		$first_match = time() + (24 * 60 * 60) + ($CONF['decal_time'] * 60 * 60); //L'heure actuelle avec l'option decalage (timestamp);
		//timestamp de fin
		$doublematch = $first_match + ((2 * 2) * 24 * 60 * 60);
		
		//Boucle des jours entre les 2 timestamps
		while($first_match < $doublematch)
		{
			$datematch = date('Y-m-d', $first_match);
			
			$rencontre = sql::fetch("SELECT COUNT(*) exist FROM matchs WHERE (team_id1= '".$info['team_id']."' OR team_id2= '".$info['team_id']."') AND FROM_UNIXTIME(timematch, '%Y-%m-%d') = '".$datematch."'");
			$rencontre2 = sql::fetch("SELECT COUNT(*) exist FROM matchs WHERE (team_id1= '".$info2['team_id']."' OR team_id2= '".$info2['team_id']."') AND FROM_UNIXTIME(timematch, '%Y-%m-%d') = '".$datematch."'");
			$demande = sql::fetch("SELECT COUNT(*) exist FROM matchs_amical_demande WHERE team_dmd = '".$info['team_id']."' AND team_accept = '".$info2['team_id']."' AND FROM_UNIXTIME(timematch, '%Y-%m-%d') = '".$datematch."'");
			
			if($rencontre['exist'] == 0 AND $rencontre2['exist'] == 0  AND $demande['exist'] == 0)
			{
				echo'<option value="' . $datematch . '">' . date($info['dateformat_choice'], $first_match) . '</option>';
			}
			
			//Ajout d'un jour au timestamp actuel
			$first_match = $first_match + (24 * 60 * 60);
		}
		?>
		</select>
		&nbsp;&nbsp; � &nbsp;
		<input type="text" name="timematch" size="10" value="20:00" /><br /><br />
		<input name="orgamatch" type="submit" value="<?php echo FAIRE_DMD; ?>" /></div>
		</form>
		</td>
	   </tr>
	  </tbody>
	 </table>
	</div>