<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }
?>
<table width="100%" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
	  <td valign="top">
		<div class="homepage_border">
		<div class="homepage_sub_header"><?php echo 'Equipement'; ?></div>
		 <table width="100%" cellpadding="0" cellspacing="0">
		  <tbody>
		   <tr>
		    <td class="homepage_sub_row">
			 <div align="center"><?php ECHO DOMI; ?><br /><img src="images/shirt/<?php echo $info2['team_shirt_dom']; ?>" border="0" \></div>
			</td>
			<td class="homepage_sub_row">
			 <div align="center"><?php ECHO EXTE; ?><br /><img src="images/shirt/<?php echo $info2['team_shirt_ext']; ?>" border="0" \></div>
			</td>
		   </tr>
		  </tbody>
		 </table>
		</div>
	  </td>
	</tr>
  </tbody>
</table>