<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }
?>
<table width="100%" cellpadding="0" cellspacing="0">
 <tbody>
  <tr>
   <td valign="top" width="100%">
    <div class="homepage_border">
	<div class="homepage_sub_header"><?php echo 'Prochain match'; ?></div>
	 <table width="100%" cellpadding="0" cellspacing="0">
	  <tbody>
	   <tr>
	    <td class="homepage_sub_row">
		<?php echo $club->last_match($info['team_id']); ?>
		</td>
	   </tr>
	  </tbody>
	 </table>
	</div>
   </td>
  </tr>
 </tbody>
</table>