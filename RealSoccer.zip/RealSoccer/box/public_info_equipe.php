<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }
?>
<table width="100%" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
	  <td valign="top">
		<div class="homepage_border">
		<div class="homepage_sub_header"><?php echo INFOEQUIP; ?></div>
		 <table width="100%" cellpadding="0" cellspacing="0">
		  <tbody>
		   <tr>
		    <td class="homepage_sub_row" width="25%"><strong><?php echo NAME; ?></strong></td>
			<td class="homepage_sub_row" width="75%" colspan="3"><?php echo $info2['team_name']; ?></td>
		   </tr>
		   <tr>
		    <td class="homepage_sub_row" width="25%"><strong><?php echo LOCALI; ?></strong></td>
			<td class="homepage_sub_row" width="75%" colspan="3"><?php echo '<a href="club.php?zone=pays&amp;id='.$info2['pays_id'].'">' .  stripslashes($info2['pays_name']) . '</a> / <a href="club.php?zone=region&amp;id='.$info2['region_id'].'">' . stripslashes($info2['region_name']); ?></a></td>
		   </tr>
		   <tr>
		    <td class="homepage_sub_row" width="25%"><strong><?php echo DIV . ' / ' . POUL; ?></strong></td>
			<td class="homepage_sub_row" width="25%"><?php echo '<a href="club.php?zone=competition&amp;page=championnat&amp;id=' . $info2['pays_id'] . '&amp;division=' . $info2['division'] . '&amp;poule=' . $info2['poule'] . '">' . $info2['division'] . ' - ' . $info2['poule'] . '</a>'; ?></td>
			<td class="homepage_sub_row" width="25%"><strong><?php echo CLASMENT; ?></strong></td>
			<td class="homepage_sub_row" width="25%"><?php echo $club->position_classement($info2['team_id'], $info2['compet_id']); ?></td>
		   </tr>
		   <tr>
		    <td class="homepage_sub_row" width="25%"><strong><?php echo STADE; ?></strong></td>
			<td class="homepage_sub_row" width="25%"><?php $nameexpl = explode(';', $info2['stade_name']); echo $nameexpl[0]; ?></td>
				<td class="homepage_sub_row" width="25%"><strong><?php echo CAPACITY; ?></strong></td>
			<td class="homepage_sub_row" width="25%"><?php echo $club->capa_stade($info2['stade_infra']); ?></td>
		   </tr>
		   <?php if(isset($info2['team_devise']) && $info2['team_devise'] != NULL) { ?>
		   <tr>
		    <td class="homepage_sub_row" width="25%"><strong><?php echo DEVISE; ?></strong></td>
			<td class="homepage_sub_row" width="75%" colspan="3"><i><?php echo $info2['team_devise']; ?></i></td>
		   </tr>
		   <?php } ?>
		  </tbody>
		 </table>
		</div>
	  </td>
	</tr>
  </tbody>
</table>