<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }
?>
<table width="100%" cellpadding="0" cellspacing="0">
 <tbody>
   <tr>
   <td valign="top">
  	<div class="homepage_border">
	<div class="homepage_sub_header"><?php echo INFOMANAG; ?></div>
	 <table width="100%" cellpadding="0" cellspacing="0">
	  <tbody>
	   <tr>
	    <td class="homepage_sub_row" width="50%"><strong><?php echo MANAGER; ?></strong></td>
		<td class="homepage_sub_row" width="50%"><?php echo $info['coach_name'] . ' <a href="club.php?zone=bureaumanager&amp;page=mp&action=ecrire&member='.$info['pseudo'].'"><img src="images/icone/mp.png" width="16" height="16" border="0" /></a>'; ?></td>
	   </tr>
	   <tr>
	    <td class="homepage_sub_row" width="50%"><strong><?php echo DATEINSCRIP; ?></strong></td>
		<td class="homepage_sub_row" width="50%"><?php echo date($info['dateformat_choice'], $info['joindate']) . ' ' . date($info['timeformat_choice'], $info['joindate']); ?></td>
	   </tr>
	   <tr>
		<td class="homepage_sub_row" width="50%"><strong><?php echo LAST_CONNEC; ?></strong></td>
		<td class="homepage_sub_row" width="50%"><?php echo date($info['dateformat_choice'], $info['lastlogin']) . ' ' . date($info['timeformat_choice'], $info['lastlogin']); ?></td>
	   </tr>
	   <tr>
	    <td class="homepage_sub_row"><strong><?php echo LANG; ?></strong></td>
		<td class="homepage_sub_row"><?php echo $info['lang']; if($info['lang_other'] != NULL) echo $info['lang_other']; ?>
		</td>
	   </tr>
	   <?php
		$trainer = sql::fetch("SELECT staff_prenom, staff_nom FROM staff WHERE team_id= '".$info['team_id']."' AND poste_actu= 'Entraineur'");
		if ($trainer['staff_prenom'] != NULL) {
	   ?>
	   <tr>
	    <td class="homepage_sub_row"><strong><?php echo TRAINER; ?></strong></td>
		<td class="homepage_sub_row"><?php echo $trainer['staff_prenom'] . ' ' . $trainer['staff_nom']; ?>
		</td>
	   </tr>
	   <?php } ?>
	  </tbody>
	 </table>
	</div>
   </td>
  </tr>
 </tbody>
</table>