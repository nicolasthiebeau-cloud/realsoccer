<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }
?>
<table width="100%" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
	  <td valign="top">
	    <div class="homepage_border">
		<div class="homepage_sub_header"><?php echo TROPHY; ?></div>
		 <table width="100%" cellpadding="0" cellspacing="0">
		  <tbody>
		   <tr>
		    <td class="homepage_sub_row">
			 <?php
			 if(isset($info2['team_cup']) && $info2['team_cup'] != NULL)
			 {
				$cup = explode(';', $data['team_cup']); $nbr = 0;
			 
				while (count($cup) > $nbr)
				{
					echo '<img src="images/cup/' . $cup[$nbr] . '" border="0" />';
					$nbr++;
				}
			 }
			 
			 else echo'<br /><br />';
			 ?>
			</td>
		   </tr>
		  </tbody>
		 </table>
		</div>
	  </td>
	</tr>
  </tbody>
</table>