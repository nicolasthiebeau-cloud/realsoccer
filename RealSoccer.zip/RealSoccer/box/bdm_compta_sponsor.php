<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

$salaire_tot = $club->salaire_joueur_total($info['team_id']);
$nb_player = $club->nb_joueur($info['team_id']);
?>
<table width="100%" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
	  <td valign="top">
	    <div class="homepage_border">
	<div class="homepage_sub_header"><?php echo COMPTA . ' & Sponsor'; ?></div>
	 <table width="100%" cellpadding="0" cellspacing="0">
	  <tbody>
	   <tr>
	    <td class="homepage_sub_row"><?php echo FINANCE . ' : ' . $info['team_money'] . ' ' . $info['pays_money']; ?></b></td>
	   </tr>
	   <tr>
	    <td class="homepage_sub_row"><?php echo SALAIRE1 . $nb_player . SALAIRE2 . ' : ' . $salaire_tot . ' ' . $info['pays_money']; ?></td>
	   </tr>
	   <td class="homepage_sub_row"><?php echo $club->viewsponsor($info['sponsor_name'], $info['sponsor_money']); ?></td>
	  </tbody>
	 </table>
	</div>
	  </td>
	</tr>
  </tbody>
</table>