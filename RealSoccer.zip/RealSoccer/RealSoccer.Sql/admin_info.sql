-- phpMyAdmin SQL Dump
-- version OVH
-- http://www.phpmyadmin.net
--
-- Client: mysql51zfs-42.perso
-- G�n�r� le : Mer 16 Novembre 2011 � 18:19
-- Version du serveur: 5.1.49
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Base de donn�es: `realsoccrs1`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin_info`
--

CREATE TABLE IF NOT EXISTS `admin_info` (
  `adinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` int(10) NOT NULL,
  `ch_1` int(11) NOT NULL,
  `ch_2` int(11) NOT NULL,
  `ch_3` int(11) NOT NULL,
  `ch_4` int(11) NOT NULL,
  `ch_5` int(11) NOT NULL,
  `mode` tinyint(2) NOT NULL,
  `url` tinyint(2) NOT NULL,
  PRIMARY KEY (`adinfo_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Contenu de la table `admin_info`
--

INSERT INTO `admin_info` (`adinfo_id`, `datetime`, `ch_1`, `ch_2`, `ch_3`, `ch_4`, `ch_5`, `mode`, `url`) VALUES
(1, 1314035704, 1, 1, 1, 2, 0, 1, 1),
(2, 1315407836, 1, 1, 2, 3, 0, 1, 1),
(3, 1316305591, 1, 1, 3, 4, 0, 1, 1),
(4, 1316601186, 1, 1, 4, 5, 0, 1, 1),
(5, 1316618379, 1, 1, 5, 6, 0, 1, 1),
(6, 1316875811, 1, 1, 6, 7, 0, 1, 1),
(7, 1318698008, 1, 1, 7, 8, 0, 1, 1),
(8, 1318885130, 1, 1, 8, 9, 0, 1, 1),
(9, 1320248253, 1, 1, 9, 10, 0, 1, 1),
(10, 1320699628, 1, 1, 10, 11, 0, 1, 1),
(11, 1320864825, 10, 3, 11, 12, 0, 1, 1);
