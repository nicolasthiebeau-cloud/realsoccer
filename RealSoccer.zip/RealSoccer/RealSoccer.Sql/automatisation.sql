-- phpMyAdmin SQL Dump
-- version OVH
-- http://www.phpmyadmin.net
--
-- Client: mysql51zfs-42.perso
-- G�n�r� le : Mer 16 Novembre 2011 � 18:22
-- Version du serveur: 5.1.49
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Base de donn�es: `realsoccrs1`
--

-- --------------------------------------------------------

--
-- Structure de la table `automatisation`
--

CREATE TABLE IF NOT EXISTS `automatisation` (
  `auto_id` int(11) NOT NULL AUTO_INCREMENT,
  `auto_type` varchar(128) NOT NULL,
  `auto_date` date NOT NULL,
  PRIMARY KEY (`auto_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Contenu de la table `automatisation`
--

INSERT INTO `automatisation` (`auto_id`, `auto_type`, `auto_date`) VALUES
(1, 'salaire', '2011-08-22'),
(2, 'sponsor', '2011-08-23'),
(3, 'entrainement', '2011-08-24'),
(4, 'salaire', '2011-08-29'),
(5, 'entrainement', '2011-08-31'),
(6, 'salaire', '2011-09-05'),
(7, 'sponsor', '2011-09-06'),
(8, 'entrainement', '2011-09-07'),
(9, 'salaire', '2011-09-12'),
(10, 'sponsor', '2011-09-13'),
(11, 'entrainement', '2011-09-14'),
(12, 'salaire', '2011-09-19'),
(13, 'sponsor', '2011-09-20'),
(14, 'entrainement', '2011-09-21'),
(15, 'salaire', '2011-09-26'),
(16, 'sponsor', '2011-09-27'),
(17, 'entrainement', '2011-09-28'),
(18, 'salaire', '2011-10-03'),
(19, 'sponsor', '2011-10-04'),
(20, 'entrainement', '2011-10-05'),
(21, 'salaire', '2011-10-10'),
(22, 'sponsor', '2011-10-11'),
(23, 'entrainement', '2011-10-12'),
(24, 'salaire', '2011-10-17'),
(25, 'sponsor', '2011-10-18'),
(26, 'entrainement', '2011-10-19'),
(27, 'salaire', '2011-10-24'),
(28, 'sponsor', '2011-10-25'),
(29, 'entrainement', '2011-10-26'),
(30, 'salaire', '2011-10-31'),
(31, 'sponsor', '2011-11-01'),
(32, 'entrainement', '2011-11-02'),
(33, 'salaire', '2011-11-07'),
(34, 'entrainement', '2011-11-09'),
(35, 'salaire', '2011-11-14'),
(36, 'salaire', '2011-11-14'),
(37, 'sponsor', '2011-11-15'),
(38, 'entrainement', '2011-11-16');
