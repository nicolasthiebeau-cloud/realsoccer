<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['pays']) AND $FORM['mode'] == 'newsaison-part1')
{
	$pays_id = htmlentities(addslashes($FORM['pays']));
	$admin->new_saison_promoreleg($pays_id, $CONF);
}

elseif (isset($FORM['pays']) AND $FORM['mode'] == 'newsaison-part2')
{
	$pays_id = htmlentities(addslashes($FORM['pays']));
	$admin->new_saison_rencontre($pays_id, $CONF);
	
	//Redirection sur la page suivi
	echo "<meta http-equiv=\"refresh\" content=\"0;url=index.php?zone=management&page=champsuivi\">";
}

?>
<form action="" method="post">
<div class="tableborder">
 <div class="tableheaderalt"><?php echo CREANS; ?></div>
  <table width="100%">
   <tbody>
    <tr>
	 <td class="tablerow2" valign="middle" width="100%" colspan="3"><b><?php echo CREANS_INFO; ?></b></td>
	</tr>
	<?php
		$req = sql::query("SELECT * FROM pays WHERE pays_select = '1' AND pays_actif = '1'");
		
		while ($donnees = mysql_fetch_array($req))
		{
	?>
	<tr>
     <td class="tablerow2" align="center"><?php echo $donnees['pays_name']; ?></td>
	 <td class="tablerow2" align="center"><?php echo'<a href="index.php?zone=management&amp;page=saisonnew&amp;pays=' . $donnees['pays_id'] . '&amp;mode=newsaison-part1">' . PART1 . '</a>'; ?></td>
	 <td class="tablerow2" align="center"><?php echo'<a href="index.php?zone=management&amp;page=saisonnew&amp;pays=' . $donnees['pays_id'] . '&amp;mode=newsaison-part2">' . PART2 . '</a>'; ?></td>
	</tr>
	<?php
		}
	?>
   </tbody>
  </table>
 </div>
</form>