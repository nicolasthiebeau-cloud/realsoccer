<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
07/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

?>
<div class="outerdiv" id="global-outerdiv"><!-- OUTERDIV -->
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
   <tbody>
    <tr>
	 <td id="rightblock" valign="top" width="100%">
	  <div style="border-bottom: 1px solid rgb(237, 237, 237); font-size: 30px; padding-left: 7px; letter-spacing: -2px;">
	  <?php echo 'RS Admin - ' . TT_INDEX;  ?>
	  </div>
	  <br />
	   <table width="100%" border="0" cellpadding="0" cellspacing="4">
	    <tbody>
		 <tr>
		  <td valign="top" width="75%">
		   <table width="100%" border="0" cellpadding="0" cellspacing="0">
		    <tbody>
			 <tr>
			  <td>
			   <div class="homepage_pane_border">
			   <div class="homepage_section"><?php echo LASTNEWS; ?></div>
			    <table width="100%" cellpadding="4" cellspacing="0">
				 <tbody>
				  <tr>
				   <td valign="top" width="50%">
					<div class="homepage_border">
					<div class="homepage_sub_header"><?php echo JOUEUR; ?></div>
					 <table width="100%" cellpadding="4" cellspacing="0">
					  <tbody>
					   <?php
						$req = sql::query("SELECT datetime, pays_flag, compet_name, team_name, pseudo  
											FROM admin_info 
											LEFT JOIN pays ON pays.pays_id = admin_info.ch_1 
											LEFT JOIN competition ON competition.compet_id = admin_info.ch_2 
											LEFT JOIN equipes ON equipes.team_id = admin_info.ch_3 
											LEFT JOIN comptes ON comptes.account_id = admin_info.ch_4 
											WHERE mode = 1 
											ORDER BY adinfo_id DESC LIMIT 5");
						
						while ($donnees = mysql_fetch_assoc($req))
						{
							echo'
						   <tr>
						    <td class="homepage_sub_row" width="5%"><img src="../images/flag/' . $donnees['pays_flag'] . '" width="28" height="16" /></td>
							<td class="homepage_sub_row" width="95%">' . date('d/m/y', $donnees['datetime']) . ' - ' . NEW_MEM . ' ' . 
							$donnees['compet_name'] . ' : ' . $donnees['team_name'] . ' (' . $donnees['pseudo'] . ').</td>
						   </tr>';
						}
					   ?>
					   <tr>
						<td class="homepage_sub_row" width="100%" colspan="2"><div align="right"><a href=""><?php echo PLUS; ?></a></div></td>
					   </tr>
					  </tbody>
					 </table>
					</div>
				   </td>
				   <td valign="top" width="50%">
					<div class="homepage_border">
					<div class="homepage_sub_header"><?php echo SERVEUR; ?></div>
					 <table width="100%" cellpadding="4" cellspacing="0">
					  <tbody>
					  <?php
						$req = sql::query("SELECT * 
											FROM admin_info 
											WHERE mode IN(3, 4)");
						
						while ($donnees = mysql_fetch_assoc($req))
						{
							echo'
						   <tr>
						    <td class="homepage_sub_row" width="5%"></td>
							<td class="homepage_sub_row" width="95%"></td>
						   </tr>';
						}
					   ?>
					   <tr>
						<td class="homepage_sub_row" width="100%" colspan="2"><div align="right"><a href=""><?php echo PLUS; ?></a></div></td>
					   </tr>
					  </tbody>
					 </table>
					</div>
				   </td>
				  </tr>
				 </tbody>
				</table>
			   </div>
			  </td>
			 </tr>
			 <tr>
			  <td>&nbsp;</td>
			 </tr>
			 <tr>
			  <td>
			   <div class="homepage_pane_border">
			   <div class="homepage_section"><?php echo TACHESTAT; ?></div>
			    <table width="100%" cellpadding="4" cellspacing="0">
			   <tbody>
			   <tr>
			   <td valign="top" width="50%">
			  	<div class="homepage_border">
				<div class="homepage_sub_header"><?php echo INFORMA; ?></div>
				 <table width="100%" cellpadding="4" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_row"><strong><?php echo MEMBRE; ?></strong></td>
					<td class="homepage_sub_row"><a href="index.php?zone=management&amp;page=memberlist"><?php echo VOIR; ?></a> (<strong><?php echo $admin->nb_joueur_general(); ?></strong>)</td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_row">&nbsp;&nbsp;|-<strong><?php echo ENLIGNE; ?></strong></td>
					<td class="homepage_sub_row"><a href="index.php?zone=management&amp;page=memberonline"><?php echo VOIR; ?></a> (<strong><?php echo $admin->nb_joueur_online(); ?></strong>)</td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_row">&nbsp;&nbsp;|-<strong><?php echo INACTIF; ?></strong></td>
					<td class="homepage_sub_row"><a href="index.php?zone=management&amp;page=memberinactif"><?php echo VOIR; ?></a> (<strong><?php echo $admin->nb_joueur_inactif(); ?></strong>)</td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_row">&nbsp;&nbsp;|-<strong><?php echo BANNI; ?></strong></td>
					<td class="homepage_sub_row"><a href="index.php?zone=management&amp;page=memberbanned"><?php echo VOIR; ?></a> (<strong><?php echo $admin->nb_joueur_banni(); ?></strong>)</td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_row"><strong><?php echo VALIDFANION; ?></strong></td>
					<td class="homepage_sub_row"><a href="index.php?zone=management&amp;page=validupload"><?php echo VOIR; ?></a> (<strong><?php echo $admin->nb_valid_total(); ?></strong>)</td>
				   </tr>
				  </tbody>
				 </table>
				</div>
			   </td>
			   <td valign="top" width="50%">
				<div class="homepage_border">
				<div class="homepage_sub_header"><?php echo ACTIONRAP; ?></div>
				 <table width="100%" cellpadding="4" cellspacing="0">
				  <tbody>
				   <tr>
					<td class="homepage_sub_row"><strong><?php echo SEARCHMEM; ?></strong>
					 <br />
					 <form name="DOIT" id="DOIT" action="" method="post">
					 <input size="33" class="textinput" id="members_display_name" name="members_display_name" value="" type="text">
					 <input value="<?php echo GO; ?>" class="realbutton" onclick="edit_member()" type="submit">
					 </form>
					</td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_row"><strong><?php echo AJOUTPLY; ?></strong>
				     <br />
				     <form action="index.php?zone=management&page=playernew" method="post">
				     <select name="position" id="position">
					  <option value="1"><?php echo GARDIEN; ?></option>
					  <option value="2"><?php echo DEFENSEUR; ?></option>
					  <option value="3"><?php echo MILIEU; ?></option>
					  <option value="4"><?php echo ATTAQUANT; ?></option>
					 </select>
				     <select name="pays_id" id="pays_id">
					 <?php
						$req = sql::query("SELECT pays_id, pays_name, pays_zone 
										   FROM pays 
										   ORDER BY pays_name");
						
						while ($donnees2 = mysql_fetch_array($req))
						{
							echo '<option value="' . $donnees2['pays_id'] . '">' . $donnees2['pays_name'] . '</option>';
						}
					 ?>
					 </select>
				     <input value="<?php echo GO; ?>" name="smallplayercreate" class="realbutton" type="submit">
				     </form>
					</td>
				   </tr>
				   <tr>
					<td class="homepage_sub_row"><strong><?php echo EDITFORUM; ?></strong>
				     <br />
					 <form name="newmem" id="newmem" action="" method="post">
					 <select name="f">
					 <option value="1"></option>
					 </select>
					 <input value="<?php echo GO; ?>" class="realbutton" type="submit">
					 </form>
					</td>
				   </tr>
				   <tr>
					<td class="homepage_sub_row">
					 <strong><?php echo RECHIP; ?></strong>
				  	 <br />
					 <form name="ipform" id="ipform" action="" method="post">
					 <input size="33" class="textinput" name="ip" value="" type="text">
					 <input value="<?php echo GO; ?>" class="realbutton" type="submit">
					 </form>
					</td>
				   </tr>
				  </tbody>
				 </table>
				</div>
			   </td>
		      </tr>
	         </tbody>
			</table>
	       </div>
		  </td>
		 </tr>
		 <tr>
		  <td>&nbsp;</td>
		 </tr>
		 <tr>
		  <td>
		   <div class="homepage_pane_border">
		   <div class="homepage_section"><a name="communication"><?php echo COMM; ?></a></div>
		    <table width="100%" cellpadding="4" cellspacing="0">
			 <tbody>
			  <tr>
			   <td valign="top" width="100%">
			    <div class="homepage_border">
				<div class="homepage_sub_header"><?php echo 'Minichat Admin'; ?></div>
				 <table width="100%" cellpadding="4" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_row" colspan="2">
					 <table width="100%" height="100%" border="0" align="center" cellspacing="5">
					  <tr>
					   <td valign="bottom" class="minichat_table">
					    <div class="minichat_scroll">
						 <div align="center">
						 <table width="100%" border="0" cellspacing="2">
						 <?php
						 $req = sql::query("SELECT mnc_id, mnc_time, minichat.account_id, texte, canal, canal_name, pseudo, team_id, team_name 
											 FROM minichat 
											 LEFT JOIN minichat_canal ON minichat.canal = minichat_canal.canal_id 
											 LEFT JOIN comptes ON minichat.account_id = comptes.account_id 
											 LEFT JOIN equipes ON minichat.account_id = equipes.account_id 
											 ORDER BY mnc_id DESC");
						
						while ($donnees = mysql_fetch_assoc($req))
						 {
						 $text = stripslashes($donnees['texte']);
						 $newtext = wordwrap($text, 50, "\n", true);
						 ?>
						  <tr>
						   <td width="15%" align="center" valign="top">[<?php echo date($info['dateformat_choice'], $donnees['mnc_time']); ?>]</td>
							<td width="75%">
							<?php echo'<a href="club.php?page=profil&amp;m='.$donnees['account_id'].'&amp;action=consulter">' . 
							$donnees['pseudo'] . '</a>'; ?> ( 
							<a href="club.php?zone=public&amp;page=teaminfo&amp;id=<?php echo $donnees['team_id']; ?>">
							<?php echo $donnees['team_name']; ?></a> ) : <?php echo $newtext; ?></td>
							<td width="10%" class="minichat_cell" valign="top"><?php if($donnees['canal'] == 0) echo CANALADMIN; else echo $donnees['canal_name']; ?></td>
						  </tr>
						  <?php
						  }
						  ?>
						 </table>
						 </div>
						</div>
					   </td>
					  </tr>
					 </table>
					</td>
				   </tr>
				   <tr>
					<td class="homepage_sub_row" colspan="2">
					 <div style="float: left;">
					 <form id="form1" name="form1" method="post" action="">
					 <select name="canal">
					 <option value="0"><?php echo CANALADMIN; ?></option>
					 <?php
					 $req = sql::query("SELECT * 
										FROM minichat_canal 
										ORDER BY position");
					 
					 while ($donnees = mysql_fetch_array($req))
					 {
					 ?>
					 <option value="<?php echo $donnees['canal_id']; ?>" 
					 <?php if(isset($FORM['canal']) && $FORM['canal'] == $donnees['canal_id']) echo 'selected="selected"'; ?> ><?php echo $donnees['canal_name']; ?></option>
					 <?php
					 }
					 ?>
					 </select>
					 <input name="minimessage" type="text" id="minimessage" size="60" />
					 <input type="submit" name="mp" id="mp" value="<?php echo MINICHATMESS; ?>" />
					 </form>
					 </div>
					 <div style="float: right;">
					 <a href="javascript:location.reload()">Rafraichir</a>&nbsp;&nbsp;<a href=""><?php echo PURGEMINICHAT; ?></a>
					 </div>
					</td>
				   </tr>
				  </tbody>
				 </table>
				</div>
			   </td>
			  </tr>
			 </tbody>
			</table>
		   </div>
		  </td>
		 </tr>
		</tbody>
	   </table>
	  </td>
	 </tr>
    </tbody>
   </table>
</div><!-- / OUTERDIV -->