<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

	$page = (!empty($FORM['page'])) ? htmlentities($FORM['page']) : 'memberlist';
	$array_pages = array(
		//Base
		'membersearch' => 'pages/manag_membre_search.php', 
		'memberlist' => 'pages/manag_membre_total.php', 
		'memberonline' => 'pages/manag_membre_online.php', 
		'memberbanned' => 'pages/manag_membre_banni.php', 
		'memberinactif' => 'pages/manag_membre_inactif.php', 
		'memberedit' => 'pages/manag_membre_edit.php', 
		'playernew' => 'pages/manag_joueur_new.php', 
		'playersuivi' => 'pages/manag_joueur_suivi.php', 
		'playeredit' => 'pages/manag_joueur_edit.php', 
		'saisonnew' => 'pages/manag_saison_new.php', 
		'champsuivi' => 'pages/manag_champ_suivi.php', 
		'champnew' => 'pages/manag_champ_new.php', 
		'cupsuivi' => 'pages/manag_cup_suivi.php', 
		'validupload' => 'pages/manag_valid_upload.php'
						);
		
	if(!array_key_exists($page, $array_pages)) include('pages/erreur.php');

	elseif(!is_file($array_pages[$page])) include('pages/erreur.php');

	else
	{
?>
<!-- OUTERDIV -->
<div class="outerdiv" id="global-outerdiv">
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
  <tbody>
   <tr>
    <td id="leftblock" valign="top" width="22%">
	 <div>
	 <!-- LEFT CONTEXT SENSITIVE MENU -->
	 <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo MENU1; ?></div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=management&amp;page=membersearch" style="text-decoration: none;"><?php echo MENU2; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=management&amp;page=memberlist" style="text-decoration: none;"><?php echo MENU3; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=management&amp;page=memberonline" style="text-decoration: none;"><?php echo MENU4; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=management&amp;page=memberinactif" style="text-decoration: none;"><?php echo MENU5; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=management&amp;page=memberbanned" style="text-decoration: none;"><?php echo MENU6; ?></a></div>
	  </div>
	  <br />
	  <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo MENU7; ?></div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=management&amp;page=playernew" style="text-decoration: none;"><?php echo MENU8; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=management&amp;page=playersuivi" style="text-decoration: none;"><?php echo MENU9; ?></a></div>
	  </div>
	  <br />
	  <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images//ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo MENU10; ?></div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=management&amp;page=champnew" style="text-decoration: none;"><?php echo MENU11; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=management&amp;page=champsuivi" style="text-decoration: none;"><?php echo MENU12; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=management&amp;page=saisonnew" style="text-decoration: none;"><?php echo MENU13; ?></a></div>
	  </div>
	  <br />
	  <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo MENU14; ?></div>
	   <div class="menulinkwrap">&nbsp;<a href="" style="text-decoration: none;"></a></div>
	  </div>
	  <br />
	  <!-- / LEFT CONTEXT SENSITIVE MENU -->
	 </div>
	</td>
	<td id="rightblock" valign="top" width="78%">
	 <div>
	 <!-- RIGHT CONTENT BLOCK -->
	  <?php include($array_pages[$page]); ?>
	 <!-- / RIGHT CONTENT BLOCK -->
	 </div>
	</td>
   </tr>
  </tbody>
 </table>
</div>
<!-- / OUTERDIV -->
<?php
	}
?>