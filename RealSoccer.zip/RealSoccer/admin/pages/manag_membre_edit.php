<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if(isset($FORM['id']))
{
	$account_id = $FORM['id']; //Retourne account_id
	
	if (isset($FORM['membermodif']))
	{		
		$ban_raison = $FORM['ban_raison'];
		
		$requete = sql::update("UPDATE comptes 
								SET pseudo = '".$FORM['pseudo']."', 
									email = '".$FORM['email']."', 
									lang = '".$FORM['lang']."', 
									lang_other = '".$FORM['lang_other']."', 
									rang = '".$FORM['rang']."', 
									coach_name = '".$FORM['coach_name']."', 
									ban_raison = '".$FORM['ban_raison']."' 
								WHERE account_id = '".$account_id."'");
	}
	
	$data = sql::fetch("SELECT * FROM comptes WHERE account_id= '".$account_id."'");
}
?>
<form action="index.php?zone=management&page=memberedit&amp;id=<?php echo $data['account_id']; ?>" method="post">
<div class="tableborder">
 <div class="tableheaderalt"><?php echo EDITMEM; ?></div>
  <table width="100%">
   <tbody>
    <tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo PSEUDO; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pseudo" id="pseudo" size="40" value="<?php echo $data['pseudo']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo EMAIL; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="email" id="email" size="40" value="<?php echo $data['email']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo LANGUEPRIN; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="lang" id="lang" size="40" value="<?php echo $data['lang']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo AUTRELANG; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="lang_other" id="lang_other" size="40" value="<?php echo $data['lang_other']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo RANG; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <select name="rang" id="rang">
        <option value="1" <?php if(isset($data['rang']) && $data['rang'] == 1) echo'selected="selected"'; ?>><?php echo $admin->show_rang(1, $CONF); ?></option>
        <option value="2" <?php if(isset($data['rang']) && $data['rang'] == 2) echo'selected="selected"'; ?>><?php echo $admin->show_rang(2, $CONF); ?></option>
        <option value="3" <?php if(isset($data['rang']) && $data['rang'] == 3) echo'selected="selected"'; ?>><?php echo $admin->show_rang(3, $CONF); ?></option>
        <option value="4" <?php if(isset($data['rang']) && $data['rang'] == 4) echo'selected="selected"'; ?>><?php echo $admin->show_rang(4, $CONF); ?></option>
		<option value="5" <?php if(isset($data['rang']) && $data['rang'] == 5) echo'selected="selected"'; ?>><?php echo $admin->show_rang(5, $CONF); ?></option>
		<option value="0" <?php if(isset($data['rang']) && $data['rang'] == 0) echo'selected="selected"'; ?>><?php echo $admin->show_rang(0, $CONF); ?></option>
      </select>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="top" width="40%"><b><?php echo BANRAISON; ?></b>
	  <div class="graytext"><?php echo BANRAISON_INFO; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <textarea name="ban_raison" type="text" cols="50" rows="4" /><?php echo stripslashes($data['ban_raison']); ?></textarea>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo COACHNAME; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="coach_name" id="coach_name" size="40" value="<?php echo $data['coach_name']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo INSCRIPDATE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <?php echo date($data['dateformat_choice'], $data['joindate']) . ' ' . date($data['timeformat_choice'], $data['joindate']); ?>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo INSCRIPIP; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <?php echo $data['joinip']; ?>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo LASTCODATE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <?php echo date($data['dateformat_choice'], $data['lastlogin']) . ' ' . date($data['timeformat_choice'], $data['lastlogin']); ?>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo LASTCOIP; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <?php echo $data['lastip']; ?>
	 </td>
	</tr>
	<tr>
	 <td class="tablesubheader" colspan="2" align="center">
	  <input name="membermodif" value="<?php echo MODIFMEM; ?>" class="realbutton" type="submit">
	 </td>
	</tr>
   </tbody>
  </table>
 </div>
</form>