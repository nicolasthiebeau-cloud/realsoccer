<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }
?>
<form action="" method="post">
<div class="tableborder">
 <div class="tableheaderalt"><?php echo MEM_SEARCH; ?></div>
  <table width="100%">
   <tbody>
    <tr>
	 <td class="tablerow1" valign="middle" width="100%" colspan="2"><b><?php echo BIENTOT; ?></b></td>
	</tr>
   </tbody>
  </table>
 </div>
</form>