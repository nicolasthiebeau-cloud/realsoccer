<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['orderby'])) $orderby = $FORM['orderby'];
else $orderby = 'joindate';

$req = sql::query("SELECT * 
					FROM comptes 
					LEFT JOIN equipes ON comptes.account_id = equipes.account_id 
					ORDER BY '".$orderby."'");
?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo ALLMEM; ?></div>
  <table width="100%">
   <tbody>
	 <tr>
	  <td class="tablerow1"><a href="index.php?zone=management&amp;page=memberlist&amp;orderby=pseudo"><?php echo PSEUDO; ?></a></td>
	  <td align="center" class="tablerow2"><a href="index.php?zone=management&amp;page=memberlist&amp;orderby=coach_name"><?php echo MANAG; ?></a></td>
	  <td class="tablerow1"><a href=""><?php echo EQUIPE; ?></a></td>
	  <td class="tablerow2"><a href="index.php?zone=management&amp;page=memberlist&amp;orderby=lang"><?php echo LANGU; ?></a></td>
	  <td align="center" class="tablerow1"><a href="index.php?zone=management&amp;page=memberlist&amp;orderby=joindate"><?php echo INSCRIP; ?></a></td>
	  <td align="center" class="tablerow2"><a href="index.php?zone=management&amp;page=memberlist&amp;orderby=lastlogin"><?php echo LASTCONNEC; ?></a></td>
	  <td align="center" class="tablerow1"><a href="index.php?zone=management&amp;page=memberlist&amp;orderby=lastip"><?php echo IP; ?></a></td>
	  <td align="center" class="tablerow2"><a href="index.php?zone=management&amp;page=memberlist&amp;orderby=rang"><?php echo RANG; ?></a></td>
	</tr>
<?php
while ($donnees = mysql_fetch_assoc($req))
{
?>
   <tr>
	<td class="tablerow1"><a href="index.php?zone=management&page=memberedit&amp;id=<?php echo $donnees['account_id']; ?>"><?php echo $donnees['pseudo']; ?></a></td>
	<td align="center" class="tablerow2"><?php echo $donnees['coach_name']; ?></td>
	<td class="tablerow1"><?php echo $donnees['team_name']; ?></td>
	<td class="tablerow2"><?php echo $donnees['lang']; ?></td>
	<td align="center" class="tablerow1"><?php echo date($donnees['dateformat_choice'], $donnees['joindate']); ?></td>
	<td align="center" class="tablerow2"><?php echo date($donnees['dateformat_choice'], $donnees['lastlogin']); ?></td>
	<td align="center" class="tablerow2"><?php echo $donnees['lastip']; ?></td>
	<td align="center" class="tablerow1"><?php echo $admin->show_rang($donnees['rang'], $CONF); ?></td>
   </tr>
<?php
}
?>
   </tbody>
  </table>
 </div>