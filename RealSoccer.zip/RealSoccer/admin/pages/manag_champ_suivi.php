<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['compet_id']) AND $FORM['mode'] == 'playmatch')
{
	//Zone match
	include("{$CONF['path']}/sources/class/class_match_apl.php");
	$match_apl = new match_apl;
	include("{$CONF['path']}/sources/class/class_match.php");
	$match = new match;
	
	$nbr = sql::fetch("SELECT COUNT(*) AS matchajouer FROM matchs WHERE compet_id='".$FORM['compet_id']."' AND timematch <= '".time()."' AND score1 = ' '"); 
;
	for($turn = 1; $turn <= $nbr['matchajouer']; $turn++)
	{
		$match->match_start($FORM['compet_id'], NULL, $info['team_id'], 1, $CONF);
		$match->match_action($FORM['compet_id'], NULL, $info['team_id'], 1, $CONF);
	}
}
?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo SUIVICHAMP; ?></div>
  <table width="100%">
   <tbody>
    <tr>
	<td width="20%" class="tablerow1"><?php echo PAYS; ?></td>
	<td width="20%" class="tablerow2"><?php echo COMPETNAME; ?></td>
	<td width="10%" class="tablerow1" align="center"><?php echo DIVPOUL; ?></td>
	<td width="10%" class="tablerow2" align="center"><?php echo EQFICREE; ?></td>
	<td width="10%" class="tablerow1" align="center"><?php echo SAISONENCOURS; ?></td>
	<td width="10%" class="tablerow2" align="center"><?php echo FINCOMPET; ?></td>
	<td width="10%" class="tablerow1" align="center"><?php echo MAJOUTOT; ?></td>
	<td width="15%" class="tablerow2" align="center">#</td>
  </tr>
<?php
$req = sql::query("SELECT * 
				   FROM competition 
				   LEFT JOIN pays ON competition.pays_id = pays.pays_id 
				   ORDER BY pays_name");

while ($donnees2 = mysql_fetch_array($req))
{
	$data = sql::fetch("SELECT * 
						FROM classement 
						LEFT JOIN matchs ON classement.compet_id = matchs.compet_id 
						WHERE classement.compet_id='".$donnees2['compet_id']."' 
						ORDER BY classement.saison_nbr DESC, matchs.timematch DESC 
						LIMIT 1");
	
	$data2 = sql::fetch("SELECT COUNT(*) AS nb_match_jouer FROM matchs WHERE compet_id='".$donnees2['compet_id']."' AND score1 != ' ' AND saison_nbr = '".$data['saison_nbr']."'"); 
?>
  <tr>
   <td class="tablerow1"><?php echo'<img src="../images/flag/' . $donnees2['pays_flag'] . '" width="32" height="20" style="vertical-align: middle;" />&nbsp;&nbsp;' .  $donnees2['pays_name'] ;?></td>
   <td class="tablerow2"><a href="<?php echo $donnees2['compet_id']; ?>"><?php echo $donnees2['compet_name'];?></a></td>
   <td class="tablerow1" align="center"><?php echo $donnees2['division'] . ' - ' . $donnees2['poule'] ;?></td>
   <td class="tablerow2" align="center"><?php echo $donnees2['nb_equipe'] . ' / ' . $donnees2['nb_equipe_fictive'] ;?></td>
   <td class="tablerow1" align="center"><?php echo $data['saison_nbr']; ?></td>
   <td class="tablerow2" align="center"><?php echo date($info['dateformat_choice'], $data['timematch']); ?></td>
   <td class="tablerow1" align="center">
   <?php 
		echo ($data2['nb_match_jouer'] / ($donnees2['config_nbteam_perchamp'] / 2)) . ' / ' . (($donnees2['config_nbteam_perchamp'] * 2) - 2) .'</td>';
		
		if ($data2['nb_match_jouer'] == 90) echo '<td class="tablerow2" align="center">' . CHAMPEND . '</td>';
		else echo '<td class="tablerow2" align="center"><a href="index.php?zone=management&amp;page=champsuivi&amp;compet_id=' . $donnees2['compet_id'] . '&amp;mode=playmatch">' . PLAYMATCH . '</a></td>';
		echo '</tr>';
	}
?>
  </tbody>
 </table>
</div>