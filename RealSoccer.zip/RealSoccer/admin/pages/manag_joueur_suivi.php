<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['transfert'])) $admin->player_transfert($FORM['player_id']);
if (isset($FORM['delete'])) $admin->player_delete($FORM['delete']);

if (isset($FORM['orderby'])) $orderby = $FORM['orderby'];
else $orderby = 'nom';

$req = sql::query("SELECT * 
				   FROM joueurs 
				   LEFT JOIN pays ON joueurs.nationalite = pays.pays_id 
				   WHERE team_id = 0 ORDER BY $orderby");
?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo SUIVIPLAY; ?></div>
  <table width="100%">
   <tbody>
	 <tr>
	  <td class="tablerow2"></td>
	  <td class="tablerow1"><a href="index.php?zone=management&page=playersuivi&amp;orderby=nom"><?php echo IDENT; ?></a></td>
	  <td class="tablerow2"><a href="index.php?zone=management&page=playersuivi&amp;orderby=age"><?php echo AGE; ?></a></td>
	  <td class="tablerow1"><a href="index.php?zone=management&page=playersuivi&amp;orderby=pays_name"><?php echo NATIO; ?></a></td>
	  <td class="tablerow2" align="center"><a href="index.php?zone=management&page=playersuivi&amp;orderby=note_gar"><?php echo NOTG; ?></a></td>
	  <td class="tablerow1" align="center"><a href="index.php?zone=management&page=playersuivi&amp;orderby=note_def"><?php echo NOTD; ?></a></td>
	  <td class="tablerow2" align="center"><a href="index.php?zone=management&page=playersuivi&amp;orderby=note_mil"><?php echo NOTM; ?></a></td>
	  <td class="tablerow1" align="center"><a href="index.php?zone=management&page=playersuivi&amp;orderby=note_atk"><?php echo NOTA; ?></a></td>
	  <td class="tablerow1" align="center"><?php echo TRANS; ?></td>
	 </tr>
	 <?php
		while ($donnees = mysql_fetch_array($req))
		{
	 ?>
	 <form action="" method="post">
	 <input name="player_id" type="hidden" value="<?php echo $donnees['player_id']; ?>" />
	 <tr>
	  <td class="tablerow2"><a href="index.php?zone=management&page=playersuivi&amp;delete=<?php echo $donnees['player_id']; ?>"><img src="../images/admin/delete.gif" border="0" /></a></td>
	  <td class="tablerow1"><a href="index.php?zone=management&page=playeredit&amp;id=<?php echo $donnees['player_id']; ?>"><?php echo $donnees['prenom'] . ' ' . $donnees['nom']; ?></a></td>
	  <td class="tablerow2"><?php echo $donnees['age']; ?></td>
	  <td class="tablerow1"><?php echo $donnees['pays_name']; ?></td>
	  <td class="tablerow2" align="center"><?php echo $admin->compare_etoile($donnees['player_id'], 1); ?></td>
	  <td class="tablerow1" align="center"><?php echo $admin->compare_etoile($donnees['player_id'], 2); ?></td>
	  <td class="tablerow2" align="center"><?php echo $admin->compare_etoile($donnees['player_id'], 3); ?></td>
	  <td class="tablerow1" align="center"><?php echo $admin->compare_etoile($donnees['player_id'], 4); ?></td>
	  <?php
			if($donnees['statut'] == 0)
			{
	  ?>
	  <td class="tablerow1" align="center"><?php  echo '<input name="transfert" type="submit" value="' . TRANS . '" />'; ?></td>
	  <?php
			}
			
			else
			{
	  ?>
	  <td class="tablerow2" align="center" colspan="2">&nbsp;</td>
	  <?php
			}
	  ?>
	 </tr>
	 </form>
	 <?php
		}
	 ?>
   </tbody>
  </table>
 </div>