<?php
//-------------------------------------------------------------------------------------//
// SMOS - Sport Manager Open Source													   //
// http://snyzone.fr/smos/															   //
//-------------------------------------------------------------------------------------//
// Le projet est open source - sous license GPL										   //
// Vous �tes libre de l'utiliser mais pas � des fins commercial						   //
//																					   //
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr							   //
// Cr�ation : 08/10/09																   //
//-------------------------------------------------------------------------------------//

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }
?>
<form action="" method="post">
<div class="tableborder">
 <div class="tableheaderalt">Page d'erreur</div>
  <table width="100%" align="center" border="0" cellpadding="5" cellspacing="0">
   <tbody>
    <tr>
	 <td class="tablerow1" valign="middle" width="100%" colspan="2"><b>La fonction n'est pas implant� :)</b></td>
	</tr>
   </tbody>
  </table>
 </div>
</form>