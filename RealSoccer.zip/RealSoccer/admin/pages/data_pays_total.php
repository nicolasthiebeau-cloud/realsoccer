<?php
//-------------------------------------------------------------------------------------//
// SMOS - Sport Manager Open Source													   //
// http://snyzone.fr/smos/															   //
//-------------------------------------------------------------------------------------//
// Le projet est open source - sous license GPL										   //
// Vous �tes libre de l'utiliser mais pas � des fins commercial						   //
//																					   //
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr							   //
// Cr�ation : 08/10/09																   //
//-------------------------------------------------------------------------------------//

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['orderby'])) $orderby = $FORM['orderby'];
else $orderby = 'pays_name';


$sql = "SELECT * FROM pays ORDER BY $orderby";
$req = mysql_query($sql) or die('Erreur SQL!<br />'.sql.'<br />'.mysql_error());
?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo ALLMEM; ?></div>
  <table width="100%">
   <tbody>
	 <tr>
	  <td class="tablerow1"><a href="index.php?zone=database&amp;page=countrylist&amp;orderby=pays_name"><?php echo CO_NAME; ?></a></td>
	  <td class="tablerow2"><a href="index.php?zone=database&amp;page=countrylist&amp;orderby=pays_champ"><?php echo CO_CHAMP; ?></a></td>
	  <td class="tablerow1"><a href="index.php?zone=database&amp;page=countrylist&amp;orderby=pays_zone"><?php echo CO_ZONE; ?></a></td>
	  <td class="tablerow2"><a href="index.php?zone=database&amp;page=countrylist&amp;orderby=pays_flag"><?php echo CO_DRAP; ?></a></td>
	  <td class="tablerow1"><a href="index.php?zone=database&amp;page=countrylist&amp;orderby=pays_money"><?php echo CO_MONN; ?></a></td>
	  <td class="tablerow2"><a href="index.php?zone=database&amp;page=countrylist&amp;orderby=pays_selectactif"><?php echo CO_SELACT; ?></a></td>
	  <td class="tablerow1"><a href="index.php?zone=database&amp;page=countrylist&amp;orderby=config_nbteam_perchamp"><?php echo CO_NBTEAM; ?></a></td>
	  <td class="tablerow2"><a href="index.php?zone=database&amp;page=countrylist&amp;orderby=config_heurematch"><?php echo CO_HMATCH; ?></a></td>
	  <td class="tablerow1"><a href="index.php?zone=database&amp;page=countrylist&amp;orderby=config_tpsentre2match"><?php echo CO_TPS2M; ?></a></td>
	  <td class="tablerow2"><a href="index.php?zone=database&amp;page=countrylist&amp;orderby=config_classement"><?php echo CO_CLASS; ?></a></td>
	</tr>
<?php
while ($donnees = mysql_fetch_array($req))
{
?>
   <tr>
	<td class="tablerow1"><a href="index.php?zone=database&page=countryedit&amp;id=<?php echo $donnees['pays_id']; ?>"><?php echo $donnees['pays_name']; ?></a></td>
	<td class="tablerow2"><?php echo $donnees['pays_champ']; ?></td>
	<td class="tablerow1"><?php echo $donnees['pays_zone']; ?></td>
	<td class="tablerow2"><?php echo '<img src="../images/flag/' . $donnees['pays_flag'] . '" width="32" height="20" style="vertical-align: top;" />'; ?></td>
	<td class="tablerow1"><?php echo $donnees['pays_money']; ?></td>
	<td class="tablerow2"><?php echo $donnees['pays_select'] . ' - ' . $donnees['pays_actif']; ?></td>
	<td class="tablerow1"><?php echo $donnees['config_nbteam_perchamp']; ?></td>
	<td class="tablerow2"><?php echo $donnees['config_heurematch']; ?></td>
	<td class="tablerow1"><?php echo $donnees['config_tpsentre2match']; ?></td>
	<td class="tablerow2"><?php echo $donnees['pays_classement']; ?></td>
   </tr>
<?php
}
?>
   </tbody>
  </table>
 </div>