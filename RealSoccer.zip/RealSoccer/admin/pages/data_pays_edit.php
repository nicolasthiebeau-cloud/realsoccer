<?php
//-------------------------------------------------------------------------------------//
// SMOS - Sport Manager Open Source													   //
// http://snyzone.fr/smos/															   //
//-------------------------------------------------------------------------------------//
// Le projet est open source - sous license GPL										   //
// Vous �tes libre de l'utiliser mais pas � des fins commercial						   //
//																					   //
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr							   //
// Cr�ation : 08/10/09																   //
//-------------------------------------------------------------------------------------//

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if(isset($FORM['id']))
{
	$pays_id = $FORM['id']; //Retourne pays_id
	
	if (isset($FORM['countrymodif']))
	{
		$requete = "UPDATE pays SET pays_name = '".$FORM['pays_name']."', 
									    pays_champ = '".$FORM['pays_ champ']."', 
									    pays_zone = '".$FORM['pays_zone']."', 
									    pays_file_nom = '".$FORM['pays_file_nom']."', 
									    pays_file_prenom = '".$FORM['pays_file_prenom']."', 
									    pays_flag = '".$FORM['pays_flag']."', 
									    pays_money = '".$FORM['pays_money']."', 
									    pays_select = '".$FORM['pays_select']."', 
									    pays_actif = '".$FORM['pays_actif']."', 
									    config_nbteam_perchamp = '".$FORM['config_nbteam_perchamp']."', 
									    config_heurematch = '".$FORM['config_heurematch']."', 
									    config_tpsentre2match = '".$FORM['config_tpsentre2match']."'
					WHERE pays_id = '".$pays_id."'";
		$resultat = mysql_query($requete) or die('Erreur SQL!<br />'.sql.'<br />'.mysql_error());
	}
	
	$sql = "SELECT * FROM pays WHERE pays_id= '".$pays_id."'"; 
	$req = mysql_query($sql) or die('Erreur SQL!<br />'.sql.'<br />'.mysql_error());
	$data = mysql_fetch_array($req);
}
?>
<form action="index.php?zone=database&page=countryedit&amp;id=<?php echo $data['pays_id']; ?>" method="post">
<div class="tableborder">
 <div class="tableheaderalt"><?php echo EDITCO; ?></div>
  <table width="100%">
   <tbody>
    <tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_NAME; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_name" id="pays_name" size="40" value="<?php echo $data['pays_name']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_CHAMP; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_ champ" id="pays_ champ" size="40" value="<?php echo $data['pays_champ']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_ZONE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <select name="pays_zone" id="pays_zone">
        <option value="999" <?php if($data['pays_zone'] == 999) echo'selected="selected"'; echo'>' . ZONE1; ?></option>
		 <option value="998" <?php if($data['pays_zone'] == 998) echo'selected="selected"'; echo'>' . ZONE2; ?></option>
		 <option value="997" <?php if($data['pays_zone'] == 997) echo'selected="selected"'; echo'>' . ZONE3; ?></option>
		 <option value="996" <?php if($data['pays_zone'] == 996) echo'selected="selected"'; echo'>' . ZONE4; ?></option>
		 <option value="995" <?php if($data['pays_zone'] == 995) echo'selected="selected"'; echo'>' . ZONE5; ?></option>
	     <option value="994" <?php if($data['pays_zone'] == 994) echo'selected="selected"'; echo'>' . ZONE6; ?></option>
		 <option value="992" <?php if($data['pays_zone'] == 992) echo'selected="selected"'; echo'>' . ZONE7; ?></option>
	     <option value="993" <?php if($data['pays_zone'] == 993) echo'selected="selected"'; echo'>' . ZONE8; ?></option>
	     <option value="991" <?php if($data['pays_zone'] == 991) echo'selected="selected"'; echo'>' . ZONE9; ?></option>
	     <option value="990" <?php if($data['pays_zone'] == 990) echo'selected="selected"'; echo'>' . ZONE10; ?></option>
	     <option value="989" <?php if($data['pays_zone'] == 989) echo'selected="selected"'; echo'>' . ZONE11; ?></option>
      </select>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_LST_NOM; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_file_nom" id="pays_file_nom" size="40" value="<?php echo $data['pays_file_nom']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_LST_PRENOM; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_file_prenom" id="pays_file_prenom" size="40" value="<?php echo $data['pays_file_prenom']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_DRAP; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_flag" id="pays_flag" size="40" value="<?php echo $data['pays_flag']; ?>" />
	  &nbsp;&nbsp;<img src="../images/flag/<?php echo $data['pays_flag']; ?>" width="32" height="20" style="vertical-align: top;" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_MONN; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_money" id="pays_money" size="40" value="<?php echo $data['pays_money']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_SELECT; ?></b>
	  <div class="graytext"><?php echo CO_SELECT_INFO; ?></div></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_select" id="pays_select" size="40" value="<?php echo $data['pays_select']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_ACTIF; ?></b>
	  <div class="graytext"><?php echo CO_ACTIF_INFO; ?></div></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_actif" id="pays_actif" size="40" value="<?php echo $data['pays_actif']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_NBTEAM; ?></b>
	  <div class="graytext"><?php echo CO_NBTEAM_INFO; ?></div></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="config_nbteam_perchamp" id="config_nbteam_perchamp" size="40" value="<?php echo $data['config_nbteam_perchamp']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_HMATCH; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="config_heurematch" id="config_heurematch" size="40" value="<?php echo $data['config_heurematch']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_TPS2M; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="config_tpsentre2match" id="config_tpsentre2match" size="40" value="<?php echo $data['config_tpsentre2match']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_CLASS; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <?php echo $data['pays_classement']; ?>
	 </td>
	</tr>
	<tr>
	 <td class="tablesubheader" colspan="2" align="center">
	  <input name="countrymodif" value="<?php echo MODIFCO; ?>" class="realbutton" type="submit">
	 </td>
	</tr>
   </tbody>
  </table>
 </div>
</form>