<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['smallplayercreate']))
{
	$admin->crea_player(NULL, NULL, NULL, $FORM['pays_id'], $FORM['position'], 'oui', NULL, NULL, NULL, NULL, NULL, NULL, 
						NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, $CONF);
	
	//Redirection sur la page suivi
	echo "<meta http-equiv=\"refresh\" content=\"0;url=index.php?zone=management&page=playersuivi\">";
}

if (isset($FORM['playercreate']))
{
	$admin->crea_player($FORM['nom'], $FORM['surnom'], $FORM['prenom'], $FORM['pays_id'], $FORM['position'], $FORM['choice_mdt'], 
						$FORM['age'], $FORM['taille'], $FORM['forme'], $FORM['moral'], $FORM['talent'], 
						$FORM['pression'], $FORM['experience'], $FORM['influence'], $FORM['agressivite'], $FORM['reflexes'], 
						$FORM['pdballe'], $FORM['degagement'], $FORM['marquage'], $FORM['tacles'], $FORM['tete'], $FORM['centres'], 
						$FORM['passes'], $FORM['vitesse'], $FORM['tir'], $FORM['creativite'], $FORM['dribble'], $FORM['cdpa'], $CONF);
	
	//Redirection sur la page suivi
	echo "<meta http-equiv=\"refresh\" content=\"0;url=index.php?zone=management&page=playersuivi\">";
}
?>
<form action="" method="post">
<div class="tableborder">
 <div class="tableheaderalt"><?php echo CREANEWPLAY; ?></div>
  <table width="100%">
   <tbody>
    <tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo NOM; ?></b>
	  <div class="graytext"><?php echo NOLSTNAMEALE; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="nom" id="nom" size="40" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo SURNOM; ?></b>
	  <div class="graytext"><?php echo FACLT; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="surnom" id="surnom" size="30" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo PRENOM; ?></b>
	  <div class="graytext"><?php echo NONAMEALE; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="prenom" id="prenom" size="40" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo PAYS; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <select name="pays_id" id="pays_id">
	  <?php
		$req = sql::query("SELECT pays_id, pays_name, pays_zone FROM pays ORDER BY pays_name");
		
		while ($donnees2 = mysql_fetch_array($req))
		{
			echo '<option value="' . $donnees2['pays_id'] . '">' . $donnees2['pays_name'] . '</option>';
		}
	  ?>
	  </select>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo POSIT; ?></b>
	  <div class="graytext"><?php echo POSTEDEP; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <select name="position" id="position">
	   <option value="1"><?php echo GARDIEN; ?></option>
	   <option value="2"><?php echo DEFENSEUR; ?></option>
	   <option value="3"><?php echo MILIEU; ?></option>
	   <option value="4"><?php echo ATTAQUANT; ?></option>
	  </select>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo MARCHTRANS; ?></b>
	  <div class="graytext"><?php echo MARCHTRANS_INFO1; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <label><input type="radio" name="choice_mdt" value="oui" id="choice_mdt_0" <?php if(isset($FORM['choice_mdt']) AND $FORM['choice_mdt'] == 'oui') echo 'checked="checked"'; else echo 'checked="checked"'; ?> /><?php echo YES; ?></label>
	  <label><input type="radio" name="choice_mdt" value="non" id="choice_mdt_1" <?php if(isset($FORM['choice_mdt']) AND $FORM['choice_mdt'] == 'non') echo 'checked="checked"'; ?> /><?php echo NO; ?></label>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="100%" colspan="2"><b>
	  <?php echo NOTEALL2; ?>
	 </b></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo AGE; ?></b>
	  <div class="graytext"><?php echo AGE_INF; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="age" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo TAILLE; ?></b>
	  <div class="graytext"><?php echo TAILLE_INF; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="taille" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo FORME; ?></b>
	  <div class="graytext"><?php echo FORME_INF; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="forme" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo MORAL; ?></b>
	  <div class="graytext"><?php echo MORA_INFO; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	 <input type="text" name="moral" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo TALENT; ?></b>
	  <div class="graytext"><?php echo TALENT_INFO; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="talent" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo PRESSION; ?></b>
	  <div class="graytext"><?php echo PRESSION_INFO; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pression" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo EXPERIENCE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="experience" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo INFLUENCE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="influence" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo AGRESSIVITE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="agressivite" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo REFLEXES; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="reflexes" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo PDBALLE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="pdballe" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo DEGAGEMENT; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="degagement" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo MARQUAGE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="marquage" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo TACLES; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="tacles" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo TETE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="tete" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CENTRES; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="centres" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo PASSES; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="passes" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo VITESSE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="vitesse" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo TIR; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="tir" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CREATIVITE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="creativite" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo DRIBBLE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="dribble" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CDPARRETE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="cdpa" /></td>
	</tr>
	<tr>
	 <td class="tablesubheader" colspan="2" align="center">
	  <input name="playercreate" value="<?php echo CREANEWPLAY2; ?>" class="realbutton" type="submit">
	 </td>
	</tr>
   </tbody>
  </table>
 </div>
</form>