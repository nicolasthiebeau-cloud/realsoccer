<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['pays_id']))
{
	require_once("{$CONF['path']}/sources/class/class_index.php");
	$index = new index;
	
	$index->crea_competition($FORM['pays_id'], 1, $CONF);
	
	//Redirection sur la page suivi
	echo "<meta http-equiv=\"refresh\" content=\"0;url=index.php?zone=management&page=champsuivi\">";
}

?>
<form name="saisieclass" action="" method="POST">
<div class="tableborder">
 <div class="tableheaderalt"><?php echo CREANEWCHAMP; ?></div>
  <table width="100%">
   <tbody>
    <tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CREANEWCHAMP; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <select name="pays_id">
	  <option value="" selected="selected"><?php echo CHOICHAMP; ?></option>
	  <?php
		$req = sql::query("SELECT * FROM pays WHERE pays_actif = 1 ORDER BY pays_name");
		
		while ($donnees = mysql_fetch_array($req))
		{
	  ?>
	  <option value="<?php echo $donnees['pays_id']; ?>"><?php echo $donnees['pays_name'] . ' - ' . $donnees['pays_champ']; ?></option>
	  <?php
		}
	  ?>
	  </select>
	 </td>
	</tr>
	<tr>
	 <td class="tablesubheader" colspan="2" align="center">
	  <input type="submit" name="create" class="realbutton" value="<?php echo CRERNEWCHAMP; ?>">
	 </td>
	</tr>
   </tbody>
  </table>
 </div>
</form>