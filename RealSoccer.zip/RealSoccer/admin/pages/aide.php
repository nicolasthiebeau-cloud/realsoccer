<?php
//-------------------------------------------------------------------------------------//
// SMOS - Sport Manager Open Source													   //
// http://snyzone.fr/smos/															   //
//-------------------------------------------------------------------------------------//
// Le projet est open source - sous license GPL										   //
// Vous �tes libre de l'utiliser mais pas � des fins commercial						   //
//																					   //
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr							   //
// Cr�ation : 08/10/09																   //
//-------------------------------------------------------------------------------------//

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

	$page = (!empty($FORM['page'])) ? htmlentities($FORM['page']) : 'memberall';
	$array_pages = array(
		//Base
		'' => '',
						);
		
	if(!array_key_exists($page, $array_pages)) include('pages/erreur.php');

	elseif(!is_file($array_pages[$page])) include('pages/erreur.php');

	else
	{
?>
<!-- OUTERDIV -->
<div class="outerdiv" id="global-outerdiv">
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
  <tbody>
   <tr>
    <td id="leftblock" valign="top" width="22%">
	 <div>
	 <!-- LEFT CONTEXT SENSITIVE MENU -->
	 <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/menu_title_bullet.gif" style="vertical-align: bottom;" border="0"> </div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=aide&amp;page=" style="text-decoration: none;">Rechercher un membre</a></div>
	  </div>
	  <br />
	  <!-- / LEFT CONTEXT SENSITIVE MENU -->
	 </div>
	</td>
	<td id="rightblock" valign="top" width="78%">
	 <div>
	 <!-- RIGHT CONTENT BLOCK -->
	  <?php include($array_pages[$page]); ?>
	 <!-- / RIGHT CONTENT BLOCK -->
	 </div>
	</td>
   </tr>
  </tbody>
 </table>
</div>
<!-- / OUTERDIV -->
<?php
	}
?>