<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if(isset($FORM['id']))
{
	$player_id = $FORM['id']; //Retourne player_id
	
	if (isset($FORM['position']))
	{		
		$requete = sql::update("UPDATE joueurs 
							   SET nom = '".$FORM['nom']."', 
								   surnom = '".$FORM['surnom']."', 
								   prenom = '".$FORM['prenom']."', 
								   age = '".$FORM['age']."', 
								   taille = '".$FORM['taille']."', 
								   position = '".$FORM['position']."', 
								   nationalite = '".$FORM['nationalite']."', 
								   forme = '".$FORM['forme']."', 
								   moral = '".$FORM['moral']."', 
								   talent = '".$FORM['talent']."', 
								   pression = '".$FORM['pression']."', 
								   experience = '".$FORM['experience']."', 
								   influence = '".$FORM['influence']."', 
								   agressivite = '".$FORM['agressivite']."', 
								   reflexes = '".$FORM['reflexes']."', 
								   pdballe = '".$FORM['pdballe']."', 
								   degagement = '".$FORM['degagement']."', 
								   marquage = '".$FORM['marquage']."', 
								   tacles = '".$FORM['tacles']."', 
								   tete = '".$FORM['tete']."', 
								   centres = '".$FORM['centres']."', 
								   passes = '".$FORM['passes']."', 
								   vitesse = '".$FORM['vitesse']."', 
								   tir = '".$FORM['tir']."', 
								   creativite = '".$FORM['creativite']."', 
								   dribble = '".$FORM['dribble']."', 
								   cdp_arrete = '".$FORM['cdp_arrete']."'
							   WHERE player_id = '".$player_id."'");
	}
	
	$data = sql::fetch("SELECT * 
						FROM joueurs 
						LEFT JOIN pays ON pays.pays_id = joueurs.nationalite 
						WHERE player_id= '".$player_id."'");
	
	if($data['team_id'] == 0)
	{
?>
<form action="index.php?zone=management&page=playeredit&amp;id=<?php echo $data['player_id']; ?>" method="post">
<div class="tableborder">
 <div class="tableheaderalt"><?php echo MODIFPLAY; ?></div>
  <table width="100%">
   <tbody>
    <tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo NOM; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="nom" id="nom" size="40" value="<?php echo $data['nom']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo SURNOM; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="surnom" id="surnom" size="30" value="<?php echo $data['surnom']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo PRENOM; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="prenom" id="prenom" size="40" value="<?php echo $data['prenom']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo NATIO; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <select name="nationalite" id="nationalite">
	  <?php
		$req = sql::query("SELECT pays_id, pays_name FROM pays ORDER BY pays_name");
		
		while ($donnees2 = mysql_fetch_array($req))
		{
			echo '<option value="' . $donnees2['pays_id'] . '"'; if($data['nationalite'] == $donnees2['pays_id']) echo'selected="selected"'; echo '>' . $donnees2['pays_name'] . '</option>';
		}
		
		echo'</select>&nbsp;&nbsp;<img src="../images/flag/' . $data['pays_flag'] . '" width="32" height="20" style="vertical-align: top;" />';
	  ?>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo POSIT; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <select name="position" id="position">
        <option value="1" <?php if($data['position'] == 1) echo'selected="selected"'; ?>><?php echo GARDIEN; ?></option>
        <option value="2" <?php if($data['position'] == 2) echo'selected="selected"'; ?>><?php echo DEFENSEUR; ?></option>
        <option value="3" <?php if($data['position'] == 3) echo'selected="selected"'; ?>><?php echo MILIEU; ?></option>
        <option value="4" <?php if($data['position'] == 4) echo'selected="selected"'; ?>><?php echo ATTAQUANT; ?></option>
      </select>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="100%" colspan="2"><b><?php echo INFO_NIVEAU; ?></b></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo GARDIEN; ?></b>
	  <div class="graytext"><?php echo PDBALLE . ', ' . DEGAGEMENT . ', ' . REFLEXES . ', ' . INFLUENCE; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <a href="../index.php?zone=help#niveaujoueur"><?php echo $admin->compare_etoile($player_id, 1); ?></a>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo DEFENSEUR; ?></b>
	  <div class="graytext"><?php echo MARQUAGE . ', ' . TACLES . ', ' . DEGAGEMENT . ', ' . TETE; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <a href="../index.php?zone=help#niveaujoueur"><?php echo $admin->compare_etoile($player_id, 2); ?></a>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo MILIEU; ?></b>
	  <div class="graytext"><?php echo CENTRES . ', ' . PASSES . ', ' . VITESSE . ', ' . TIR; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <a href="../index.php?zone=help#niveaujoueur"><?php echo $admin->compare_etoile($player_id, 3); ?></a>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo ATTAQUANT; ?></b>
	  <div class="graytext"><?php echo TIR . ', ' . CREATIVITE . ', ' . TETE . ', ' . DRIBBLE; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <a href="../index.php?zone=help#niveaujoueur"><?php echo $admin->compare_etoile($player_id, 4); ?></a>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="100%" colspan="2"><b>
	 <?php echo NOTEALL; ?>
	 </b></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo AGE; ?></b>
	  <div class="graytext"><?php echo AGE_INF; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="age" value="<?php echo $data['age']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo TAILLE; ?></b>
	  <div class="graytext"><?php echo TAILLE_INF; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="taille" value="<?php echo $data['taille']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo FORME; ?></b>
	  <div class="graytext"><?php echo FORME_INF; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="forme" value="<?php echo $data['forme']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo MORAL; ?></b>
	  <div class="graytext"><?php echo MORA_INFO; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	 <input type="text" name="moral" value="<?php echo $data['moral']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo TALENT; ?></b>
	  <div class="graytext"><?php echo TALENT_INFO; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="talent" value="<?php echo $data['talent']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo PRESSION; ?></b>
	  <div class="graytext"><?php echo PRESSION_INFO; ?></div>
	 </td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pression" value="<?php echo $data['pression']; ?>" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo EXPERIENCE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="experience" value="<?php echo $data['experience']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo INFLUENCE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="influence" value="<?php echo $data['influence']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo AGRESSIVITE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="agressivite" value="<?php echo $data['agressivite']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo REFLEXES; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="reflexes" value="<?php echo $data['reflexes']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo PDBALLE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="pdballe" value="<?php echo $data['pdballe']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo DEGAGEMENT; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="degagement" value="<?php echo $data['degagement']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo MARQUAGE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="marquage" value="<?php echo $data['marquage']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo TACLES; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="tacles" value="<?php echo $data['tacles']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo TETE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="tete" value="<?php echo $data['tete']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CENTRES; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="centres" value="<?php echo $data['centres']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo PASSES; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="passes" value="<?php echo $data['passes']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo VITESSE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="vitesse" value="<?php echo $data['vitesse']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo TIR; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="tir" value="<?php echo $data['tir']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CREATIVITE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="creativite" value="<?php echo $data['creativite']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo DRIBBLE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="dribble" value="<?php echo $data['dribble']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CDPARRETE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%"><input type="text" name="cdp_arrete" value="<?php echo $data['cdp_arrete']; ?>" /></td>
	</tr>
	<tr>
	 <td class="tablesubheader" colspan="2" align="center">
	  <input name="playermodif" value="<?php echo MODIFPLAYER; ?>" class="realbutton" type="submit">
	 </td>
	</tr>
   </tbody>
  </table>
 </div>
</form>
<?php
	}
		
	else echo ERROR_NOEDIT_PLAYER;
}
?>