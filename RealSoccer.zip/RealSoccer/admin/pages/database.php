<?php
//-------------------------------------------------------------------------------------//
// SMOS - Sport Manager Open Source													   //
// http://snyzone.fr/smos/															   //
//-------------------------------------------------------------------------------------//
// Le projet est open source - sous license GPL										   //
// Vous �tes libre de l'utiliser mais pas � des fins commercial						   //
//																					   //
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr							   //
// Cr�ation : 08/10/09																   //
//-------------------------------------------------------------------------------------//

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

	$page = (!empty($FORM['page'])) ? htmlentities($FORM['page']) : 'datainfo';
	$array_pages = array(
		//Base
		'datainfo' => 'pages/data_information.php',
		'countrynew' => 'pages/data_pays_new.php', 
		'countrylist' => 'pages/data_pays_total.php', 
		'countryedit' => 'pages/data_pays_edit.php', 
						);
		
	if(!array_key_exists($page, $array_pages)) include('pages/erreur.php');

	elseif(!is_file($array_pages[$page])) include('pages/erreur.php');

	else
	{
?>
<!-- OUTERDIV -->
<div class="outerdiv" id="global-outerdiv">
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
  <tbody>
   <tr>
    <td id="leftblock" valign="top" width="22%">
	 <div>
	 <!-- LEFT CONTEXT SENSITIVE MENU -->
	 <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> Personalisation</div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=database&amp;page=countrylist" style="text-decoration: none;">Liste des pays</a></div>
	  </div>
	 </div>
	 <br />
	 <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/ico_creation.png" style="vertical-align: bottom;" border="0"> Cr�ation</div>
	   <div class="menulinkwrap">&nbsp;<a href="index.php?zone=database&amp;page=countrynew" style="text-decoration: none;">Nouveau pays</a></div>
	  </div>
	 </div>
	 <br />
	  <!-- / LEFT CONTEXT SENSITIVE MENU -->
	</td>
	<td id="rightblock" valign="top" width="78%">
	 <div>
	 <!-- RIGHT CONTENT BLOCK -->
	  <?php include($array_pages[$page]); ?>
	 <!-- / RIGHT CONTENT BLOCK -->
	 </div>
	</td>
   </tr>
  </tbody>
 </table>
</div>
<!-- / OUTERDIV -->
<?php
	}
?>