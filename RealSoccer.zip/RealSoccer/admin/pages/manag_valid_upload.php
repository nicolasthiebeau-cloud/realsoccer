<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if(isset($FORM['choix'])) $admin->choice_valid_upload($FORM['id'], $FORM['choix']);

?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo 'Fanion � valider'; ?></div>
  <table width="100%">
   <tbody>
	 <tr>
	  <td class="tablerow1"></td>
	  <td class="tablerow2"><?php echo EQUIPE; ?></td>
	  <td align="center" class="tablerow2"><?php echo 'Choix'; ?></td>
	</tr>
<?php
$req = sql::query("SELECT team_id, team_name, fanion FROM equipes WHERE fanion != '".NULL."' AND fanion_valid = 0");

while ($donnees = mysql_fetch_array($req))
{
?>
   <tr>
	<td align="center" class="tablerow2">
	<?php echo'<img src="../upload/fanion/' . $donnees['fanion'] . '" width="150" height="150" />'; ?>
	</td>
	<td class="tablerow1"><?php echo $donnees['team_name']; ?></td>
	<td align="center" class="tablerow1">
	<?php echo '
	<a href="index.php?zone=management&page=validupload&amp;choix=acceptfanion&amp;id=' . $donnees['team_id'] . '">
	<img src="../images/icone/tick.gif" border="0" />
	</a>&nbsp;&nbsp;
	<a href="index.php?zone=management&page=validupload&amp;choix=refusefanion&amp;id=' . $donnees['team_id'] . '">
	<img src="../images/icone/cross.gif" border="0" />
	</a>'; ?>
	</td>
   </tr>
<?php
}
?>
   </tbody>
  </table>
 </div>
 <br />
<div class="tableborder">
 <div class="tableheaderalt"><?php echo 'Photo joueur � valider'; ?></div>
  <table width="100%">
   <tbody>
	 <tr>
	  <td class="tablerow1"></td>
	  <td class="tablerow2"><?php echo 'Identit�'; ?></td>
	  <td align="center" class="tablerow2"><?php echo 'Choix'; ?></td>
	</tr>
<?php
$req = sql::query("SELECT player_id, photo, nom, prenom FROM joueurs WHERE photo != '".NULL."' AND photo_valid = 0");

while ($donnees = mysql_fetch_assoc($req))
{
?>
   <tr>
	<td align="center" class="tablerow2">
	<?php echo'<img src="../upload/joueur/' . $donnees['photo'] . '" width="150" height="150" />'; ?>
	</td>
	<td class="tablerow1"><?php echo $donnees['prenom'] . ' ' . $donnees['nom']; ?></td>
	<td align="center" class="tablerow1">
	<?php echo '
	<a href="index.php?zone=management&page=validupload&amp;choix=acceptphoto&amp;id=' . $donnees['player_id'] . '">
	<img src="../images/icone/tick.gif" border="0" />
	</a>&nbsp;&nbsp;
	<a href="index.php?zone=management&page=validupload&amp;choix=refusephoto&amp;id=' . $donnees['player_id'] . '">
	<img src="../images/icone/cross.gif" border="0" />
	</a>'; ?>
	</td>
   </tr>
<?php
}
?>
   </tbody>
  </table>
 </div>