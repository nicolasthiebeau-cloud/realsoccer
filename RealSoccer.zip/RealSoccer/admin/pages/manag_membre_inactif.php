<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
08/10/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['delete']))
{
	$admin->delete_member($FORM['account_id']);
}

$datetimestamp = time() - (14 * 24 * 60 * 60);

$req = sql::query("SELECT * 
				   FROM comptes 
				   LEFT JOIN equipes ON comptes.account_id = equipes.account_id 
				   LEFT JOIN competition ON equipes.compet_id = competition.compet_id 
				   WHERE comptes.lastlogin < '".$datetimestamp."'");
?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo MEM_INACTIF; ?></div>
  <table width="100%">
   <tbody>
	 <tr>
	  <td align="center" class="tablerow1">&nbsp;</td>
	  <td align="center" class="tablerow2"><?php echo COMPET; ?></td>
	  <td align="center" class="tablerow1"><?php echo PSEUDO; ?></td>
	  <td align="center" class="tablerow2"><?php echo EQUIPE; ?></td>
	  <td align="center" class="tablerow1"><?php echo LANGU; ?></td>
	  <td align="center" class="tablerow2"><?php echo LASTCONNEC; ?></td>
	  <td align="center" class="tablerow1">&nbsp;</td>
	</tr>
<?php
while ($donnees = mysql_fetch_array($req))
{
?>
  <form action="" method="post">
  <input name="account_id" type="hidden" value="<?php echo $donnees['account_id']; ?>" />
   <tr>
	<td class="tablerow1"><a href="index.php?zone=management&page=memberedit&amp;id=<?php echo $donnees['account_id']; ?>"><?php echo $donnees['pseudo']; ?></a></td>
	<td align="center" class="tablerow1"><?php echo $donnees['compet_name']; ?></td>
	<td align="center" class="tablerow2"><?php echo $donnees['coach_name']; ?></td>
	<td class="tablerow1"><?php echo $donnees['team_name']; ?></td>
	<td class="tablerow2"><?php echo $donnees['lang']; ?></td>
	<td align="center" class="tablerow2"><?php echo date($donnees['dateformat_choice'], $donnees['lastlogin']); ?></td>
	<td align="center" class="tablerow2"><?php echo $donnees['lastip']; ?></td>
	<td align="center" class="tablerow1"><input name="delete" type="submit" value="<?php echo DELETEMEM; ?>" /></td>
   </tr>
  </form>
<?php
}
?>
   </tbody>
  </table>
 </div>