<?php
//-------------------------------------------------------------------------------------//
// SMOS - Sport Manager Open Source													   //
// http://snyzone.fr/smos/															   //
//-------------------------------------------------------------------------------------//
// Le projet est open source - sous license GPL										   //
// Vous �tes libre de l'utiliser mais pas � des fins commercial						   //
//																					   //
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr							   //
// Cr�ation : 08/10/09																   //
//-------------------------------------------------------------------------------------//

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['countrycreate']))
{
	crea_country($FORM['pays_name'], $FORM['pays_champ'], $FORM['pays_zone'], $FORM['pays_file_nom'], 
				 $FORM['pays_file_prenom'], $FORM['pays_flag'], $FORM['pays_money'], $FORM['pays_select'], 
				 $FORM['pays_actif'], $FORM['config_nbteam_perchamp'], $FORM['config_heurematch'], 
				 $FORM['config_tpsentre2match']);
	//Redirection sur la page suivi
	echo "<meta http-equiv=\"refresh\" content=\"0;url=index.php?zone=database&page=countrylist\">";
}
?>
<form action="" method="post">
<div class="tableborder">
 <div class="tableheaderalt"><?php echo EDITCO; ?></div>
  <table width="100%">
   <tbody>
    <tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_NAME; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_name" id="pays_name" size="40" value="" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_CHAMP; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_ champ" id="pays_ champ" size="40" value="" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_ZONE; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <select name="pays_zone" id="pays_zone">
        <option value="999"><?php echo ZONE1; ?></option>
		<option value="998"><?php echo ZONE2; ?></option>
		<option value="997"><?php echo ZONE3; ?></option>
		<option value="996"><?php echo ZONE4; ?></option>
		<option value="995"><?php echo ZONE5; ?></option>
	    <option value="994"><?php echo ZONE6; ?></option>
		<option value="992"><?php echo ZONE7; ?></option>
	    <option value="993"><?php echo ZONE8; ?></option>
	    <option value="991"><?php echo ZONE9; ?></option>
	    <option value="990"><?php echo ZONE10; ?></option>
	    <option value="989"><?php echo ZONE11; ?></option>
      </select>
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_LST_NOM; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_file_nom" id="pays_file_nom" size="40" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_LST_PRENOM; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_file_prenom" id="pays_file_prenom" size="40" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_DRAP; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_flag" id="pays_flag" size="40" value="" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_MONN; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_money" id="pays_money" size="40" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_SELECT; ?></b>
	  <div class="graytext"><?php echo CO_SELECT_INFO; ?></div></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_select" id="pays_select" size="40" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_ACTIF; ?></b>
	  <div class="graytext"><?php echo CO_ACTIF_INFO; ?></div></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="pays_actif" id="pays_actif" size="40" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_NBTEAM; ?></b>
	  <div class="graytext"><?php echo CO_NBTEAM_INFO; ?></div></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="config_nbteam_perchamp" id="config_nbteam_perchamp" size="40" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_HMATCH; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="config_heurematch" id="config_heurematch" size="40" />
	 </td>
	</tr>
	<tr>
	 <td class="tablerow1" valign="middle" width="40%"><b><?php echo CO_TPS2M; ?></b></td>
	 <td class="tablerow2" valign="middle" width="60%">
	  <input type="text" name="config_tpsentre2match" id="config_tpsentre2match" size="40" />
	 </td>
	</tr>
	<tr>
	 <td class="tablesubheader" colspan="2" align="center">
	  <input name="countrycreate" value="<?php echo CREATECO; ?>" class="realbutton" type="submit">
	 </td>
	</tr>
   </tbody>
  </table>
 </div>
</form>