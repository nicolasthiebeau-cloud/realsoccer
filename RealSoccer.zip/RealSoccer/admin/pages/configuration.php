<?php
//-------------------------------------------------------------------------------------//
// SMOS - Sport Manager Open Source													   //
// http://snyzone.fr/smos/															   //
//-------------------------------------------------------------------------------------//
// Le projet est open source - sous license GPL										   //
// Vous �tes libre de l'utiliser mais pas � des fins commercial						   //
//																					   //
// Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr							   //
// Cr�ation : 08/10/09																   //
//-------------------------------------------------------------------------------------//

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['configchange']))
{
	//Global
	$admin->updateconfig($FORM['decal_time'], 'decal_time');
	$admin->updateconfig($FORM['rang_0'], 'rang_0');
	$admin->updateconfig($FORM['rang_1'], 'rang_1');
	$admin->updateconfig($FORM['rang_2'], 'rang_2');
	$admin->updateconfig($FORM['rang_3'], 'rang_3');
	$admin->updateconfig($FORM['rang_4'], 'rang_4');
	$admin->updateconfig($FORM['rang_5'], 'rang_5');
	//Upload
	$admin->updateconfig($FORM['upload_dir'], 'upload_dir');
	//Inscription
	$admin->updateconfig($FORM['stop_inscription'], 'stop_inscription');
	$admin->updateconfig($FORM['team_shirt_dom'], 'team_shirt_dom');
	$admin->updateconfig($FORM['team_shirt_ext'], 'team_shirt_ext');
	$admin->updateconfig($FORM['team_money'], 'team_money');
	$admin->updateconfig($FORM['stade_infra'], 'stade_infra');
	$admin->updateconfig($FORM['formationcenter'], 'formationcenter');
	$admin->updateconfig($FORM['trainingcenter'], 'trainingcenter');
	$admin->updateconfig($FORM['note_pri_min'], 'note_pri_min');
	$admin->updateconfig($FORM['note_pri_max'], 'note_pri_max');
	$admin->updateconfig($FORM['note_sec_min'], 'note_sec_min');
	$admin->updateconfig($FORM['note_sec_max'], 'note_sec_max');
	$admin->updateconfig($FORM['note_age_min'], 'note_age_min');
	$admin->updateconfig($FORM['note_age_max'], 'note_age_max');
	$admin->updateconfig($FORM['note_tll_min'], 'note_tll_min');
	$admin->updateconfig($FORM['note_tll_max'], 'note_tll_max');
	$admin->updateconfig($FORM['salaire_multiple'], 'salaire_multiple');
	//Stade
	$admin->updateconfig($FORM['place_debout'], 'place_debout');
	$admin->updateconfig($FORM['place_assise'], 'place_assise');
	$admin->updateconfig($FORM['place_debout_couverte'], 'place_debout_couverte');
	$admin->updateconfig($FORM['place_assise_couverte'], 'place_assise_couverte');
	$admin->updateconfig($FORM['tribune_presidentielle'], 'tribune_presidentielle');
	$admin->updateconfig($FORM['buvette'], 'buvette');
	$admin->updateconfig($FORM['nom_stade'], 'nom_stade');
	$admin->updateconfig($FORM['nom_tribune'], 'nom_tribune');
	//March� des transferts
	$admin->updateconfig($FORM['jourdevente'], 'jourdevente');
	//Match
	$admin->updateconfig($FORM['minuteplay'], 'minuteplay');
	$admin->updateconfig($FORM['expulsion_penalite'], 'expulsion_penalite');
	$admin->updateconfig($FORM['suspension'], 'suspension');
	//Fonction Automatique
	$admin->updateconfig($FORM['salaire_day'], 'salaire_day');
	$admin->updateconfig($FORM['recette_day'], 'recette_day');
	$admin->updateconfig($FORM['training_day'], 'training_day');
	
	echo "<meta http-equiv=\"refresh\" content=\"0;url=index.php?zone=configuration\">";
}
?>
<form method="post" action="">
<div class="outerdiv" id="global-outerdiv"><!-- OUTERDIV -->
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
   <tbody>
    <tr>
	 <td id="rightblock" valign="top" width="100%">
	  <div style="border-bottom: 1px solid rgb(237, 237, 237); font-size: 30px; padding-left: 7px; letter-spacing: -2px;">
	  <?php echo TT_INDEX;  ?>
	  </div>
	  <br />
	   <table width="100%" border="0" cellpadding="0" cellspacing="4">
	    <tbody>
		 <tr>
		  <td valign="top" width="75%">
		   <table width="100%" border="0" cellpadding="0" cellspacing="0">
		    <tbody>
			 <tr>
			  <td>
			   <div class="homepage_pane_border">
			   <div class="homepage_section"><?php echo TT_INDEX; ?></div>
			    <table width="100%" cellpadding="4" cellspacing="0">
			   <tbody>
			   <tr>
			   <td valign="top" width="100%">
				<div class="homepage_border">
				<div class="homepage_sub_header"><a name="global" id="global"><?php echo GLO_TIT; ?></a></div>
				 <table width="100%" cellpadding="4" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php $timeok = time() + ($CONF['decal_time'] * 60 * 60); echo GLO_4 . ' ' . date($info['timeformat_choice'], $timeok); ?>.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="decal_time" value="<?php echo $CONF['decal_time']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo GLO_1; ?> 5.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="rang_5" value="<?php echo $CONF['rang_5']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo GLO_1; ?> 4.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="rang_4" value="<?php echo $CONF['rang_4']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo GLO_1; ?> 3.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="rang_3" value="<?php echo $CONF['rang_3']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo GLO_1; ?> 2.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="rang_2" value="<?php echo $CONF['rang_2']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo GLO_1 . ' 1 ' . GLO_2; ?>.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="rang_1" value="<?php echo $CONF['rang_1']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo GLO_1 . ' 0 ' . GLO_3; ?>.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="rang_0" value="<?php echo $CONF['rang_0']; ?>" /></td>
				   </tr>
				  </tbody>
				 </table>
				</div>
			   </td>
			  </tr>
			   <tr>
			   <td valign="top" width="100%">
				<div class="homepage_border">
				<div class="homepage_sub_header"><a name="inscription" id="inscription"><?php echo INS_TIT; ?></a></div>
				 <table width="100%" cellpadding="4" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo INS_1; ?></td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="stop_inscription" value="<?php echo $CONF['stop_inscription']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo INS_2; ?></td>
					<td class="homepage_sub_conf"><input type="text" name="team_shirt_dom" value="<?php echo $CONF['team_shirt_dom']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo INS_3; ?></td>
					<td class="homepage_sub_conf"><input type="text" name="team_shirt_ext" value="<?php echo $CONF['team_shirt_ext']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo INS_4; ?></td>
					<td class="homepage_sub_conf"><input type="text" name="team_money" value="<?php echo $CONF['team_money']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo INS_5 . '<br />' . INS_6; ?></td>
					<td class="homepage_sub_conf"><input type="text" name="stade_infra" value="<?php echo $CONF['stade_infra']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo INS_7; ?></td>
					<td class="homepage_sub_conf"><input type="text" name="formationcenter" value="<?php echo $CONF['formationcenter']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo INS_8; ?></td>
					<td class="homepage_sub_conf"><input type="text" name="trainingcenter" value="<?php echo $CONF['trainingcenter']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo INS_9; ?></td>
					<td class="homepage_sub_conf"><input type="text" name="note_pri_min" value="<?php echo $CONF['note_pri_min']; ?>" /> / <input type="text" name="note_pri_max" value="<?php echo $CONF['note_pri_max']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo INS_10; ?></td>
					<td class="homepage_sub_conf"><input type="text" name="note_sec_min" value="<?php echo $CONF['note_sec_min']; ?>" /> / <input type="text" name="note_sec_max" value="<?php echo $CONF['note_sec_max']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo INS_11; ?></td>
					<td class="homepage_sub_conf"><input type="text" name="note_age_min" value="<?php echo $CONF['note_age_min']; ?>" /> / <input type="text" name="note_age_max" value="<?php echo $CONF['note_age_max']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo INS_12; ?></td>
					<td class="homepage_sub_conf"><input type="text" name="note_tll_min" value="<?php echo $CONF['note_tll_min']; ?>" /> / <input type="text" name="note_tll_max" value="<?php echo $CONF['note_tll_max']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo INS_13; ?></td>
					<td class="homepage_sub_conf"><input type="text" name="salaire_multiple" value="<?php echo $CONF['salaire_multiple']; ?>" /></td>
				   </tr>
				  </tbody>
				 </table>
				</div>
			   </td>
		      </tr>
			  <tr>
			   <td valign="top" width="100%">
				<div class="homepage_border">
				<div class="homepage_sub_header"><a name="stade" id="stade"><?php echo STA_TIT; ?></a></div>
				 <table width="100%" cellpadding="4" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo STA_1; ?>.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="place_debout" value="<?php echo $CONF['place_debout']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo STA_2; ?>.</td>
					<td class="homepage_sub_conf"><input type="text" name="place_assise" value="<?php echo $CONF['place_assise']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo STA_3; ?>.</td>
					<td class="homepage_sub_conf"><input type="text" name="place_debout_couverte" value="<?php echo $CONF['place_debout_couverte']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo STA_4; ?>.</td>
					<td class="homepage_sub_conf"><input type="text" name="place_assise_couverte" value="<?php echo $CONF['place_assise_couverte']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo STA_5; ?>.</td>
					<td class="homepage_sub_conf"><input type="text" name="tribune_presidentielle" value="<?php echo $CONF['tribune_presidentielle']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo STA_6; ?>.</td>
					<td class="homepage_sub_conf"><input type="text" name="buvette" value="<?php echo $CONF['buvette']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo STA_7; ?>.</td>
					<td class="homepage_sub_conf"><input type="text" name="nom_stade" value="<?php echo $CONF['nom_stade']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo STA_8; ?>.</td>
					<td class="homepage_sub_conf"><input type="text" name="nom_tribune" value="<?php echo $CONF['nom_tribune']; ?>" /></td>
				   </tr>
				  </tbody>
				 </table>
				</div>
			   </td>
			  </tr>
			  <tr>
			   <td valign="top" width="100%">
				<div class="homepage_border">
				<div class="homepage_sub_header"><a name="mdt" id="mdt"><?php echo MDT_TIT; ?></a></div>
				 <table width="100%" cellpadding="4" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo MDT_1; ?>.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="jourdevente" value="<?php echo $CONF['jourdevente']; ?>" /></td>
				   </tr>
				  </tbody>
				 </table>
				</div>
			   </td>
			  </tr>
			  <tr>
			   <td valign="top" width="100%">
				<div class="homepage_border">
				<div class="homepage_sub_header"><a name="match" id="match"><?php echo MAT_TIT; ?></a></div>
				 <table width="100%" cellpadding="4" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo MAT_1; ?>.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="minuteplay" value="<?php echo $CONF['minuteplay']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo MAT_2; ?>.</td>
					<td class="homepage_sub_conf"><input type="text" name="expulsion_penalite" value="<?php echo $CONF['expulsion_penalite']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo MAT_3; ?>.</td>
					<td class="homepage_sub_conf"><input type="text" name="suspension" value="<?php echo $CONF['suspension']; ?>" /></td>
				   </tr>
				  </tbody>
				 </table>
				</div>
			   </td>
			  </tr>
			  <tr>
			   <td valign="top" width="100%">
			  <div class="homepage_border">
				<div class="homepage_sub_header"><a name="upload" id="upload"><?php echo'Upload'; ?></a></div>
				 <table width="100%" cellpadding="4" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo'R�pertoire upload<br />En local ce sera ex : c:/wamp/www/upload/ et sur un serveur ce sera ex : /home.10.8/emufr/blabla/smop/test/upload/'; ?>.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="upload_dir" value="<?php echo $CONF['upload_dir']; ?>" /></td>
				   </tr>
				  </tbody>
				 </table>
				</div>
			   </td>
			  </tr>
			  <tr>
			   <td valign="top" width="100%">
				<div class="homepage_border">
				<div class="homepage_sub_header"><a name="fonctionauto" id="fonctionauto"><?php echo FON_TIT; ?></a></div>
				 <table width="100%" cellpadding="4" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_conf" colspan="2"><div align="center"><?php echo FON_1; ?></div></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf" width="70%"><?php echo FON_2; ?>.</td>
					<td class="homepage_sub_conf" width="30%"><input type="text" name="salaire_day" value="<?php echo $CONF['salaire_day']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo FON_3; ?>.</td>
					<td class="homepage_sub_conf"><input type="text" name="recette_day" value="<?php echo $CONF['recette_day']; ?>" /></td>
				   </tr>
				   <tr>
				    <td class="homepage_sub_conf"><?php echo FON_4; ?>.</td>
					<td class="homepage_sub_conf"><input type="text" name="training_day" value="<?php echo $CONF['training_day']; ?>" /></td>
				   </tr>
				  </tbody>
				 </table>
				</div>
			   </td>
			  </tr>
			  <tr>
			   <td height="30" colspan="2" align="center" valign="middle"><input type="submit" name="configchange" value="<?php echo CONF_BUTTON; ?>" /></form></td>
			  </tr>
	         </tbody>
			</table>
	       </div>
		  </td>
		 </tr>
		</tbody>
	   </table>
	  </td>
	  <td valign="top" width="25%">
	<div class="homepage_pane_border" id="acp-news-outer">
	 <div class="homepage_section"><?php echo ACC_RAP; ?></div>
		<div>
			<div id="acp-news-wrapper">
			 <table width="100%" cellpadding="4" cellspacing="0">
			  <tbody>
			   <tr>
				<td class="homepage_sub_row"><a href="#global"><?php echo GLO_TIT; ?></a></td>
			   </tr>
			   <tr>
				<td class="homepage_sub_row"><a href="#inscription"><?php echo INS_TIT; ?></a></td>
			   </tr>
			   <tr>
				<td class="homepage_sub_row"><a href="#stade"><?php echo STA_TIT; ?></a></td>
			   </tr>
			   <tr>
				<td class="homepage_sub_row"><a href="#mdt"><?php echo MDT_TIT; ?></a></td>
			   </tr>
			   <tr>
				<td class="homepage_sub_row"><a href="#match"><?php echo MAT_TIT; ?></a></td>
			   </tr>
			   <tr>
				<td class="homepage_sub_row"><a href="#upload"><?php echo'Upload'; ?></a></td>
			   </tr>
			   <tr>
				<td class="homepage_sub_row"><a href="#fonctionauto"><?php echo FON_TIT; ?></a></td>
			   </tr>
			   <tr>
			  </tbody>
			 </table>
			</div>
		</div>
	</div>
	<br>
 </td>
</tr>
</tbody>
</table>
	 </div><!-- / RIGHT CONTENT BLOCK -->
	 </td></tr>
</tbody></table>
</div><!-- / OUTERDIV -->