<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
07/10/09	Cr�ation
*/


//Session
session_start();
if(empty($_SESSION['pseudo']) OR $_SESSION['rang'] < 3)	header('location: ../index.php');

//Protection contre les injections
define('SMOSPHP', 1);
$CONF = array();
$FORM = array();

//Configuration de base
$CONF['path'] = '..';

//On fusionne les variables GET et POST et on les prot�ges
$FORM = array_merge($_GET, $_POST);

//Mise � 0 des variables pour le nombre de requ�te, et le temps de la page
$nombrerequetes = 0;
$timer_requetes = 0;

//Function base de donn�e et fichier connexion
include("{$CONF['path']}/settings_sql.php");
include("{$CONF['path']}/sources/class/class_sql.php");
$sql = new sql;
$sql->connect();

//On recup�re les config de la table
$req = sql::query("SELECT config_name, config_value FROM configuration");
while($settings = mysql_fetch_assoc($req))
{ $CONF[$settings['config_name']] = $settings['config_value']; }

//Function admin de base
require_once("{$CONF['path']}/sources/class/class_admin.php");
$admin = new admin;

//Ajout d'un message dans le minichat
if(isset($FORM['minimessage'])) $admin->ajouteminimessage($FORM['canal'], $FORM['minimessage'], $_SESSION['id']);

//Zone info Management
$info = $admin->info_alljunction($_SESSION['pseudo']);

//Choix de la langue (� partir de la table comptes)
include("{$CONF['path']}/languages/" . $info['lang'] . " - Administration.php");

	$page = (!empty($FORM['zone'])) ? htmlentities($FORM['zone']) : 'main';
	$array_pages = array(
		//Base
		'main' => 'pages/main.php',
		'logout' => '../pages/logout.php',
		//Zone
		'management' => 'pages/management.php', 
		'database' => 'pages/database.php', 
		'configuration' => 'pages/configuration.php', 
		'aide' => 'pages/aide.php' 
						);
		
	if(!array_key_exists($page, $array_pages)) include('pages/erreur.php');

	elseif(!is_file($array_pages[$page])) include('pages/erreur.php');

	else
	{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head> 
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"> 
<title><?php echo 'RS Admin - ' . TT_INDEX;  ?></title>
<link rel="shortcut icon" href="../favicon.ico">
<link href="admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
<a name="top" id="top"></a>
<div id="ipdwrapper"><!-- IPDWRAPPER -->
<!-- TOP TABS -->
<div class="tabwrap-main">
 <div <?php if(isset($FORM['zone'])) echo $admin->menutab($FORM['zone'], 'main'); else echo'class="tabon-main"'; ?>><img src="../images/admin/vide.png" style="vertical-align: middle;"> <a href="index.php"><?php echo TAB_1; ?></a></div>
 <div <?php if(isset($FORM['zone'])) echo $admin->menutab($FORM['zone'], 'management'); else echo'class="taboff-main"'; ?>><img src="../images/admin/vide.png" style="vertical-align: middle;"> <a href="index.php?zone=management"><?php echo TAB_2; ?></a></div>
 <div <?php if(isset($FORM['zone'])) echo $admin->menutab($FORM['zone'], 'database'); else echo'class="taboff-main"'; ?>><img src="../images/admin/vide.png" style="vertical-align: middle;"> <a href="index.php?zone=database"><?php echo TAB_3; ?></a></div>
 <div <?php if(isset($FORM['zone'])) echo $admin->menutab($FORM['zone'], 'configuration'); else echo'class="taboff-main"'; ?>><img src="../images/admin/vide.png" style="vertical-align: middle;"> <a href="index.php?zone=configuration"><?php echo TAB_4; ?></a></div>
 <div <?php if(isset($FORM['zone'])) echo $admin->menutab($FORM['zone'], 'aide'); else echo'class="taboff-main"'; ?>><img src="../images/admin/help.png" style="vertical-align: middle;"> <a href="index.php?zone=aide"><?php echo TAB_5; ?></a></div>
 <div class="logoright"></div>
</div>
<!-- / TOP TABS -->
<div class="sub-tab-strip">
 <div class="global-memberbar"><?php echo BIENVENUE . ' <strong>' . $_SESSION['pseudo']; ?></strong> [<a href=""><?php echo DECO; ?></a>]</div>
 <?php if($_SESSION['pseudo'] != 'admin') { ?>
 <div class="navwrap"><a href="../club.php"><?php echo RETURNGAME; ?></a></div>
 <?php } ?>
</div>
<?php include($array_pages[$page]); ?>
<br />
<div class="global-copyright" align="center">RealSoccer - Propuls� par <a href="http://noxo-studio.fr" target="_blank">Noxo Studio</a><br />
<?php echo 'Page contenant '.$nombrerequetes.' requ&ecirc;tes mysql execut&eacute;es en '.$timer_requetes.' secondes'; ?>
<br /><br />

</div>
</div><!-- / IPDWRAPPER -->
</body>
</html>
<?php
	}
?> 