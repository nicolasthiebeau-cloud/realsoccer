<?php 
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
17/05/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['pseudo']) ||	isset($FORM['mdp']) ||	isset($FORM['souvenir']))
{	
	$pseudo=htmlentities(addslashes($FORM['pseudo']));
	$mdp=md5(htmlentities(addslashes($FORM['mdp'])));
	$souvenir = '';
	$error = $index->login($pseudo, $mdp, $souvenir);
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo 'RealSoccer - ' . TT_CONNEC;  ?></title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"> 
<meta http-equiv="Pragma" content="no-cache" />
<meta name="description" content="RealSoccer ! D�couvrez le foot en ligne !">
<meta name="keywords" content="Jeu Foot ! RealSoccer">
<meta name="author" content="Noxo Studio">
<meta name=identifier-url content="http://noxo-studio.fr">
<meta name="revisit-after" content="7 days">
<meta name="category" content="Jeux PHP">
<link rel="shortcut icon" href="smos.ico">
<link href="index.css" rel="stylesheet" type="text/css" />
	<script src="http://platform.twitter.com/widgets.js" type="text/javascript"></script>
    <script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>

</head>
<body>
<div class="index2">
  <div class="index_logo png"></div>
  <div class="index_title">
    <div align="center" class="Style2"><?php echo TITLE; ?></div>
  </div>
  <div class="index_login2">
	  <span class="Style4"><?php echo GAME_INFO; ?></span>
	  <br />
	  <br />
	  <div align="center" class="Style3"><a href="index.php?page=newaccount"><?php echo INSCRIPT; ?></a></div>
	  <br />
	  <br />
	  <div align="center" class="Style5">
	  <?php echo MEM_ONLINE . ': ' . $index->nb_member_online(); ?> - 
	  <?php echo LAST_MEM . ': ' . $index->last_member(); ?> - 
	  <?php echo MEM_TOT . ': ' . $index->nb_member_total(); ?>
      </div>
      <br />
      <?php if(isset($error)) echo '<font color="#FF0000"><b>'.$error.'</b></font><br />'; else echo'<br /><br />'; ?>
	  <br />
	<div align="right">
    <form id="form1" name="form1" method="post" action="">
    <label for="pseudo"><?php echo PSEUDO . ': '; ?></label>
    <input name="pseudo" type="text" id="pseudo" class="log_champ" size="20" />
    <label for="mdp"><?php echo MDP . ': '; ?></label>
    <input name="mdp" type="password" id="mdp" class="log_champ" size="20" />
    <br />
    <label for="souvenir"><?php echo SOUVENIR; ?> </label>
    <input type="checkbox" name="souvenir" id="souvenir" />&nbsp;&nbsp;
      <input type="submit" name="connexion" id="connexion" class="log_button" value="<?php echo BUTTON_CONNEX; ?>" />
    </form>
    </div>
  </div>
  <div style="float: right;margin-right: 100px;margin-top: -265px;">
  <div style="background: #fff;margin-bottom: 10px;">
<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fpages%2FRealSoccerfr%2F195885947127620&amp;width=292&amp;colorscheme=light&amp;show_faces=true&amp;border_color=%23444&amp;stream=false&amp;header=false&amp;height=358" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:292px; height:358px;" allowTransparency="true"></iframe>
</div>
<a href="http://twitter.com/share" class="twitter-share-button" data-url="http://realsoccer.fr" data-via="noxodev" data-text="D�couvrez vite le foot en ligne via Realsoccer !" data-related="twitter,twitfond" data-count="vertical" data-lang="fr">Tweeter</a> <g:plusone size="tall"></g:plusone>
</div>
</div>