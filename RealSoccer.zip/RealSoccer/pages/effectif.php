<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//On recup la derni�re saison en cours
$view = sql::fetch("SELECT saison_nbr 
				    FROM classement 
				    WHERE team_id= '".$info['team_id']."' 
				    ORDER BY saison_nbr DESC 
				    LIMIT 1");

if (isset($FORM['orderby'])) $orderby = $FORM['orderby'];
else $orderby = 'joindate';
?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo EFFECT; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	  <td class="homepage_sub_header" align="center"><?php echo NATIO; ?></td>
	  <td class="homepage_sub_header" align="center"><?php echo INFO; ?></td>
	  <td class="homepage_sub_header" align="center"><?php echo IDENTITE; ?></td>
	  <td class="homepage_sub_header" align="center"><?php echo POSITION; ?></td>
	  <td class="homepage_sub_header" align="center"><?php echo AGE; ?></td>
	  <td class="homepage_sub_header" align="center"><?php echo FORME; ?></td>
	  <td class="homepage_sub_header" align="center"><?php echo MORAL; ?></td>
	  <td class="homepage_sub_header" align="center"><?php echo APPAR; ?></td>
	  <td class="homepage_sub_header" align="center"><?php echo BUT; ?></td>
	  <td class="homepage_sub_header" align="center"><?php echo PASDEC; ?></td>
	  <td class="homepage_sub_header" align="center"><?php echo COMPO; ?></td>
	</tr>
<?php
$req = sql::query("SELECT joueurs.player_id, joueurs.team_id, nom, surnom, prenom, age, forme, moral, statut, 
						   pays_name, pays_flag, 
						   group_id, pos_shortname, 
						   champ_sel, champ_but, champ_pasdec, 
						   N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15, 
						   dmd_id, 
						   suspension, 
						   blessure 
					FROM joueurs 
					LEFT JOIN pays ON joueurs.nationalite = pays.pays_id 
					LEFT JOIN joueurs_position ON joueurs.position = joueurs_position.pos_id 
					LEFT JOIN classement_joueur ON joueurs.player_id = classement_joueur.player_id 
					LEFT JOIN tactiques ON tactiques.id_team = joueurs.team_id 
					LEFT JOIN joueurs_achat_demande ON joueurs_achat_demande.player_id = joueurs.player_id
					LEFT JOIN stamp_suspension ON stamp_suspension.id_player = joueurs.player_id 
					LEFT JOIN stamp_blessure ON stamp_blessure.id_player = joueurs.player_id 
					WHERE joueurs.team_id= '".$info['team_id']."' AND saison_nbr = '".$view['saison_nbr']."' 
					AND age > 16 
					ORDER BY joueurs.position, nom");

$color = 1;

while ($donnees = mysql_fetch_assoc($req))
{
?>
	<tr>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo '<img src="images/flag' . '/' . $donnees['pays_flag'] . '" width="32" height="20" alt="' . $donnees['pays_name'] . '" />'; ?></td>
    <td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $club->info_effect($donnees['blessure'], $donnees['suspension'], $donnees['statut'], $donnees['dmd_id']); ?></td>
	<td <?php echo $club->colorchoice($color); ?>><?php echo' <a href="club.php?zone=management&amp;page=joueur&amp;id='. $donnees['player_id'] .'"><strong>'. stripslashes($donnees['prenom']) . ' ';
			  if ($donnees['surnom'] != NULL) echo '\' '. stripslashes($donnees['surnom']) . ' \'';
			  echo ' ' . stripslashes($donnees['nom']); ?></strong></a></td>
    <td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $club->smallposition($donnees['group_id'], $donnees['pos_shortname']); ?></td>
    <td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $donnees['age']; ?></td>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $club->notecolor100(round($donnees['forme'])); ?></td>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $club->notecolor100(round($donnees['moral'])); ?></td>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $donnees['champ_sel']; //A MODIFIER ?></td>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $donnees['champ_but']; ?></td>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $donnees['champ_pasdec']; ?></td>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $club->info_compo($donnees); ?></td>
  </tr>
<?php
	if($color == 1) $color++; else $color--;
}
?>
   </tbody>
  </table>
 </div>