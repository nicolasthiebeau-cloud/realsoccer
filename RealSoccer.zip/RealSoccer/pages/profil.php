<?php
if (isset($_SESSION['id'])): 
	$idUser = $_SESSION['id'];
	
	if (isset($_POST['editInfos'])):
		$email = mysql_real_escape_string($_POST['email']);
		$coach_name = mysql_real_escape_string($_POST['coach_name']);
		
		mysql_query("UPDATE comptes SET email='$email', coach_name='$coach_name' WHERE account_id='".$idUser."'");
	endif;
	
	$demUser = mysql_query("SELECT * FROM comptes WHERE account_id='".$idUser."'");
	$infosUser = mysql_fetch_assoc($demUser);
	
	if (isset($_POST['editPw'])):
		$exPw = mysql_real_escape_string($_POST['exPw']);
		$newPw = mysql_real_escape_string($_POST['newPw']);
		$newPw2 = mysql_real_escape_string($_POST['newPw2']);
		
		if($infosUser['mdp']==md5($exPw)):
			if ($newPw==$newPw2):
				if (strlen($newPw)>5):
					mysql_query("UPDATE comptes SET mdp='".md5($newPw)."' WHERE account_id='$idUser'");
					echo '<strong>La modification du mot de passe a bien �t� effectu�e.</strong>';
				else:
					echo '<strong>Erreur : Votre nouveau mot de passe est trop court.</strong>';
				endif;
			endif;
		else:
			echo '<strong>Erreur : L\'ancien mot de passe n\'est pas bon.</strong>';
		endif;
	endif;
		
	?>
    <br /><br />
    <fieldset><legend>Modification des informations</legend>
        <form action="" method="POST">
            <table>
                <tr><td>Pseudo</td><td><input type="text" name="pseudo" value="<?php echo $infosUser['pseudo']; ?>" disabled="disabled" /></td></tr>
                <tr><td>Mail</td><td><input type="text" name="email" value="<?php echo $infosUser['email']; ?>" /></td></tr>
                <tr><td>Nom entra�neur</td><td><input type="text" name="coach_name" value="<?php echo $infosUser['coach_name']; ?>" /></td></tr>
                <tr><td>Date d'inscription</td><td><?php echo date('d/m/Y � H:m', $infosUser['joindate']); ?></td></tr>
                <tr><td>Derni�re connexion</td><td><?php echo date('d/m/Y � H:m', $infosUser['lastlogin']); ?></td></tr>
                <tr><td></td><td><input type="submit" name="editInfos" value="Mettre � jour les informations" /></td></tr>
            </table>
        </form>
    </fieldset>
    
    <fieldset><legend>Modification du mot de passe</legend>
        <form action="" method="POST">
            <table>
                <tr><td>Ancien mot de passe</td><td><input type="text" name="exPw" /></td></tr>
                <tr><td>Nouveau mot de passe</td><td><input type="text" name="newPw" /></td></tr>
                <tr><td>Confirmation</td><td><input type="text" name="newPw2"  /></td></tr>
                <tr><td></td><td><input type="submit" name="editPw" value="Mettre � jour le mot de passe" /></td></tr>
            </table>
        </form>
    </fieldset>
    
    <?php




else: header('location: index.php'); endif;

?>