<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['minimessage']) AND $FORM['minimessage'] != NULL)
{
	$time = time(); $account = $info['account_id']; 
	$minimessage = htmlentities(addslashes($FORM['minimessage']));
	$canal = $info['canal_choice'];
	
	if(!empty($_SESSION['pseudo']))
	{
		$resultat = sql::insert("INSERT INTO minichat(mnc_time, account_id, texte, canal) 
								 VALUES('".$time."', '".$account."', '".$minimessage."', '".$canal."')");
	}
}
?>
  <table width="100%" cellpadding="0" cellspacing="0">
    <tbody>
	  <tr>
	    <td valign="top" width="100%">
		<div class="homepage_border">
		<div class="homepage_sub_header"><?php echo MINICHAT; ?></div>
		  <table width="100%" cellpadding="0" cellspacing="0">
		    <tbody>
			  <tr>
			    <td class="homepage_sub_row" colspan="2">
				  <table width="100%" height="100%" border="0" align="center" cellspacing="5">
				    <tr>
				      <td valign="bottom" class="minichat_table">
					  <div class="minichat_scroll">
					    <table width="98%" border="0" cellspacing="2">
						<?php
						$req = sql::query("SELECT mnc_id, mnc_time, minichat.account_id, texte, pseudo, team_id, team_name 
											FROM minichat 
											LEFT JOIN comptes ON minichat.account_id = comptes.account_id 
											LEFT JOIN equipes ON minichat.account_id = equipes.account_id 
											WHERE canal IN('".$info['canal_choice']."', 0) 
											ORDER BY mnc_id DESC");
						
						while ($donnees = mysql_fetch_assoc($req))
						{
							$text = stripslashes($donnees['texte']);
							$newtext = wordwrap($text, 50, "\n", true);
						?>
						  <tr>
						    <td width="15%" align="center" valign="top">[<?php echo date($info['dateformat_choice'], $donnees['mnc_time']); ?>]</td>
							<td width="85%">
							<?php echo'<a href="club.php?page=profil&amp;m='.$donnees['account_id'].'&amp;action=consulter">' . 
							$donnees['pseudo'] . '</a>'; ?> ( 
							<a href="club.php?zone=public&amp;page=teaminfo&amp;id=<?php echo $donnees['team_id']; ?>">
							<?php echo $donnees['team_name']; ?></a> ) : <?php echo $newtext; ?></td>
						  </tr>
						<?php
						}
						?>
						</table>
					  </div>
					  </td>
					</tr>
				  </table>
				</td>
			  </tr>
			  <tr>
				<td class="homepage_sub_row" colspan="2">
				<div style="float: left;">
				<form id="form1" name="form1" method="post" action="">
				<select name="canal" onChange="submit();">
				<?php
				$req3 = sql::query("SELECT * FROM minichat_canal ORDER BY position") ;
				while ($donnees = mysql_fetch_array($req3))
				{
				?>
				<option value="<?php echo $donnees['canal_id']; ?>" 
				<?php if($info['canal_choice'] == $donnees['canal_id']) echo 'selected="selected"'; ?> ><?php echo $donnees['canal_name']; ?></option>
				<?php
				}
				?>
				</select>
				<input name="minimessage" type="text" id="minimessage" size="60" />
				<input type="submit" name="mp" id="mp" value="<?php echo MINICHATMESS; ?>" />
				</form>
				</div>
				<div style="float: right;">
				<a href="javascript:location.reload()">Rafraichir</a>&nbsp;&nbsp;
				</div>
				</td>
			  </tr>
			</tbody>
		  </table>
		</div>
		</div>
	    </td>
	  </tr>
    </tbody>
  </table>