<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
01/09/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//Class Stade
include('sources/class_page/class_stade.php');
$stade = new stade;

if (isset($FORM['tribune']) && $FORM['tribune'] != NULL) 
{
	//S�paration du nom du stade et des tribunes
	$tribexpl = explode(';', $info['stade_infra']);
	
	//Protection de la saisie
	$tribune = htmlentities(addslashes($FORM['tribune']));
	
	switch($tribune)
	{
		case "nordouest" : 	$trib = $tribexpl[0]; break;
		case "nord" : 		$trib = $tribexpl[1]; break;
		case "nordest" : 	$trib = $tribexpl[2]; break;
		case "ouest" : 		$trib = $tribexpl[3]; break;
		case "est" : 		$trib = $tribexpl[4]; break;
		case "sudouest" :	$trib = $tribexpl[5]; break;
		case "sud" : 		$trib = $tribexpl[6]; break;
		case "sudest" : 	$trib = $tribexpl[7]; break;
		default : 			$trib = 'error'; break;
	}
}

else die("Pas de tribune selectionner.");

//Construction d'une tribune
if(isset($FORM['stad_id'])) $error = $stade->tribune_construction($tribune, $FORM['stad_id'], $FORM['tmp_fin'], $FORM['price'], $info);

//Changement du nom de la tribune
if(isset($FORM['nomtribune'])) $error = $stade->tribune_change_name($tribune, $FORM['nomtribune'], $info, $CONF)
?>
<div style="border-bottom: 1px solid rgb(237, 237, 237); font-size: 25px; padding-left: 7px; letter-spacing: -2px;">
  <div align="center">
    <?php echo $stade->affiche_nom_tribune($info['stade_name'], $FORM['tribune']); ?>
  </div>
</div>
<br />
<table width="100%" border="0" cellspacing="8" cellpadding="0">
  <tr>
    <td width="50%" valign="top">
<?php 
$timestamp = sql::fetch("SELECT COUNT(*) AS exist FROM stamp_construction WHERE type = 'tribune' AND position = '".$tribune."' AND id_team = '".$info['team_id']."'");

if ($timestamp['exist'] == 0)
{
?>
  <div class="tableborder">
  <div class="tableheaderalt"><?php echo CHX_TRIB . ' ' . $tribune; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
<?php
	$req = sql::query("SELECT * FROM stade WHERE stad_pos='".$tribune."'");
	while ($donnees = mysql_fetch_array($req))
	{
	?>
	<tr>
	  <td class="homepage_sub_header" align="center">
	    <form method="post" action="club.php?zone=management&amp;page=infrastade&amp;tribune=<?php echo $tribune; ?>">
		<input name="stad_id" type="hidden" value="<?php echo $donnees['stad_id']; ?>" />
		<input name="tmp_fin" type="hidden" value="<?php echo $donnees['duree_const']; ?>" />
		<input name="price" type="hidden" value="<?php echo $donnees['price']; ?>" />
		<input type="image" name="achatok" src="<?php echo 'images/stade/' . $donnees['tribune_img'] . '_' . $tribune . '.gif'; ?>" />
		</form>
		<p><?php echo '<strong><u>' . $donnees['stad_type'] . ' : ' . $donnees['tribune_img'] . '</u></strong>&nbsp;&nbsp;&nbsp;' . COUT . ' : ' . 
		$donnees['price'] . ' - ' . $stade->switchcontrucdate($donnees['duree_const']) . ' ' . JOURCONST . '<br /><br />';
		echo PL_DEBOUT . ' : ' . $donnees['pla_debout'] . '&nbsp;&nbsp;&nbsp;' . PL_ASSIS . ' : ' . $donnees['pla_assise'] . '<br />';
		echo PL_DEBOUTC . ' : ' . $donnees['pla_debout_couv'] . '&nbsp;&nbsp;&nbsp;' . PL_ASSISC . ' : ' . $donnees['pla_assise_couv'] . '<br />'; 
		echo TRI_PRESI . ' : ' . $donnees['tribune_presi'] . '&nbsp;&nbsp;&nbsp;' . BUVET . ' : ' . $donnees['buvette'] . '<br />'; ?></p>
	  </td>
	</tr>
	<tr>
	  <td class="homepage_sub_header"><hr />
	  </td>
	</tr>
	<?php	
	}
	?>
     </tbody>
  </table>
 </div>
<?php
}

else
{
?>
  <div class="tableborder">
  <div class="tableheaderalt"><?php echo CONST_TRIB . ' ' . $tribune; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <?php
	$data = sql::fetch("SELECT * 
						FROM stamp_construction 
						LEFT JOIN stade ON stade.stad_id = stamp_construction.id 
						WHERE type = 'tribune' 
						  AND position = '".$tribune."' 
						  AND id_team = '".$info['team_id']."'");
   ?>
   <tbody>
	 <tr>
	  <td class="homepage_sub_header" align="center">
	    <img src="images/stade/<?php echo $data['tribune_img'] . '_' . $tribune . '.gif'; ?>" />
		<p><?php echo '<strong><u>' . $data['stad_type'] . ' : ' . $data['tribune_img'] . '</u></strong>&nbsp;&nbsp;&nbsp;' . COUT . ' : ' . 
		$data['price'] . ' - ' . $stade->switchcontrucdate($data['duree_const']) . ' ' . JOURCONST . '<br /><br />';
		echo PL_DEBOUT . ' : ' . $data['pla_debout'] . '&nbsp;&nbsp;&nbsp;' . PL_ASSIS . ' : ' . $data['pla_assise'] . '<br />';
		echo PL_DEBOUTC . ' : ' . $data['pla_debout_couv'] . '&nbsp;&nbsp;&nbsp;' . PL_ASSISC . ' : ' . $data['pla_assise_couv'] . '<br />'; 
		echo TRI_PRESI . ' : ' . $data['tribune_presi'] . '&nbsp;&nbsp;&nbsp;' . BUVET . ' : ' . $data['buvette'] . '<br /><br />';
		echo CONST_END . ' : ' . $stade->comparetimestamp($data['timestamp_fin']); ?></p>
	  </td>
	</tr>
     </tbody>
  </table>
 </div>
<?php
}
?>
	</td>
    <td width="50%" valign="top">
  <div class="tableborder">
  <div class="tableheaderalt"><?php echo TRIB_ACTU; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	  <td class="homepage_sub_header" align="center">
	    <?php
		$data = sql::fetch("SELECT * FROM stade WHERE stad_id='".$trib."'");
		?>
		<div align="center"><img src="images/stade/<?php echo $data['tribune_img'] . '_' . $tribune; ?>.gif" border="0" /></div>
		<?php echo PL_DEBOUT . ' : ' . $data['pla_debout']; ?><br />
		<?php echo PL_ASSIS . ' : ' . $data['pla_assise']; ?><br />
		<?php echo PL_DEBOUTC . ' : ' . $data['pla_debout_couv']; ?><br />
		<?php echo PL_ASSISC . ' : ' . $data['pla_assise_couv']; ?><br />
		<?php echo TRI_PRESI . ' : ' . $data['tribune_presi']; ?><br /><br />
		<?php echo BUVET . ' : ' . $data['buvette']; ?><br />
	  </td>
	</tr>
	<tr>
	  <td class="homepage_sub_header" align="center">
	  
	  </td>
	</tr>
   </tbody>
  </table>
 </div>
 <br />
  <div class="tableborder">
  <div class="tableheaderalt"><?php echo TRIB_ACTU; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	  <td class="homepage_sub_header" align="center">
	    <?php echo TRIB_MODIFINFO . ' ' . $CONF['nom_tribune'] . ' ' . $info['pays_money']; ?>.
		<form method="post" action="club.php?zone=management&amp;page=infrastade&amp;tribune=<?php echo $tribune; ?>"  onsubmit='return confirm (&quot;<?php echo TRIB_MODIFRETURN; ?>&quot;)' >
        <input name="nomtribune" type="text" size="49" maxlength="49" />
        <br /><br />
        <input type="submit" name="button" id="button" value="<?php echo TRIB_MODIF; ?>" />
        </form>
	  </td>
	</tr>
   </tbody>
  </table>
  </div>
  </td>
 </tr>
</table>