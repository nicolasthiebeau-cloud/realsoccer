<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
29/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//Age
if(isset($FORM['age_min']) && isset($FORM['age_max'])) { $age_min = $FORM['age_min']; $age_max = $FORM['age_max']; }
else { $age_min = 0; $age_max = 99; }

//Sort
if(isset($FORM['fsort1']) && $FORM['fsort1'] != 0) $sort1 = ", " . $FORM['fsort1'];
if(isset($FORM['fsort2']) && $FORM['fsort2'] != 0) $sort2 = ", " . $FORM['fsort2'];

$req = sql::query("SELECT * 
				   FROM joueurs 
				   LEFT JOIN pays ON pays.pays_id = joueurs.nationalite 
				   LEFT JOIN joueurs_position ON joueurs.position = joueurs_position.pos_id 
				   WHERE statut = 1 
				     AND age BETWEEN  ".$age_min." AND ".$age_max." 
					 AND team_id != ".$info['team_id']." 
				   ORDER BY nom");
?>
<table width="100%" border="0" cellspacing="8" cellpadding="0">
  <tr>
    <td width="50%" valign="top">
	<div class="tableborder">
	<div class="tableheaderalt"><?php echo 'March� des Transferts'; ?></div>
	<table width="100%" border="0" cellspacing="0" cellpadding="1">
	  <tr>
	   <td class="homepage_sub_row_2">&nbsp;</td>
	   <td class="homepage_sub_row_2"><?php echo IDENTITE; ?></td>
	   <td class="homepage_sub_row_2" align="center"><?php echo POSITION; ?></td>
	   <td class="homepage_sub_row_2"><?php echo AGE; ?></td>
	   <td class="homepage_sub_row_2"><?php echo TAILLE; ?></td>
	   <td class="homepage_sub_row_2" align="center"><?php echo GARDIEN; ?></td>
	   <td class="homepage_sub_row_2" align="center"><?php echo DEFENSEUR; ?></td>
	   <td class="homepage_sub_row_2" align="center"><?php echo MILIEU; ?></td>
	   <td class="homepage_sub_row_2" align="center"><?php echo ATTAQUANT; ?></td>
	   <td class="homepage_sub_row_2"></td>
	  </tr>
	  <?php
	  while ($donnees = mysql_fetch_assoc($req))
	  {
	  ?>
	  <tr>
	   <td class="homepage_sub_row_2"><div align="center"><?php echo'<img src="images/flag' . '/' . $donnees['pays_flag'] . '" width="32" height="20" alt="' . $donnees['pays_name'] . '" />'; ?></div></td>
	   <td class="homepage_sub_row_2" valign="middle"><?php echo'<a href="club.php?zone=marchetransfert&page=joueur&id=' . $donnees['player_id'] . '">' . $donnees['nom'] . ' ' . $donnees['prenom'] . '</a>'; ?></td>
	   <td class="homepage_sub_row_2" align="center"><?php echo $club->smallposition($donnees['group_id'], $donnees['pos_shortname']); ?></td>
	   <td class="homepage_sub_row_2"><?php echo $donnees['age']; ?></td>
	   <td class="homepage_sub_row_2"><?php echo $donnees['taille']; ?></td>
	   <td class="homepage_sub_row_2"><div align="center"><a href="club.php?zone=support&amp;page=notice#niveaujoueur"><?php echo $club->compare_etoile($donnees['player_id'], $donnees, 1); ?></a></div></td>
	   <td class="homepage_sub_row_2"><div align="center"><a href="club.php?zone=support&amp;page=notice#niveaujoueur"><?php echo $club->compare_etoile($donnees['player_id'], $donnees, 2); ?></a></div></td>
	   <td class="homepage_sub_row_2"><div align="center"><a href="club.php?zone=support&amp;page=notice#niveaujoueur"><?php echo $club->compare_etoile($donnees['player_id'], $donnees, 3); ?></a></div></td>
	   <td class="homepage_sub_row_2"><div align="center"><a href="club.php?zone=support&amp;page=notice#niveaujoueur"><?php echo $club->compare_etoile($donnees['player_id'], $donnees, 4); ?></a></div></td>
	   <td class="homepage_sub_row_2"></td>
	  </tr>
	  <?php
	  }
	?>
	</table>
	</div>
	</td>
  </tr>
</table>