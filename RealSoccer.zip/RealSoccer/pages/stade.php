<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
01/09/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//Fonction du stade
include('sources/class_page/class_stade.php');
$stade = new stade;

if(isset($FORM['nomstade'])) $stade->stade_change_name($FORM['nomstade'], $info, $CONF);
?>
<div style="border-bottom: 1px solid rgb(237, 237, 237); font-size: 25px; padding-left: 7px; letter-spacing: -2px;">
  <div align="center">
    <?php echo $stade->affiche_nom_stade($info['stade_name']); ?>
  </div>
</div>
<br />
 <div id="fulstade">
<?php echo $stade->stade_viewer($info['stade_infra'], $info['team_id']); ?>
</div>
<br />
<table width="100%" border="0" cellspacing="8" cellpadding="0">
  <tr>
    <td width="50%" valign="top">
  <div class="tableborder">
  <div class="tableheaderalt"><?php echo LEGEND; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	  <td class="homepage_sub_header" align="center">
	    <img src="images/stade/travaux.gif" border="0" /> <?php echo LEG_CONST; ?>.<br /><br /><br /><br />
	  </td>
	</tr>
     </tbody>
  </table>
 </div>
	</td>
    <td width="50%" valign="top">
  <div class="tableborder">
  <div class="tableheaderalt"><?php echo STADE_MODIF; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	  <td class="homepage_sub_header" align="center">
	    <?php echo STADE_MODIFINFO . ' ' . $CONF['nom_stade'] . ' ' . $info['pays_money']; ?>.
		<form method="post" action="club.php?zone=management&amp;page=stade"  onsubmit='return confirm (&quot;<?php echo STADE_MODIFRETURN; ?>&quot;)' >
        <input name="nomstade" type="text" id="nomstade" size="49" maxlength="49" />
        <br /><br />
        <input type="submit" name="button" id="button" value="<?php echo STADE_MODIF; ?>" />
        </form>
	  </td>
	</tr>
     </tbody>
  </table>
 </div>
	</td>
  </tr>
</table>