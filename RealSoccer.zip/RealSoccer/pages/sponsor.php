<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//choix du sponsor
if(isset($FORM['sponsor']))
{
	$requete = sql::update("UPDATE equipes SET sponsor_id = '".$FORM['sponsor']."' WHERE team_id = '".$info['team_id']."'");
	echo "<meta http-equiv=\"refresh\" content=\"0;url=club.php?zone=bureaumanager&amp;page=sponsor\">";
}
?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo SPONCHOICE; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	<tr>
      <td class="homepage_sub_row">
	  <?php echo SPONINFO; ?>
	  </td>
    </tr>
<?php
if ($info['sponsor_id'] == 0)
{
?>
	<form action='' method='post'>
	<tr>
      <td class="homepage_sub_row">
	  <select name='sponsor'>
	  <?php
	  $req = sql::query("SELECT sponsor_id, sponsor_name, sponsor_money FROM sponsor WHERE sponsor_div >= '".$info['division']."' ORDER BY sponsor_name DESC");
	  
	  while ($donnees = mysql_fetch_assoc($req))
	  {
		echo '<option value="' . $donnees['sponsor_id'] . '">' . $donnees['sponsor_name'] . ' - ' . $donnees['sponsor_money'] . '</option>';
	  }
	  ?>
	  </select>
	  </td>
    </tr>
	<tr>
      <td class="homepage_sub_row">
	  <input type='submit' value='<?php echo SPONCHOICE2; ?>'>
	  </td>
    </tr>
	</form>
<?php
}

else
{
?>
	<tr>
      <td class="homepage_sub_row">
	  <?php echo $club->viewsponsor($info['sponsor_name'], $info['sponsor_money']); ?>
	  </td>
    </tr>
<?php
}
?>
   </tbody>
  </table>
 </div>