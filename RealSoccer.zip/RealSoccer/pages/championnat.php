<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
23/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }
?>
<link href="scripts/menu_onglet_classement.css" rel="stylesheet" type="text/css" />
<table width="100%" border="0" cellspacing="8" cellpadding="0">
  <tr>
    <td width="60%" valign="top">
<div class="homepage_border">
<div class="homepage_sub_header"><?php echo CLASSEMENT; ?></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="class_other" width="10%"></td>
    <td class="class_other" width="45%"><?php echo TEAM; ?></td>
	<td class="class_other" width="5%" align="center"><?php echo MJ; ?></td>
	<td class="class_other" width="5%" align="center"><?php echo V; ?></td>
	<td class="class_other" width="5%" align="center"><?php echo N; ?></td>
	<td class="class_other" width="5%" align="center"><?php echo D; ?></td>
	<td class="class_other" width="5%" align="center"><?php echo BP; ?></td>
	<td class="class_other" width="5%" align="center"><?php echo BC; ?></td>
	<td class="class_other" width="5%" align="center"><?php echo DIFF; ?></td>
	<td class="class_other" width="15%" align="center"><?php echo POINT; ?></td>
  </tr>
<?php
	//Affichage classement �quipe
	$req = sql::query("SELECT MJ, V, N, D, BP, BC, point, 
							  equipes.team_id AS team_id, team_name 
					   FROM classement 
					   LEFT JOIN equipes ON equipes.team_id = classement.team_id 
					   WHERE classement.compet_id='".$compet_id."' 
						 AND saison_nbr='".$saison_nbr."' 
					   ORDER BY point DESC, BP-BC DESC");
	
	$classement = 1;
	
	while ($donnees = mysql_fetch_assoc($req))
	{
?>
	<tr>
    <td align="center" <?php echo $club->classcolor($classement); ?>><b><?php if($donnees['MJ'] == 0) echo '-'; else echo $classement; ?></td>
	<td <?php echo $club->classcolor($classement); ?>><a href="club.php?zone=public&amp;page=teaminfo&amp;id=<?php echo $donnees['team_id']; ?>"><?php echo $donnees['team_name']; ?></a></td>
    <td align="center" <?php echo $club->classcolor($classement); ?>><?php echo $donnees['MJ']; ?></td>
	<td align="center" <?php echo $club->classcolor($classement); ?>><?php echo $donnees['V']; ?></td>
	<td align="center" <?php echo $club->classcolor($classement); ?>><?php echo $donnees['N']; ?></td>
	<td align="center" <?php echo $club->classcolor($classement); ?>><?php echo $donnees['D']; ?></td>
	<td align="center" <?php echo $club->classcolor($classement); ?>><?php echo $donnees['BP']; ?></td>
	<td align="center" <?php echo $club->classcolor($classement); ?>><?php echo $donnees['BC']; ?></td>
	<td align="center" <?php echo $club->classcolor($classement); ?>><?php $result = $donnees['BP'] - $donnees['BC']; echo $result; ?></td>
	<td align="center" <?php echo $club->classcolor($classement); ?>><?php echo $donnees['point']; ?></td>
  </tr>
<?php
		$classement++;
	}
?>
</table>
</div>
<br />
<table>
  <tr>
    <td><?php echo INFO_VIC; ?>&nbsp;&nbsp;&nbsp;<?php echo INFO_NUL; ?>&nbsp;&nbsp;&nbsp;<?php echo INFO_DEF; ?><br /></td>
  </tr>
</table>
<br />
<div class="homepage_border">
<div class="homepage_sub_header"><?php echo CLASSBUTEUR; ?></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="class_other" width="10%" align="center">-</td>
	<td class="class_other" width="40%"><?php echo NONPLAYER; ?></td>
    <td class="class_other" width="40%"><?php echo TEAM; ?></td>
	<td class="class_other" width="10%" align="center"><?php echo NBBUT; ?></td>
  </tr>
<?php
	// Affichage classement Buteur
	$req = sql::query("SELECT champ_but, 
							   equipes.team_id AS team_id, team_name, 
							   joueurs.player_id AS player_id, nom, prenom 
						FROM classement_joueur 
						LEFT JOIN equipes ON equipes.team_id = classement_joueur.team_id 
						LEFT JOIN joueurs ON joueurs.player_id = classement_joueur.player_id 
						WHERE classement_joueur.compet_id = '".$compet_id."' 
						AND saison_nbr='".$saison_nbr."' 
						AND champ_but != 0 
						ORDER BY champ_but DESC LIMIT 10");
	
	$class = 1;
	
	while ($donnees = mysql_fetch_assoc($req))
	{
?>
	<tr>
    <td class="class_other" align="center"><b><?php echo $class++; ?></td>
	<td class="class_other"><a href="club.php?zone=management&amp;page=joueur&amp;id=<?php echo $donnees['player_id']; ?>"><?php echo $donnees['prenom'] . ' ' . $donnees['nom']; ?></a></td>
	<td class="class_other"><a href="club.php?zone=public&amp;page=teaminfo&amp;id=<?php echo $donnees['team_id']; ?>"><?php echo $donnees['team_name']; ?></a></td>
	<td class="class_other" align="center"><?php echo $donnees['champ_but']; ?></td>
  </tr>
<?php
	}
?>
</table>
</div>
<br />
<div class="homepage_border">
<div class="homepage_sub_header"><?php echo CLASSPASSEUR; ?></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="class_other" width="10%"></td>
	<td class="class_other" width="40%"><?php echo NONPLAYER; ?></td>
    <td class="class_other" width="40%"><?php echo TEAM; ?></td>
	<td class="class_other" width="10%" align="center"><?php echo NBPD; ?></td>
  </tr>
<?php
	// Affichage classement passeur decisif
	$req = sql::query("SELECT champ_pasdec, 
							   equipes.team_id AS team_id, team_name, 
							   joueurs.player_id AS player_id, nom, prenom 
						FROM classement_joueur 
						LEFT JOIN equipes ON equipes.team_id = classement_joueur.team_id 
						LEFT JOIN joueurs ON joueurs.player_id = classement_joueur.player_id 
						WHERE classement_joueur.compet_id = '".$compet_id."' 
						AND saison_nbr='".$saison_nbr."' 
						AND champ_pasdec != 0 
						ORDER BY champ_pasdec DESC LIMIT 10");
	
	$class = 1;
	
	while ($donnees = mysql_fetch_assoc($req))
	{
?>
	<tr>
    <td class="class_other" align="center"><b><?php echo $class++; ?></td>
	<td class="class_other"><a href="club.php?zone=management&amp;page=joueur&amp;id=<?php echo $donnees['player_id']; ?>"><?php echo $donnees['prenom'] . ' ' . $donnees['nom']; ?></a></td>
	<td class="class_other"><a href="club.php?zone=public&amp;page=teaminfo&amp;id=<?php echo $donnees['team_id']; ?>"><?php echo $donnees['team_name']; ?></a></td>
	<td class="class_other" align="center"><?php echo $donnees['champ_pasdec']; ?></td>
  </tr>
<?php
	}
?>
</table>
</div>
  </td>
    <td width="40%" rowspan="2" valign="top">
	  <div class="homepage_border">
	  <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" style="font-size:10px;">
<?php

	$journee = 1;
	
	$req = sql::query("SELECT matchs.renco_id, matchs.compet_id, matchs.cup_id, matchs.timematch, 
							   matchs.journee, matchs.score1, matchs.score2, matchs.renco_type, 
							   equipe1.team_id AS team_id1, equipe1.team_name AS team_name1, 
							   equipe2.team_id AS team_id2, equipe2.team_name AS team_name2, 
							   compet_name 
						FROM matchs 
						LEFT JOIN equipes AS equipe1 ON equipe1.team_id = matchs.team_id1 
						LEFT JOIN equipes AS equipe2 ON equipe2.team_id = matchs.team_id2 
						LEFT JOIN competition ON competition.compet_id = matchs.compet_id 
						WHERE matchs.compet_id='".$compet_id."' 
						AND saison_nbr = '".$saison_nbr."' 
						ORDER BY journee");
	
	while ($donnees = mysql_fetch_assoc($req))
	{
		if(isset($journee) && $journee == $donnees['journee'])
		{
			?>
			<tr>
              <td colspan="4" class="homepage_sub_header_mini" align="center"><?php echo DAYMATCH . ' : ' . $journee; ?><?php echo ' - ' . LE . date($info['dateformat_choice'], $donnees['timematch']) . A . date($info['timeformat_choice'], $donnees['timematch']); ?></td>
			</tr>
			<?php
			$journee++;
		}
		?>
	<tr>
	<td align="right" width="42%" class="class_other_mini"><a href="club.php?zone=public&amp;page=teaminfo&amp;id=<?php echo $donnees['team_id1']; ?>">
	<?php echo $donnees['team_name1']; ?></a></td>
	<td align="center" width="15%" class="class_other_mini"><a href="club.php?zone=match&amp;id=<?php echo $donnees['renco_id']; ?>"><?php echo $donnees['score1'] . ' - ' . $donnees['score2']; ?></a></td>
    <td align="left" width="42%" class="class_other_mini"><a href="club.php?zone=public&amp;page=teaminfo&amp;id=<?php echo $donnees['team_id2']; ?>">
	<?php echo $donnees['team_name2']; ?></a></td>
  </tr>
<?php
	}
?>	
      </table>
	  </div>
	</td>
  </tr>
</table>