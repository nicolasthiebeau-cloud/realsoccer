<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
30/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//Class et Lang Entrainement
include('sources/lang_page/' . $info['lang'] . '/lang_entrainement.php');
include('sources/class_page/class_entrainement.php');
$entrainement = new entrainement;

//Cout d'am�lioration du niveau suivant !
$cout_amelioration = ($info['trainingcenter'] * 5000) + 20000;
$temps_construction = 259200;

//Construction du centre 
if(isset($FORM['action']) && $FORM['action'] == 'construction') $error = $entrainement->construction_centre($cout_amelioration, $temps_construction, $info);

//Am�lioration du centre 
if(isset($FORM['action']) && $FORM['action'] == 'agrandissement') $error = $entrainement->agrandissement_centre($cout_amelioration, $temps_construction, $info);

//Cr�ation de l'entraineur
if(isset($FORM['nationalite'])) $error = $entrainement->creation_entraineur($FORM['nationalite'], $info);

//Entrainement collectif 
if(isset($FORM['action']) && $FORM['action'] == 'collectif') $entrainement->entrainement_collectif($FORM['train'], $info);

//Entrainement individuel
if(isset($FORM['action']) && $FORM['action'] == 'individuel') $error2 = $entrainement->entrainement_individuel($FORM['indivjoueur'], $FORM['indivtrain'], $info);

//Entrainement des jeunes
if(isset($FORM['action']) && $FORM['action'] == 'jeune') $entrainement->entrainement_jeune($FORM['jjoueur'], $FORM['jtrain'], $info);

// On cherche le niveau du centre d'entrainement et on l'affiche
$i = sql::fetch("SELECT equipes.team_id, formationcenter, trainingcenter, training_choice, 
						type, id, timestamp_fin 
				 FROM equipes 
				 LEFT JOIN stamp_construction ON stamp_construction.id_team = equipes.team_id 
				 WHERE team_id= '".$info['team_id']."'");

if(!isset($i['timestamp_fin']) && $i['trainingcenter'] == 0)
{
	echo'
	<a name="view"></a>
	<table width="100%" border="0" cellspacing="2" cellpadding="2">
	  <tr>
		<td valign="top" width="60%">
		  <div class="tableborder">
		  <div class="homepage_sub_header">' . TRENTRAICOLLEC . '</div>
		    <table width="100% border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td class="homepage_sub_row">' . 
				CONST_NO1 . ' ' . $cout_amelioration . ' ' . CONST_NO2 . '<br /><br />';
				
				if ($cout_amelioration <= $info['team_money'])
				{
					echo'<div align="center"><a href="club.php?zone=management&amp;page=entrainement&amp;action=construction">' . CONST_SUBMIT . '</a></div>';
				}
				
				else $error = CONST_NOMONEY;
				
				if (isset($error)) echo '<br /><font color="#FF0000"><b>'.$error.'</b></font>';
				
				echo'
				</td>
			  </tr>
			</table>
		  </div>
		</td>
	  </tr>
	</table>';
}

else
{
?>
<a name="view"></a>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td valign="top" width="60%">
	  <div class="tableborder">
	  <div class="homepage_sub_header"><?php echo TRENTRAICOLLEC; ?></div>
	    <table width="100%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
            <td class="homepage_sub_row">
		    <?php
			echo COLLEC_INFO . '<br /><br />';
			
			if ($i['trainingcenter'] >= 1)
			{
				echo'<form action="club.php?zone=management&amp;page=entrainement&amp;action=collectif" method="POST">';
				echo TRAINACTU . ' : <br / >';
				?>
				<select name="train">
				<option value=""></option>
				<option value="1" <?php if(isset($i['training_choice']) && $i['training_choice'] == 1) echo'selected="selected"'; ?>><?php echo CENTRES; ?></option>
				<option value="2" <?php if(isset($i['training_choice']) && $i['training_choice'] == 2) echo'selected="selected"'; ?>><?php echo CDPARRETE; ?></option>
				<option value="3" <?php if(isset($i['training_choice']) && $i['training_choice'] == 3) echo'selected="selected"'; ?>><?php echo CREATIVITE; ?></option>
				<option value="4" <?php if(isset($i['training_choice']) && $i['training_choice'] == 4) echo'selected="selected"'; ?>><?php echo DEGAGEMENT; ?></option>
				<option value="5" <?php if(isset($i['training_choice']) && $i['training_choice'] == 5) echo'selected="selected"'; ?>><?php echo DRIBBLE; ?></option>
				<option value="6" <?php if(isset($i['training_choice']) && $i['training_choice'] == 6) echo'selected="selected"'; ?>><?php echo INFLUENCE; ?></option>
				<option value="7" <?php if(isset($i['training_choice']) && $i['training_choice'] == 7) echo'selected="selected"'; ?>><?php echo MARQUAGE; ?></option>
				<option value="8" <?php if(isset($i['training_choice']) && $i['training_choice'] == 8) echo'selected="selected"'; ?>><?php echo PASSES; ?></option>
				<option value="9" <?php if(isset($i['training_choice']) && $i['training_choice'] == 9) echo'selected="selected"'; ?>><?php echo PDBALLE; ?></option>
				<option value="10" <?php if(isset($i['training_choice']) && $i['training_choice'] == 10) echo'selected="selected"'; ?>><?php echo REFLEXES; ?></option>
				<option value="11" <?php if(isset($i['training_choice']) && $i['training_choice'] == 11) echo'selected="selected"'; ?>><?php echo TACLES; ?></option>
				<option value="12" <?php if(isset($i['training_choice']) && $i['training_choice'] == 12) echo'selected="selected"'; ?>><?php echo TETE; ?></option>
				<option value="13" <?php if(isset($i['training_choice']) && $i['training_choice'] == 13) echo'selected="selected"'; ?>><?php echo TIR; ?></option>
				<option value="14" <?php if(isset($i['training_choice']) && $i['training_choice'] == 14) echo'selected="selected"'; ?>><?php echo VITESSE; ?></option>
				</select>
				<input type="submit" value="<?php echo TRAINSUBMIT; ?>">
				</form>
			<?php
			}
			
			else echo COLLEC_INFO;
			?>
		  </td>
        </tr>
		</table>
	  </div>
	  <br />
	  <div class="tableborder">
	  <div class="homepage_sub_header"><?php echo TRENTRAIINDIVI; ?></div>
	    <table width="100% border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td class="homepage_sub_row">
		    <?php
			if ($i['trainingcenter'] >= 2)
			{
				if (isset($error2)) echo '<font color="#FF0000"><b>'.$error2.'</b></font>';
				?>
				<form action="club.php?zone=management&amp;page=entrainement&amp;action=individuel" method="POST">
				<table width="40%" border="0" cellspacing="5" cellpadding="0" align="center">
				  <tr>
				    <td valign="middle" width="50%">Identit�</td>
					<td valign="middle" width="50%">Entrainement</td>
				  </tr>
				  <?php
				  //Nombre d'entrainement individuel selon le niveau du centre d'entrainement
				  switch($i['trainingcenter'])
				  {
					case 1: $traintotal = 0; break;
					case 2: $traintotal = 1; break;
					case 3: $traintotal = 2; break;
					case 4: $traintotal = 2; break;
					case 5: $traintotal = 3; break;
					case 6: $traintotal = 3; break;
					case 7: $traintotal = 4; break;
					case 8: $traintotal = 4; break;
					case 9: $traintotal = 5; break;
					case 10: $traintotal = 5; break;
					default: $traintotal = 0; break;
				  }
				  
				  $trainturn = 1;
				  $playerturn = 0;
				  
				  while($traintotal >= $trainturn)
				  {
					$numb = 1;
					
					$train = sql::fetch("SELECT player_id, trainsolo_choice 
										 FROM joueurs 
										 WHERE team_id= '".$info['team_id']."' 
										   AND age >= 17 
										   AND trainsolo_choice != 0 
										 LIMIT {$playerturn}, 1");
					
					echo'<tr>
						   <td valign="middle">
						   <select name="indivjoueur[]">
						   <option value="" ></option>';
						   
					
					$req = sql::query("SELECT player_id, nom, prenom, 
											   pos_name, joueurs_position.position 
										FROM joueurs 
										LEFT JOIN joueurs_position ON joueurs_position.pos_id = joueurs.position 
										WHERE team_id= '".$info['team_id']."' 
										AND age >= 17 
										ORDER BY joueurs_position.position");
					
					while ($donnees = mysql_fetch_assoc($req))
					{
						if($numb == $donnees['position'])
						{
							echo'<optgroup label="' . $donnees['pos_name'] .'"></OPTGROUP>';
							$numb++;
						}
						
						echo'<option value="' . $donnees['player_id'] . '"';
						if(isset($train['player_id']) && $train['player_id'] == $donnees['player_id']) echo 'selected="selected"';
						echo'>' . stripslashes($donnees['prenom']) . ' ' . stripslashes($donnees['nom']) . '</option>';
					}
					
					echo'</select>
						 </td>';
					?>
				    <td valign="middle">
					<select name="indivtrain[]">
					<option value=""></option>
					<option value="1" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 1) echo 'selected="selected"'; ?> ><?php echo CENTRES; ?></option>
					<option value="2" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 2) echo 'selected="selected"'; ?> ><?php echo CDPARRETE; ?></option>
					<option value="3" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 3) echo 'selected="selected"'; ?> ><?php echo CREATIVITE; ?></option>
					<option value="4" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 4) echo 'selected="selected"'; ?> ><?php echo DEGAGEMENT; ?></option>
					<option value="5" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 5) echo 'selected="selected"'; ?> ><?php echo DRIBBLE; ?></option>
					<option value="6" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 6) echo 'selected="selected"'; ?> ><?php echo INFLUENCE; ?></option>
					<option value="7" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 7) echo 'selected="selected"'; ?> ><?php echo MARQUAGE; ?></option>
					<option value="8" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 8) echo 'selected="selected"'; ?> ><?php echo PASSES; ?></option>
					<option value="9" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 9) echo 'selected="selected"'; ?> ><?php echo PDBALLE; ?></option>
					<option value="10" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 10) echo 'selected="selected"'; ?> ><?php echo REFLEXES; ?></option>
					<option value="11" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 11) echo 'selected="selected"'; ?> ><?php echo TACLES; ?></option>
					<option value="12" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 12) echo 'selected="selected"'; ?> ><?php echo TETE; ?></option>
					<option value="13" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 13) echo 'selected="selected"'; ?> ><?php echo TIR; ?></option>
					<option value="14" <?php if(isset($train['trainsolo_choice']) && $train['trainsolo_choice'] == 14) echo 'selected="selected"'; ?> ><?php echo VITESSE; ?></option>
					</select>
					</td>
				  </tr>
				  <?php
				  $trainturn++;
				  $playerturn++;
				  }
				  ?>
				  <tr>
					<td valign="middle" align="center" colspan="5"><input type="submit" value="<?php echo TRAINSUBMIT; ?>"></td>
				  </tr>
			    </table>
			    </form>
			<?php
			}
				
			else echo INDIV_INFO2;
			?>
			</td>
		  </tr>
		</table>
	  </div>
	  <br />
	  <div class="tableborder">
	  <div class="homepage_sub_header"><?php echo TRENTRAIJEUN; ?></div>
	    <table width="100% border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td class="homepage_sub_row">
			  <form action='club.php?zone=management&amp;page=entrainement&amp;action=jeune' method='POST'>
			  <table width="100%" border="0" cellspacing="5" cellpadding="0">
			    <tr>
				  <td valign="middle">&nbsp;</td>
				  <td valign="middle">Identit�</td>
				  <td valign="middle">Position</td>
				  <td valign="middle">Entrainement actuel</td>
				</tr>
				<?php
				//On recup les joueurs du centre de formation
				$req = sql::query("SELECT player_id, nom, surnom, prenom, age, forme, moral, trainsolo_choice, 
										   pays_name, pays_flag, 
										   group_id, pos_shortname 
									FROM joueurs 
									LEFT JOIN pays ON pays.pays_id = joueurs.nationalite 
									LEFT JOIN joueurs_position ON joueurs_position.pos_id = joueurs.position 
									WHERE team_id = '".$info['team_id']."' 
									AND age <= 16 
									ORDER BY joueurs.position, nom"); 
				
				$color = 1;
				$jjnumber = 1;
				
				while ($donnees = mysql_fetch_assoc($req))
				{
					?>
				<input name="jjoueur[]" type="hidden" value="<?php echo $donnees['player_id']; ?>" />
				<tr>
				  <td valign="middle"><?php echo '<img src="images/flag' . '/' . $donnees['pays_flag'] . '" width="32" height="20" alt="' . $donnees['pays_name'] . '" />'; ?></td>
				  <td valign="middle">
				  <a href="club.php?zone=management&amp;page=joueur&amp;id=<?php echo $donnees['player_id']; ?>">
				  <b><?php 
				  echo stripslashes($donnees['nom']) . '</b> ';
				  if ($donnees['surnom'] != NULL) echo '\' '. stripslashes($donnees['surnom']) . ' \''; echo ' ' . stripslashes($donnees['prenom']); ?></a></td>
				  <td valign="middle"><?php echo $club->smallposition($donnees['group_id'], $donnees['pos_shortname']); ?></td>
				  <td valign="middle">
				  <select name='jtrain[]'>
				  <option value=""></option>
				  <option value="1" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 1) echo 'selected="selected"'; echo'>' . CENTRES; ?></option>
				  <option value="2" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 2) echo 'selected="selected"'; echo'>' .  CDPARRETE; ?></option>
				  <option value="3" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 3) echo 'selected="selected"'; echo'>' .  CREATIVITE; ?></option>
				  <option value="4" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 4) echo 'selected="selected"'; echo'>' .  DEGAGEMENT; ?></option>
				  <option value="5" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 5) echo 'selected="selected"'; echo'>' .  DRIBBLE; ?></option>
				  <option value="6" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 6) echo 'selected="selected"'; echo'>' .  INFLUENCE; ?></option>
				  <option value="7" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 7) echo 'selected="selected"'; echo'>' .  MARQUAGE; ?></option>
				  <option value="8" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 8) echo 'selected="selected"'; echo'>' .  PASSES; ?></option>
				  <option value="9" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 9) echo 'selected="selected"'; echo'>' .  PDBALLE; ?></option>
				  <option value="10" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 10) echo 'selected="selected"'; echo'>' .  REFLEXES; ?></option>
				  <option value="11" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 11) echo 'selected="selected"'; echo'>' .  TACLES; ?></option>
				  <option value="12" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 12) echo 'selected="selected"'; echo'>' .  TETE; ?></option>
				  <option value="13" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 13) echo 'selected="selected"'; echo'>' .  TIR; ?></option>
				  <option value="14" <?php if(isset($donnees['trainsolo_choice']) && $donnees['trainsolo_choice'] == 14) echo 'selected="selected"'; echo'>' .  VITESSE; ?></option>
				  </select>
				  </td>
				</tr>
				<?php
					$jjnumber++;
				}
				?>
				<tr>
				  <td valign="middle" align="center" colspan="5"><input type='submit' value="<?php echo TRAINSUBMIT; ?>"></td>
				</tr>
			  </table>
			  </form>
			</td>
		  </tr>
		</table>
	  </div>
	</td>
	<td valign="top" width="40%">
	<div class="tableborder">
<div class="homepage_sub_header"><?php echo 'Centre d\'entrainement'; ?></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	   <td class="homepage_sub_row_2">
<?php
$construct = sql::fetch("SELECT COUNT(*) AS exist FROM stamp_construction WHERE id_team = '".$info['team_id']."' AND type = 'centreentrainement'");

if($i['trainingcenter'] == 0 && $construct['exist'] == 1)
{
	echo "Votre centre d'entrainement est en cours de construction.<br />
	Les travaux se termine dans :<br /><br />";

	$data = sql::fetch("SELECT timestamp_fin FROM stamp_construction WHERE id_team = '".$info['team_id']."' AND type = 'centreentrainement'");
	
	echo '&nbsp;&nbsp;&nbsp;&nbsp;' . $entrainement->comparetimestamp($data['timestamp_fin']) . '<br /><br />';
	
	if (isset($error)) echo '<br /><font color="#FF0000"><b>'.$error.'</b></font>';
}

elseif($i['trainingcenter'] >= 1 && $construct['exist'] == 0)
{
	echo "Votre centre d'entrainement est actuellement au niveau " . $i["trainingcenter"] . "<br />
	Pour l'am�liorer vous devez payer " . $cout_amelioration . " euros, et la construction durera 3 jours.<br /><br />";
	
	if ($cout_amelioration <= $info['team_money'])
	{
		echo "<div align=\"center\"><a href=\"club.php?zone=management&amp;page=entrainement&amp;action=agrandissement\">Agrandir le centre d'entrainement.</a></div>";
	}
	
	else echo"Pas assez d'argent pour agrandir le centre d'entrainement";
	
	if (isset($error)) echo '<br /><font color="#FF0000"><b>'.$error.'</b></font>';
}
	
else
{
	echo "Votre centre d'entrainement est en cours d'agrandissement.<br />
	Les travaux se termine dans :<br /><br />";
	
	$data = sql::fetch("SELECT timestamp_fin FROM stamp_construction WHERE id_team = '".$info['team_id']."' AND type = 'centreentrainement'");
	
	echo '&nbsp;&nbsp;&nbsp;&nbsp;' . $entrainement->comparetimestamp($data['timestamp_fin']) . '<br /><br />';
	
	if (isset($error)) echo '<br /><font color="#FF0000"><b>'.$error.'</b></font>';
}
?>
	   </td>
	 </tr>
   </tbody>
  </table>
</div>
 <br />
 <div class="tableborder">
<div class="homepage_sub_header"><?php echo 'Staff'; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	   <td class="homepage_sub_row_2">
<?php
$trainer = sql::fetch("SELECT staff_prenom, staff_nom 
					   FROM staff 
					   WHERE team_id= '".$info['team_id']."' 
					     AND poste_actu= 'Entraineur'");

if($i['trainingcenter'] == 0)
{
	echo'Vous devez recruter un entraineur pour pouvoir entrainer vos joueurs.<br /><br />';
	echo'<div align="center"><strong>Pas de centre d\'entrainement</strong></div>';
}

elseif($i['trainingcenter'] >= 1 && !isset($trainer['staff_prenom']))
{
	echo'<form action="club.php?zone=management&amp;page=entrainement" method="POST">';
	echo'Vous devez recruter un entraineur pour pouvoir entrainer vos joueurs.<br /><br />';
	echo'Nationalit� : 
	<select name="nationalite">';
	
	$req = sql::query("SELECT pays_id, pays_name, pays_zone 
						FROM pays 
						WHERE pays_select= 1 
						ORDER BY pays_zone DESC");
						
	while ($donnees = mysql_fetch_assoc($req))
	{
		echo '<option value="' . $donnees['pays_id'] . '">' . $donnees['pays_name'] . '</option>';
	}
	echo'
	</select><br / >
	Poste :
	<select name="poste">
	<option value="Entraineur">Entraineur</option>
	</select><br />
	<div align="center"><input type="submit" value="Recruter un membre du staff"></div></form>';
}

else
{
    echo'<div align="center"><strong>';
	
	if ($trainer['staff_prenom'] != NULL) echo 'Entraineur : ' . stripslashes($trainer['staff_prenom']) . ' ' . stripslashes($trainer['staff_nom']) . '</strong>';
}
?>
	   </td>
	 </tr>
   </tbody>
  </table>
 </div>
	   </td>
	 </tr>
   </tbody>
  </table>
 </div>
<?php
}
?>