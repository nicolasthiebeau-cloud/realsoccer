<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
29/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

$page = (!empty($FORM['page'])) ? htmlentities($FORM['page']) : 'main';
$array_pages = array(
	//Base
	'main' => 'pages/marche_main.php', 
	'result' => 'pages/marche_resultat.php', 
	'suivi' => 'pages/suivi.php', 
	'encherir' => 'pages/transferable.php', 
	'joueur' => 'pages/joueur.php'	
					);
	
if(!array_key_exists($page, $array_pages)) include('pages/erreur.php');

elseif(!is_file($array_pages[$page])) include('pages/erreur.php');

else
{
?>
<a name="view"></a>
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
  <tbody>
   <tr>
    <td id="leftblock" valign="top" width="22%">
	 <div>
	 <!-- LEFT CONTEXT SENSITIVE MENU -->
	 <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo 'March� des transferts'; ?></div>
	  <div class="menulinkwrap">
	  <form action="club.php?zone=marchetransfert" method="post">
	  <table width="80%" cellpadding="1" cellspacing="0" align="center">
	    <tr>
		  <td>
		  Zone de recherche des joueurs : <br />
	  <select name="payszone">
     <option value="999"><?php echo ZONE1; ?></option>
	 <option value="998"><?php echo ZONE2; ?></option>
	 <option value="997"><?php echo ZONE3; ?></option>
	 <option value="996"><?php echo ZONE4; ?></option>
	 <option value="995"><?php echo ZONE5; ?></option>
     <option value="994"><?php echo ZONE6; ?></option>
	 <option value="992"><?php echo ZONE7; ?></option>
     <option value="993"><?php echo ZONE8; ?></option>
     <option value="991"><?php echo ZONE9; ?></option>
     <option value="990"><?php echo ZONE10; ?></option>
     <option value="989"><?php echo ZONE11; ?></option>
     <OPTGROUP LABEL="- - - - -"></OPTGROUP>
	 <?php
		$req = sql::query("SELECT pays_id, pays_name 
						   FROM pays 
						   ORDER BY pays_name");
		
		while ($donnees = mysql_fetch_assoc($req))
		{
			echo '<option  value="' . $donnees['pays_id'] . '">' . $donnees['pays_name'] . '</option>';
		}
	 ?>
	 </select>
		  </td>
		</tr>
		<tr>
		  <td>
		  Ag�s entre  : <br />
	 <select name="age_min">
	 <option value="0">0</option>
	 <option value="17">17</option>
	 <option value="19">19</option>
	 <option value="21">21</option>
	 <option value="23">23</option>
	 <option value="25">25</option>
	 <option value="27">27</option>
	 <option value="29">29</option>
	 <option value="31">31</option>
	 <option value="33">33</option>
	 </select> & 
	 <select name="age_max">
	 <option value="99">99</option>
	 <option value="35">35</option>
	 <option value="33">33</option>
	 <option value="31">31</option>
	 <option value="29">29</option>
	 <option value="27">27</option>
	 <option value="25">25</option>
	 <option value="23">23</option>
	 <option value="21">21</option>
	 <option value="19">19</option>
	 <option value="17">17</option>
	 </select> ans
		  </td>
		</tr>
		<tr>
		  <td>
		  Tri� par : <br />
		  <select name="ftsort1">
		  <option value="0"></option>
		  <option value="centres"><?php echo CENTRES; ?></option>
		  <option value="cdp_arrete"><?php echo CDPARRETE; ?></option>
		  <option value="creativite"><?php echo CREATIVITE; ?></option>
		  <option value="degagement"><?php echo DEGAGEMENT; ?></option>
		  <option value="dribble"><?php echo DRIBBLE; ?></option>
		  <option value="influence"><?php echo INFLUENCE; ?></option>
		  <option value="marquage"><?php echo MARQUAGE; ?></option>
		  <option value="passes"><?php echo PASSES; ?></option>
		  <option value="pdballe"><?php echo PDBALLE; ?></option>
		  <option value="reflexes"><?php echo REFLEXES; ?></option>
		  <option value="tacles"><?php echo TACLES; ?></option>
		  <option value="tete"><?php echo TETE; ?></option>
		  <option value="tir"><?php echo TIR; ?></option>
		  <option value="vitesse"><?php echo VITESSE; ?></option>
		  </select><br />
		  <select name="ftsort2">
		  <option value="0"></option>
		  <option value="centres"><?php echo CENTRES; ?></option>
		  <option value="cdp_arrete"><?php echo CDPARRETE; ?></option>
		  <option value="creativite"><?php echo CREATIVITE; ?></option>
		  <option value="degagement"><?php echo DEGAGEMENT; ?></option>
		  <option value="dribble"><?php echo DRIBBLE; ?></option>
		  <option value="influence"><?php echo INFLUENCE; ?></option>
		  <option value="marquage"><?php echo MARQUAGE; ?></option>
		  <option value="passes"><?php echo PASSES; ?></option>
		  <option value="pdballe"><?php echo PDBALLE; ?></option>
		  <option value="reflexes"><?php echo REFLEXES; ?></option>
		  <option value="tacles"><?php echo TACLES; ?></option>
		  <option value="tete"><?php echo TETE; ?></option>
		  <option value="tir"><?php echo TIR; ?></option>
		  <option value="vitesse"><?php echo VITESSE; ?></option>
		  </select><br />
		  <select name="ftsort3">
		  <option value="0"></option>
		  <option value="centres"><?php echo CENTRES; ?></option>
		  <option value="cdp_arrete"><?php echo CDPARRETE; ?></option>
		  <option value="creativite"><?php echo CREATIVITE; ?></option>
		  <option value="degagement"><?php echo DEGAGEMENT; ?></option>
		  <option value="dribble"><?php echo DRIBBLE; ?></option>
		  <option value="influence"><?php echo INFLUENCE; ?></option>
		  <option value="marquage"><?php echo MARQUAGE; ?></option>
		  <option value="passes"><?php echo PASSES; ?></option>
		  <option value="pdballe"><?php echo PDBALLE; ?></option>
		  <option value="reflexes"><?php echo REFLEXES; ?></option>
		  <option value="tacles"><?php echo TACLES; ?></option>
		  <option value="tete"><?php echo TETE; ?></option>
		  <option value="tir"><?php echo TIR; ?></option>
		  <option value="vitesse"><?php echo VITESSE; ?></option>
		  </select>
		  </td>
		</tr>
		<tr>
		  <td colspan="2"><div align="center"><input type="submit" VALUE="Afficher le R�sultat"></div></form></td>
	    </tr>
	  </table>
	  </div>
	  <br />
	  </div>
	  <br />
	  <?php if(isset($FORM['page']) && $FORM['page'] == 'joueur') include("pages/joueur_menu.php"); ?>
	 <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo 'Joueur suivi'; ?></div>
	  <div class="menulinkwrap">&nbsp;<a href="club.php?zone=marchetransfert" style="text-decoration: none;"><?php echo'Recherche'; ?></a></div>
	  </div>
	  <!-- / LEFT CONTEXT SENSITIVE MENU -->
	 </div>
	</td>
	<td id="rightblock" valign="top" width="78%">
	 <div>
	 <!-- RIGHT CONTENT BLOCK -->
	  <?php include($array_pages[$page]); ?>
	 <!-- / RIGHT CONTENT BLOCK -->
	 </div>
	</td>
   </tr>
  </tbody>
 </table>
<?php
}
?>