<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
23/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//Championnat
if(isset($FORM['id']) OR isset($FORM['division']) OR isset($FORM['poule']))
{
	$championnat = htmlentities(addslashes($FORM['id'])); //Retourne pays_id
	$division = htmlentities(addslashes($FORM['division'])); //Retourne la division
	$poule = htmlentities(addslashes($FORM['poule'])); //Retourne la poule
	$divi_poule = $division . ' - ' . $poule;
	
	$data = sql::fetch("SELECT compet_id, saison_nbr 
						FROM classement 
						WHERE compet_id = (SELECT compet_id 
										   FROM competition 
										   WHERE pays_id='".$championnat."' 
										     AND division='".$division."' 
										     AND poule='".$poule."' 
										   ORDER BY compet_id DESC LIMIT 1) 
						ORDER BY saison_nbr DESC LIMIT 1");
	
	$compet_id = $data['compet_id'];
	$saison_nbr = $data['saison_nbr'];
	
	//match_autolauncher($compet_id, $CONF); ////////////////////////////////////
}
	elseif(isset($FORM['saison']) OR isset($FORM['championnat']) OR isset($FORM['divi_poule']))
{
	$saison_nbr = htmlentities(addslashes($FORM['saison'])); //Retourne saison_nbr
	$championnat = htmlentities(addslashes($FORM['championnat'])); //Retourne pays_id
	$divi_poule = htmlentities(addslashes($FORM['divi_poule']));
	
	$divipoule = explode(' - ', $divi_poule); //Pour s�par� la division de la poule
	$division = $divipoule[0];
	$poule = $divipoule[1];
	
	$data = sql::fetch("SELECT compet_id 
						FROM competition 
						WHERE pays_id='".$championnat."' 
						  AND division='".$division."' 
						  AND poule='".$poule."'
						ORDER BY compet_id DESC LIMIT 1");
	
	$compet_id = $data['compet_id'];
	
	//match_autolauncher($compet_id, $CONF); ///////////////////////////////////
}

else
{
	$data = sql::fetch("SELECT classement.compet_id, saison_nbr, 
							   pays_id, division, poule 
						FROM classement 
						LEFT JOIN competition ON competition.compet_id = classement.compet_id 
						WHERE team_id='".$info['team_id']."' 
						ORDER BY saison_nbr DESC LIMIT 1");
	
	$compet_id = $data['compet_id']; 
	$saison_nbr = $data['saison_nbr']; //La derni�re saison en cours
	$championnat = $data['pays_id']; 
	$divi_poule = $data['division'] . ' - ' . $data['poule'];
}

$page = (!empty($FORM['page'])) ? htmlentities($FORM['page']) : 'main';
$array_pages = array(
	//Base
	'main' => 'pages/compet_main.php', 
	'championnat' => 'pages/championnat.php', 
	'match' => 'pages/match.php'		
					);
	
if(!array_key_exists($page, $array_pages)) include('pages/erreur.php');
elseif(!is_file($array_pages[$page])) include('pages/erreur.php');
else
{
?>
<a name="view"></a>
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
  <tbody>
   <tr>
    <td id="leftblock" valign="top" width="22%">
	 <div>
	 <!-- LEFT CONTEXT SENSITIVE MENU -->
	 <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo 'Mes comp�titions'; ?></div>
	  <div class="menulinkwrap">&nbsp;<a href="<?php echo'club.php?zone=competition&amp;page=championnat&amp;id=' . $info['pays_id'] . '&amp;division=' . $info['division'] . '&amp;poule=' . $info['poule']; ?>" style="text-decoration: none;"><?php echo $info['compet_name']; ?></a></div>
	  </div>
	  <br />
	  <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo 'Toutes les comp�titions'; ?></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=competition" style="text-decoration: none;"><?php echo'match du jour'; ?></a></div>
	   <div class="menulinkwrap">&nbsp;Tous les championnats
<table width="100%" border="0" cellpadding="2" align="center">
  <tr>
    <td valign="top"><form name='saisieclass' action='club.php?zone=competition&amp;page=championnat#view' method='POST'>
	<select name="saison" onChange="submit();">
<?php
	$req = sql::query("SELECT saison_nbr 
						FROM classement 
						WHERE team_id='".$info['team_id']."' 
						ORDER BY saison_nbr DESC");
	
	while ($donnees = mysql_fetch_assoc($req))
	{	
?>
	<option value="<?php echo $donnees['saison_nbr']; ?>" 
	<?php if($saison_nbr == $donnees['saison_nbr']) echo 'selected="selected"'; ?> ><?php echo $donnees['saison_nbr']; ?></option>
<?php
	}
?>
	</select></td>
	<td valign="top"><select name="championnat" onChange="submit();">
<?php
	$req = sql::query("SELECT pays_id, pays_champ 
					   FROM pays 
					   WHERE pays_actif = 1");
	
	while ($donnees2 = mysql_fetch_assoc($req))
	{	
?>
	<option value="<?php echo $donnees2['pays_id']; ?>" 
	<?php if($championnat == $donnees2['pays_id']) echo 'selected="selected"'; ?> ><?php echo $donnees2['pays_champ']; ?></option>
<?php
	}
?>
	</select></td>
	<td valign="top"><select name="divi_poule" onChange="submit();">
<?php
	$req = sql::query("SELECT division, poule 
						FROM competition 
						WHERE pays_id='".$championnat."' 
						ORDER BY division, poule");
	
	while ($donnees3 = mysql_fetch_assoc($req))
	{
?>
	<option value="<?php $divipoule = $donnees3['division'] . ' - ' . $donnees3['poule']; echo $divipoule; ?>" 
	<?php if($divi_poule == $divipoule) echo 'selected="selected"'; ?> ><?php echo $divipoule; ?></option>
<?php
	}
?>
	</select>
	</form></td>
	<td></td>
  </tr>
</table>
	   </div>
	  </div>
	  <br />
	  <!-- / LEFT CONTEXT SENSITIVE MENU -->
	 </div>
	</td>
	<td id="rightblock" valign="top" width="78%">
	 <div>
	 <!-- RIGHT CONTENT BLOCK -->
	  <?php include($array_pages[$page]); ?>
	 <!-- / RIGHT CONTENT BLOCK -->
	 </div>
	</td>
   </tr>
  </tbody>
 </table>
<?php
}
?>