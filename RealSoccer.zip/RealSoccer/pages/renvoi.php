<?php 
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['renvoi_player_id']))
{
	$renvoi_player_id = htmlentities(addslashes($FORM['renvoi_player_id']));
	$renvoiprice = 1000; //Prix du renvoi d'un joueur
	
	//On retire le renvoiprice de l'�quipe
	$requete = sql::update("UPDATE equipes SET team_money = team_money - '".$renvoiprice."' WHERE team_id = '".$info['team_id']."'");
	
	//Fonction pour retirer le joueur de la tactique
	$club->verif_player_ontactik($renvoi_player_id, $info['team_id']);
	
	//On modifie completement le joueur...
	$age_min = $CONF['note_age_min']; $age_max = $CONF['note_age_max'];
	$tll_min = $CONF['note_tll_min']; $tll_max = $CONF['note_tll_max'];
	$p_min = $CONF['note_pri_min']; 	$p_max = $CONF['note_pri_max'];
	$s_min = $CONF['note_sec_min']; 	$s_max = $CONF['note_sec_max'];
	
	$pays_id = $FORM['renvoi_pays_id'];
	$multiple = $CONF['salaire_multiple'];
	
	srand ((double) microtime() * 10000000); $input = array (1, 2, 3, 4); 
	$rand_keys = array_rand ($input, 2); $position = $input[$rand_keys[0]];
	
	$data = sql::fetch("SELECT pays_name, pays_file_nom, pays_file_prenom FROM pays WHERE pays_id = '".$pays_id."'");
	
	//-------------------------------------------------------
	// Choix d'une liste de nom al�atoire selon le pays(pays_id)
	if ($data['pays_file_nom'] != NULL) $sourcefile = 'txt' . '/' . $data['pays_file_nom'];
	else $sourcefile = 'txt' . '/' . 'nom_france.txt';
	$bddfile = fopen($sourcefile, "r");
	$bddarray = array(); // Cr�ation du tableau qui contiendra toutes les phrases
	while ( $line = fgets($bddfile) ) { array_push($bddarray, $line); }// On la rajoute au tableau
	fclose ($bddfile); // On ferme le fichier
	srand((double)microtime(2) * 1000000) ;
	$nom = $bddarray[rand(0, count($bddarray)-1)];
	//-------------------------------------------------------
	
	//-------------------------------------------------------
	// Choix d'une liste de pr�nom al�atoire selon le pays(pays_id)
	if ($data['pays_file_prenom'] != NULL) $sourcefile = 'txt' . '/' . $data['pays_file_prenom'];
	else $sourcefile = 'txt' . '/' . 'prenom_france.txt';
	$bddfile = fopen($sourcefile, "r");
	$bddarray = array(); // Cr�ation du tableau qui contiendra toutes les phrases
	while ( $line = fgets($bddfile) ) { array_push($bddarray, $line); }// On la rajoute au tableau
	fclose ($bddfile); // On ferme le fichier
	srand((double)microtime(2) * 1000000) ;
	$prenom = $bddarray[rand(0, count($bddarray)-1)];
	//-------------------------------------------------------
	
	if ($position == 1)
	{
		if(!isset($influence)) $influence = rand($p_min, $p_max);
		if(!isset($reflexes)) $reflexes = rand($p_min, $p_max);
		if(!isset($pdballe)) $pdballe = rand($p_min, $p_max);
		if(!isset($degagement)) $degagement = rand($p_min, $p_max);
		if(!isset($marquage)) $marquage = rand($s_min, $s_max);
		if(!isset($tacles)) $tacles = rand($s_min, $s_max);
		if(!isset($tete)) $tete = rand($s_min, $s_max);
		if(!isset($centres)) $centres = rand($s_min, $s_max);
		if(!isset($passes)) $passes = rand($s_min, $s_max);
		if(!isset($vitesse)) $vitesse = rand($s_min, $s_max);
		if(!isset($tir)) $tir = rand($s_min, $s_max);
		if(!isset($creativite)) $creativite = rand($s_min, $s_max);
		if(!isset($dribble)) $dribble = rand($s_min, $s_max);
		if(!isset($cdpa)) $cdpa = rand($p_min, $p_max);
		$salaire = $multiple * ($pdballe + $degagement + $reflexes + $influence); //Calcul du salaire gardien
	}
	
	elseif ($position == 2)
	{
		if(!isset($influence)) $influence = rand($s_min, $s_max);
		if(!isset($reflexes)) $reflexes = rand($s_min, $s_max);
		if(!isset($pdballe)) $pdballe = rand($s_min, $s_max);
		if(!isset($degagement)) $degagement = rand($p_min, $p_max);
		if(!isset($marquage)) $marquage = rand($p_min, $p_max);
		if(!isset($tacles)) $tacles = rand($p_min, $p_max);
		if(!isset($tete)) $tete = rand($p_min, $p_max);
		if(!isset($centres)) $centres = rand($s_min, $s_max);
		if(!isset($passes)) $passes = rand($s_min, $s_max);
		if(!isset($vitesse)) $vitesse = rand($s_min, $s_max);
		if(!isset($tir)) $tir = rand($s_min, $s_max);
		if(!isset($creativite)) $creativite = rand($s_min, $s_max);
		if(!isset($dribble)) $dribble = rand($s_min, $s_max);
		if(!isset($cdpa)) $cdpa = rand($p_min, $p_max);
		$salaire = $multiple * ($marquage + $tacles + $degagement + $tete); //Calcul du salaire d�fenseur
	}
	
	elseif ($position == 3)
	{
		if(!isset($influence)) $influence = rand($s_min, $s_max);
		if(!isset($reflexes)) $reflexes = rand($s_min, $s_max);
		if(!isset($pdballe)) $pdballe = rand($s_min, $s_max);
		if(!isset($degagement)) $degagement = rand($s_min, $s_max);
		if(!isset($marquage)) $marquage = rand($s_min, $s_max);
		if(!isset($tacles)) $tacles = rand($s_min, $s_max);
		if(!isset($tete)) $tete = rand($s_min, $s_max);
		if(!isset($centres)) $centres = rand($p_min, $p_max);
		if(!isset($passes)) $passes = rand($p_min, $p_max);
		if(!isset($vitesse)) $vitesse = rand($p_min, $p_max);
		if(!isset($tir)) $tir = rand($p_min, $p_max);
		if(!isset($creativite)) $creativite = rand($s_min, $s_max);
		if(!isset($dribble)) $dribble = rand($s_min, $s_max);
		if(!isset($cdpa)) $cdpa = rand($p_min, $p_max);
		$salaire = $multiple * ($centres + $passes + $vitesse + $tir); //Calcul du salaire milieu
	}
	
	elseif ($position == 4)
	{
		if(!isset($influence)) $influence = rand($s_min, $s_max);
		if(!isset($reflexes)) $reflexes = rand($s_min, $s_max);
		if(!isset($pdballe)) $pdballe = rand($s_min, $s_max);
		if(!isset($degagement)) $degagement = rand($s_min, $s_max);
		if(!isset($marquage)) $marquage = rand($s_min, $s_max);
		if(!isset($tacles)) $tacles = rand($s_min, $s_max);
		if(!isset($tete)) $tete = rand($p_min, $p_max);
		if(!isset($centres)) $centres = rand($s_min, $s_max);
		if(!isset($passes)) $passes = rand($s_min, $s_max);
		if(!isset($vitesse)) $vitesse = rand($s_min, $s_max);
		if(!isset($tir)) $tir = rand($p_min, $p_max);
		if(!isset($creativite)) $creativite = rand($p_min, $p_max);
		if(!isset($dribble)) $dribble = rand($p_min, $p_max);
		if(!isset($cdpa)) $cdpa = rand($p_min, $p_max);
		$salaire = $multiple * ($tir + $creativite + $tete + $dribble); //Calcul du salaire attaquant
	}
	
	$age = rand($age_min, $age_max);
	$taille = rand($tll_min, $tll_max);
	$talent = rand(20, 100);
	$pression = rand(0, 100);
	$experience = rand(0, 20);
	$agressivite = rand(0, 20);
	$forme = 100;
	$moral = 100;
	
	$requete = sql::update("UPDATE joueurs 
							SET team_id = 0, 
								photo = '', 
								photo_valid = 0, 
								nom = '".$nom."', 
								surnom = '', 
								prenom = '".$prenom."', 
								age = '".$age."', 
								taille = '".$taille."', 
								position = '".$position."', 
								nationalite = '".$pays_id."', 
								forme = '".$forme."', 
								moral = '".$moral."', 
								talent = '".$talent."', 
								pression = '".$pression."', 
								experience = '".$experience."', 
								influence = '".$influence."', 
								agressivite = '".$agressivite."', 
								reflexes = '".$reflexes."', 
								pdballe = '".$pdballe."', 
								degagement = '".$degagement."', 
								marquage = '".$marquage."', 
								tacles = '".$tacles."', 
								tete = '".$tete."', 
								centres = '".$centres."', 
								passes = '".$passes."', 
								vitesse = '".$vitesse."', 
								tir = '".$tir."', 
								creativite = '".$creativite."', 
								dribble = '".$dribble."', 
								cdp_arrete = '".$cdpa."', 
								salaire = '".$salaire."', 
								trainsolo_choice = '', 
								statut = 1 
							WHERE player_id = '".$renvoi_player_id."'");
	
	$transfert = time() . '/' . 'VIDE';
	
	$requete = sql::update("UPDATE joueurs_historique SET transfert = '".$transfert."' WHERE player_id = '".$renvoi_player_id."'");

	echo '<meta http-equiv="refresh" content="0;url=club.php?zone=management&amp;page=effectif">';
	exit;	
}
?>