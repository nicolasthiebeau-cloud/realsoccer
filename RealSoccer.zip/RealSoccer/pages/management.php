<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

$page = (!empty($FORM['page'])) ? htmlentities($FORM['page']) : 'main';
$array_pages = array(
	//Base
	'main' => 'pages/effectif.php', 
	'effectif' => 'pages/effectif.php', 
	'joueur' => 'pages/joueur.php', 
	'tactique' => 'pages/tactique.php', 
	'calendrier' => 'pages/calendrier.php', 
	'centreformation' => 'pages/centreformation.php', 
	'entrainement' => 'pages/entrainement.php', 
	'infirmerie' => 'pages/infirmerie.php', 
	'stade' => 'pages/stade.php', 
	'infrastade' => 'pages/stade_infra.php', 
	'journal' => 'pages/journal.php',
	'renvoi' => 'pages/renvoi.php', 
	'suivi' => 'pages/suivi.php' 
					);
	
if(!array_key_exists($page, $array_pages)) include('pages/erreur.php');

elseif(!is_file($array_pages[$page])) include('pages/erreur.php');

else
{
?>
<a name="view"></a>
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
  <tbody>
   <tr>
    <td id="leftblock" valign="top" width="22%">
	 <div>
	 <!-- LEFT CONTEXT SENSITIVE MENU -->
	 <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="./images/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo $info['team_name']; ?></div>
	   <div class="menulinkwrap">&nbsp;&nbsp;|- <a href="club.php?zone=management&amp;page=effectif" style="text-decoration: none;"><?php echo EFFECTIF; ?></a></div>
	   <div class="menulinkwrap">&nbsp;&nbsp;|- <a href="club.php?zone=management&amp;page=tactique" style="text-decoration: none;"><?php echo TACTIQUE; ?></a></div>
	   <div class="menulinkwrap">&nbsp;&nbsp;|- <a href="club.php?zone=management&amp;page=calendrier" style="text-decoration: none;"><?php echo CALEND; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=management&amp;page=journal" style="text-decoration: none;"><?php echo ALLJOURN; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=management&amp;page=entrainement" style="text-decoration: none;"><?php echo TRAINING; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=management&amp;page=centreformation" style="text-decoration: none;"><?php echo FORMACENTRE; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=management&amp;page=infirmerie" style="text-decoration: none;"><?php echo INFIRMERIE; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=management&amp;page=stade" style="text-decoration: none;"><?php echo STADE; ?></a></div>
	  </div>
	  <br />
	  <?php if(isset($FORM['page']) && $FORM['page'] == 'joueur') include("pages/joueur_menu.php"); ?>
	</td>
	<td id="rightblock" valign="top" width="78%">
	 <div>
	 <!-- RIGHT CONTENT BLOCK -->
	  <?php include($array_pages[$page]); ?>
	 <!-- / RIGHT CONTENT BLOCK -->
	 </div>
	</td>
   </tr>
  </tbody>
 </table>
<?php
}
?>