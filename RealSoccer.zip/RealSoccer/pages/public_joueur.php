<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
29/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }
?>

<table width="100%">
<tbody>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td colspan="3">
	<div align="center">
	<?php echo $joueur->affiche_titre($data['prenom'], $data['surnom'], $data['nom'], $data['team_id'], $data['team_name'], $data['pays_flag'], $data['pos_name']); ?>
	</div>
	</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" width="33%">
	<div class="homepage_border">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td colspan="2">
		 <div align="center">
		 <?php echo $joueur->affiche_photo($data['photo'], $data['photo_valid']); ?>
		 </div>
		</td>
      </tr>
      <tr>
        <td class="homepage_sub_row_2">
		<?php echo $joueur->affiche_nationalite($data['pays_flag'], $data['pays_name']); ?>
		  <div align="right"></div>
		</td>
		<td class="homepage_sub_row_2">&nbsp;</td>
      </tr>
      <tr>
        <td class="homepage_sub_row_3"><?php echo $data['age'] . ' ' . YEARS; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><?php echo $data['taille'] . ' ' . CM; ?></div></td>
      </tr>
      <tr>
        <td class="homepage_sub_row_3"><?php echo SALAIRE; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><?php echo $data['salaire'] . ' ' . $info['pays_money'] . ' / ' . WEEK; ?></div></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_2"><?php echo VALEUR; ?></td>
		<td class="homepage_sub_row_2"><div align="right">&nbsp;<?php echo $joueur->estimation_joueur($data, $info); ?></div></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_3"><?php echo STATUT; ?></td>
		<td class="homepage_sub_row_3">
		<div align="right">
		<?php if($data['statut'] == 0) echo VENTE_NO; else echo VENTE_YES; ?>
		</div>
		</td>
      </tr>
	  <?php
	  if(isset($data['dmd_id']))
	  {
		  $req = sql::query("SELECT dmd_id, team_dmd, new_price, 
									team_id, team_name 
							 FROM joueurs_achat_demande 
							 LEFT JOIN equipes ON equipes.team_id = joueurs_achat_demande.team_dmd 
							 WHERE player_id = '".$player_id."' 
							 ORDER BY dmd_id");
	  ?>
	  <tr>
        <td class="homepage_sub_row_2" valign="top" colspan="2"><b><u><?php echo OFFRE; ?></u></b>
		<?php  
		  while($dmd = mysql_fetch_array($req))
		  {
			echo' | <a href="club.php?zone=public&amp;page=teaminfo&amp;id=' . $dmd['team_id'] . '">' . $dmd['team_name'] . '</a> ';
		  }
		?>
		</td>
      </tr>
	  <?php
	  }
	  ?>
    </table>
	</div>
	<br />
	<div class="homepage_border">
	<div class="homepage_sub_header"><?php echo HISTORIQUE; ?></div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tr>
        <td class="homepage_sub_row_2"><?php echo DATE; ?></td>
		<td class="homepage_sub_row_2"><?php echo CLUB; ?></td>
		<td class="homepage_sub_row_2"><?php echo VALEUR; ?></td>
      </tr>
	  <?php
	  $transfert = explode(";", $data['transfert']);
	  $nb_transfert = count($transfert);
	  $cunt = --$nb_transfert;
	  while($cunt >= 0)
	  {
		$transfert_info = explode("/", $transfert[$cunt]);
		$cunt_info = 0;
		?>
	  <tr>
        <td class="homepage_sub_row_3"><?php echo date($info['dateformat_choice'], $transfert_info[$cunt_info]); $cunt_info++; ?></td>
		<td class="homepage_sub_row_3">
		<?php
		if($transfert_info[$cunt_info] == 0) echo'<a href="club.php?zone=support&amp;page=notice#sansclub">' . SANSCLUB . '</a>'; 
		else echo'<a href="club.php?zone=public&amp;page=teaminfo&amp;id=' . $transfert_info[$cunt_info] . '">' . $joueur->teamid_to_teamname($transfert_info[$cunt_info]) . '</a>'; 
		$cunt_info++;
		?>
		</td>
		<td class="homepage_sub_row_3">
		<?php 
		if($transfert_info[$cunt_info] == 'FORMACLUB') echo FORMACLUB; 
		elseif($transfert_info[$cunt_info] == 'VIDE') echo''; 
		elseif($transfert_info[$cunt_info] == 0) echo LIBRE;
		else echo $transfert_info[$cunt_info] . ' Euros'; ?>
		</td>
      </tr>
	  <?php
	  $cunt--;
	  }
	?>
    </table>
	</div>
	</td>
    <td valign="top" width="33%">
	<div class="homepage_border">
	<div class="homepage_sub_header"><?php echo TECHNIQUE; ?></div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td class="homepage_sub_row_2"><?php echo CENTRES; ?></td>
		<td class="homepage_sub_row_2"><div align="right"><?php echo $joueur->notecolor20(round($data['centres'])); ?></div></td>
      </tr>
      <tr>
        <td class="homepage_sub_row_3"><?php echo CDPARRETE; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><?php echo $joueur->notecolor20(round($data['cdp_arrete'])); ?></div></td>
      </tr>
      <tr>
        <td class="homepage_sub_row_2"><?php echo DRIBBLE; ?></td>
		<td class="homepage_sub_row_2"><div align="right"><?php echo $joueur->notecolor20(round($data['dribble'])); ?></div></td>
      </tr>
      <tr>
        <td class="homepage_sub_row_3"><?php echo MARQUAGE; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><?php echo $joueur->notecolor20(round($data['marquage'])); ?></div></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_2"><?php echo PASSES; ?></td>
		<td class="homepage_sub_row_2"><div align="right"><?php echo $joueur->notecolor20(round($data['passes'])); ?></div></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_3"><?php echo PDBALLE; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><?php echo $joueur->notecolor20(round($data['pdballe'])); ?></div></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_2"><?php echo TACLES; ?></td>
		<td class="homepage_sub_row_2"><div align="right"><?php echo $joueur->notecolor20(round($data['tacles'])); ?></div></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_3"><?php echo TETE; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><?php echo $joueur->notecolor20(round($data['tete'])); ?></div></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_2"><?php echo TIR; ?></td>
		<td class="homepage_sub_row_2"><div align="right"><?php echo $joueur->notecolor20(round($data['tir'])); ?></div></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_3"><?php echo VITESSE; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><?php echo $joueur->notecolor20(round($data['vitesse'])); ?></div></td>
      </tr>
    </table>
	</div>
	<br />
	<div class="homepage_border">
	<div class="homepage_sub_header"><?php echo AUTRES; ?></div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
 	  <tr>
        <td class="homepage_sub_row_2"><?php echo FORME; ?></td>
		<td class="homepage_sub_row_2"><div align="right"><?php echo $club->notecolor100(round($data['forme'])); ?></div></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_3"><?php echo MORAL; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><?php echo $club->notecolor100(round($data['moral'])); ?></div></td>
      </tr>
    </table>
	</div>
	</td>
    <td valign="top" width="33%">
	<div class="homepage_border">
	<div class="homepage_sub_header"><?php echo MENTAL; ?></div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td class="homepage_sub_row_2"><?php echo AGRESSIVITE; ?></td>
		<td class="homepage_sub_row_2"><div align="right"><?php echo $joueur->notecolor20(round($data['agressivite'])); ?></div></td>
      </tr>
      <tr>
        <td class="homepage_sub_row_3"><?php echo CREATIVITE; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><?php echo $joueur->notecolor20(round($data['creativite'])); ?></div></td>
      </tr>
      <tr>
        <td class="homepage_sub_row_2"><?php echo DEGAGEMENT; ?></td>
		<td class="homepage_sub_row_2"><div align="right"><?php echo $joueur->notecolor20(round($data['degagement'])); ?></div></td>
      </tr>
      <tr>
        <td class="homepage_sub_row_3"><?php echo EXPERIENCE; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><?php echo $joueur->notecolor20(round($data['experience'])); ?></div></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_2"><?php echo INFLUENCE; ?></td>
		<td class="homepage_sub_row_2"><div align="right"><?php echo $joueur->notecolor20(round($data['influence'])); ?></div></td>
      </tr>
      <tr>
        <td class="homepage_sub_row_3"><?php echo REFLEXES; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><?php echo $joueur->notecolor20(round($data['reflexes'])); ?></div></td>
      </tr>
    </table>
	</div>
	<br />
	<div class="homepage_border">
	<div class="homepage_sub_header"><?php echo NIVEAU; ?></div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
 	  <tr>
        <td class="homepage_sub_row_2"><?php echo GARDIEN; ?></td>
		<td class="homepage_sub_row_2"><div align="right"><a href="club.php?zone=support&amp;page=notice#niveaujoueur"><?php echo $club->compare_etoile($player_id, $data, 1); ?></a></div></td>
      </tr>
      <tr>
        <td class="homepage_sub_row_3"><?php echo DEFENSEUR; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><a href="club.php?zone=support&amp;page=notice#niveaujoueur"><?php echo $club->compare_etoile($player_id, $data, 2); ?></a></div></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_2"><?php echo MILIEU; ?></td>
		<td class="homepage_sub_row_2"><div align="right"><a href="club.php?zone=support&amp;page=notice#niveaujoueur"><?php echo $club->compare_etoile($player_id, $data, 3); ?></a></div></td>
      </tr>
      <tr>
        <td class="homepage_sub_row_3"><?php echo ATTAQUANT; ?></td>
		<td class="homepage_sub_row_3"><div align="right"><a href="club.php?zone=support&amp;page=notice#niveaujoueur"><?php echo $club->compare_etoile($player_id, $data, 4); ?></a></div></td>
      </tr>
    </table>
	</div>
	</td>
  </tr>
  <tr>
	<td colspan="3">
	<div class="homepage_border">
	<div class="homepage_sub_header"><?php echo SAISON_STAT; ?></div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
 	  <tr>
        <td class="homepage_sub_row_2" width="25%"><?php echo '&nbsp;'; ?></td>
		<td class="homepage_sub_row_2" width="15%"><?php echo AB_SEL; ?></td>
		<td class="homepage_sub_row_2" width="15%"><?php echo BUT; ?></td>
		<td class="homepage_sub_row_2" width="15%"><?php echo AB_PASDEC; ?></td>
		<td class="homepage_sub_row_2" width="15%"><?php echo AB_CJAUNE; ?></td>
		<td class="homepage_sub_row_2" width="15%"><?php echo AB_CROUGE; ?></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_3"><?php echo HORSCOMPET; ?></td>
		<td class="homepage_sub_row_3"><?php if($data['hcomp_sel'] == 0) echo'-'; else echo $data['hcomp_sel']; ?></td>
		<td class="homepage_sub_row_3"><?php if($data['hcomp_but'] == 0) echo'-'; else echo $data['hcomp_but']; ?></td>
		<td class="homepage_sub_row_3"><?php if($data['hcomp_pasdec'] == 0) echo'-'; else echo $data['hcomp_pasdec']; ?></td>
		<td class="homepage_sub_row_3"><?php if($data['hcomp_cjaune'] == 0) echo'-'; else echo $data['hcomp_cjaune']; ?></td>
		<td class="homepage_sub_row_3"><?php if($data['hcomp_crouge'] == 0) echo'-'; else echo $data['hcomp_crouge']; ?></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_2"><?php echo CHAMP; ?></td>
		<td class="homepage_sub_row_2"><?php if($data['champ_sel'] == 0) echo'-'; else echo $data['champ_sel']; ?></td>
		<td class="homepage_sub_row_2"><?php if($data['champ_but'] == 0) echo'-'; else echo $data['champ_but']; ?></td>
		<td class="homepage_sub_row_2"><?php if($data['champ_pasdec'] == 0) echo'-'; else echo $data['champ_pasdec']; ?></td>
		<td class="homepage_sub_row_2"><?php if($data['champ_cjaune'] == 0) echo'-'; else echo $data['champ_cjaune']; ?></td>
		<td class="homepage_sub_row_2"><?php if($data['champ_crouge'] == 0) echo'-'; else echo $data['champ_crouge']; ?></td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_3"><?php echo NATCUP; ?></td>
		<td class="homepage_sub_row_3">-</td>
		<td class="homepage_sub_row_3">-</td>
		<td class="homepage_sub_row_3">-</td>
		<td class="homepage_sub_row_3">-</td>
		<td class="homepage_sub_row_3">-</td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_2"><?php echo CONTICUP; ?></td>
		<td class="homepage_sub_row_2">-</td>
		<td class="homepage_sub_row_2">-</td>
		<td class="homepage_sub_row_2">-</td>
		<td class="homepage_sub_row_2">-</td>
		<td class="homepage_sub_row_2">-</td>
      </tr>
	  <tr>
        <td class="homepage_sub_row_3"><?php echo TOTAL; ?></td>
		<td class="homepage_sub_row_3"><?php $total_sel = $data['hcomp_sel'] + $data['champ_sel']; if($total_sel == 0) echo'-'; else echo $total_sel; ?></td>
		<td class="homepage_sub_row_3"><?php $total_but = $data['hcomp_but'] + $data['champ_but']; if($total_but == 0) echo'-'; else echo $total_but; ?></td>
		<td class="homepage_sub_row_3"><?php $total_pasdec = $data['hcomp_pasdec'] + $data['champ_pasdec']; if($total_pasdec == 0) echo'-'; else echo $total_pasdec; ?></td>
		<td class="homepage_sub_row_3"><?php $total_cjaune = $data['hcomp_cjaune'] + $data['champ_cjaune']; if($total_cjaune == 0) echo'-'; else echo $total_cjaune; ?></td>
		<td class="homepage_sub_row_3"><?php $total_crouge = $data['hcomp_crouge'] + $data['champ_crouge']; if($total_crouge == 0) echo'-'; else echo $total_crouge; ?></td>
      </tr>
    </table>
	</div>
	</td>
  </tr>
</table>
   </tbody>
  </table>