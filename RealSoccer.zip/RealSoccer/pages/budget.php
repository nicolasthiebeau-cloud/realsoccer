<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//Estimation des entr�es du stade
$trib = explode(';', $info['stade_infra']);

$nb = sql::fetch("SELECT SUM(pla_debout) AS place_debout, 
						 SUM(pla_assise) AS place_assise, 
						 SUM(pla_debout_couv) AS place_debout_couverte, 
						 SUM(pla_assise_couv) AS place_assise_couverte, 
						 SUM(tribune_presi) AS tribune_presidentielle, 
						 SUM(buvette) AS buvette 
				  FROM stade WHERE stad_id IN($trib[0], $trib[1], $trib[2], $trib[3], $trib[4], $trib[5], $trib[6], $trib[7])");

$money1 = $nb['place_debout'] * $CONF['place_debout']; $money2 = $nb['place_assise'] * $CONF['place_assise'];
$money3 = $nb['place_debout_couverte'] * $CONF['place_debout_couverte']; $money4 = $nb['place_assise_couverte'] * $CONF['place_assise_couverte'];
$money5 = $nb['tribune_presidentielle'] * $CONF['tribune_presidentielle']; $money6 = $nb['buvette'] * ($CONF['buvette'] * ($money1 + $money2 + $money3 + $money4 + $money5));

$estima_stade = $money1 + $money2 + $money3 + $money4 + $money5 + $money6;
?>
<table width="100%" border="0" cellspacing="8" cellpadding="0">
  <tr>
    <td width="50%" valign="top">
      <div class="tableborder">
	  <div class="tableheaderalt"><?php echo RECHEBDO; ?></div>
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="homepage_sub_row_green"><?php echo SPONAFF . ' : '; ?></td>
		  <td class="homepage_sub_row_green"><?php echo $info['sponsor_money']; ?></td>
        </tr>
		<tr>
          <td class="homepage_sub_row_green"><?php echo ESTIMSATADE . ' : '; ?></td>
		  <td class="homepage_sub_row_green"><?php echo $estima_stade; ?></td>
        </tr>
		<tr>
          <td class="homepage_sub_row_green">&nbsp;</td>
		  <td class="homepage_sub_row_green">--------------</td>
        </tr>
		<tr>
          <td class="homepage_sub_row_green"><?php echo TOTAL; ?></td>
		  <td class="homepage_sub_row_green"><?php $recettes_tot = $estima_stade + $info['sponsor_money']; echo $recettes_tot; ?></td>
        </tr>
      </table> 
	  </div>
    </td>
    <td width="50%" valign="top">
      <div class="tableborder">
	  <div class="tableheaderalt"><?php echo DEPHEBDO; ?></div>
	  <table width="100% border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="homepage_sub_row_red"><?php echo PLAYSALAIRE . ' : '; ?></td>
		  <td class="homepage_sub_row_red"><?php $salaire_tot = $club->salaire_joueur_total($info['team_id']); echo $salaire_tot; ?></td>
        </tr>
		<tr>
          <td class="homepage_sub_row_red"><?php echo STAFFSALAIRE . ' : '; ?></td>
		  <td class="homepage_sub_row_red"><?php $salaire_staff_tot = $club->salaire_staff_total($info['team_id']); echo $salaire_staff_tot; ?></td>
        </tr>
		<tr>
          <td class="homepage_sub_row_red">&nbsp;</td>
		  <td class="homepage_sub_row_red">--------------</td>
        </tr>
		<tr>
          <td class="homepage_sub_row_red"><?php echo TOTAL; ?></td>
		  <td class="homepage_sub_row_red"><?php $depenses_tot = $salaire_tot + $salaire_staff_tot; echo $depenses_tot; ?></td>
        </tr>
      </table>
	  </div>
    </td>
  </tr>
</table>