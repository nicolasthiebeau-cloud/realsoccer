<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
17/05/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['mode']) AND !empty($_SESSION['pseudo']))
{
	if($FORM['mode'] == 'acceptamical' OR $FORM['mode'] == 'refuseamical')
	{
		$club->gestionmatchamical($FORM['demande'], $info['team_id'], $FORM['mode']);
	}
	
	else
	{
		$club->gestionachatdemande($FORM['demande'], $info['team_id'], $FORM['mode']);
	}
}

$nbre_non_vus = sql::fetch("SELECT COUNT(*) AS nbre FROM messagerie WHERE destinataire= '".$_SESSION['pseudo']."' AND vu= 0");
?>
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
   <tbody>
    <tr>
	 <td id="rightblock" valign="top" width="100%">
	   <table width="100%" border="0" cellpadding="0" cellspacing="4">
	    <tbody>
		 <tr>
		  <td valign="top" width="33%">
		   <table width="100%" border="0" cellpadding="0" cellspacing="0">
		    <tbody>
			 <tr>
			   <td>
			   <div class="homepage_border">
			   <table id="common_actions" width="100%" cellpadding="0" cellspacing="0">
				<tbody>
			   <tr>
			  <td valign="top" width="50%">
				<div><img src="images/icone/vide.png" border="0"> <a href="club.php?zone=bureaumanager&amp;page=budget"><?php echo BUDGET; ?></a></div>
				<div><img src="images/icone/vide.png" border="0"> <a href="club.php?zone=bureaumanager&amp;page=sponsor"><?php echo 'Sponsors'; ?></a></div>
				<div><img src="images/icone/vide.png" border="0"> <a href="club.php?zone=bureaumanager&amp;page=equipement"><?php echo EQUIPEMENT; ?></a></div>
			  </td>
			  <td valign="top" width="50%">
			    <div><img src="images/icone/vide.png" border="0"> <a href="club.php?zone=bureaumanager&amp;page=fanion"><?php echo FANION; ?></a></div>
				<div><img src="images/icone/vide.png" border="0"> <a href="club.php?zone=bureaumanager&amp;page=mp"><?php echo MESSAGERIE; if($nbre_non_vus['nbre'] > 0) echo '(' . $nbre_non_vus['nbre'] . ')'; ?></a></div>
				<div><img src="images/icone/vide.png" border="0"> <a href="club.php?zone=bureaumanager&amp;page=histoire"><?php echo HISTOCLUB; ?></a></div>
			  </td>
			 </tr>
			</tbody>
		   </table>
		   </div>
			  </td>
			 </tr>
			 <tr>
			  <td>&nbsp;</td>
			 </tr>
			 <tr>
			  <td>
			    <?php include("box/bdm_info_manager.php"); ?>
		  </td>
		 </tr>
		 <tr>
		  <td>&nbsp;</td>
		 </tr>
		 <tr>
		  <td>
			<?php include("box/bdm_compta_sponsor.php"); ?>
		  </td>
		 </tr>
		 <tr>
		   <td>&nbsp;</td>
		 </tr>
		 <tr>
		   <td>
			 <?php include("box/bdm_construction.php"); ?>
		   </td>
		 </tr>
		</tbody>
	   </table>
	  </td>
	  <td valign="top" width="33%">
		   <table width="100%" border="0" cellpadding="0" cellspacing="0">
		    <tbody>
			 <tr>
			   <td>
				<?php include("box/bdm_info_equipe.php"); ?>
			   </td>
		   </tr>
		   <tr>
		     <td>&nbsp;</td>
		   </tr>
		   <tr>
		     <td>
				<?php include("box/bdm_equipement.php"); ?>
			  </td>
			</tr>
		   <tr>
		     <td>&nbsp;</td>
		   </tr>
		   <tr>
			   <td>
			    <?php include("box/bdm_galerie_trophee.php"); ?>
			   </td>
			  </tr>
		 </tbody>
	   </table>
	  </td>
	  <td valign="top" width="33%">
		    <table width="100%" cellpadding="0" cellspacing="0">
			 <tbody>
			  <tr>
		       <td>
				<?php include("box/bdm_proch_match.php"); ?>
		       </td>
		      </tr>
			  <tr>
			   <td>&nbsp;</td>
			  </tr>
			  <tr>
			   <td>
			    <?php include("box/bdm_messagerie_interne.php"); ?>
			   </td>
			  </tr>
			  <tr>
		     <td>&nbsp;</td>
		      </tr>
		   <?php include("box/bdm_match_demande.php"); ?>
		   <?php include("box/bdm_achat_joueur.php"); ?>
			 </tbody>
			</table>
	  </td>
	 </tr>
    </tbody>
   </table>
  </td>
 </tr>
</tbody>
</table>