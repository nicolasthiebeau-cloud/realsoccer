<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

function redirection($url){
    echo "<script type=\"text/javascript\">\n"
    . "<!--\n"
    . "\n"
    . "function redirect() {\n"
    . "window.location='" . html_entity_decode($url) . "'\n"
    . "}\n"
    . "setTimeout('redirect()','2000');\n"
    . "\n"
    . "// -->\n"
    . "</script>\n";
     }

if (isset($FORM['member']))
{
	$member = $FORM['member'];
}
    
// Si la session est d�marr�e et si les variables $FORM['mp'] et$FORM['action'] n'existent pas, alors on affiche la page
if(!isset($FORM['mp']) AND !isset($FORM['action']))
{
	// on r�cup�re les donn�es sur les messages adress�s au membre connect�.
	$retour = sql::query("SELECT id, sujet, expediteur, timestamp, vu FROM messagerie WHERE destinataire='".$_SESSION['pseudo']."' AND (efface='0' OR efface='2') ORDER BY id DESC");
	?>
 <div class="tableborder">
 <div class="tableheaderalt"><?php echo 'Bo�te de r�ceptions'; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <thead>
     <th class="homepage_sub_row"><em>Lu</em>/<strong>Non lu (<?php echo $nbre_non_vus['nbre'];?>)</strong></th>
     <th class="homepage_sub_row">Sujet</th>
     <th class="homepage_sub_row">Auteur</th>
     <th class="homepage_sub_row">Date</th>
	 <th class="homepage_sub_row">&nbsp;</th>
   </thead>
   <tfoot>
     <th class="homepage_sub_row"><em>Lu</em>/<strong>Non lu(<?php echo $nbre_non_vus['nbre'];?>)</strong></th>
     <th class="homepage_sub_row">Sujet</th>
     <th class="homepage_sub_row">Auteur</th>
     <th class="homepage_sub_row">Date</th>
	 <th class="homepage_sub_row">&nbsp;</th>
   </tfoot>
   <tbody>
	<?php
	// on cr�� une boucle
	while($donnees = mysql_fetch_assoc($retour))
    {
		// on enl�ve les slashs inutiles qui se seraient ajout�s
		$sujet = stripslashes($donnees['sujet']);
		$expediteur = stripslashes($donnees['expediteur']);
		$date = $donnees['timestamp'];
		// si le message n'est pas lu on le montre et on marque son sujet en gras
		if($donnees['vu'] == 0)
		{
			// on cr�� une ligne sur le tableau
			echo'
			<tr>
			  <td class="homepage_sub_row"><strong>Non lu</strong></td>
			  <td class="homepage_sub_row"><strong><a href="club.php?zone=bureaumanager&amp;page=mp&mp='.$donnees['id'].'&amp;action=lire">'.$sujet.'</a></strong></td>
			  <td class="homepage_sub_row">'.$expediteur.'</td>
			  <td class="homepage_sub_row">Le' .date('d/m/Y \� H\hi', $date).'</td>
			  <td class="homepage_sub_row"><a href="club.php?zone=bureaumanager&amp;page=mp&action=supprimer&amp;suppr=1&amp;id='.$donnees['id'].'">Supprimer ce message</a></td>
			</tr>';
		}
		// sinon on marque que le sujet � �t� lu et on met en italique
		else
		{
			// on cr�� une nouvelle ligne sur le tableau
			echo '
			<tr>
			  <td class="homepage_sub_row"><em>Lu</em></td>
			  <td class="homepage_sub_row"><em><a href="club.php?zone=bureaumanager&amp;page=mp&mp='.$donnees['id'].'&amp;action=lire">'.$sujet.'</a></em></td>
			  <td class="homepage_sub_row">'.$expediteur.'</td>
			  <td class="homepage_sub_row">Le' .date('d/m/Y \� H\hi', $date).'</td>
			  <td class="homepage_sub_row"><a href="club.php?zone=bureaumanager&amp;page=mp&action=supprimer&amp;suppr=1&amp;id='.$donnees['id'].'">Supprimer ce message</a></td>
			</tr>';
		}
	}
	?>
   </tbody>
  </table>
 </div>
<p>
  <a href="club.php?zone=bureaumanager&amp;page=mp&action=LireMpRecu">Voir les messages envoy�s</a>
  <a href="club.php?zone=bureaumanager&amp;page=mp&action=ecrire">Ecrire un nouveau message</a>
</p>
<?php
// on ferme la condition
}
	
// sinon si la variable $FORM['mp'] existe, si l'utilisateur est conn�ct� et si la variable $FORM['action'] existe et contient 'lire' alors...
elseif(isset($FORM['mp']) AND isset($FORM['action']) AND $FORM['action'] == 'lire')
{
	$id_mp = $FORM['mp'];
	// on r�cup�re les donn�es o� l'id est �gale � l'id envoy�e par l'url
	$donnees = sql::fetch("SELECT destinataire, sujet, expediteur, timestamp, message FROM messagerie WHERE id='".$id_mp."'");
	// v�rification pour pas qu'une autre personne que le destinataire puisse voir le message
	if($donnees['destinataire'] == $_SESSION['pseudo'])
	{
		?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo 'Bo�te de r�ceptions'; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
		<?php
		// on enl�ve les slashs inutiles
		$sujet = stripslashes($donnees['sujet']);
		$expediteur = stripslashes($donnees['expediteur']);
		// on met la date au format Jour/mois/ann�e � heure h minutes
		$date = date('d/m/Y \� H\hi', $donnees['timestamp']);
		$mp = stripslashes($donnees['message']);  
		// on affiche le mp      
		echo '
		<tr>
		  <td class="td"><h1>'.$sujet.'</h1></td>
		</tr>
		<tr>
		  <td class="td">Le '.$date.'</td>
		</tr>
		<tr>
		  <td class="td">De : '.$expediteur.'</td>
		</tr>
		<tr>
		  <td class="td">
		  Message :
		  <br /><br/>
		  '.$mp.'
		  </td>
		</tr>
		<tr>
		  <td class="td">
		  <a href="club.php?zone=bureaumanager&amp;page=mp&action=ecrire&reponse='.$id_mp.'">R�pondre</a> 
		  <a href="club.php?zone=bureaumanager&amp;page=mp&action=ecrire">Nouveau</a>    
		  <a href="club.php?zone=bureaumanager&amp;page=mp">Revenir au menu de la messagerie</a>
		  </td>
		</tr>';
		// on met que le message a �t� lu.
		sql::update("UPDATE messagerie SET vu='1' WHERE id='".$id_mp."'");
		?>
   </tbody>
  </table>
 </div>
    <?php
	}
	
	else
	{
		// on affiche un message d'erreur si on essaye de lire un message qui n'est pas adress� � soi-m�me.
		echo 'Ceci est un message priv� qui ne s\'adresse pas � vous mais � '.$donnees['destinataire'].'';
		// on ferme la condition "secondaire"
    }
	
// on ferme la condition "primaire"
}
	
// Sinon si l'url indique qu'on veut envoyer un nouveau message ('ecrire'), on affiche un formulaire d'envoi.
elseif(isset($FORM['action']) AND $FORM['action'] == 'ecrire')
{
	// si la variable $FORM['reponse'] n'existe pas alors c'est un nouveau message
	if(!isset($FORM['reponse']))
	{
	?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo 'Nouveau message'; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	<tr>
      <td class="homepage_sub_row">
	    <form action="club.php?zone=bureaumanager&amp;page=mp&action=traitement" method="post">
		<a href="club.php?zone=bureaumanager&amp;page=mp">Boite de r�ception</a>
		<br /><br />
		<label>Sujet :<input type="text" name="sujet" /></label>
		<br />
		<label>Destinataire :<input type="text" name="destinataire" value="<?php if (isset($member)): echo $member; endif; ?>" /></label>
		<br />
		<label>Message :<textarea name="message" rows="10" cols="40"></textarea></label>
		<br />
		<input type="submit" value="Envoyer le message" />
		</form>
	  </td>
    </tr>
   </tbody>
  </table>
 </div>
	<?php
	}
		
	// sinon c'est une r�ponse
	else
    {
		// on r�cup�re les donn�es du mp dont l'id est �gale � celui auquel on veut r�pondre
		$donnees_reponse = sql::fetch("SELECT sujet, expediteur FROM messagerie WHERE id='".$FORM['reponse']."'");
		?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo 'Bo�te de r�ceptions'; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	<tr>
      <td class="homepage_sub_row">
	    <form action="club.php?zone=bureaumanager&amp;page=mp&action=traitement" method="post">
		<!-- on met RE : devant le sujet auquel on r�pond -->
		<a href="club.php?zone=bureaumanager&amp;page=mp">Boite de r�ception</a>
		<br /><br />
		<label>Sujet :<input type="text" name="sujet" value="RE : <?php echo $donnees_reponse['sujet'];?>"/></label>
		<br />
		<label>Destinataire :<input type="text" name="destinataire" value="<?php echo $donnees_reponse['expediteur']; ?>"/></label>
		<br />
		<label>Message :<textarea name="message" rows="10" cols="40"></textarea></label>
		<br />
		<input type="submit" value="Envoyer le message" />
		</form>
	  </td>
    </tr>
   </tbody>
  </table>
 </div>
	<?php
	}
}

// sinon si la variable $FORM['action'] est �gale � 'traitement' alors on traite les donn�es envoy�es par le fomulaire
elseif(isset($FORM['action']) AND $FORM['action'] == 'traitement')
{
	// si le message le sujet et le destinataire ne sont pas vide
	if(!empty($_POST['sujet']) AND !empty($_POST['destinataire']) AND !empty($_POST['message']))
	{
		// on regarde si il existe une entr�e avec le pseudo du destinataire
		$nbr_entrees = sql::fetch("SELECT COUNT(*) AS nbre_entrees FROM comptes WHERE pseudo='".$_POST['destinataire']."'");
		// si il existe
		if($nbr_entrees['nbre_entrees'] == 1)
		{
			// on s�curise les valeurs envoy�es
			$sujet = addslashes(htmlentities($_POST['sujet']));
			$destinataire = addslashes(htmlentities($_POST['destinataire']));
			$message = addslashes(nl2br(htmlentities($_POST['message'])));
			$expediteur = $_SESSION['pseudo'];
			$timestamp = time();
			// on r�cup�re le dernier message envoy� au destinataire
			$donnees = sql::fetch("SELECT destinataire, sujet, message FROM messagerie WHERE expediteur='$expediteur' ORDER BY id DESC LIMIT 0,1");
			// si c'est le m�me que celui qu'on veut envoyer
			if($donnees['destinataire'] == $destinataire AND $donnees['sujet'] == $sujet AND $donnees['message'] == $message)
			{
				// on l'enregistre pas et on affiche un message d'erreur
				echo 'Vous ne pouvez pas poster le m�me message 2 fois d\'affil�e';
			}
			// sinon ce n'est pas un double post
			else
			{
				// alors on enregistre dans la base de donn�es
				sql::insert("INSERT INTO messagerie(sujet, expediteur, destinataire, message, timestamp, vu, efface) VALUES('" . $sujet . "', '" . $expediteur . "', '" . $destinataire . "', '" . $message . "', '" . $timestamp . "', '0', '0')");
				// on met un message
				echo 'Votre message a bien �t� envoy� � '.$destinataire.'. Vous allez �tre redirig� vers votre bo�te de r�ception dans une seconde.';
				// et on redirige vers la bo�te de r�ception
				redirection('club.php?zone=bureaumanager&amp;page=mp');
			}
		}
		
		// sinon le membre n'est pas enregistr� dans la table
		else
		{
			// alors on affiche un message d'erreur
			echo 'Le membre � qui vous souhaitez envoyer ce message n\'existe pas/plus. Vous allez �tre redirig� vers votre bo�te de r�ception dans 2 secondes';
			// et on redirige vers la bo�te de r�ception
			redirection('club.php?zone=bureaumanager&amp;page=mp');
		}
	}
	
	// sinon tous les champs sont pas remplis
    else
	{
		// alors on affiche un message d'erreur et un lien
		echo 'Vous devez remplir tout les champs. <a href="club.php?zone=bureaumanager&amp;page=mp&action=ecrire">Recommencer</a>.';
	}
} // sinon si la variable $FORM['action'] est �gale � 'LireMpRecu' on affiche la bo�te d'envoi

elseif (!isset($FORM['mp']) && ($FORM['action'] == 'LireMpRecu')){
	// on r�cup�re les messages qu'on a envoy�s et que l'on n'a pas supprim�
    $retour = sql::query("SELECT id, destinataire, sujet, timestamp FROM messagerie WHERE expediteur='".$_SESSION['pseudo']."' AND (efface='0' OR efface='1') ORDER BY id DESC");
	?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo 'Messages envoy�s'; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <thead>
     <th class="homepage_sub_row">Sujet</th>
     <th class="homepage_sub_row">Destinataire</th>
     <th class="homepage_sub_row">Date</th>
	 <th class="homepage_sub_row">&nbsp;</th>
   </thead>
   <tfoot>
     <th class="homepage_sub_row">Sujet</th>
     <th class="homepage_sub_row">Destinataire</th>
     <th class="homepage_sub_row">Date</th>
	 <th class="homepage_sub_row">&nbsp;</th>
   </tfoot>
   <tbody>
	<?php
	// on cr�e une boucle avec les entr�es de la table
	while($donnees = mysql_fetch_assoc($retour))
	{
		// on enl�ve les �ventuelles slashs en trop
		$sujet = stripslashes($donnees['sujet']);
		$destinataire = stripslashes($donnees['destinataire']);  
		$date = $donnees['timestamp'];
		// on ajoute une ligne au tableau pour chaque message
		echo'
		<tr>
		  <td class="homepage_sub_row"><a href="club.php?zone=bureaumanager&amp;page=mp&mp='.$donnees['id'].'&amp;action=lire">'.$sujet.'</a></td>
		  <td class="homepage_sub_row">'.$destinataire.'</td>
		  <td class="homepage_sub_row">Le' .date('d/m/Y \� H\hi', $date).'</td>
		  <td class="homepage_sub_row"><a href="club.php?zone=bureaumanager&amp;page=mp&action=supprimer&amp;suppr=2&amp;id='.$donnees['id'].'">Supprimer ce message</a></td>
		</tr>';
	// on ferme la boucle
	}
	?> 
   </tbody>
  </table>
 </div>
<p>
  <a href="club.php?zone=bureaumanager&amp;page=mp">Bo�te de r�ception</a>
  <a href="club.php?zone=bureaumanager&amp;page=mp&action=ecrire">Ecrire un nouveau message</a>
</p>
<?php
// on ferme la condition
}

// si la variable $FORM['id'] qui contient l'id du message existe, si la variable $FORM['suppr'] qui indique qui a supprim� le message (destinataire ou exp�diteur) existe et si le variable $FORM['action'] est �gale � 'supprimer' qui indique la suppression d'un message alors on le supprime.
elseif(isset($FORM['action']) AND isset($FORM['suppr']) AND isset($FORM['id']) AND $FORM['action'] == 'supprimer')
{
	$id = $FORM['id'];
	// si c'est l'exp�diteur qui supprime le message alors
	if($FORM['suppr'] == 2)
	{
		// on r�cup�re les donn�es o� l'id du message � supprimer est �gale � l'id d'un message
        $donnees = sql::fetch("SELECT expediteur, efface FROM messagerie WHERE id='".$id."'");
		// si l'exp�diteur est bien le membre qui veut supprimer le message
		if($_SESSION['pseudo'] == $donnees['expediteur'])
		{
			// et si le message a d�j� �t� supprim� par le destinataire
			if($donnees['efface'] == 1)
			{
				// on supprime l'entr�e correspondante de la table
				sql::delete("DELETE FROM messagerie WHERE id='".$id."'");
				// on affiche un message
				echo 'Le message a �t� supprim� avec succ�s. Vous allez �tre redirig� vers votre bo�te de r�ception dans 2 secondes.';
				// et on redirige
				redirection('club.php?zone=bureaumanager&amp;page=mp');
			}
			
			// sinon si le message n'a pas �t� supprim� par le destinataire
			elseif($donnees['efface'] == 0)
			{
				// alors on modifie le champ efface par 2 pour que le destinataire puisse encore voir le message
				sql::update("UPDATE messagerie SET efface='2' WHERE id='".$id."'");
				// on affiche un message
				echo 'Le message a �t� supprim� avec succ�s. Vous allez �tre redirig� vers votre bo�te de r�ception dans 2 secondes.';
				// et on redirige
				redirection('club.php?zone=bureaumanager&amp;page=mp');
			}
			
			// sinon
			else
			{
				// on affiche un message d'erreur
				echo 'Une erreur est survenue lors de votre demande. Veuillez recommencer ult�rieurement.';
			}
		}
		
		// sinon le membre qui veut supprimer le message n'est pas l'exp�diteur
		else
		{
			// donc on affiche un message d'erreur
			echo 'Vous ne pouvez pas supprimer un message que vous n\'avez pas envoy� vous m�me.';
		}
	}
	
	// sinon si c'est le destinataire qui veut supprimer un message
	elseif($FORM['suppr'] == 1)
	{
		// on r�cup�re les donn�es sur le message que l'on veut supprimer
		$donnees = sql::fetch("SELECT destinataire, efface FROM messagerie WHERE id='".$id."'");
		// si le destinataire du message est bien le membre qui veut supprimer le message
		if($_SESSION['pseudo'] == $donnees['destinataire'])
		{
			// et si le message a �t� supprim� par l'exp�diteur
			if($donnees['efface'] == 2)
			{
				// alors on supprime l'entr�e correspondante de la table
				sql::delete("DELETE FROM messagerie WHERE id='".$id."'");
				// on affiche un message
				echo 'Le message a �t� supprim� avec succ�s. Vous allez �tre redirig� vers votre bo�te de r�ception dans 2 secondes.';
				// et on redirige
				redirection('club.php?zone=bureaumanager&amp;page=mp');
			}
			
			// sinon si le message n'a pas �t� supprim� par l'exp�diteur
			elseif($donnees['efface'] == 0)
			{
				// alors on modifie la valeur de efface par 1 pour que l'exp�diteur puisse encore voir le message
				sql::update("UPDATE messagerie SET efface='1' WHERE id='".$id."'");
				// on affiche un message
				echo 'Le message a �t� supprim� avec succ�s. Vous allez �tre redirig� vers votre bo�te de r�ception dans 2 secondes.';
				//et on redirige
				redirection('club.php?zone=bureaumanager&amp;page=mp');
			}
			
			// sinon
			else
			{
				// on affiche un message d'erreur
				echo 'Une erreur est survenue lors de votre demande. Veuillez recommencer ult�rieurement.';
			}
		}
		
		// sinon le membre qui veut supprimer le message n'est pas le destinataire de celui-ci
		else
		{
			// donc on affiche un message d'erreur
			echo 'Vous ne pouvez pas supprimer un message qui ne vous a pas �t� envoy�.';
		}
	}
	
	// sinon l'action demand�e n'existe pas($FORM['action'])
	else
	{
		// alors on affiche un message d'erreur
		echo 'Une erreur est survenue lors de votre demande. Veuillez recommencer ult�rieurement.';
	}
}

// sinon on met un message d'erreur qui envoie un lien pour se connecter.
else
{
	echo 'Vous n\'�tes pas connect� ou une erreur est survenue lors de votre demande veuillez recommencer ult�rieurement.<a href="connexion.php">Se connecter</a>';
}
?>