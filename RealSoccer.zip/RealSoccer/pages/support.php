<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
20/10/08	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

$page = (!empty($FORM['page'])) ? htmlentities($FORM['page']) : 'forums';
$array_pages = array(
	//Forums
	'forums' => 'forums/index.php', 
	'profil' => 'forums/voirprofil.php', 
	'modifprofil' => 'forums/modifprofil.php', 
	'listemembre' => 'forums/listemembre.php', 
	'viewforum' => 'forums/voirforum.php', 
	'viewtopic' => 'forums/voirtopic.php', 
	'poster' => 'forums/poster.php', 
	'postok' => 'forums/postok.php'
					);
	
if(!array_key_exists($page, $array_pages)) include('pages/erreur.php');

elseif(!is_file($array_pages[$page])) include('pages/erreur.php');

else
{
?>
<a name="view"></a>
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
  <tbody>
   <tr>
    <td id="leftblock" valign="top" width="22%">
	 <div>
	 <!-- LEFT CONTEXT SENSITIVE MENU -->
	 <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo $info['team_name']; ?></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=forums" style="text-decoration: none;"><?php echo 'Forums'; ?></a></div>
	  </div>
	  <br />
	  <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="../images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo 'Manuel du jeu'; ?></div>
	   <div class="menulinkwrap">&nbsp;<a href="" style="text-decoration: none;"><?php echo ''; ?></a></div>
	  </div>
	  <br />
	  <!-- / LEFT CONTEXT SENSITIVE MENU -->
	 </div>
	</td>
	<td id="rightblock" valign="top" width="78%">
	 <div>
	 <!-- RIGHT CONTENT BLOCK -->
	  <?php include($array_pages[$page]); ?>
	 <!-- / RIGHT CONTENT BLOCK -->
	 </div>
	</td>
   </tr>
  </tbody>
 </table>
<?php
}
?>