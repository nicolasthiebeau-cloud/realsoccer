<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
23/10/08	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//Langue des commentaires
include("languages/" . $info['lang'] . "-Commentaire.php");
//--------------------------

if(isset($FORM['id']));
{
	$matchinfo = sql::fetch("SELECT matchs.timematch, matchs.journee, matchs.score1, matchs.score2, 
									matchs.matchinfo, matchs.compoinfo, matchs.eq1_info, matchs.eq2_info, 
									matchs.commentinfo, 
									equipe1.team_id AS team_id1, equipe1.team_name AS team_name1, 
									equipe2.team_id AS team_id2, equipe2.team_name AS team_name2, 
									compet_name, 
									match_id, carton_jaune, carton_rouge, expulsion, blesse 
							FROM matchs 
							LEFT JOIN equipes AS equipe1 ON equipe1.team_id = matchs.team_id1 
							LEFT JOIN equipes AS equipe2 ON equipe2.team_id = matchs.team_id2 
							LEFT JOIN competition ON competition.compet_id = matchs.compet_id 
							LEFT JOIN matchs_encours ON matchs_encours.renco_id = matchs.renco_id 
							WHERE matchs.renco_id= '".$FORM['id']."'");
	
	
	if($matchinfo['score1'] == NULL)
	{
		echo PROGRAMATCHLE . ' : ' . date($info['dateformat_choice'], $matchinfo['timematch']) . ' ' . A . ' ' . date($info['timeformat_choice'], $matchinfo['timematch']);
	}
	
	else
	{
	//---- Partie matchinfo
		$explodeinfo = explode(';', $matchinfo['matchinfo']);
		
		if (isset($matchinfo['match_id']))
		{
			$carton_jaune = $matchinfo['carton_jaune']; 
			$carton_rouge = $matchinfo['carton_rouge'];
			//Expulsion
			//Blesse
		}
		
		else
		{
			$carton_jaune = $explodeinfo[7]; 
			$carton_rouge = $explodeinfo[8];
			//Expulsion
			//Blesse
		}
		
	//-----Partie buteurs
		$buteur1 = explode('/', $matchinfo['eq1_info']);
		$nbbuteur1 = count($buteur1); $nba = 1;
		$buteur2 = explode('/', $matchinfo['eq2_info']);
		$nbbuteur2 = count($buteur2); $nbb = 1;
		
		//Explode des joueurs
		$player = explode(';', $matchinfo['compoinfo']);
		
		//Les couleurs des equipes (� modifier aussi dans Francais_Commentaire.php)
		$color1 = 'red';
		$color2 = 'blue';
		
		//Si equipe du joueur => lien management sinon public
		if($matchinfo['team_id1'] == $info['team_id']) $zonechoice = 'management'; else $zonechoice = 'public';
		if($matchinfo['team_id2'] == $info['team_id']) $zonechoice = 'management'; else $zonechoice = 'public';
?>
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
   <tbody>
     <tr>
	 <td id="rightblock" valign="top" width="100%">
	   <table width="100%" border="0" cellpadding="0" cellspacing="4">
	    <tbody>
		 <tr>
		  <td valign="top" colspan="3">
		    <table width="100%" border="0" cellpadding="0" cellspacing="4">
	          <tbody>
			    <tr>
				  <td valign="top" width="10%">
					<div align="left">
					<img src="images/icone/loading.gif" width="18" height="18" style="vertical-align: bottom;" />&nbsp;
					<a href="club.php?zone=match&amp;id=<?php echo $FORM['id']; ?>"><strong>Rafraichir la page</strong></a></div>
				  </td>
				  <td valign="top" width="30%">
				    <div align="right"><h1><strong><?php echo $matchinfo['team_name1']; ?></strong></h1></div>
				  </td>
			      <td valign="top" width="20%">
				    <div align="center"><h1><strong><?php echo $matchinfo['score1'] . ' - ' . $matchinfo['score2']; ?></strong></h1></div>
				  </td>
				  <td valign="top" width="30%">
				    <div align="left"><h1><strong><?php echo $matchinfo['team_name2']; ?></strong></h1></div>
				  </td>
				  <td valign="top" width="10%" rowspan="2">
				    <div align="right">
					<?php echo '<img src="images/meteo/' . $explodeinfo[1] . '.gif" width="77" height="53" /><br />'; ?>
					<?php echo '<strong>' . $explodeinfo[0] . '<br />Spectateur : ' . $explodeinfo[2] . '</strong>'; ?>
					</div>
				  </td>
				</tr>
				<tr>
				  <td valign="top">
				    <div align="center"></div>
				  </td>
				  <td valign="top" colspan="3">
				    <div align="center"><?php echo '<img src="images/flag/' . $explodeinfo[5] . '" width="20" height="15" style="vertical-align: bottom;" /> <strong>' . ARBITRE . ' : ' . $explodeinfo[6] . '</strong>'; ?></div>
				  </td>
				  </td>
				</tr>
			  </tbody>
			</table>
		  </td>
		 </tr>
		 <tr>
		  <td valign="top" width="20%">
		   <table width="100%" border="0" cellpadding="0" cellspacing="0">
		    <tbody>
			 <tr>
			   <td valign="top">
			     <div class="homepage_border">
				 <div class="homepage_sub_header"><?php echo 'Info match'; ?></div>
				 <table width="100%" cellpadding="0" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_row">
				      <?php
					  if ($nbbuteur1 != 1) echo'<strong>'.$matchinfo['team_name1'].'</strong><br />But :';
					  while($nba < $nbbuteur1)
					  {
						  echo ' ' . player($buteur1[$nba++], NULL, $info);
						  echo'(' . $buteur1[$nba++] . '\') ';
					  }
					  ?>
				    </td>
				   </tr>
				  </tbody>
				 </table>
				 </div>
			   </td>
			 </tr>
			 <tr>
			  <td>&nbsp;</td>
			 </tr>
			 <tr>
			   <td valign="top">
			     <div class="homepage_border">
				 <div class="homepage_sub_header"><?php echo 'Compo. d\'�quipe ' . $matchinfo['team_name1']; ?></div>
				 <table width="100%" cellpadding="0" cellspacing="0">
				  <tbody>
				   <tr>
				    <td>
	      </td>
		   <tr>
<?php
echo '<td width="5%" class="homepage_sub_row_2">1</td>';
echo '<td width="65%" class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[0] . '"><span style="color: '.$color1.'">' . $player[1] . '</span></a></td>';
echo '<td width="10%" class="homepage_sub_row_2">&nbsp;</td>';
echo '<td width="20%" class="homepage_sub_row_2">' . recupcartonfor($player[0], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_3">2</td>';
echo '<td class="homepage_sub_row_3"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[2] . '"><span style="color: '.$color1.'">' . $player[3] . '</span></a></td>';
echo '<td class="homepage_sub_row_3">&nbsp;</td>';
echo '<td class="homepage_sub_row_3">' . recupcartonfor($player[2], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_2">3</td>';
echo '<td class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[4] . '"><span style="color: '.$color1.'">' . $player[5] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_2">&nbsp;</td>';
echo '<td class="homepage_sub_row_2">' . recupcartonfor($player[4], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_3">4</td>';
echo '<td class="homepage_sub_row_3"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[6] . '"><span style="color: '.$color1.'">' . $player[7] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_3">&nbsp;</td>';
echo '<td class="homepage_sub_row_3">' . recupcartonfor($player[6], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_2">5</td>';
echo '<td class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[8] . '"><span style="color: '.$color1.'">' . $player[9] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_2">&nbsp;</td>';
echo '<td class="homepage_sub_row_2">' . recupcartonfor($player[8], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_3">6</td>';
echo '<td class="homepage_sub_row_3"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[10] . '"><span style="color: '.$color1.'">' . $player[11] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_3">&nbsp;</td>';
echo '<td class="homepage_sub_row_3">' . recupcartonfor($player[10], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_2">7</td>';
echo '<td class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[12] . '"><span style="color: '.$color1.'">' . $player[13] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_2">&nbsp;</td>';
echo '<td class="homepage_sub_row_2">' . recupcartonfor($player[12], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_3">8</td>';
echo '<td class="homepage_sub_row_3"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[14] . '"><span style="color: '.$color1.'">' . $player[15] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_3">&nbsp;</td>';
echo '<td class="homepage_sub_row_3">' . recupcartonfor($player[14], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_2">9</td>';
echo '<td class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[16] . '"><span style="color: '.$color1.'">' . $player[17] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_2">&nbsp;</td>';
echo '<td class="homepage_sub_row_2">' . recupcartonfor($player[16], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_3">10</td>';
echo '<td class="homepage_sub_row_3"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[18] . '"><span style="color: '.$color1.'">' . $player[19] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_3">&nbsp;</td>';
echo '<td class="homepage_sub_row_3">' . recupcartonfor($player[18], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_2">11</td>';
echo '<td class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[20] . '"><span style="color: '.$color1.'">' . $player[21] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_2">&nbsp;</td>';
echo '<td class="homepage_sub_row_2">' . recupcartonfor($player[20], $carton_jaune, $carton_rouge) . '</td>';
?>
				   </tr>
				  </tbody>
				 </table>
				 </div>
			   </td>
			 </tr>
			 <tr>
			  <td>&nbsp;</td>
			 </tr>
			 <tr>
			  <td valign="top">
			     <div class="homepage_border">
				 <div class="homepage_sub_header"><?php echo 'Equipement'; ?></div>
				 <table width="100%" cellpadding="0" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_row">
				      <div align="center">
					  <?php echo '<img src="images/shirt/' . $explodeinfo[3] . '" width="115" height="115" />'; ?>
					  </div>
				    </td>
				   </tr>
				  </tbody>
				 </table>
				 </div>
			   </td>
		     </tr>
		    </tbody>
	       </table>
	      </td>
	      <td valign="top" width="60%">
		   <div class="homepage_border">
		   <div class="homepage_sub_header">&nbsp;</div>
		   <table width="100%" border="0" cellpadding="0" cellspacing="0">
		    <tbody>
<?php
	//---- Partie commentaires
	$comment = explode(';', $matchinfo['commentinfo']);
	$nbcomment = count($comment);
	
	while($nbcomment > 0)
	{
		$nbcomment--;
		$zicomment = explode('_', $comment[$nbcomment]);
		
		if(isset($zicomment[0])) $temps = $zicomment[0]; else $temps = NULL;
		if(isset($zicomment[1])) $part1 = $zicomment[1]; else $part1 = NULL;
		if(isset($zicomment[2])) $part2 = $zicomment[2]; else $part2 = NULL;
		if(isset($zicomment[3])) $part3 = $zicomment[3]; else $part3 = NULL;
		if(isset($zicomment[4])) $part4 = $zicomment[4]; else $part4 = NULL;
		if(isset($zicomment[5])) $part5 = $zicomment[5]; else $part5 = NULL;
		if(isset($zicomment[6])) $part6 = $zicomment[6]; else $part6 = NULL;
		if(isset($zicomment[7])) $part7 = $zicomment[7]; else $part7 = NULL;
		
		echo'<tr>
		      <td class="homepage_sub_row" width="10%" align="right" valign="top">' . $temps . '</td>';
		echo' <td class="homepage_sub_row" width="90%" align="left" valign="top">' . commentaire($part1,$part2,$part3,$part4,$part5,$part6,$part7,$info) . '</td>
		     </tr>';
	}
?> 
		    </tbody>
	       </table>
		   </div>
	      </td>
	      <td valign="top" width="20%">
		    <table width="100%" cellpadding="0" cellspacing="0">
			 <tbody>
			  <tr>
		       <td valign="top">
			     <div class="homepage_border">
				 <div class="homepage_sub_header"><?php echo 'Info match'; ?></div>
				 <table width="100%" cellpadding="0" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_row" valign="top">
					  <?php
					  if ($nbbuteur2 != 1) echo'<strong>'.$matchinfo['team_name2'].'</strong><br />But :';
					  while($nbb < $nbbuteur2)
					  {
						  echo ' ' . player($buteur2[$nbb++], NULL, $info);
						  echo'(' . $buteur2[$nbb++] . '\') ';
					  }
					  ?>
				    </td>
				   </tr>
				  </tbody>
				 </table>
				 </div>
			   </td>
		      </tr>
			  <tr>
			   <td>&nbsp;</td>
			  </tr>
			  <tr>
		       <td valign="top">
			     <div class="homepage_border">
				 <div class="homepage_sub_header"><?php echo 'Compo d\'�quipe ' . $matchinfo['team_name2']; ?></div>
				 <table width="100%" cellpadding="0" cellspacing="0">
				  <tbody>
				   <tr>
				    <td valign="top">
			    </td>
			   <tr>
<?php
echo '<td width="5%" class="homepage_sub_row_2">1</td>';
echo '<td width="65%" class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[22] . '"><span style="color: '.$color2.'">' . $player[23] . '</span></a></td>';
echo '<td width="10%" class="homepage_sub_row_2">&nbsp;</td>';
echo '<td width="20%" class="homepage_sub_row_2">' . recupcartonfor($player[22], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_3">2</td>';
echo '<td class="homepage_sub_row_3"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[24] . '"><span style="color: '.$color2.'">' . $player[25] . '</span></a></td>';
echo '<td class="homepage_sub_row_3">&nbsp;</td>';
echo '<td class="homepage_sub_row_3">' . recupcartonfor($player[24], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_2">3</td>';
echo '<td class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[26] . '"><span style="color: '.$color2.'">' . $player[27] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_2">&nbsp;</td>';
echo '<td class="homepage_sub_row_2">' . recupcartonfor($player[26], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_3">4</td>';
echo '<td class="homepage_sub_row_3"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[28] . '"><span style="color: '.$color2.'">' . $player[29] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_3">&nbsp;</td>';
echo '<td class="homepage_sub_row_3">' . recupcartonfor($player[28], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_2">5</td>';
echo '<td class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[30] . '"><span style="color: '.$color2.'">' . $player[31] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_2">&nbsp;</td>';
echo '<td class="homepage_sub_row_2">' . recupcartonfor($player[30], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_3">6</td>';
echo '<td class="homepage_sub_row_3"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[32] . '"><span style="color: '.$color2.'">' . $player[33] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_3">&nbsp;</td>';
echo '<td class="homepage_sub_row_3">' . recupcartonfor($player[32], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_2">7</td>';
echo '<td class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[34] . '"><span style="color: '.$color2.'">' . $player[35] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_2">&nbsp;</td>';
echo '<td class="homepage_sub_row_2">' . recupcartonfor($player[34], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_3">8</td>';
echo '<td class="homepage_sub_row_3"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[36] . '"><span style="color: '.$color2.'">' . $player[37] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_3">&nbsp;</td>';
echo '<td class="homepage_sub_row_3">' . recupcartonfor($player[36], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_2">9</td>';
echo '<td class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[38] . '"><span style="color: '.$color2.'">' . $player[39] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_2">&nbsp;</td>';
echo '<td class="homepage_sub_row_2">' . recupcartonfor($player[38], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_3">10</td>';
echo '<td class="homepage_sub_row_3"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[40] . '"><span style="color: '.$color2.'">' . $player[41] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_3">&nbsp;</td>';
echo '<td class="homepage_sub_row_3">' . recupcartonfor($player[40], $carton_jaune, $carton_rouge) . '</td>';
?>
			   </tr>
			   <tr>
<?php
echo '<td class="homepage_sub_row_2">11</td>';
echo '<td class="homepage_sub_row_2"><a href="club.php?zone=' . $zonechoice . '&amp;page=joueur&amp;id=' . $player[42] . '"><span style="color: '.$color2.'">' . $player[43] . '</span></a></td>'; 
echo '<td class="homepage_sub_row_2">&nbsp;</td>';
echo '<td class="homepage_sub_row_2">' . recupcartonfor($player[42], $carton_jaune, $carton_rouge) . '</td>';
?>
				   </tr>
				  </tbody>
				 </table>
				 </div>
			   </td>
		      </tr>
			  <tr>
			   <td>&nbsp;</td>
			  </tr>
			  <tr>
			   <td valign="top">
			     <div class="homepage_border">
				 <div class="homepage_sub_header"><?php echo 'Equipement'; ?></div>
				 <table width="100%" cellpadding="0" cellspacing="0">
				  <tbody>
				   <tr>
				    <td class="homepage_sub_row">
				      <div align="center">
					  <?php echo '<img src="images/shirt/' . $explodeinfo[4] . '" width="115" height="115" />'; ?>
					  </div>
				    </td>
				   </tr>
				  </tbody>
				 </table>
				 </div>
			   </td>
			  </tr>
			 </tbody>
			</table>
	      </td>
	   </tr>
    </tbody>
   </table>
  </td>
 </tr>
</tbody>
</table>
<?php
	}
}
?>