<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//Class et Lang Tactique
include('sources/lang_page/' . $info['lang'] . '/lang_tactique.php');
include('sources/class_page/class_tactique.php');
$tactique = new tactique;

if(isset($FORM['choixtactique']) OR isset($FORM['tactik_select']))
{
	$chx_tact = htmlentities(addslashes($FORM['tactik_select']));
	$defautpenalty = htmlentities(addslashes($FORM['defautpenalty']));
	$defautcfranc = htmlentities(addslashes($FORM['defautcfranc']));
	$player = $FORM['player'];
	$nb_joueur = htmlentities(addslashes($FORM['nb_joueur']));
	
	//On cr�e les variable pour eviter les erreurs du style "Undefined variable"
	$nbr1 = $nbr2 = $nbr3 = $nbr4 = $nbr5 = $nbr6 = $nbr7 = $nbr8 = $nbr9 = $nbr10 = $nbr11 = 0;
	
	//On recup les joueurs qui formeront l'�quipe et on leur attribut la place
	for($nb = 0; $nb < $nb_joueur; $nb++)
	{
		if(isset($player[$nb]))
		{
			$mid = explode(';', $player[$nb]);
			
			switch($mid[0])
			{
				case 1: $nbr1 = $mid[1]; break;
				case 2: $nbr2 = $mid[1]; break;
				case 3: $nbr3 = $mid[1]; break;
				case 4: $nbr4 = $mid[1]; break;
				case 5: $nbr5 = $mid[1]; break;
				case 6: $nbr6 = $mid[1]; break;
				case 7: $nbr7 = $mid[1]; break;
				case 8: $nbr8 = $mid[1]; break;
				case 9: $nbr9 = $mid[1]; break;
				case 10: $nbr10 = $mid[1]; break;
				case 11: $nbr11 = $mid[1]; break;
			}
		}
	}
	
	//Si la tactique est valider (bouton en bas) on lance la partie verif et creation de la tactique
	if(isset($FORM['validtactik']))
	{
		$pos_manquante = $tactique->verif_joueur_exist($nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11);
		
		if($pos_manquante == NULL)
		{
			if($tactique->verif_tireur_penalty($defautpenalty, $nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11) == 1)
			{
				if($tactique->verif_tireur_cfranc($defautcfranc, $nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11) == 1)
				{
					$error = $tactique->create_tactique($chx_tact, $defautpenalty, $defautcfranc, $nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11, $info);
				}
				
				else $error = ERROR_BADCFRANC;
			}
			
			else $error = ERROR_BADPENALTY;
		}
		
		else
		{
			$nb = count($pos_manquante);
			$error = ERROR_MANQUEJOUEUR . ' : ';
			for($nbi = 0; $nbi < $nb; $nbi++) $error .= '(' . $pos_manquante[$nbi] . ') ';
		}
	}
}

else
{
	//On cherche si une tactique existe d�j�
	$data = sql::fetch("SELECT id_team, tact_name, tact_using, N1, N2, N3, N3, N4, N5, N6, 
							   N7, N8, N9, N10, N11, N12, N13, N14, N15, penalty, cfranc 
						FROM tactiques 
						WHERE id_team = {$info['team_id']}");

	$nbr15 = $data['N15']; $nbr14 = $data['N14']; $nbr13 = $data['N13']; $nbr12 = $data['N12']; $nbr11 = $data['N11']; 
	$nbr10 = $data['N10']; $nbr9 = $data['N9']; $nbr8 = $data['N8']; $nbr7 = $data['N7']; $nbr6 = $data['N6'];
	$nbr5 = $data['N5']; $nbr4 = $data['N4']; $nbr3 = $data['N3']; $nbr2 = $data['N2']; $nbr1 = $data['N1'];
	$defautpenalty = $data['penalty']; $defautcfranc = $data['cfranc'];
	
	if(isset($data['tact_using'])) $chx_tact = $data['tact_using'];
	else $chx_tact = '442';
}

$req = sql::query("SELECT joueurs.player_id, joueurs.team_id, nom, surnom, prenom, age, forme, moral, 
						   pays_name, pays_flag, 
						   group_id, pos_shortname, 
						   suspension 
					FROM joueurs 
					LEFT JOIN pays ON joueurs.nationalite = pays.pays_id 
					LEFT JOIN joueurs_position ON joueurs.position = joueurs_position.pos_id 
					LEFT JOIN stamp_suspension ON stamp_suspension.id_player = joueurs.player_id 
					WHERE joueurs.team_id= '".$info['team_id']."' 
					AND age > 16 
					ORDER BY joueurs.position, nom"); 

$color = 1;

$number = mysql_num_rows($req)
?>
<form action="club.php?zone=management&amp;page=tactique#view" name="choixtactique" method="post">
<input name="nb_joueur" value="<?php echo $number; ?>" type="hidden" />
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td valign="top" width="60%">
  <div class="tableborder">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo COMPO; ?></td>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo NATIO; ?></td>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo INFO; ?></td>
	  <td class="homepage_sub_header" align="center" width="20%"><?php echo IDENTITE; ?></td>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo POSITION; ?></td>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo AGE; ?></td>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo FORME; ?></td>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo MORAL; ?></td>
	</tr>
<?php
while ($donnees = mysql_fetch_assoc($req))
{
	$info_effect = $club->info_effect(NULL, $donnees['suspension'], NULL, NULL);
?>
  <tr>
	<td <?php echo $club->colorchoice($color); ?> align="center">
	<select name="player[]">
	 <option value=""></option>
	 <?php 
	 echo $tactique->show_number_player($info_effect, $donnees['player_id'], $nbr1, $nbr2, $nbr3, $nbr4, $nbr5, $nbr6, $nbr7, $nbr8, $nbr9, $nbr10, $nbr11);
	 ?>
	</select>
	</td>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo '<img src="images/flag' . '/' . $donnees['pays_flag'] . '" width="32" height="20" alt="' . $donnees['pays_name'] . '" />'; ?></td>
    <td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $info_effect; ?></td>
	<td <?php echo $club->colorchoice($color); ?>><?php echo ' <a href="club.php?zone=management&amp;page=joueur&amp;id='. $donnees['player_id'] .'"><strong>'. stripslashes($donnees['prenom']) . ' ';
			  if ($donnees['surnom'] != NULL) echo '\' '. stripslashes($donnees['surnom']) . ' \'';
			  echo ' ' . stripslashes($donnees['nom']); ?></strong></a></td>
    <td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $club->smallposition($donnees['group_id'], $donnees['pos_shortname']); ?></td>
    <td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $donnees['age']; ?></td>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $club->notecolor100(round($donnees['forme'])); ?></td>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $club->notecolor100(round($donnees['moral'])); ?></td>
  </tr>
<?php
	if($color == 1) $color++; else $color--;
}
?>
   </tbody>
  </table>
 </div>
	</td>
    <td valign="top" width="40%">
<div class="tableborder">
<div class="homepage_sub_header"><?php echo TACTIK; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	   <td class="homepage_sub_row_2">
	   <div align="center">
	   <select name="tactik_select" id="tactik_select" onChange="submit();">
		<option value="442" <?php if($chx_tact == "442") echo 'selected="selected"'; ?>>4 - 4 - 2</option>
		<option value="433" <?php if($chx_tact == "433") echo 'selected="selected"'; ?>>4 - 3 - 3</option>
        <option value="451" <?php if($chx_tact == "451") echo 'selected="selected"'; ?>>4 - 5 - 1</option>
        <option value="352" <?php if($chx_tact == "352") echo 'selected="selected"'; ?>>3 - 5 - 2</option>
        <option value="541" <?php if($chx_tact == "541") echo 'selected="selected"'; ?>>5 - 4 - 1</option>
        <option value="343" <?php if($chx_tact == "343") echo 'selected="selected"'; ?>>3 - 4 - 3</option>
        <option value="352" <?php if($chx_tact == "352") echo 'selected="selected"'; ?>>3 - 5 - 2</option>
        <option value="442etoile" <?php if($chx_tact == "442etoile") echo 'selected="selected"'; ?>>4 - 4 - 2*</option>
	   </select>
	   </div>
	   </td>
	 </tr>
	 <tr>
	   <td class="homepage_sub_row_3">
	   <div align="center">
	   <?php if(isset($error)) echo'<font color="#FF0000"><b>'.$error.'</b></font>'; else'&nbsp;' ?>
	   </div>
	   </td>
	 </tr>
	 <tr>
	   <td class="homepage_sub_row_2">
	   <div align="center">
	   <div id="tactik-img"><img src="images/tactique/<?php echo $chx_tact; ?>.jpg" alt="" width="271" height="400" align="middle" /></div>
	   </div>
	   </td>
	 </tr>
   </tbody>
  </table>
 </div>
	</td>
  </tr>
  <tr>
    <td valign="top" colspan="2">
<div class="tableborder">
<div class="homepage_sub_header"><?php echo 'Consigne de match'; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	   <td class="homepage_sub_row_2" width="33%">
		
	   </td>
	   <td class="homepage_sub_row_2" width="33%">
		
	   </td>
	   <td class="homepage_sub_row_2" width="33%">
		<?php echo TIRPENALTY . ' (' . TIRPENALTYINFO; ?>)<br /> 
		<select name="defautpenalty" id="defautpenalty">
		<option value=""></option>
		<?php
		$req = sql::query("SELECT player_id, nom, prenom 
						   FROM joueurs 
						   WHERE team_id= '".$info['team_id']."' 
						     AND age >= '17' 
						   ORDER BY position, nom");
		
		while ($donnees = mysql_fetch_assoc($req))
		{
		?>
		<option value="<?php echo $donnees['player_id']; ?>" <?php if(isset($defautpenalty) && $defautpenalty == $donnees['player_id']) echo 'selected="selected"'; ?> >
		<?php echo $donnees['prenom'] . ' ' . $donnees['nom']; ?></option>
		<?php } ?>
		</select>
	   </td>
	 </tr>
	 <tr>
	   <td class="homepage_sub_row_2">
		
	   </td>
	   <td class="homepage_sub_row_2">
		
	   </td>
	   <td class="homepage_sub_row_2">
		<?php echo TIRCFRANC . ' (' . TIRCFRANCINFO; ?>)<br />
		<select name="defautcfranc" id="defautcfranc">
		<option value=""></option>
		<?php
		$req = sql::query("SELECT player_id, nom, prenom 
						   FROM joueurs 
						   WHERE team_id= '".$info['team_id']."' 
						     AND age >= '17' 
						   ORDER BY position, nom");
		
		while ($donnees = mysql_fetch_array($req))
		{
		?>
		<option value="<?php echo $donnees['player_id']; ?>" <?php if(isset($defautcfranc) && $defautcfranc == $donnees['player_id']) echo 'selected="selected"'; ?> >
		<?php echo $donnees['prenom'] . ' ' . $donnees['nom']; ?></option>
		<?php } ?>
		</select>
	   </td>
	 </tr>
	   <td class="homepage_sub_row_2" colspan="3">
		<div align="center"><input name="validtactik" type="submit" value="<?php echo VALID_TACTIK; ?>" /></div></div>
	   </td>
	 </tr>
   </tbody>
  </table>
 </div>
	</td>
  </tr>
</table>
</form>