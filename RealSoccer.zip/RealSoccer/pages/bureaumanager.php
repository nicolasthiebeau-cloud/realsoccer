<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

$nbre_non_vus = sql::fetch("SELECT COUNT(*) AS nbre FROM messagerie WHERE destinataire= '".$_SESSION['pseudo']."' AND vu= 0");

$page = (!empty($FORM['page'])) ? htmlentities($FORM['page']) : 'main';
$array_pages = array(
	//Base
	'main' => 'club.php', 
	'sponsor' => 'pages/sponsor.php', 
	'budget' => 'pages/budget.php', 
	'equipement' => 'pages/equipement.php', 
	'fanion' => 'pages/fanion.php', 
	'mp' => 'pages/messagerie.php', 
	'messagerieclub' => 'pages/messagerie_interne_plus.php', 
	'histoire' => 'pages/historique.php', 
	'profil' => 'pages/profil.php', 
					);
	
if(!array_key_exists($page, $array_pages)) include('pages/erreur.php');
elseif(!is_file($array_pages[$page])) include('pages/erreur.php');
else
{	
?>
<a name="view"></a>
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
  <tbody>
   <tr>
    <td id="leftblock" valign="top" width="22%">
	 <div>
	 <!-- LEFT CONTEXT SENSITIVE MENU -->
	 <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo 'Bureau du manager'; ?></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php" style="text-decoration: none;"><?php echo INFOGEN; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=bureaumanager&amp;page=messagerieclub" style="text-decoration: none;"><?php echo 'Messagerie interne du club'; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=bureaumanager&amp;page=budget" style="text-decoration: none;"><?php echo BUDGET; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=bureaumanager&amp;page=sponsor" style="text-decoration: none;"><?php echo 'Sponsor'; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=bureaumanager&amp;page=equipement" style="text-decoration: none;"><?php echo EQUIPEMENT; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=bureaumanager&amp;page=fanion" style="text-decoration: none;"><?php echo FANION; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=bureaumanager&amp;page=mp" style="text-decoration: none;"><?php echo MESSAGERIE; if($nbre_non_vus['nbre'] > 0) echo '(' . $nbre_non_vus['nbre'] . ')'; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=bureaumanager&amp;page=histoire" style="text-decoration: none;"><?php echo HISTOCLUB; ?></a></div>
	  </div>
	  <!-- / LEFT CONTEXT SENSITIVE MENU -->
	 </div>
	</td>
	<td id="rightblock" valign="top" width="78%">
	 <div>
	 <!-- RIGHT CONTENT BLOCK -->
	  <?php include($array_pages[$page]); ?>
	 <!-- / RIGHT CONTENT BLOCK -->
	 </div>
	</td>
   </tr>
  </tbody>
 </table>
<?php
}
?>