<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

function colorshirt($color)
{
	switch($color)
	{
		case 0: return '<img src="images/palette/blanc.gif" alt="" width="20" height="20" />'; break;
		case 1: return '<img src="images/palette/bleu.gif" alt="" width="20" height="20" />'; break;
		case 2: return '<img src="images/palette/rouge.gif" alt="" width="20" height="20" />'; break;
		case 3: return '<img src="images/palette/vert.gif" alt="" width="20" height="20" />'; break;
		case 4: return '<img src="images/palette/jaune.gif" alt="" width="20" height="20" />'; break;
		case 5: return '<img src="images/palette/noir.gif" alt="" width="20" height="20" />'; break;
		case 6: return '<img src="images/palette/orange.gif" alt="" width="20" height="20" />'; break;
		case 7: return '<img src="images/palette/violet.gif" alt="" width="20" height="20" />'; break;
		
		default : return ''; break;
	}
}

//changement de maillot
if (isset($FORM['equip_colorprim'])) $equip_colorprim = $FORM['equip_colorprim'];
if (isset($FORM['equip_colorsecon'])) $equip_colorsecon = $FORM['equip_colorsecon'];
if(isset($FORM['shirt']) && isset($FORM['domext']))
{
	if(!empty($FORM['shirt']))
	{
		if($FORM['domext'] == "domicile")
		{
			$requete = sql::update("UPDATE equipes SET team_shirt_dom = '".$FORM['shirt']."' WHERE team_id = '".$info['team_id']."'");
			$error1 = COMMAILLOTDOMOK;
		}
		
		else
		{
			$requete = sql::update("UPDATE equipes SET team_shirt_ext = '".$FORM['shirt']."' WHERE team_id = '".$info['team_id']."'");
			$error1 = COMMAILLOTEXTOK;
		}
	}
	
	else $error1 = 'Vous n\'avez pas choisi de maillot';
}
?>
<table width="100%" border="0" cellspacing="8" cellpadding="0">
  <tr>
    <td width="50%" valign="top">
      <div class="tableborder">
	  <div class="tableheaderalt"><?php echo PREMCOLOR . ' : '; ?></div>
	  <table width="100% border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="homepage_sub_row">
		  <br /><br />
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=0#view"><img src="images/palette/blanc.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=1#view"><img src="images/palette/bleu.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=2#view"><img src="images/palette/rouge.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=3#view"><img src="images/palette/vert.gif" alt="" width="20" height="20" border="0" /></a>
		  <br />
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=4#view"><img src="images/palette/jaune.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=5#view"><img src="images/palette/noir.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=6#view"><img src="images/palette/orange.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=7#view"><img src="images/palette/violet.gif" alt="" width="20" height="20" border="0" /></a>
		  <br /><br />
		  <?php if(isset($FORM['equip_colorprim'])) { echo CHOICECOLOR . ' : ' . colorshirt($equip_colorprim); } ?>
		  <br />
		  </td>
        </tr>
      </table> 
	  </div>
    </td>
    <td width="50%" valign="top">
      <div class="tableborder">
	  <div class="tableheaderalt"><?php echo SECCOLOR . ' : '; ?></div>
	  <table width="100% border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="homepage_sub_row">
		  <?php if(isset($FORM['equip_colorprim'])) { ?>
		  <br /><br />
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=<?php echo $equip_colorprim; ?>&amp;equip_colorsecon=0#view"><img src="images/palette/blanc.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=<?php echo $equip_colorprim; ?>&amp;equip_colorsecon=1#view"><img src="images/palette/bleu.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=<?php echo $equip_colorprim; ?>&amp;equip_colorsecon=2#view"><img src="images/palette/rouge.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=<?php echo $equip_colorprim; ?>&amp;equip_colorsecon=3#view"><img src="images/palette/vert.gif" alt="" width="20" height="20" border="0" /></a>
		  <br />
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=<?php echo $equip_colorprim; ?>&amp;equip_colorsecon=4#view"><img src="images/palette/jaune.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=<?php echo $equip_colorprim; ?>&amp;equip_colorsecon=5#view"><img src="images/palette/noir.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=<?php echo $equip_colorprim; ?>&amp;equip_colorsecon=6#view"><img src="images/palette/orange.gif" alt="" width="20" height="20" border="0" /></a>
		  <a href="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=<?php echo $equip_colorprim; ?>&amp;equip_colorsecon=7#view"><img src="images/palette/violet.gif" alt="" width="20" height="20" border="0" /></a>
		  <br /><br />
		  <?php } if(isset($FORM['equip_colorsecon'])) { echo CHOICECOLOR . ' : ' . colorshirt($equip_colorsecon); } ?>
		  <br />
		  </td>
        </tr>
      </table>
	  </div>
    </td>
  </tr>
  <tr>
    <td valign="top" colspan="2">
      <div class="tableborder">
	  <div class="tableheaderalt"></div>
	  <table width="100% border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="homepage_sub_row">
		  <?php if (isset($FORM['equip_colorsecon'])) { ?>
		  <form action="club.php?zone=bureaumanager&amp;page=equipement&amp;equip_colorprim=<?php echo $equip_colorprim; ?>&amp;equip_colorsecon=<?php echo $equip_colorsecon; ?>#view" method="post">
		  <input type="hidden" name="equip_colorprim" value="<?php echo $equip_colorprim; ?>" />
		  <input type="hidden" name="equip_colorsecon" value="<?php echo $equip_colorsecon; ?>" />
		  <div align="center">
		  <label for="domext"><?php echo SHCHOICE; ?></label>
		  <select name="domext" id="domext">
		   <option value="domicile"><?php echo SHDOM; ?></option>
		   <option value="exterieur"><?php echo SHEXT; ?></option>
		  </select>
		  <input name="choixok" type="submit" value="<?php echo VALIDCHOICE; ?>" />
		  </div>
		  <br />
		  <?php
		  if(isset($error1)) echo $error1;
		  
		  $shirt = 1;
		  //Blanc
		  if($equip_colorprim == 0 && $equip_colorsecon == 0) { $shirt_max = 9; $colo = '00'; }
		  if($equip_colorprim == 0 && $equip_colorsecon == 1) { $shirt_max = 10; $colo = '01'; }
		  if($equip_colorprim == 0 && $equip_colorsecon == 2) { $shirt_max = 11; $colo = '02'; }
		  if($equip_colorprim == 0 && $equip_colorsecon == 3) { $shirt_max = 2; $colo = '03'; }
		  if($equip_colorprim == 0 && $equip_colorsecon == 4) { $shirt_max = 0; $colo = '04'; }
		  if($equip_colorprim == 0 && $equip_colorsecon == 5) { $shirt_max = 17; $colo = '05'; }
		  if($equip_colorprim == 0 && $equip_colorsecon == 6) { $shirt_max = 0; $colo = '06'; }
		  if($equip_colorprim == 0 && $equip_colorsecon == 7) { $shirt_max = 0; $colo = '07'; }
		  //Bleu
		  if($equip_colorprim == 1 && $equip_colorsecon == 0) { $shirt_max = 16; $colo = '10'; }
		  if($equip_colorprim == 1 && $equip_colorsecon == 1) { $shirt_max = 14; $colo = '11'; }
		  if($equip_colorprim == 1 && $equip_colorsecon == 2) { $shirt_max = 8; $colo = '12'; }
		  if($equip_colorprim == 1 && $equip_colorsecon == 3) { $shirt_max = 0; $colo = '13'; }
		  if($equip_colorprim == 1 && $equip_colorsecon == 4) { $shirt_max = 0; $colo = '14'; }
		  if($equip_colorprim == 1 && $equip_colorsecon == 5) { $shirt_max = 16; $colo = '15'; }
		  if($equip_colorprim == 1 && $equip_colorsecon == 6) { $shirt_max = 0; $colo = '16'; }
		  if($equip_colorprim == 1 && $equip_colorsecon == 7) { $shirt_max = 0; $colo = '17'; }
		  //Rouge
		  if($equip_colorprim == 2 && $equip_colorsecon == 0) { $shirt_max = 17; $colo = '20'; }
		  if($equip_colorprim == 2 && $equip_colorsecon == 1) { $shirt_max = 6; $colo = '21'; }
		  if($equip_colorprim == 2 && $equip_colorsecon == 2) { $shirt_max = 13; $colo = '22'; }
		  if($equip_colorprim == 2 && $equip_colorsecon == 3) { $shirt_max = 0; $colo = '23'; }
		  if($equip_colorprim == 2 && $equip_colorsecon == 4) { $shirt_max = 0; $colo = '24'; }
		  if($equip_colorprim == 2 && $equip_colorsecon == 5) { $shirt_max = 17; $colo = '25'; }
		  if($equip_colorprim == 2 && $equip_colorsecon == 6) { $shirt_max = 0; $colo = '26'; }
		  if($equip_colorprim == 2 && $equip_colorsecon == 7) { $shirt_max = 0; $colo = '27'; }
		  //Vert
		  if($equip_colorprim == 3 && $equip_colorsecon == 0) { $shirt_max = 15; $colo = '30'; }
		  if($equip_colorprim == 3 && $equip_colorsecon == 1) { $shirt_max = 7; $colo = '31'; }
		  if($equip_colorprim == 3 && $equip_colorsecon == 2) { $shirt_max = 9; $colo = '32'; }
		  if($equip_colorprim == 3 && $equip_colorsecon == 3) { $shirt_max = 9; $colo = '33'; }
		  if($equip_colorprim == 3 && $equip_colorsecon == 4) { $shirt_max = 0; $colo = '34'; }
		  if($equip_colorprim == 3 && $equip_colorsecon == 5) { $shirt_max = 16; $colo = '35'; }
		  if($equip_colorprim == 3 && $equip_colorsecon == 6) { $shirt_max = 0; $colo = '36'; }
		  if($equip_colorprim == 3 && $equip_colorsecon == 7) { $shirt_max = 0; $colo = '37'; }
		  //Jaune
		  if($equip_colorprim == 4 && $equip_colorsecon == 0) { $shirt_max = 0; $colo = '40'; }
		  if($equip_colorprim == 4 && $equip_colorsecon == 1) { $shirt_max = 0; $colo = '41'; }
		  if($equip_colorprim == 4 && $equip_colorsecon == 2) { $shirt_max = 0; $colo = '42'; }
		  if($equip_colorprim == 4 && $equip_colorsecon == 3) { $shirt_max = 0; $colo = '43'; }
		  if($equip_colorprim == 4 && $equip_colorsecon == 4) { $shirt_max = 0; $colo = '44'; }
		  if($equip_colorprim == 4 && $equip_colorsecon == 5) { $shirt_max = 0; $colo = '45'; }
		  if($equip_colorprim == 4 && $equip_colorsecon == 6) { $shirt_max = 0; $colo = '46'; }
		  if($equip_colorprim == 4 && $equip_colorsecon == 7) { $shirt_max = 0; $colo = '47'; }
		  //Noir
		  if($equip_colorprim == 5 && $equip_colorsecon == 0) { $shirt_max = 16; $colo = '50'; }
		  if($equip_colorprim == 5 && $equip_colorsecon == 1) { $shirt_max = 8; $colo = '51'; }
		  if($equip_colorprim == 5 && $equip_colorsecon == 2) { $shirt_max = 10; $colo = '52'; }
		  if($equip_colorprim == 5 && $equip_colorsecon == 3) { $shirt_max = 0; $colo = '53'; }
		  if($equip_colorprim == 5 && $equip_colorsecon == 4) { $shirt_max = 0; $colo = '54'; }
		  if($equip_colorprim == 5 && $equip_colorsecon == 5) { $shirt_max = 6; $colo = '55'; }
		  if($equip_colorprim == 5 && $equip_colorsecon == 6) { $shirt_max = 0; $colo = '56'; }
		  if($equip_colorprim == 5 && $equip_colorsecon == 7) { $shirt_max = 0; $colo = '57'; }
		  //Orange
		  if($equip_colorprim == 6 && $equip_colorsecon == 0) { $shirt_max = 0; $colo = '60'; }
		  if($equip_colorprim == 6 && $equip_colorsecon == 1) { $shirt_max = 0; $colo = '61'; }
		  if($equip_colorprim == 6 && $equip_colorsecon == 2) { $shirt_max = 0; $colo = '62'; }
		  if($equip_colorprim == 6 && $equip_colorsecon == 3) { $shirt_max = 0; $colo = '63'; }
		  if($equip_colorprim == 6 && $equip_colorsecon == 4) { $shirt_max = 0; $colo = '64'; }
		  if($equip_colorprim == 6 && $equip_colorsecon == 5) { $shirt_max = 0; $colo = '65'; }
		  if($equip_colorprim == 6 && $equip_colorsecon == 6) { $shirt_max = 0; $colo = '66'; }
		  if($equip_colorprim == 6 && $equip_colorsecon == 7) { $shirt_max = 0; $colo = '67'; }
		  //Violet
		  if($equip_colorprim == 7 && $equip_colorsecon == 0) { $shirt_max = 0; $colo = '70'; }
		  if($equip_colorprim == 7 && $equip_colorsecon == 1) { $shirt_max = 0; $colo = '71'; }
		  if($equip_colorprim == 7 && $equip_colorsecon == 2) { $shirt_max = 0; $colo = '72'; }
		  if($equip_colorprim == 7 && $equip_colorsecon == 3) { $shirt_max = 0; $colo = '73'; }
		  if($equip_colorprim == 7 && $equip_colorsecon == 4) { $shirt_max = 0; $colo = '74'; }
		  if($equip_colorprim == 7 && $equip_colorsecon == 5) { $shirt_max = 0; $colo = '75'; }
		  if($equip_colorprim == 7 && $equip_colorsecon == 6) { $shirt_max = 0; $colo = '76'; }
		  if($equip_colorprim == 7 && $equip_colorsecon == 7) { $shirt_max = 0; $colo = '77'; }
		  
		  while ($shirt_max >= $shirt)
		  {
			  echo '
			  <div class="shirt">
			  <input type="radio" name="shirt" value="' . $colo . '_cl' . $shirt . '.png" id="shirt_dom_0" />
			  <br />
			  <img src="images/shirt/' . $colo . '_cl' . $shirt . '.png" alt="" />
			  </div>';
			  $shirt++;
		  }
		} ?>
		  </form>
		  </td>
        </tr>
      </table> 
	  </div>
    </td>
</table>