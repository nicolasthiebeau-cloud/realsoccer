<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/09/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//Fonction du stade
include('sources/class_page/class_stade.php');
$stade = new stade;

?>
<div style="border-bottom: 1px solid rgb(237, 237, 237); font-size: 25px; padding-left: 7px; letter-spacing: -2px;">
  <div align="center">
    <?php echo $stade->affiche_nom_stade($info['stade_name']); ?>
  </div>
</div>
<br />
 <div id="fulstade">
<?php echo $stade->stade_viewer_public($info['stade_infra'], $info['team_id']); ?>
</div>
<br />
<table width="100%" border="0" cellspacing="8" cellpadding="0">
  <tr>
    <td width="50%" valign="top">
  <div class="tableborder">
  <div class="tableheaderalt"><?php echo LEGEND; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	  <td class="homepage_sub_header" align="center">
	    <img src="images/stade/travaux.gif" border="0" /> <?php echo LEG_CONST; ?>.<br />
	  </td>
	</tr>
     </tbody>
  </table>
 </div>
	</td>
    <td width="50%" valign="top">
  <div class="tableborder">
  <div class="tableheaderalt">&nbsp;</div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	  <td class="homepage_sub_header" align="center"><br /><br />
	  </td>
	</tr>
     </tbody>
  </table>
 </div>
	</td>
  </tr>
</table>