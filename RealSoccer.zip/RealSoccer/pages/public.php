<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
01/09/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['id']) && $FORM['id'] != $info['team_id'])
{
	if($FORM['page'] == 'joueur')
	{
		$data = sql::fetch("SELECT team_id FROM joueurs WHERE player_id= '".$FORM['id']."'");
		
		$info2 = $club->info_publicjunction($data['team_id']);
		$classement = $club->position_classement($info2['team_id'], $info2['compet_id']);
	}
	
	else
	{
		$info2 = $club->info_publicjunction($FORM['id']);
		$classement = $club->position_classement($info2['team_id'], $info2['compet_id']);
	}

	$page = (!empty($FORM['page'])) ? htmlentities($FORM['page']) : 'teaminfo';
	$array_pages = array(
		//Base
		'teaminfo' => 'pages/public_teaminfo.php', 
		'effectif' => 'pages/public_effectif.php', 
		'joueur' => 'pages/public_joueur.php', 
		'calendrier' => 'pages/public_calendrier.php', 
		'stade' => 'pages/public_stade.php', 
		'' => ''
						);
		
	if(!array_key_exists($page, $array_pages)) include('pages/erreur.php');

	elseif(!is_file($array_pages[$page])) include('pages/erreur.php');

	else
	{
?>
<a name="view"></a>
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
  <tbody>
   <tr>
    <td id="leftblock" valign="top" width="22%">
	 <div>
	  <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo'Information public'; ?></div>
	   <div class="menulinkwrap">
	   <div align="center">
	  <?php 
	  if($info2['fanion'] != NULL AND $info2['fanion_valid'] == 1)
	  {
		echo'<img src="upload/fanion/'.$info2['fanion'].'" width="150" height="150" style="vertical-align: middle;">';
	  }
	  
	   else { echo'<img src="images/icone/nologo.png" style="vertical-align: middle;">'; } ?>
	   </div>
	  </div>
	   </div>
	  </div>
	  <br />
	 <!-- LEFT CONTEXT SENSITIVE MENU -->
	  <div class="menuouterwrap">
	  <div class="menucatwrap"><img src="images/admin/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo $info2['team_name']; ?></div>
	   <div class="menulinkwrap">&nbsp;&nbsp;|- <a href="club.php?zone=public&amp;page=teaminfo&amp;id=<?php echo $info2['team_id']; ?>" style="text-decoration: none;"><?php echo 'L\'�quipe'; ?></a></div>
	   <div class="menulinkwrap">&nbsp;&nbsp;|- <a href="club.php?zone=public&amp;page=effectif&amp;id=<?php echo $info2['team_id']; ?>" style="text-decoration: none;"><?php echo EFFECTIF; ?></a></div>
	   <div class="menulinkwrap">&nbsp;&nbsp;|- <a href="club.php?zone=public&amp;page=calendrier&amp;id=<?php echo $info2['team_id']; ?>" style="text-decoration: none;"><?php echo CALEND; ?></a></div>
	   <div class="menulinkwrap">&nbsp;<a href="club.php?zone=public&amp;page=stade&amp;id=<?php echo $info2['team_id']; ?>" style="text-decoration: none;"><?php echo STADE; ?></a></div>
	  </div>
	  <br />
	  <!-- / LEFT CONTEXT SENSITIVE MENU -->
	  <?php if($FORM['page'] == 'joueur') include("pages/joueur_menu.php"); ?>
	 </div>
	</td>
	<td id="rightblock" valign="top" width="78%">
	 <div>
	 <!-- RIGHT CONTENT BLOCK -->
	  <?php include($array_pages[$page]); ?>
	 <!-- / RIGHT CONTENT BLOCK -->
	 </div>
	</td>
   </tr>
  </tbody>
 </table>
<?php
	}
}

elseif($FORM['id'] == $info['team_id']) echo "<meta http-equiv=\"refresh\" content=\"0;url=club.php\">";
else echo'Equipe Fictive';
?>