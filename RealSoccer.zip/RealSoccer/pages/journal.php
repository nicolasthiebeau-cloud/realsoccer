<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
05/09/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if(isset($FORM['newmessage']))
{
	$titre = htmlentities(addslashes($FORM['titre']));
	$message = htmlentities(addslashes($FORM['message']));
	
	if(isset($titre) && isset($message))
	{
		$requete = sql::insert("INSERT INTO journal(pays, region, titre, corp, auteur, creanews) 
								VALUES ({$FORM['pays']}, {$FORM['region']}, '{$titre}', '{$message}', {$_SESSION['id']}, '".time()."')");
		$error = 'Votre article a �t� poster';
	}
	
	else $error = 'Il manque le titre ou le message de votre article';
}

if(isset($FORM['pays']))
{
	if(isset($FORM['region'])) $regionadd = 'AND region= ' . $FORM['region'];
	
	$pays = $FORM['pays']; $region = $FORM['region'];
	
	$req2 = sql::query("SELECT * 
						FROM journal 
						LEFT JOIN comptes ON comptes.account_id = journal.auteur 
						WHERE pays= {$pays} {$regionadd} 
						ORDER BY creanews");
}

else
{
	$pays = $info['team_country']; $region = $info['team_region'];
	
	$req2 = sql::query("SELECT * 
						FROM journal 
						LEFT JOIN comptes ON comptes.account_id = journal.auteur 
						WHERE pays= {$pays} AND region= {$region} 
						ORDER BY creanews");
}

echo '<div align="right"><b><h2>Le journal</h2></b></div>&nbsp;&nbsp;&nbsp;';

if(isset($error)) echo $error . '<br /><br />';

echo'<form action="" name="choixpays" method="post">';
echo'<select name="pays" onChange="submit();">';

$req = sql::query("SELECT pays_id, pays_name 
					FROM pays 
					WHERE pays_actif= 1 
					ORDER BY pays_name");

while ($donnees = mysql_fetch_assoc($req))
{
	echo'<option value="' . $donnees['pays_id'] . '"';
	if($pays == $donnees['pays_id']) echo' selected="selected"';
	echo'>' . $donnees['pays_name'] . '</option>';
}

echo'</select>&nbsp;&nbsp;&nbsp;';

echo'<select name="region" onChange="submit();">';

$req = sql::query("SELECT region_id, region_name 
					FROM region 
					WHERE pays_id= {$pays} 
					ORDER BY region_name");

while ($donnees = mysql_fetch_assoc($req))
{
	echo'<option value="' . $donnees['region_id'] . '"';
	if($region == $donnees['region_id']) echo' selected="selected"';
	echo'>' . $donnees['region_name'] . '</option>';
}

echo'</select></form><br /><br />';

if (mysql_num_rows($req2) < 1)
{
	echo'Pas de nouvelle';
}

while ($donnees = mysql_fetch_assoc($req2))
{
?>
<div class="menuouterwhite">
<div class="menucatwrap"> <?php echo $donnees['titre']; ?></div>
<div class="menulinkwrap"><?php echo nl2br($donnees['corp']); ?></div>
<div class="menulinkwrap"><div align="right"><?php echo POSTLE . ' ' .  date($info['dateformat_choice'], $donnees['creanews']) . ' ' . BY . ' ' . $donnees['pseudo']; ?></div></div>
</div>
<br />
<?php
}
?>
<br />
<hr>
<br />
<form action="" name="newmessage" method="post">
<input name="pays" value="<?php echo $pays; ?>" type="hidden" />
<input name="region" value="<?php echo $region; ?>" type="hidden" />
<input type="text" size="60" name="titre" />
<br /><br />
<textarea name="message" rows="10" cols="60"></textarea>
<br />
<input type="submit" name="newmessage" value="Poster un article" />
</form>
   </tbody>
  </table>
 </div>