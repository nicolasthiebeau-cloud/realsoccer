<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
01/09/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if(isset($FORM['orgamatch']))
{
	if($FORM['datematch'] != NULL && $FORM['timematch'] != NULL)
	{
		$date = explode('-', $FORM['datematch']);
		$heure = explode(':', $FORM['timematch']);
		$timestamp_ok = mktime($heure[0], $heure[1], 0, $date[1], $date[2], $date[0]);
		
		if($FORM['choixdomext'] == 'domicile')
		{
			$requete = sql::insert("INSERT INTO matchs_amical_demande 
									VALUES ('', '".$timestamp_ok."', '".$info['team_id']."', '".$FORM['team_id']."', '".$info['team_id']."', '".$FORM['team_id']."', '', '1')");
		}
		
		else
		{
			$requete = sql::insert("INSERT INTO matchs_amical_demande 
									VALUES ('', '".$timestamp_ok."', '".$FORM['team_id']."', '".$info['team_id']."','".$info['team_id']."', '".$FORM['team_id']."', '', '1')");
		}
	}
}

if($info2['fictive'] == 0)
{
?>
 <table id="tablewrap" width="100%" cellpadding="0" cellspacing="8">
   <tbody>
    <tr>
	 <td id="rightblock" valign="top" width="100%">
	   <table width="100%" border="0" cellpadding="0" cellspacing="4">
	    <tbody>
		 <tr>
		  <td valign="top" width="50%">
		   <table width="100%" border="0" cellpadding="0" cellspacing="0">
		    <tbody>
			 <tr>
			  <td>
			    <?php include("box/public_orga_match.php"); ?>
		      </td>
			 </tr>
			 <tr>
		       <td>&nbsp;</td>
		     </tr>
			 <tr>
			  <td>
			    <?php include("box/public_info_manager.php"); ?>
		      </td>
			 </tr>
		    </tbody>
	       </table>
	      </td>
	      <td valign="top" width="50%">
		   <table width="100%" border="0" cellpadding="0" cellspacing="0">
		    <tbody>
			 <tr>
			   <td>
				<?php include("box/public_info_equipe.php"); ?>
			   </td>
		   </tr>
		   <tr>
		     <td>&nbsp;</td>
		   </tr>
		   <tr>
		     <td>
				<?php include("box/public_equipement.php"); ?>
			  </td>
			</tr>
		   <tr>
		     <td>&nbsp;</td>
		   </tr>
		   <tr>
			   <td>
			    <?php include("box/public_galerie_trophee.php"); ?>
			   </td>
			  </tr>
		 </tbody>
	   </table>
	  </td>
	 </tr>
    </tbody>
   </table>
  </td>
 </tr>
</tbody>
</table>
<?php
}

else echo FICTIEQ;
?>