<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
15/05/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

if (isset($FORM['pseudo']) 
&& isset($FORM['mdp']) 
&& isset($FORM['mdp2']) 
&& isset($FORM['email']) 
&& isset($FORM['managername']) 
&& isset($FORM['teamname']) 
&& isset($FORM['countryplay']) 
&& isset($FORM['regionplay']) 
&& isset($FORM['conditions']))
{
	$pseudo = htmlentities(addslashes($FORM['pseudo']));
	$mdp = htmlentities(addslashes($FORM['mdp']));
	$mdp2 = htmlentities(addslashes($FORM['mdp2']));
	$email = htmlentities(addslashes($FORM['email']));
	$managername = htmlentities(addslashes($FORM['managername']));
	$lang = htmlentities(addslashes($FORM['lang']));
	$otherlang = htmlentities(addslashes($FORM['otherlang']));
	$teamname = htmlentities(addslashes($FORM['teamname']));
	$pays_id = htmlentities(addslashes($FORM['countryplay']));
	$regionplay = htmlentities(addslashes($FORM['regionplay']));
	$conditions = htmlentities(addslashes($FORM['conditions']));
	
	$joindate = time(); $joinip = $_SERVER['REMOTE_ADDR']; $error = 0;
	
	if (!preg_match('/^[A-Za-z0-9-_]{3,25}$/', $pseudo)) //Si v�rification du pseudo non conforme
	{ $error++; $error1 = ERROR_PSEUDO_NCONF; }
	$verifpseudo = $index->verif_pseudo_exist($pseudo);
	if ($verifpseudo == $pseudo) //Si le pseudo existe d�j�
	{ $error++; $error1 = ERROR_PSEUDO_EXIST; }
	if (!preg_match('/^[A-Za-z0-9]{6,20}$/', $mdp)) //Si v�rification du mot de passe non conforme
	{ $error++; $error2 = ERROR_MDP_NCONF; }
	if ($mdp != $mdp2) // Si mot de passe n'est pas �gal au mot de passe de confirmation
	{ $error++; $error3 = ERROR_MDP_NIDENT; }
	if (!preg_match('#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#', $email)) //Si v�rification de l'email non conforme  
	{ $error++; $error4 = ERROR_MAIL_NCONF; }
	$verifemail = $index->verif_email_exist($email);
	if ($verifemail == $email) //Si l'email existe d�j�
	{ $error++; $error4 = ERROR_MAIL_EXIST; }
	if  (!preg_match('/^[A-Za-z0-9- ]{3,25}$/', $managername)) //Si v�rification du nom de l'entraineur non conforme
	{ $error++; $error5 = ERROR_MANAG_NCONF; }
	if (!preg_match('/^[A-Za-z0-9- ]{3,35}$/', $teamname)) //Si v�rification de l'�quipe non conforme
	{ $error++; $error6 = ERROR_TEAM_NCONF; }
	$verifteam = $index->verif_team_exist($teamname);
	if ($verifteam == $teamname) //Si le nom de l'�quipe existe d�j�
	{ $error++; $error6 = ERROR_TEAM_EXIST; }
	if (!isset($FORM['countryplay']) && $countryplay == "0" OR $regionplay == "0") //Si aucun pays ou r�gion � �t� choisi
	{ $error++; $error7 = ERROR_NO_COUNTRY; }
	if ($conditions == null) // Si la variable conditions n'est pas null (non coch�)
	{ $error++; $error8 = ERROR_REGLEM; }
	
	if($lang == 'Francais') $canalchoice = 1;
	elseif($lang == 'English') $canalchoice = 3;
	else $canalchoice = 2;

	if ($error == 0)
	{	//Cr�ation du compte
		$requete = sql::insert("INSERT INTO comptes(pseudo, mdp, email, lang, lang_other, rang, coach_name, joindate, joinip, lastlogin, lastip, canal_choice) 
								VALUES ('".$pseudo."', '".md5($mdp)."', '".$email."', '".$lang."', '".$otherlang."', '1', '".$managername."', '".$joindate."', '".$joinip."', '".$joindate."', '".$joinip."', '".$canalchoice."')");
		
		$account_id = mysql_insert_id();
		$compet_id = $index->last_competition($pays_id);
		
		if($compet_id == NULL)
		{
			$index->crea_competition($pays_id, NULL, $CONF); //Cr�ation d'un nouveau championnat, �quipes et joueurs fictifs selon le pays
			$compet_id = $index->last_competition($pays_id); //On recup un nouveau compet_id
		}
		
		$index->maj_competition($compet_id);
		//on recup une �quipe fictive quelquonque et son team_id.
		$team_id = $index->ramdom_equipe_fictive($compet_id);
		//on update les infos de cette equipe fictive par celle du joueur.
		$stadium = STADE . ' ' . $teamname;
		$requete = sql::update("UPDATE equipes
								SET account_id = '".$account_id."', 
									compet_id = '".$compet_id."', 
									team_name = '".$teamname."', 
									team_country = '".$pays_id."', 
									team_region = '".$regionplay."', 
									team_devise = '',
									fanion = '', 
									fanion_valid = '0', 
									team_shirt_dom = '".$CONF['team_shirt_dom']."', 
									team_shirt_ext = '".$CONF['team_shirt_ext']."', 
									team_money = '".$CONF['team_money']."', 
									formationcenter = '".$CONF['formationcenter']."', 
									trainingcenter = '1', 
									training_choice = '', 
									stade_name = '".$stadium."', 
									stade_infra = '".$CONF['stade_infra']."', 
									sponsor_id = '', 
									team_cup = '', 
									team_history = '', 
									fictive = '0' 
								WHERE team_id = '".$team_id."'");
		
		//On previent l'admin d'un nouvel inscrit
		$index->adm_info_newplayer($pays_id, $compet_id, $team_id, $account_id);
		
		$requete = sql::insert("INSERT INTO equipes_mess_interne(team_id, date, mode) 
								VALUES ({$team_id}, '".time()."', 12)");
		
		$data = sql::fetch("SELECT comptes.account_id, pseudo, mdp, rang, team_id, competition.compet_id 
							FROM comptes 
							LEFT JOIN equipes ON comptes.account_id = equipes.account_id 
							LEFT JOIN competition ON equipes.compet_id = competition.compet_id 
							WHERE pseudo = '{$pseudo}'") ;
		
		session_start();
		$_SESSION['id'] = $data['account_id'];
		$_SESSION['pseudo'] = $pseudo;
		$_SESSION['rang'] = $data['rang'];
		$_SESSION['level'] = $data['rang'];
		$_SESSION['team_id'] = $data['team_id'];
		header("location:club.php");
	}
}

if (isset($CONF['stop_inscription']) && $CONF['stop_inscription'] == 0)
{
	echo STOP_INSCRIPT;
}

else
{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo 'RealSoccer - ' . TT_INSCRIP;  ?></title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"> 
<meta http-equiv="Pragma" content="no-cache" />
<meta name="description" content="RealSoccer ! D�couvrez le foot en ligne !">
<meta name="keywords" content="Jeu Foot ! RealSoccer">
<meta name="author" content="Noxo Studio">
<meta name=identifier-url content="http://noxo-studio.fr">
<meta name="revisit-after" content="7 days">
<meta name="category" content="Jeux PHP">
<link rel="shortcut icon" href="smos.ico">
<link href="index.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="index">
  <div class="index_logo"></div>
  <div class="reg_title">
    <div align="center" class="Style2">Inscription</div>
  </div>
  <div class="reg_form">
<div align="center"><span class="Style4"><?php echo INFO_CONNEX; ?></span>
    <br />
</div>
<form id="inscription" name="inscription" method="post" action="index.php?page=newaccount">
  <label for="pseudo"><?php echo PSEUDO2; ?></label>
  <input type="text" name="pseudo" id="pseudo" class="log_champ" value="<?php if (isset($FORM['pseudo'])) echo htmlentities (trim($FORM['pseudo']));?>" /> 
  <?php if (isset($error1)) echo '<font color="#FF0000"><b>'.$error1.'</b></font>'; ?>
  <p>
    <label for="mdp"><?php echo MDP2; ?></label>
    <input type="password" name="mdp" class="log_champ" id="mdp" /> 
	<?php if (isset($error2)) echo '<font color="#FF0000"><b>'.$error2.'</b></font>'; ?>
    <label for="mdp2"><?php echo MDP2BIS; ?></label>
    <input type="password" name="mdp2" class="log_champ" id="mdp2" /> 
	<?php if (isset($error3)) echo '<font color="#FF0000"><b>'.$error3.'</b></font>'; ?>
  </p>
  <p>
    <label for="email"><?php echo EMAIL2; ?></label>
    <input type="text" name="email" class="log_champ" id="email" value="<?php if (isset($FORM['email'])) echo htmlentities (trim($FORM['email']));?>" /> 
	<?php if (isset($error4)) echo '<font color="#FF0000"><b>'.$error4.'</b></font>'; ?>
  </p>
<br />
<div align="center"><span class="Style4"><?php echo INFOMANAGTEAM; ?></span></div>
<br />
  <label for="managername"><?php echo MANAGERNAME; ?></label>
  <input type="text" name="managername" class="log_champ" id="managername" value="<?php if (isset($FORM['managername'])) echo htmlentities (trim($FORM['managername']));?>" /> 
  <?php if (isset($error5)) echo '<font color="#FF0000"><b>'.$error5.'</b></font>'; ?>
<p>
  <label for="lang"><?php echo LANG2; ?></label>
  <select name="lang" id="lang">
    <option selected="selected">Francais</option>
    <option>English</option>
  </select>
  <label for="otherlang"><?php echo LANG2OTHER; ?></label>
  <input type="text" name="otherlang" class="log_champ" id="otherlang" />
</p>
<p>
  <label for="teamname"><?php echo TEAMNAME; ?></label>
  <input type="text" name="teamname" class="log_champ" id="teamname" value="<?php if (isset($FORM['teamname'])) echo htmlentities (trim($FORM['teamname']));?>" /> 
  <?php if (isset($error6)) echo '<font color="#FF0000"><b>'.$error6.'</b></font>'; ?>
</p>
<script language="JavaScript">
    
    function trierMenuregionplay(form,list,typecountryplay) // Cr�ation de la fonction qui va �crire les diff�rentes options dans le second menu d�roulant en fonction du choix effectu�.
    { // Dans cette fonction on rabat le nom du formulaire , le nom du menu "select" et la "value" du choix que l'on a effectu�.
     list.options.length=0;// La remise � 0 des options du menu d�roulant est tr�s importante autrement il "rajoutera" � chaque choix diff�rent de nouvelles options.
     // ici on commence les tests d'�galit� avec la "value" retourn�e qui porte le nom de"typecountryplay".
	 // ce que l'on �crit en premier es le texte que va afficher notre menu d�roulant, le second est la "value" que celui-ci retournera. Et ainsi de suite.
     if (typecountryplay == "1") {
		<?php $req = sql::query("SELECT * FROM region WHERE pays_id='1' ORDER BY region_name") ;
		while ($donnees = mysql_fetch_array($req)) { echo 'choix=new Option("' . $donnees['region_name'] . '","' . $donnees['region_id'] . '"); form.regionplay.options[form.regionplay.options.length]=choix;'; } ?> }
     else if (typecountryplay == "2") {
		<?php $req = sql::query("SELECT * FROM region WHERE pays_id='2' ORDER BY region_name") ;
		while ($donnees = mysql_fetch_array($req)) { echo 'choix=new Option("' . $donnees['region_name'] . '","' . $donnees['region_id'] . '"); form.regionplay.options[form.regionplay.options.length]=choix;'; } ?> }
     else if (typecountryplay == "3") {
		<?php $req = sql::query("SELECT * FROM region WHERE pays_id='3' ORDER BY region_name") ;
		while ($donnees = mysql_fetch_array($req)) { echo 'choix=new Option("' . $donnees['region_name'] . '","' . $donnees['region_id'] . '"); form.regionplay.options[form.regionplay.options.length]=choix;'; } ?> }
     else if (typecountryplay == "4") {
		<?php $req = sql::query("SELECT * FROM region WHERE pays_id='4' ORDER BY region_name") ;
		while ($donnees = mysql_fetch_array($req)) { echo 'choix=new Option("' . $donnees['region_name'] . '","' . $donnees['region_id'] . '"); form.regionplay.options[form.regionplay.options.length]=choix;'; } ?> }
	 else if (typecountryplay == "10") {
		<?php $req = sql::query("SELECT * FROM region WHERE pays_id='10' ORDER BY region_name") ;
		while ($donnees = mysql_fetch_array($req)) { echo 'choix=new Option("' . $donnees['region_name'] . '","' . $donnees['region_id'] . '"); form.regionplay.options[form.regionplay.options.length]=choix;'; } ?> }
	 else if (typecountryplay == "21") {
		<?php $req = sql::query("SELECT * FROM region WHERE pays_id='21' ORDER BY region_name") ;
		while ($donnees = mysql_fetch_array($req)) { echo 'choix=new Option("' . $donnees['region_name'] . '","' . $donnees['region_id'] . '"); form.regionplay.options[form.regionplay.options.length]=choix;'; } ?> }
	 else if (typecountryplay == "10") {
		<?php $req = sql::query("SELECT * FROM region WHERE pays_id='43' ORDER BY region_name") ;
		while ($donnees = mysql_fetch_array($req)) { echo 'choix=new Option("' . $donnees['region_name'] . '","' . $donnees['region_id'] . '"); form.regionplay.options[form.regionplay.options.length]=choix;'; } ?> }
	}
</script>
<p>
   <label for="countryplay"><?php echo PLAY_COUNTRY; ?></label>
       <select name="countryplay" onChange="trierMenuregionplay(this.form,this.form.regionplay,this.value)"><!-- Appel de notre fonction avec toutes les infos (nom de formulaire, nom du second menu d�roulant et la value). -->
     <option value="0"><?php echo SELECT_COUNTRY; ?></option>
<?php
$req = sql::query("SELECT pays_id, pays_name FROM pays WHERE pays_actif='1'") ;
while ($donnees = mysql_fetch_array($req))
{
	echo '<option value="' . $donnees['pays_id'] . '">' . $donnees['pays_name'] . '</option>';
}
?>
     </select>
	 <label for="regionplay"><?php echo REGION; ?></label>
	 <select name="regionplay">
     <option value="0"><?php echo SELECT_REGION; ?></option>
     </select>
	 <?php if (isset($error7)) echo '<font color="#FF0000"><b>'.$error7.'</b></font>'; ?>
</p>
<p><?php echo INFO_REGLEMENT; ?><br />
<input type="checkbox" name="conditions" <?php if(isset($FORM['conditions']) && $FORM['conditions'] != NULL) echo 'checked="checked"'; ?>/><big><?php echo REGLEMENT; ?></big>
<br/><?php if (isset($error8)) echo '<font color="#FF0000"><b>'.$error8.'</b></font>'; ?></p>
<input name="inscription" type="submit" class="log_button" value="<?php echo INSCRIP; ?>" />
</form>
<?php } ?>    
  </div>
</div>