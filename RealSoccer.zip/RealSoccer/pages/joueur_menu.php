<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
29/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//Class et Lang joueur
include('sources/lang_page/' . $info['lang'] . '/lang_joueur.php');
include('sources/class_page/class_joueur.php');
$joueur = new joueur;

if(isset($FORM['id']))
{
	$player_id = $FORM['id']; //Retourne player_id
	
	//Change le statut du joueur
	if(isset($FORM['statut'])) $joueur->changestatut($player_id, $FORM['statut']);
	
	//Cr�ation/modification du surnom
	if(isset($FORM['surname'])) $joueur->changesurnom($player_id, $FORM['surname']); 
	
	//Change la position
	if(isset($FORM['position'])) $joueur->changeposition($player_id, $FORM['position']); 
	
	//Fait une offre au manager ou achat direct
	if (isset($FORM['offerok'])) 
	{
		if(isset($FORM['team_id']) && $FORM['team_id'] == 0)
		{
			$club->joueurachatdirect($FORM['id'], $info['team_id'], $FORM['price'], $FORM['name']);
		}
		
		else
		{
			$requete = sql::insert("INSERT INTO joueurs_achat_demande(player_id, team_dmd, new_price, team_accept) 
									VALUES ('".$player_id."', '".$info['team_id']."', '".$FORM['price']."', '".$FORM['team_id']."')");
		}
	}
	
	//Ajout d'une photo au joueur
	if(isset($FORM['playerphotook'])) 
	{
		$uploaddir = $CONF['upload_dir'] . 'joueur/';
		$uploadfile = $uploaddir . basename($_FILES['playerphoto']['name']);
		
		if($_FILES['playerphoto']['size'] <= 30000)
		{
			if(move_uploaded_file($_FILES['playerphoto']['tmp_name'], $uploadfile))
			{
				$requete = sql::update("UPDATE joueurs SET photo= '".$_FILES['playerphoto']['name']."', photo_valid=0 WHERE player_id = '".$player_id."'");
				echo "<meta http-equiv=\"refresh\" content=\"0;url=club.php?zone=management&amp;page=effectif\">";
			}
		}
			
		else echo PHOTO_TAILLE . ' : ' . $_FILES['playerphoto']['size'] . 'octets';
	}
	
	//Rharasperation de toutes les infos sur le joueur
	$data = $joueur->rharasp_infojoueur($player_id);
	
	//On verifie si le manager � deja fait une demande
	$exist_offer_player = $joueur->verif_player_offer($player_id, $info['team_id']);
	
	//On verifie la limite de joueur
	$nb_player = $joueur->limit15playermin($data['team_id']); 
}
?>
<div class="menuouterwrap">
<div class="menucatwrap"><img src="images/club/ico_manag.png" style="vertical-align: bottom;" border="0"> <?php echo 'Menu Joueur'; ?></div>
<?php
if($data['team_id'] == $info['team_id'])
{
?>
<div class="menulinkwrap">
<?php echo SURNAME; ?>
<form method="post" action="club.php?zone=management&amp;page=joueur&amp;id=<?php echo $player_id; ?>#view">
<div align="right">
<input type="text" name="surname" id="surname" />
<input type="submit" name="surnameok" id="surnameok" value="<?php echo MAJ; ?>" />
</div>
</form>
</div>
<div class="menulinkwrap">
<?php echo PHOTO_INFO; ?>
<form enctype="multipart/form-data" method="post" action="club.php?zone=management&amp;page=joueur&amp;id=<?php echo $player_id; ?>#view">
<div align="right">
<input type="file" name="playerphoto" id="playerphoto" />
<input type="submit" name="playerphotook" id="playerphotook" value="<?php echo MAJ; ?>" />
</div>
</form>
</div>
<div class="menulinkwrap">
<?php echo CATEG_CHANGE; ?>
<form method="post" action="club.php?zone=management&amp;page=joueur&amp;id=<?php echo $player_id; ?>#view">
<div align="right">
<select name="position" id="position">
<?php
	$req = sql::query("SELECT pos_id, pos_name FROM joueurs_position ORDER BY position");
	while ($donnees = mysql_fetch_assoc($req))
	{
		echo'<option value="' . $donnees['pos_id'] . '" ';
		if($donnees['pos_id'] == $data['position']) echo'selected="selected"';
		echo'>' . $donnees['pos_name'] . '</option>';
	}
?>
</select>
<input type="submit" name="positionok" id="positionok" value="<?php echo MAJ; ?>" />
</div>
</form>
</div>
<div class="menulinkwrap">
<?php
	if($nb_player > 15)
	{
		echo INFO_RESILI;
?>
<form action="club.php?zone=management&amp;page=renvoi" onsubmit='return confirm (&quot;<?php echo RESILI_REPLY . ' ' . $data['prenom'] . ' ' . $data['nom'] . ' ?'; ?>&quot;)' method="post">
<input name="renvoi_player_id" value="<?php echo $player_id; ?>" type="hidden" />
<input name="renvoi_pays_id" value="<?php echo $data['pays_id']; ?>" type="hidden" />
<div align="right">
<input value="<?php echo RESILI_OK; ?>" type="submit" />
</div>
</form>

<?php
	}

	else
	{
		echo RESILI_NO;
	}
}

else
{
	if($data['team_id'] == 0)
	{
		echo OFFERACHAT . '<br />'; 
		
		if(isset($FORM['zone']) && $FORM['zone'] == 'marchetransfert')
		echo'<form method="post" action="club.php?zone=marchetransfert&amp;page=joueur&amp;id='.$player_id.'#view">';
		else
		echo'<form method="post" action="club.php?zone=public&amp;page=joueur&amp;id='.$player_id.'#view">';
?>
<input name="team_id" value="<?php echo $data['team_id']; ?>" type="hidden" />
<input name="player_id" value="<?php echo $data['player_id']; ?>" type="hidden" />
<input name="price" value="0" type="hidden" />
<input name="name" value="<?php echo $data['prenom'] . ' ' . $data['nom']; ?>" type="hidden" />
<input type="submit" name="offerok" id="offerok" value="<?php echo ACHATLIBRE; ?>" />
</form>
<?php
	}
	
	elseif($data['statut'] == 1)
	{
		if($data['age'] >= 17)
		{
			if($nb_player > 15)
			{
				if($exist_offer_player == 0)
				{
?>
<?php 
echo OFFERACHAT; 

if(isset($FORM['zone']) && $FORM['zone'] == 'marchetransfert')
echo'<form method="post" action="club.php?zone=marchetransfert&amp;page=joueur&amp;id='.$player_id.'#view">';
else
echo'<form method="post" action="club.php?zone=public&amp;page=joueur&amp;id='.$player_id.'#view">';
?>
<input name="team_id" value="<?php echo $data['team_id']; ?>" type="hidden" />
<input type="text" name="price" />
<input type="submit" name="offerok" id="offerok" value="<?php echo OFFERACHAT; ?>" />
</form>
<?php
				}
					
				else echo OFFERTWICE;
				
			}
			
			else echo OFFERMINPL;
		}
		
		else echo OFFERYOUNG; 
	}
	
	else echo OFFERNO;
}
?>
</div>
</div>
<br />