<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }
?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo HISTOCLUB; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
<?php
$histo = explode(';', $info['team_history']); $nbr = 0; $color = 1;

while (count($histo) > $nbr)
{
?>

	<tr>
      <td <?php echo $club->colorchoice($color) . '>' . $histo[$nbr]; ?></td>
    </tr>
<?php
	$nbr++;
	if($color == 1) $color++; else $color--;
}
?>
   </tbody>
  </table>
 </div>