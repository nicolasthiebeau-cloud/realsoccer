<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
02/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//syst�me de copie du fanion vers dossier /fanion
if(isset($_FILES['fanion']))
{
	$uploaddir = $CONF['upload_dir'] . 'fanion/';
	$uploadfile = $uploaddir . basename($_FILES['fanion']['name']);

	if($_FILES['fanion']['size'] <= 30000)
	{
		if(move_uploaded_file($_FILES['fanion']['tmp_name'], $uploadfile))
		{
			$requete = sql::update("UPDATE equipes SET fanion = '".$_FILES['fanion']['name']."', fanion_valid=0 WHERE team_id = '".$info['team_id']."'");
			echo "<meta http-equiv=\"refresh\" content=\"0;url=club.php?zone=bureaumanager&amp;page=fanion\">";
		}
	}
		
	else echo'Votre fanion d�passe la taille maximum autoris�, il fait : ' . $_FILES[$fanion]['size'] . 'octects';
}
	?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo 'Personnaliser votre fanion'; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	<tr>
      <td class="homepage_sub_row">
	    <?php echo' La personnalisation du fanion doit �tre valider par un membre du staff pour �tre visible par tous.<br /> 
					Tous fanions � caract�re sexuel, raciste, discriminatoire, ou autres sera rejeter.
					Le fanion ne doit pas d�passer 150px par 150px et �tre au format jpg, png, ou gif'; 
		?>
	  </td>
    </tr>
<?php
if($info['fanion'] != NULL && $info['fanion_valid'] == 0) //Si fanion mais pas valid�
{
?>
     <tr>
      <td class="homepage_sub_row">
		<div align="center">
	    <?php
		echo'<img src="upload/fanion/' . '/' . $info['fanion'] . '" width="150" height="150" /><br />';
		echo'Fanion en cours de validation...';
		?>
		</div>
	  </td>
    </tr>
<?php
}

else //Si fanion et valid� ou pas de fanion
{
	if($info['fanion'] != NULL)
	{
?>
     <tr>
      <td class="homepage_sub_row">
		<div align="center">
	    <?php echo'<img src="upload/fanion/' . '/' . $info['fanion'] . '" width="150" height="150" />'; ?>
		</div>
	  </td>
    </tr>
<?php
	}
?>
	 <tr>
      <td class="homepage_sub_row">
	    <form enctype="multipart/form-data" method="post" action="">
		<div align="center">
		<input type="hidden" name="MAX_FILE_SIZE" value="30000" />
	    <input type="file" name="fanion" id="fanion" />
		</div>
	  </td>
    </tr>
	<tr>
      <td class="homepage_sub_row">
	    <div align="center">
		<input type="submit" name="fanionok" id="fanionok" value="Faire une demande de validation" />
		</div>
		</form>
	  </td>
    </tr>
<?php
}
?>
   </tbody>
  </table>
 </div>