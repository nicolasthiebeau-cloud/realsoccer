<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
01/09/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

//Class Centreformation
include('sources/class_page/class_centreformation.php');
$centreformation = new centreformation;

//Cout d'am�lioration du niveau suivant !
$cout_amelioration = ($info['formationcenter'] * 5000) + 20000;
$temps_construction = 259200;

//Construction du centre 
if(isset($FORM['action']) && $FORM['action'] == 'construction') $error = $centreformation->construction_centre($cout_amelioration, $temps_construction, $info);

//Am�lioration du centre
if(isset($FORM['action']) && $FORM['action'] == 'agrandissement') $error = $centreformation->agrandissement_centre($cout_amelioration, $temps_construction, $info);

//Recrutement d'un jeune
if (isset($FORM['nationalite']) AND isset($FORM['position'])) $error = $centreformation->recrut_jeune($FORM['position'], $FORM['nationalite'], $info, $CONF);

// On cherche le niveau du centre de formation et on affiche
$i = sql::fetch("SELECT * 
				 FROM equipes 
				 WHERE team_id = {$info['team_id']}");
?>
<form action="club.php?zone=management&amp;page=centreformation" method="post">
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td valign="top" width="60%">
<a name="view"></a>
<div class="tableborder">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo NATIO; ?></td>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo INFO; ?></td>
	  <td class="homepage_sub_header" align="center" width="20%"><?php echo IDENTITE; ?></td>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo POSITION; ?></td>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo AGE; ?></td>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo FORME; ?></td>
	  <td class="homepage_sub_header" align="center" width="10%"><?php echo MORAL; ?></td>
	</tr>
<?php
$req = sql::query("SELECT player_id, nom, surnom, prenom, age, forme, moral, 
						  pays_name, pays_flag, 
						  group_id, pos_shortname 
					FROM joueurs 
					LEFT JOIN pays ON pays.pays_id = joueurs.nationalite 
					LEFT JOIN joueurs_position ON joueurs_position.pos_id = joueurs.position
					WHERE team_id= '".$info['team_id']."' 
					AND age <= 16 
					ORDER BY joueurs.position, nom"); 
					
$color = 1;

while ($donnees = mysql_fetch_assoc($req))
{
?>
  <tr>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo '<img src="images/flag' . '/' . $donnees['pays_flag'] . '" width="32" height="20" alt="' . $donnees['pays_name'] . '" />'; ?></td>
    <td <?php echo $club->colorchoice($color); ?> align="center"></td>
	<td <?php echo $club->colorchoice($color); ?>><?php /*echo info_effect($donnees['player_id']);*/ echo ' <a href="club.php?zone=management&amp;page=joueur&amp;id='. $donnees['player_id'] .'"><strong>'. stripslashes($donnees['prenom']) . ' ';
			  if ($donnees['surnom'] != NULL) echo '\' '. stripslashes($donnees['surnom']) . ' \'';
			  echo ' ' . stripslashes($donnees['nom']); ?></strong></a></td>
    <td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $club->smallposition($donnees['group_id'], $donnees['pos_shortname']); ?></td>
    <td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $donnees['age']; ?></td>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $club->notecolor100(round($donnees['forme'])); ?></td>
	<td <?php echo $club->colorchoice($color); ?> align="center"><?php echo $club->notecolor100(round($donnees['moral'])); ?></td>
  </tr>
<?php
	if($color == 1) $color++; else $color--;
}
?>
   </tbody>
  </table>
 </div>
	</td>
    <td valign="top" width="40%">
<div class="tableborder">
<div class="homepage_sub_header"><?php echo FCTITLE; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	   <td class="homepage_sub_row_2">
<?php
$construct = sql::fetch("SELECT COUNT(*) AS exist FROM stamp_construction WHERE id_team = '".$info['team_id']."' AND type = 'centreformation'");

if($i['formationcenter'] == 0 && $construct['exist'] == 0)
{
	echo FCHOWMUCHCONSTRUC1 . ' ' . $cout_amelioration . ' ' . FCHOWMUCHCONSTRUC2 . '.<br /><br />';
	
	if ($cout_amelioration <= $info['team_money'])
    {
		echo '<div align="center"><a href="club.php?zone=management&amp;page=centreformation&amp;action=construction">' . FCCONSTRUCCENTR . '</a></div>';
    }
	
	else $error = FCNOMONEYCONSTR;
	
	if (isset($error)) echo '<br /><font color="#FF0000"><b>'.$error.'</b></font>';
?>
	   </td>
	 </tr>
   </tbody>
  </table>
 </div>
 <br />
 <div class="tableborder">
<div class="homepage_sub_header"><?php echo FCFORMERJEUNE; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	   <td class="homepage_sub_row_2">
	   <?php echo FCINFORECRUT; ?><br /><br />
	   <strong><?php echo FCNOCENTRE; ?></strong>
	 </tr>
   </tbody>
  </table>
 </div>
<?php
}

elseif($i['formationcenter'] == 0 && $construct['exist'] == 1)
{
	echo FCCONSTRUCOK . '.<br />' . FCTRAVTIME . ' :<br /><br />';

	$data2 = sql::fetch("SELECT timestamp_fin FROM stamp_construction WHERE id_team = '".$info['team_id']."' AND type = 'centreformation'");
	
	echo '&nbsp;&nbsp;&nbsp;&nbsp;' . $centreformation->comparetimestamp($data2['timestamp_fin']) . '<br /><br />';
	
	if (isset($error)) echo '<br /><font color="#FF0000"><b>'.$error.'</b></font>';
?>
	   </td>
	 </tr>
   </tbody>
  </table>
 </div>
 <br />
 <div class="tableborder">
<div class="homepage_sub_header"><?php echo FCFORMERJEUNE; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	   <td class="homepage_sub_row_2">
	   <?php echo FCINFORECRUT; ?><br /><br />
	   <strong><?php echo FCNOCENTRE; ?></strong></td>
	 </tr>
   </tbody>
  </table>
 </div>
 <br />
 <?php
 }
 
 elseif($i['formationcenter'] >= 1 && $construct['exist'] == 0)
{
	echo FCHOWMUCHCNTR1 . ' ' . $i["formationcenter"] . "<br />" . FCHOWMUCHCNTR2 . ' ' . $cout_amelioration . FCHOWMUCHCNTR3 . ".<br /><br />";
	
	if ($cout_amelioration <= $info['team_money'])
	{
		echo '<div align="center"><a href="club.php?zone=management&amp;page=centreformation&amp;action=agrandissement">' . FCAGRANDCENTR . '.</a></div>';
	}
	
	else echo FCNOMONEYCENT;
	
	if (isset($error)) echo '<br /><font color="#FF0000"><b>'.$error.'</b></font>';
?>
	   </td>
	 </tr>
   </tbody>
  </table>
 </div>
 <br />
<div class="tableborder">
<div class="homepage_sub_header"><?php echo FCFORMERJEUNE; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	   <td class="homepage_sub_row_2">
	   <?php echo NATIONALITY; ?>
	   </td>
	   <td class="homepage_sub_row_2">
	   <select name='nationalite'>
	   <?php
	   $req = sql::query("SELECT pays_id, pays_name, pays_zone 
						  FROM pays 
						  WHERE pays_select= '1' 
						  ORDER BY pays_zone DESC");
		
	   while ($donnees2 = mysql_fetch_assoc($req))
	   {
		   echo '<option value="' . $donnees2['pays_id'] . '">' . $donnees2['pays_name'] . '</option>';
	   }
	  ?>
	  </select>
	   </td>
	 </tr>
	 <tr>
	   <td class="homepage_sub_row_3">
	   <?php echo POSITION; ?>
	   </td>
	   <td class="homepage_sub_row_3">
	   <select name='position'>
	   <option value='1'><?php echo GARDIEN; ?></option>
	   <option value='2'><?php echo DEFENSEUR; ?></option>
	   <option value='3'><?php echo MILIEU; ?></option>
	   <option value='4'><?php echo ATTAQUANT; ?></option>
	   </select>
	   </td>
	 </tr>
	 <tr>
	   <td class="homepage_sub_row_2" colspan="2">
	   <div align="center"><input type="submit" value="<?php echo FCFORMERJOUEUR; ?>"></div>
	   </td>
	 </tr>
   </tbody>
  </table>
 </div>
 <br />
<?php
}
	
else
{
	echo FCUPGRAOK . "<br />" . FCTRAVTIME . ":<br /><br />";
	
	$data2 = sql::fetch("SELECT timestamp_fin FROM stamp_construction WHERE id_team = '".$info['team_id']."' AND type = 'centreformation'");
	
	echo '&nbsp;&nbsp;&nbsp;&nbsp;' . $centreformation->comparetimestamp($data2['timestamp_fin']) . '<br /><br />';
	
	if (isset($error)) echo '<br /><font color="#FF0000"><b>'.$error.'</b></font>';
?>
	   </td>
	 </tr>
   </tbody>
  </table>
 </div>
 <br />
<div class="tableborder">
<div class="homepage_sub_header"><?php echo FCFORMERJEUNE; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
	 <tr>
	   <td class="homepage_sub_row_2">
	   <?php echo NATIONALITY; ?>
	   </td>
	   <td class="homepage_sub_row_2">
	   <select name='nationalite'>
	   <?php
	   $req4 = sql::query("SELECT pays_id, pays_name, pays_zone FROM pays WHERE pays_select= 1 ORDER BY pays_zone DESC");
	   while ($donnees2 = mysql_fetch_array($req4))
	   {
		   echo '<option value="' . $donnees2['pays_id'] . '">' . $donnees2['pays_name'] . '</option>';
	   }
	  ?>
	  </select>
	   </td>
	 </tr>
	 <tr>
	   <td class="homepage_sub_row_3">
	   <?php echo POSITION; ?>
	   </td>
	   <td class="homepage_sub_row_3">
	   <select name='position'>
	   <option value='1'><?php echo GARDIEN; ?></option>
	   <option value='2'><?php echo DEFENSEUR; ?></option>
	   <option value='3'><?php echo MILIEU; ?></option>
	   <option value='4'><?php echo ATTAQUANT; ?></option>
	   </select>
	   </td>
	 </tr>
	 <tr>
	   <td class="homepage_sub_row_2" colspan="2">
	   <div align="center"><input type="submit" value="<?php echo FCFORMERJOUEUR; ?>"></div>
	   </td>
	 </tr>
   </tbody>
  </table>
 </div>
 <br />
<?php } ?>
	</td>
  </tr>
</table>
</form>