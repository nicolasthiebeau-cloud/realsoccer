<?php
/*
SMOS - Sport Manager Open Source
http://snyzone.fr/smos/

Le projet est open source - sous license GPL
Vous �tes libre de l'utiliser mais pas � des fins commercial

Cod� par Ysn38 - Yannick San Nicolas - ysn38@snyzone.fr
30/08/09	Cr�ation
*/

if (!defined('SMOSPHP')) { die("This file cannot be accessed directly."); }

$req = sql::query("SELECT matchs.renco_id, matchs.compet_id, matchs.cup_id, matchs.timematch, 
						  matchs.journee, matchs.score1, matchs.score2, matchs.renco_type, 
						  equipe1.team_id AS team_id1, equipe1.team_name AS team_name1, 
						  pays1.pays_flag AS pays1_flag, 
						  equipe2.team_id AS team_id2, equipe2.team_name AS team_name2, 
						  pays2.pays_flag AS pays2_flag, 
						  compet_name 
				   FROM matchs 
				   LEFT JOIN equipes AS equipe1 ON equipe1.team_id = matchs.team_id1 
				   LEFT JOIN pays AS pays1 ON pays1.pays_id = equipe1.team_country 
				   LEFT JOIN equipes AS equipe2 ON equipe2.team_id = matchs.team_id2 
				   LEFT JOIN pays AS pays2 ON pays2.pays_id = equipe2.team_country 
				   LEFT JOIN competition ON competition.compet_id = matchs.compet_id  
				   WHERE team_id1 = {$info['team_id']} OR team_id2 = {$info['team_id']} ORDER BY timematch");

$color = 1;
?>
<div class="tableborder">
 <div class="tableheaderalt"><?php echo CALENDMATCH; ?></div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tbody>
<?php
while ($donnees = mysql_fetch_assoc($req))
{
?>
	<tr>
    <td <?php echo $club->colorchoice($color); ?> align="left" width="20%"><?php echo LE . date($info['dateformat_choice'], $donnees['timematch']) . A . date($info['timeformat_choice'], $donnees['timematch']); ?></td>
	<td <?php echo $club->colorchoice($color); ?> align="right" width="25%">
	<a href="club.php?zone=public&amp;page=teaminfo&amp;id=<?php echo $donnees['team_id1'] . '"><strong>' . $donnees['team_name1']; ?></strong></a>
	<?php echo'&nbsp;<img src="images/flag' . '/' . $donnees['pays1_flag'] . '" width="25" height="15" style="vertical-align: middle;" />'; ?>
	</td>
	<td <?php echo $club->colorchoice($color); ?> align="center" width="10%"><a href="club.php?zone=match&amp;id=<?php echo $donnees['renco_id']; ?>"><?php echo $donnees['score1']; ?> - <?php echo $donnees['score2']; ?></a></td>
	<td <?php echo $club->colorchoice($color); ?> align="left" width="25%">
	<?php echo'<img src="images/flag' . '/' . $donnees['pays2_flag'] . '" width="25" height="15" style="vertical-align: middle;" />&nbsp;'; ?>
	<a href="club.php?zone=public&amp;page=teaminfo&amp;id=<?php echo $donnees['team_id2'] . '"><strong>' . $donnees['team_name2']; ?></strong></a>
	</td>
	<td <?php echo $club->colorchoice($color); ?> align="right" width="20%">
	<?php
		if($donnees['renco_type'] == 1) echo $donnees['compet_name'] . ' (' . DAYMATCH . ' : ' . $donnees['journee'] . ')';
	elseif($donnees['renco_type'] == 2) echo AMICAL;
	//elseif($donnees['renco_type'] == 3) echo teamid_to_teamname($donnees['compet_id']);
	?>
	</td>
  </tr>
<?php
	if($color == 1) $color++; else $color--;
}
?>
   </tbody>
  </table>
 </div>